"""OBO wiring: the SQL warehouse connection must authenticate AS the signed-in
user (their forwarded token), and one user's cached source/connection must never
be reused for another. These pin the token selection, the per-identity cache key,
and the isolation property that makes true OBO safe under concurrent callers.
"""

from __future__ import annotations

import finops.deps as deps
from finops.config import Settings


def test_sql_token_obo_uses_the_forwarded_user_token(monkeypatch, request_headers):
    monkeypatch.setattr(deps, "get_user_token", lambda request: "user-A-token")
    settings = Settings(auth_mode="obo", databricks_token="")
    assert deps._sql_token(settings, request_headers({})) == "user-A-token"


def test_sql_token_dev_pat_takes_precedence(monkeypatch, request_headers):
    # Local dev: an explicit PAT wins even in obo mode.
    monkeypatch.setattr(deps, "get_user_token", lambda request: "ignored")
    settings = Settings(auth_mode="obo", databricks_token="local-pat")
    assert deps._sql_token(settings, request_headers({})) == "local-pat"


def test_sql_token_sp_mode_uses_service_principal(request_headers):
    # sp mode: None -> get_connection authenticates as the app service principal.
    settings = Settings(auth_mode="sp", databricks_token="")
    assert deps._sql_token(settings, request_headers({})) is None


def test_identity_key_is_per_user_in_obo(monkeypatch, request_headers):
    settings = Settings(auth_mode="obo", databricks_token="")
    monkeypatch.setattr(deps, "get_user_token", lambda request: "token-A")
    key_a = deps._identity_key(settings, request_headers({}))
    monkeypatch.setattr(deps, "get_user_token", lambda request: "token-B")
    key_b = deps._identity_key(settings, request_headers({}))
    assert key_a != key_b
    assert key_a.startswith("u:") and key_b.startswith("u:")


def test_identity_key_shared_for_sp(request_headers):
    assert deps._identity_key(Settings(auth_mode="sp"), request_headers({})) == "sp"


def test_cached_source_isolates_users_and_reuses_per_user(monkeypatch, request_headers):
    """Two different OBO callers get DIFFERENT source instances (no token/data
    bleed); the same caller reuses one instance (so its cache survives)."""
    deps._SOURCE_CACHE.clear()
    settings = Settings(auth_mode="obo", databricks_token="")
    built: list[object] = []

    def factory(s, connect):
        obj = object()
        built.append(obj)
        return obj

    monkeypatch.setattr(deps, "get_user_token", lambda request: "token-A")
    a1 = deps._cached_source("spend", settings, request_headers({}), factory)
    a2 = deps._cached_source("spend", settings, request_headers({}), factory)
    monkeypatch.setattr(deps, "get_user_token", lambda request: "token-B")
    b1 = deps._cached_source("spend", settings, request_headers({}), factory)

    assert a1 is a2          # same user -> cached instance reused
    assert a1 is not b1      # different user -> isolated instance
    assert len(built) == 2
