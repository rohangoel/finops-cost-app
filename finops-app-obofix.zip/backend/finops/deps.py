"""FastAPI dependencies — wires config -> identity -> scope -> data source.

The identity provider is a singleton; identity, token, connection and source are
resolved per request so the SQL connection always uses the caller's token (OBO)
or the SP token (prod), and scope is always derived server-side.
"""

from __future__ import annotations

import hashlib
from functools import lru_cache

from fastapi import Depends, Request

from .config import get_settings
from .data import (
    AnomalySource,
    AppsSource,
    FleetSource,
    GenieSource,
    SpendSource,
    make_anomaly_source,
    make_apps_source,
    make_fleet_source,
    make_genie_source,
    make_recommendation_source,
    make_spend_source,
)
from .data.scoping import ScopeError
from .data.sql_client import get_connection
from .identity import IdentityProvider, Scope, make_identity_provider
from .models import Identity
from .services import RecommendationService
from .services.health_service import HealthService


@lru_cache(maxsize=1)
def get_identity_provider() -> IdentityProvider:
    return make_identity_provider(get_settings())


def get_identity(request: Request) -> Identity:
    return get_identity_provider().resolve(request)


def get_scope(identity: Identity = Depends(get_identity)) -> Scope:
    return Scope.from_identity(identity)


def get_account_view(request: Request):
    """The global account/cloud/account_id selection, from the same query params the
    frontend appends to every GET. Drives the recommendation source's fetch filter and
    (in central mode) scopes the spend read. Empty in single-account mode."""
    from .data.account_view import AccountView

    return AccountView.from_query(request.query_params)


def get_view_scope(request: Request, scope: Scope = Depends(get_scope)) -> Scope:
    """Scope for the account-wide *content* views, narrowed to a single workspace
    when the client asks for one via ``?workspace_id=``.

    This is what makes the UI's global workspace switcher apply everywhere at once:
    the frontend appends ``workspace_id`` to every request, so one selection scopes
    recommendations, the overview, the serverless case, Genie and Apps together
    rather than only the two pages that have a ``/workspaces/{id}/...`` route.

    It is still a *filter within* the caller's server-derived scope, never a grant:
    narrowing only removes access (see :meth:`Scope.narrowed_to`), so a workspace
    admin naming a workspace they do not own gets empty results, not someone else's.

    An absent or blank ``workspace_id`` (the "all workspaces" selection) leaves the
    caller's full scope untouched. A malformed (non-numeric) id is ignored here
    rather than raised: unlike the path-param endpoints, this is an optional view
    filter, so a bad value should fall back to the full scope, not 400 the page.
    """
    workspace_id = request.query_params.get("workspace_id")
    if not workspace_id:
        return scope
    try:
        return scope.narrowed_to(workspace_id)
    except ScopeError:
        return scope


def _sql_token(settings, request: Request) -> str | None:
    """Which token the SQL warehouse connection authenticates with.

    * dev / explicit PAT (``DATABRICKS_TOKEN``) — use it directly;
    * **OBO** (``FINOPS_AUTH_MODE=obo``) — the signed-in user's forwarded token,
      so every read runs AS the user and their Unity Catalog grants govern what
      the app can see (true on-behalf-of). Requires the app to carry the ``sql``
      user_api_scope (set on the app resource) or the forwarded token cannot reach
      the warehouse;
    * otherwise (``sp`` mode) — ``None``, i.e. the app's own service principal.
    """
    if settings.databricks_token:
        return settings.databricks_token
    if settings.auth_mode == "obo":
        return get_user_token(request)
    return None


def _identity_key(settings, request: Request) -> str:
    """Per-caller cache key. In OBO mode each user gets their OWN cached source and
    connection, so one user's token — or cached rows — can never serve another
    user's request (the sources below are reused across requests for their
    in-memory caches). dev and sp mode share a single key."""
    if settings.databricks_token or settings.auth_mode != "obo":
        return "sp"
    tok = get_user_token(request) or ""
    if not tok:
        return "anon"
    # Key by a hash of the token: a rotated token yields a new key (hence a fresh
    # connection), and a cache HIT always means the identical, still-valid token.
    return "u:" + hashlib.sha256(tok.encode()).hexdigest()[:16]


#: (kind, identity_key) -> source instance. Per-identity so OBO never shares one
#: caller's connection/cache with another; capped to bound growth under token churn.
_SOURCE_CACHE: dict[tuple[str, str], object] = {}
_SOURCE_CACHE_CAP = 256


def _cached_source(kind: str, settings, request: Request, factory):
    """A per-identity source, built (and cached) on first use for this caller. The
    connect closure captures the caller's token, so queries that open a connection
    inside worker threads still authenticate as the right identity."""
    key = (kind, _identity_key(settings, request))
    src = _SOURCE_CACHE.get(key)
    if src is None:
        token = _sql_token(settings, request)

        def connect():
            return get_connection(settings, token)

        src = factory(settings, connect)
        if len(_SOURCE_CACHE) >= _SOURCE_CACHE_CAP:
            _SOURCE_CACHE.clear()  # crude eviction; identities re-warm on next call
        _SOURCE_CACHE[key] = src
    return src


def get_recommendation_service(request: Request) -> RecommendationService:
    settings = get_settings()

    # True OBO: the SQL connection runs AS the caller (their forwarded token), so
    # their Unity Catalog grants govern reads — no app-SP grant needed. dev uses the
    # local PAT; sp mode uses the app service principal. Built fresh per request
    # (never a shared singleton) so one caller's token is never reused for another.
    token = _sql_token(settings, request)

    def connect():
        return get_connection(settings, token)

    source = make_recommendation_source(settings, connect)
    # Global account/cloud/account_id view filter, from the same per-request query
    # params the frontend appends to every GET (see api/client.ts). Applied at the
    # source's fetch boundary, so ONE account selection filters every recommendation
    # surface — overview, next-best-actions, list, groups, detail — and two customers'
    # findings can never mix. Only in central mode; single-account deployments carry
    # no account columns and the UI sends nothing.
    if getattr(settings, "central_mode", False):
        from .data.account_view import AccountView

        source.account_view = AccountView.from_query(request.query_params)
    return RecommendationService(source)


def get_spend_source(request: Request) -> SpendSource:
    """Total-workspace-spend reader. Per-identity (OBO): runs as the caller so
    their grants govern reads; the short-lived cache is kept per caller."""
    return _cached_source("spend", get_settings(), request, make_spend_source)


def get_genie_source(request: Request) -> GenieSource:
    """Genie cost reader. Per-identity (OBO); its live path scans billing.usage
    four times, so the cache is kept per caller."""
    return _cached_source("genie", get_settings(), request, make_genie_source)


def get_apps_source(request: Request) -> AppsSource:
    """Databricks Apps inventory reader. Per-identity (OBO); cache kept per caller."""
    return _cached_source("apps", get_settings(), request, make_apps_source)


def get_anomaly_source(request: Request) -> AnomalySource:
    """Cost anomaly reader. Per-identity (OBO); cache kept per caller."""
    return _cached_source("anomaly", get_settings(), request, make_anomaly_source)


def get_fleet_source(request: Request) -> FleetSource:
    """Fleet-wide serverless evidence. Per-identity (OBO); cache kept per caller."""
    return _cached_source("fleet", get_settings(), request, make_fleet_source)


def get_health_service(request: Request) -> HealthService:
    """Data-source access checker. Per-identity (OBO) so the probe reflects the
    caller's OWN grants; each caller keeps the 15-minute probe cache."""
    return _cached_source("health", get_settings(), request, HealthService)


def get_genie_conversation(request: Request):
    """Client for the context-aware Genie chat (FINOPS_GENIE_MODE=api).

    Unlike the SQL sources, this is NOT a process singleton and does NOT hold a
    connection: it is a thin per-request wrapper over a stateless REST client, and
    it must run as the CALLER (their OBO token governs which data Genie can read),
    so caching one across users would be wrong."""
    from .services.genie_conversation import GenieConversationClient

    return GenieConversationClient(get_settings())


def get_user_token(request: Request) -> str | None:
    """The signed-in user's access token (OBO), for calls that must run AS the user
    rather than as the app SP — e.g. the Genie Conversation API, whose answers are
    scoped by the user's own Unity Catalog grants."""
    return get_identity_provider().access_token(request)



def stoptheleak_enabled() -> bool:
    """FINOPS_STOPTHELEAK_ENABLED, as a dependency so tests can switch it."""
    return get_settings().stoptheleak_enabled


def require_stoptheleak(enabled: bool = Depends(stoptheleak_enabled)) -> None:
    """404 every StopTheLeak endpoint when the integration is off, as if absent."""
    from fastapi import HTTPException

    if not enabled:
        raise HTTPException(status_code=404, detail="Not found")


def get_caller_email(
    request: Request, enabled: bool = Depends(stoptheleak_enabled)
) -> str | None:
    """The signed-in user's email, lowercased, for My findings and votes.

    Read ONLY from ``X-Forwarded-Email``, which the Databricks Apps proxy sets from the
    authenticated session, and never from a query parameter or the request body, so a
    user cannot claim someone else's findings or vote as them. ``FINOPS_DEV_EMAIL``
    (server config) stands in for the header locally, where no proxy sets it. Unlike
    ``get_identity`` there is no fallback to other headers or to a placeholder user:
    no email means no findings, not someone else's.

    Always None when the StopTheLeak integration is off, which is what turns off the
    recipient path into the resource page: with no email, only workspace scope counts.
    """
    if not enabled:
        return None
    email = (request.headers.get("x-forwarded-email") or "").strip().lower()
    if email:
        return email
    return get_settings().dev_email or None


def get_feedback_store(enabled: bool = Depends(stoptheleak_enabled)):
    """The StopTheLeak feedback store, or None unless both FINOPS_STOPTHELEAK_ENABLED
    and FINOPS_FEEDBACK_ENABLED are on.

    Process-singleton; it holds no connection (one is opened per operation)."""
    settings = get_settings()
    if not (enabled and settings.feedback_enabled):
        return None
    global _FEEDBACK_STORE
    if _FEEDBACK_STORE is None:
        from .data.feedback_store import FeedbackStore, make_connect

        _FEEDBACK_STORE = FeedbackStore(make_connect(settings))
    return _FEEDBACK_STORE


_FEEDBACK_STORE = None
