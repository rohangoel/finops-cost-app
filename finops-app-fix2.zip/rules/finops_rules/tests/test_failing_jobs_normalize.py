"""_normalize_days must never raise, whatever shape the SQL/transport hands it —
a viz helper that can 500 the whole recommendations endpoint is the bug we hit
on the client (OBO/REST shaped the ARRAY<STRUCT> column differently)."""

from __future__ import annotations

from finops_rules.catalog.failing_jobs import _normalize_days


def test_list_of_dicts_is_normalized():
    out = _normalize_days([{"d": "2026-10-01", "s": 5, "f": 2}])
    assert out == [{"d": "2026-10-01", "s": 5, "f": 2}]


def test_positional_tuples_are_normalized():
    assert _normalize_days([("2026-10-01", 5, 2)]) == [{"d": "2026-10-01", "s": 5, "f": 2}]


def test_json_string_is_parsed():
    out = _normalize_days('[{"d": "2026-10-02", "s": 1, "f": 0}]')
    assert out == [{"d": "2026-10-02", "s": 1, "f": 0}]


def test_none_and_empty_are_empty():
    assert _normalize_days(None) == []
    assert _normalize_days([]) == []
    assert _normalize_days("") == []


def test_non_iterable_does_not_raise():
    # The failure that 500'd the client: a non-iterable value must yield [], not raise.
    assert _normalize_days(5) == []
    assert _normalize_days(3.5) == []
    assert _normalize_days(True) == []


def test_garbage_string_is_empty_not_an_error():
    assert _normalize_days("not json") == []
