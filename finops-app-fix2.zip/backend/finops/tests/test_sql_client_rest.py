"""The Statement Execution REST shim used for OBO reads.

The warehouse returns JSON_ARRAY values as strings; the shim must coerce them back
to the Python types the Thrift connector produced (ints, floats, bools, decoded
complex types, None) so downstream math/sorting/serialization behaves identically.
It must also poll PENDING/RUNNING to completion, follow result chunks, and raise on
a non-SUCCEEDED terminal state. No warehouse is contacted — the SDK client is faked.
"""

from __future__ import annotations

import types

from databricks.sdk.service.sql import ColumnInfoTypeName, StatementState

from finops.data.sql_client import _RestConnection, _RestCursor


def _col(name, tn):
    return types.SimpleNamespace(name=name, type_name=tn)


def _resp(state, columns=None, data=None, next_chunk=None, error=None):
    return types.SimpleNamespace(
        statement_id="stmt-1",
        status=types.SimpleNamespace(state=state, error=error),
        manifest=types.SimpleNamespace(
            schema=types.SimpleNamespace(columns=columns or [])
        ),
        result=types.SimpleNamespace(data_array=data, next_chunk_index=next_chunk),
    )


def _client(execute_response, get_responses=None, chunks=None):
    seq = list(get_responses or [])

    class SE:
        def execute_statement(self, **kwargs):
            return execute_response

        def get_statement(self, sid):
            return seq.pop(0)

        def get_statement_result_chunk_n(self, sid, n):
            return (chunks or {}).get(n)

    return types.SimpleNamespace(statement_execution=SE())


def test_rest_cursor_coerces_json_strings_to_native_types():
    cols = [
        _col("n", ColumnInfoTypeName.LONG),
        _col("amt", ColumnInfoTypeName.DOUBLE),
        _col("ok", ColumnInfoTypeName.BOOLEAN),
        _col("name", ColumnInfoTypeName.STRING),
        _col("tags", ColumnInfoTypeName.ARRAY),
    ]
    data = [
        ["5", "3.5", "true", "hi", "[1, 2]"],
        ["0", "0.0", "false", "x", None],
        [None, None, None, None, None],
    ]
    cur = _RestCursor(_client(_resp(StatementState.SUCCEEDED, cols, data)), "wh")
    cur.execute("SELECT 1")
    rows = cur.fetchall()
    assert rows[0] == (5, 3.5, True, "hi", [1, 2])
    assert rows[1] == (0, 0.0, False, "x", None)
    assert rows[2] == (None, None, None, None, None)
    assert [d[0] for d in cur.description] == ["n", "amt", "ok", "name", "tags"]


def test_rest_cursor_polls_until_succeeded():
    cols = [_col("c", ColumnInfoTypeName.INT)]
    exec_resp = _resp(StatementState.RUNNING)  # returned by execute_statement
    done = _resp(StatementState.SUCCEEDED, cols, [["7"]])
    cur = _RestCursor(_client(exec_resp, get_responses=[done]), "wh")
    cur._POLL_SECONDS = 0  # don't actually sleep in the test
    cur.execute("SELECT 7")
    assert cur.fetchall() == [(7,)]


def test_rest_cursor_follows_result_chunks():
    cols = [_col("c", ColumnInfoTypeName.INT)]
    first = _resp(StatementState.SUCCEEDED, cols, [["1"]], next_chunk=1)
    chunk1 = types.SimpleNamespace(data_array=[["2"]], next_chunk_index=None)
    cur = _RestCursor(_client(first, chunks={1: chunk1}), "wh")
    cur.execute("SELECT c")
    assert cur.fetchall() == [(1,), (2,)]


def test_rest_cursor_raises_on_failure():
    err = types.SimpleNamespace(message="PERMISSION_DENIED on billing")
    cur = _RestCursor(_client(_resp(StatementState.FAILED, error=err)), "wh")
    try:
        cur.execute("SELECT 1")
    except RuntimeError as exc:
        assert "PERMISSION_DENIED" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected RuntimeError on FAILED statement")


def test_rest_cursor_fetchone_walks_rows():
    cols = [_col("c", ColumnInfoTypeName.INT)]
    cur = _RestCursor(_client(_resp(StatementState.SUCCEEDED, cols, [["1"], ["2"]])), "wh")
    cur.execute("SELECT c")
    assert cur.fetchone() == (1,)
    assert cur.fetchone() == (2,)
    assert cur.fetchone() is None


def test_rest_connection_cursor_is_a_context_manager():
    cols = [_col("c", ColumnInfoTypeName.INT)]
    conn = _RestConnection(_client(_resp(StatementState.SUCCEEDED, cols, [["1"]])), "wh")
    with conn as c, c.cursor() as cur:
        cur.execute("SELECT c")
        assert cur.fetchall() == [(1,)]
