import { execSync } from "node:child_process";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import pkg from "./package.json" with { type: "json" };

// A human-readable build version baked into the bundle, shown in the app footer
// so it is always clear which build is deployed. Format:
// "<pkg.version> · <commit-date> · <git-sha>" (e.g. "0.1.0 · 2026-09-20 · a1b2c3d").
// The DATE leads because it's the label a non-engineer reads to answer "is this
// the build from last week or today?"; the short SHA stays for engineers who want
// to pin the exact commit. It's the commit date of HEAD (not the build-machine
// clock) so the string is reproducible and tied to the code, not to when someone
// happened to run the build. A PR number is deliberately NOT used: it isn't known
// to git at build time (a commit doesn't carry its PR), so it can't be derived
// here without extra plumbing. The "-dirty" marker was dropped — the deploy tree
// always carries incidental untracked files (build caches, local config), so it
// fired on every build and only added noise. Falls back to the package version
// alone when git isn't available.
function buildVersion(): string {
  try {
    const sha = execSync("git rev-parse --short HEAD", { stdio: ["ignore", "pipe", "ignore"] })
      .toString()
      .trim();
    const date = execSync("git show -s --format=%cd --date=short HEAD", {
      stdio: ["ignore", "pipe", "ignore"],
    })
      .toString()
      .trim();
    return `${pkg.version} · ${date} · ${sha}`;
  } catch {
    return pkg.version;
  }
}

// Dev: proxy /api and /health to the FastAPI backend (default :8000; override
// with FINOPS_API_TARGET to run a second backend, e.g. a demo-mode one, alongside).
const apiTarget = process.env.FINOPS_API_TARGET ?? "http://localhost:8000";
// Build: emit the SPA into the backend's static/ dir so FastAPI serves it.
export default defineConfig({
  define: {
    __APP_VERSION__: JSON.stringify(buildVersion()),
  },
  plugins: [react()],
  server: {
    port: Number(process.env.FINOPS_DEV_PORT ?? 5173),
    proxy: {
      "/api": apiTarget,
      "/health": apiTarget,
    },
  },
  build: {
    outDir: "../backend/finops/static",
    emptyOutDir: true,
  },
});
