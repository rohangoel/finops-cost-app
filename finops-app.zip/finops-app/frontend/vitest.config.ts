import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

// Separate from vite.config.ts on purpose: that one imports from "vite" (no test
// types) and bakes a git build-version via execSync, neither of which belongs in
// the test runner. The react plugin is here so the .tsx modules under test (e.g.
// chartkit.tsx) transform correctly; tests run in node since the chart math is
// pure and renders nothing.
export default defineConfig({
  plugins: [react()],
  test: {
    include: ["src/**/*.test.ts", "src/**/*.test.tsx"],
    environment: "node",
  },
});
