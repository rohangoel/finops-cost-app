import { Navigate, Route, Routes } from "react-router-dom";
import { AccountGate } from "./components/AccountGate";
import { Layout } from "./components/Layout";
import { useMe } from "./hooks/useMe";
import { useAccountScope, useAccountScopeCacheSync } from "./hooks/useAccountScope";
import { useConfig } from "./hooks/useConfig";
import { useScopeCacheSync } from "./hooks/useWorkspaceScope";
import { AccountOverview } from "./pages/AccountOverview";
import { Apps } from "./pages/Apps";
import { CostAnomalies } from "./pages/CostAnomalies";
import { GenieCosts } from "./pages/GenieCosts";
import { Labs } from "./pages/Labs";
import { MyFindings } from "./pages/MyFindings";
import { NextBestActions } from "./pages/NextBestActions";
import { RecommendationDetail } from "./pages/RecommendationDetail";
import { Recommendations } from "./pages/Recommendations";
import { ResourceDetail } from "./pages/ResourceDetail";
import { RuleCatalog } from "./pages/RuleCatalog";
import { WorkspaceDetail } from "./pages/WorkspaceDetail";

export default function App() {
  const { data: identity, isLoading, error } = useMe();
  const { data: config, isLoading: configLoading } = useConfig();
  const [accountScope] = useAccountScope();
  // Refetch every page's data when the global workspace or account scope changes.
  useScopeCacheSync();
  useAccountScopeCacheSync();

  if (isLoading || configLoading) return <div className="boot">Loading FinOps…</div>;
  if (error || !identity)
    return <div className="boot error">Could not resolve your identity. {String(error ?? "")}</div>;

  // Central (multi-account) mode gates on an account selection up front: no account
  // data loads until the user picks a customer, so the app never fetches the slow
  // all-accounts view and each account is cached warm after its first load. Swapping
  // accounts (Layout's "Change account") clears the scope and returns here.
  // Single-account deployments (central_mode=false) never gate.
  if (config?.central_mode && !accountScope.salesforce_account_name) {
    return <AccountGate />;
  }

  const isAdmin = identity.role === "platform_admin";
  // Optional StopTheLeak integration: the My findings tab (off by default).
  const myFindings = !!config?.stoptheleak_enabled;
  // Workspace admins land directly on their (first) workspace. With My findings on,
  // someone who admins no workspace (most StopTheLeak recipients) lands on their own
  // findings. "0" is the placeholder the OBO provider uses for a workspace admin with
  // no workspaces.
  const firstWorkspace = identity.workspace_ids.find((w) => w && w !== "0");
  const home = isAdmin ? <AccountOverview /> : firstWorkspace || !myFindings ? (
    <Navigate to={`/workspaces/${firstWorkspace ?? identity.workspace_ids[0] ?? ""}`} replace />
  ) : (
    <Navigate to="/my-findings" replace />
  );

  return (
    <Routes>
      <Route element={<Layout identity={identity} />}>
        <Route path="/" element={home} />
        {myFindings && <Route path="/my-findings" element={<MyFindings />} />}
        <Route path="/next-best-actions" element={<NextBestActions />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/recommendations/:id" element={<RecommendationDetail />} />
        <Route path="/labs" element={<Labs />} />
        <Route path="/resources/:groupId" element={<ResourceDetail />} />
        <Route path="/workspaces/:workspaceId" element={<WorkspaceDetail />} />
        <Route path="/apps" element={<Apps />} />
        <Route path="/workspaces/:workspaceId/apps" element={<Apps />} />
        <Route path="/cost-anomalies" element={<CostAnomalies />} />
        <Route path="/workspaces/:workspaceId/cost-anomalies" element={<CostAnomalies />} />
        {/* Genie Costs: single-account (non-central) only — see Layout nav gate. The
            route is harmless in central mode; the nav link is what's hidden. */}
        <Route path="/genie-costs" element={<GenieCosts />} />
        <Route path="/workspaces/:workspaceId/genie-costs" element={<GenieCosts />} />
        <Route path="/rules" element={<RuleCatalog />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
