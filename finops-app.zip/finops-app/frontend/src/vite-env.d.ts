/// <reference types="vite/client" />

/** Build version baked in by vite.config.ts at build time (package version +
 *  git short SHA), rendered in the app footer. See vite.config.ts `define`. */
declare const __APP_VERSION__: string;
