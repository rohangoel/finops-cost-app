import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { ServerlessCase } from "../api/types";

/** The "About Serverless" case: issue categories with this account's evidence.
 *
 *  Reads its own endpoint rather than deriving from the recommendation list,
 *  because it deliberately includes findings hidden from the recommendation GUI
 *  (old DBRs) and adds fleet-level facts no single rule owns. Slow-moving, so
 *  cached generously. */
export function useServerlessCase() {
  return useQuery({
    queryKey: ["serverless-case"],
    queryFn: () => apiGet<ServerlessCase>("/api/serverless-case"),
    staleTime: 10 * 60 * 1000,
  });
}
