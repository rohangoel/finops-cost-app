import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { Recommendation, RecommendationGroup } from "../api/types";
import { useAccountScope } from "./useAccountScope";

export interface RecommendationFilters {
  workspace_id?: string;
  rule_id?: string;
  // Group filter: keep only resources where ALL of these recommendation types
  // apply at once (conjunctive). Serialized to the `rule_ids` query param.
  rule_ids?: string[];
  resource_type?: string;
  priority?: string;
  min_savings?: number;
  sort?: "nba" | "savings";
}
// NB: the account / cloud / databricks_account_id filters are NOT here — they are
// global (the account scope bar, lib/accountScope), ride every request via apiGet,
// and are applied server-side to every surface, so they are never per-list filters.

export interface RecommendationFacets {
  salesforce_account_name: string[];
  cloud_type: string[];
  databricks_account_id: string[];
}

// Distinct account/cloud/account_id values, to populate the filter dropdowns. Empty
// arrays in single-account mode (the frontend then hides them).
//
// The facets are DEPENDENT: the backend narrows cloud to the selected account and
// account_id to the selected account + cloud (the account list stays complete for the
// gate). The account scope rides the request via apiGet, so we key on the two dimensions
// the response actually depends on — salesforce_account_name and cloud_type — so the
// dropdowns cascade as you pick. (databricks_account_id is the leaf and changes no
// facet, so it is deliberately absent from the key to avoid needless refetches.)
export function useRecommendationFacets() {
  const [scope] = useAccountScope();
  return useQuery({
    queryKey: ["recommendation-facets", scope.salesforce_account_name, scope.cloud_type],
    queryFn: () => apiGet<RecommendationFacets>("/api/recommendation-facets"),
  });
}

export function useRecommendations(filters: RecommendationFilters = {}) {
  return useQuery({
    queryKey: ["recommendations", filters],
    queryFn: () =>
      apiGet<Recommendation[]>(
        "/api/recommendations",
        filters as Record<string, string | number | undefined>,
      ),
  });
}

// Grouped overview: one row per resource. `rule_id` (single) is not a group
// filter — a group spans rules — so it is dropped. `rule_ids` (multi) IS a group
// filter with ALL semantics: keep resources where every listed type applies. It
// is flattened to a comma-separated `rule_ids` param the client can serialize.
export function useRecommendationGroups(filters: RecommendationFilters = {}) {
  const { rule_id: _rule_id, rule_ids, ...rest } = filters;
  const params: Record<string, string | number | undefined> = {
    ...(rest as Record<string, string | number | undefined>),
    rule_ids: rule_ids && rule_ids.length > 0 ? rule_ids.join(",") : undefined,
  };
  return useQuery({
    queryKey: ["recommendation-groups", params],
    queryFn: () => apiGet<RecommendationGroup[]>("/api/recommendation-groups", params),
  });
}

export function useRecommendation(id: string) {
  return useQuery({
    queryKey: ["recommendation", id],
    queryFn: () => apiGet<Recommendation>(`/api/recommendations/${id}`),
    enabled: !!id,
  });
}

export function useRecommendationGroup(groupId: string) {
  return useQuery({
    queryKey: ["recommendation-group", groupId],
    queryFn: () => apiGet<RecommendationGroup>(`/api/recommendation-groups/${groupId}`),
    enabled: !!groupId,
  });
}
