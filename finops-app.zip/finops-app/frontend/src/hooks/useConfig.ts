import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { AppConfig } from "../api/types";

/** App-wide config (compute mode, currency, Genie panel toggle). It changes only
 *  on redeploy, so cache it for the whole session. */
export function useConfig() {
  return useQuery({
    queryKey: ["config"],
    queryFn: () => apiGet<AppConfig>("/api/config"),
    staleTime: Infinity,
  });
}
