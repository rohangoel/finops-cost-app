import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { Identity } from "../api/types";

export function useMe() {
  return useQuery({ queryKey: ["me"], queryFn: () => apiGet<Identity>("/api/me") });
}
