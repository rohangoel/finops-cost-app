import { useCallback, useEffect, useState } from "react";
import { applyTheme, resolveInitialTheme, storeTheme, type Theme } from "../lib/theme";

/** Reactive theme state kept in sync with <html data-theme> + localStorage. */
export function useTheme(): { theme: Theme; toggle: () => void } {
  const [theme, setTheme] = useState<Theme>(() => resolveInitialTheme());

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  const toggle = useCallback(() => {
    setTheme((t) => {
      const next: Theme = t === "dark" ? "light" : "dark";
      storeTheme(next);
      return next;
    });
  }, []);

  return { theme, toggle };
}
