import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { GenieCosts } from "../api/types";

/** Genie cost analysis for the caller's scope.
 *
 *  Its own query, like `useSpend`: the data comes from a different source (the
 *  Genie snapshot, or live billing aggregates as fallback), may legitimately be
 *  unavailable while every other page still works, and changes daily at most —
 *  so it is cached generously. */
export function useGenieCosts(workspaceId?: string) {
  return useQuery({
    // workspaceId is part of the key so the platform view and each workspace
    // drill-in are cached separately instead of overwriting one another.
    queryKey: ["genie", workspaceId ?? "platform"],
    queryFn: () =>
      apiGet<GenieCosts>(workspaceId ? `/api/genie/${workspaceId}` : "/api/genie"),
    staleTime: 5 * 60 * 1000,
  });
}
