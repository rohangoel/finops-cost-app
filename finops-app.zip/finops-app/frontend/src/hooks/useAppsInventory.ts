import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { AppsInventory } from "../api/types";

/** Databricks Apps inventory for the caller's scope, or one workspace.
 *
 *  Its own query, like `useGenieCosts`: a different source (the apps snapshot, or
 *  live billing + audit aggregates as fallback), may legitimately be unavailable
 *  while every other page works, and changes daily at most — so cached generously.
 *
 *  Pass `workspaceId` for the per-workspace drill-in; it is part of the query key so
 *  the platform view and each workspace view cache separately. */
export function useAppsInventory(workspaceId?: string) {
  return useQuery({
    queryKey: ["apps", workspaceId ?? "platform"],
    queryFn: () =>
      apiGet<AppsInventory>(workspaceId ? `/api/apps/${workspaceId}` : "/api/apps"),
    staleTime: 5 * 60 * 1000,
  });
}
