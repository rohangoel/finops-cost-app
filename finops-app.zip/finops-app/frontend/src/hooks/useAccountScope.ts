import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useSyncExternalStore } from "react";
import {
  type AccountScope,
  getAccountScope,
  setAccountScope,
  subscribeAccountScope,
} from "../lib/accountScope";

/** Read + set the global account scope, reactively.
 *
 *  Backed by `useSyncExternalStore` over lib/accountScope's pub/sub, so a change
 *  made anywhere — this window's switcher OR another browser window (via the
 *  `storage` event) — re-renders every consumer. All fields empty = the unfiltered
 *  all-accounts central view. */
export function useAccountScope(): [AccountScope, (patch: Partial<AccountScope>) => void] {
  const scope = useSyncExternalStore(subscribeAccountScope, getAccountScope, getAccountScope);
  return [scope, setAccountScope];
}

/** Mounted once at the app root: when the account scope changes, drop cached query
 *  data so every open surface refetches under the new account filter. The facets
 *  query (the switcher's own option lists) is account-independent — it lists every
 *  account regardless of the pick — so it is left in place to avoid a needless
 *  round-trip and a flickering switcher. */
export function useAccountScopeCacheSync(): void {
  const queryClient = useQueryClient();
  useEffect(() => {
    return subscribeAccountScope(() => {
      queryClient.invalidateQueries({
        predicate: (q) => q.queryKey[0] !== "recommendation-facets",
      });
    });
  }, [queryClient]);
}
