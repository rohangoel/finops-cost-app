import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { AccountSpend } from "../api/types";

/** Total billed spend for the caller's scope.
 *
 *  Kept in its own query (not folded into the account overview) because it comes
 *  from a different source — the precomputed spend snapshot, or a live billing
 *  aggregate as fallback — and may legitimately be unavailable while the rest of
 *  the page still works. Spend changes daily at most, so it is cached generously. */
export function useSpend() {
  return useQuery({
    queryKey: ["spend"],
    queryFn: () => apiGet<AccountSpend>("/api/spend"),
    staleTime: 5 * 60 * 1000,
  });
}

/** Monthly spend for one workspace, or `undefined` when unavailable. */
export function useWorkspaceSpend(workspaceId: string) {
  const { data, ...rest } = useSpend();
  const ws = data?.workspaces.find((w) => w.workspace_id === workspaceId);
  return { ...rest, data: ws, unavailable: data?.unavailable ?? false };
}
