import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { Recommendation } from "../api/types";

export function useNextBestActions(limit = 10) {
  return useQuery({
    queryKey: ["nba", limit],
    queryFn: () => apiGet<Recommendation[]>("/api/next-best-actions", { limit }),
  });
}
