import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { RuleMeta, WorkspaceDetail, WorkspaceSummary } from "../api/types";

export function useWorkspaces() {
  return useQuery({
    queryKey: ["workspaces"],
    queryFn: () => apiGet<WorkspaceSummary[]>("/api/workspaces"),
  });
}

export function useWorkspaceDetail(workspaceId: string) {
  return useQuery({
    queryKey: ["workspace-detail", workspaceId],
    queryFn: () => apiGet<WorkspaceDetail>(`/api/workspaces/${workspaceId}/summary`),
    enabled: !!workspaceId,
  });
}

export function useRules() {
  return useQuery({ queryKey: ["rules"], queryFn: () => apiGet<RuleMeta[]>("/api/rules") });
}
