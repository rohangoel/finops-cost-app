import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { TaggingOverview } from "../api/types";

// Governance / chargeback findings for the Tagging & Chargeback tab. The global
// workspace + account scope ride the request via apiGet, and the account-scope
// cache sync (App.tsx) refetches on account change, so the key stays static like
// the other account-wide views (account-overview, nba).
export function useTagging() {
  return useQuery({
    queryKey: ["tagging"],
    queryFn: () => apiGet<TaggingOverview>("/api/tagging"),
  });
}
