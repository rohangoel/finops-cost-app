import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { PricingSummary } from "../api/types";

/** Fetch pricing capability info: whether contract rates and cloud costs are available.
 *  Scope-aware via the same workspace_id param that other endpoints accept. */
export function usePricing() {
  return useQuery({
    queryKey: ["pricing"],
    queryFn: () => apiGet<PricingSummary>("/api/pricing"),
  });
}
