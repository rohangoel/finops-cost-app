import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { AccountOverview } from "../api/types";

export function useAccountOverview() {
  return useQuery({
    queryKey: ["account-overview"],
    queryFn: () => apiGet<AccountOverview>("/api/account/overview"),
  });
}
