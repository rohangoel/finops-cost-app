import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { ExperimentalOverview } from "../api/types";

// Phase 4 experimental (Labs) findings. Like useTagging, the global workspace +
// account scope ride the request via apiGet and the account-scope cache sync
// (App.tsx) refetches on account change, so the key stays static.
export function useExperimental() {
  return useQuery({
    queryKey: ["experimental"],
    queryFn: () => apiGet<ExperimentalOverview>("/api/experimental"),
  });
}
