import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useSyncExternalStore } from "react";
import { getScope, setScope, subscribeScope } from "../lib/scope";

/** Read + set the global workspace scope, reactively.
 *
 *  Backed by `useSyncExternalStore` over lib/scope's pub/sub, so a change made
 *  anywhere — this window's switcher OR another browser window (via the `storage`
 *  event) — re-renders every consumer. `""` means the all-workspaces platform view. */
export function useWorkspaceScope(): [string, (id: string) => void] {
  const scope = useSyncExternalStore(subscribeScope, getScope, getScope);
  return [scope, setScope];
}

/** Mounted once at the app root: when the scope changes, drop all cached query
 *  data so every open tab refetches under the new workspace filter. Without this,
 *  react-query would keep serving the previous workspace's results until each
 *  query's staleTime elapsed. */
export function useScopeCacheSync(): void {
  const queryClient = useQueryClient();
  useEffect(() => {
    return subscribeScope(() => {
      // The workspace list itself is scope-independent (the switcher always needs
      // the full list); everything else is refetched under the new scope.
      queryClient.invalidateQueries({
        predicate: (q) => q.queryKey[0] !== "workspaces",
      });
    });
  }, [queryClient]);
}
