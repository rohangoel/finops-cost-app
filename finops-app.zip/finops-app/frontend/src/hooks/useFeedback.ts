import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiGet, apiPost, apiSend } from "../api/client";
import type { EmailPreference, MyFindings, Vote, VoteRequest } from "../api/types";

/** Findings routed to the signed-in user. The backend identifies them by the
 *  X-Forwarded-Email header only; nothing here sends an email. */
export function useMyFindings(enabled = true) {
  return useQuery({
    queryKey: ["my-findings"],
    queryFn: () => apiGet<MyFindings>("/api/my-findings"),
    enabled,
  });
}

/** finding_key -> the user's latest vote. `{}` when feedback is off. */
export function useMyVotes(enabled = true) {
  return useQuery({
    queryKey: ["my-votes"],
    queryFn: () => apiGet<Record<string, Vote>>("/api/feedback/mine"),
    enabled,
  });
}

export function useCastVote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: VoteRequest) => apiPost<Vote>("/api/feedback", body),
    onSuccess: (vote) => {
      if (!vote) return;
      qc.setQueryData<Record<string, Vote>>(["my-votes"], (old) => ({
        ...(old ?? {}),
        [vote.finding_key]: vote,
      }));
    },
  });
}

export function useEmailPreference(enabled: boolean) {
  return useQuery({
    queryKey: ["email-preference"],
    queryFn: () => apiGet<EmailPreference>("/api/email-preference"),
    enabled,
  });
}

/** weekly=false opts out (a row in ops.opt_outs); true undoes it. */
export function useSetWeeklyEmail() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (weekly: boolean) =>
      apiSend(weekly ? "PUT" : "DELETE", "/api/email-preference/weekly-email"),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["email-preference"] }),
  });
}
