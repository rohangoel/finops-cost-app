import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { HealthReport } from "../api/types";

/** Which system tables are readable, and which rules are blocked without them.
 *
 *  Cached hard on both sides: the server re-probes at most every 15 minutes, and
 *  grants change on the order of weeks, so refetching on window focus or mount
 *  would spend latency on an answer that almost never moves. */
export function useDataHealth() {
  return useQuery({
    queryKey: ["data-health"],
    queryFn: () => apiGet<HealthReport>("/api/data-health"),
    staleTime: 15 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });
}
