import { useQuery } from "@tanstack/react-query";
import { apiGet } from "../api/client";
import type { CostAnomalies } from "../api/types";

/** Cost anomalies for the caller's scope, or one workspace.
 *
 *  Its own query, like `useAppsInventory`: a different source (the anomaly snapshot,
 *  or a live 35-day billing scan as fallback), may legitimately be unavailable while
 *  every other page works, and changes daily at most — so cached generously.
 *
 *  `workspaceId` is part of the query key so the platform view and each workspace
 *  view cache separately. */
export function useCostAnomalies(workspaceId?: string) {
  return useQuery({
    queryKey: ["anomalies", workspaceId ?? "platform"],
    queryFn: () =>
      apiGet<CostAnomalies>(workspaceId ? `/api/anomalies/${workspaceId}` : "/api/anomalies"),
    staleTime: 5 * 60 * 1000,
  });
}
