// Same-origin fetch wrapper. In Databricks Apps the user's OAuth token is
// injected by the platform, so the browser never handles tokens.

import { getAccountScope } from "../lib/accountScope";
import { getScope } from "../lib/scope";

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export async function apiGet<T>(path: string, params?: Record<string, string | number | undefined>): Promise<T> {
  const url = new URL(path, window.location.origin);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== "") url.searchParams.set(k, String(v));
    }
  }
  // The global workspace scope rides on every GET, so one selection in the
  // switcher filters every account-wide view at once (see lib/scope.ts and the
  // backend's get_view_scope). Endpoints that don't opt in ignore it, and a caller
  // that set workspace_id itself (e.g. a path-addressed drill-in) always wins.
  const scope = getScope();
  if (scope && !url.searchParams.has("workspace_id")) {
    url.searchParams.set("workspace_id", scope);
  }
  // The global account scope rides on every GET too (central mode), so one pick in
  // the account switcher filters every recommendation surface at once and two
  // customers' findings never mix (see lib/accountScope.ts + the backend's
  // AccountView, applied at the source's fetch boundary). Empty in single-account
  // mode. A caller that set a value itself always wins.
  const account = getAccountScope();
  for (const [k, v] of Object.entries(account)) {
    if (v && !url.searchParams.has(k)) url.searchParams.set(k, v);
  }
  const res = await fetch(url.toString(), { headers: { Accept: "application/json" } });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
  return res.json() as Promise<T>;
}

export async function apiPost<T>(path: string, body?: unknown): Promise<T | null> {
  const res = await fetch(new URL(path, window.location.origin).toString(), {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return null;
  return res.json() as Promise<T>;
}

/** PUT / DELETE with no response body expected (204). */
export async function apiSend(method: "PUT" | "DELETE", path: string): Promise<void> {
  const res = await fetch(new URL(path, window.location.origin).toString(), {
    method,
    headers: { Accept: "application/json" },
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
}
