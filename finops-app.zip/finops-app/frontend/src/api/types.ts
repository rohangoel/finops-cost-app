// TypeScript mirror of the recommendation contract.
// Keep in sync (additively) with backend/finops/models/recommendation.py and
// precompute/ddl/finops_recommendations.sql. See docs/DATA_MODEL.md.

export interface Recommendation {
  recommendation_id: string;
  snapshot_date: string;
  rule_id: string;
  rule_version: string;
  rule_title: string;
  category: string;
  workspace_id: string;
  workspace_name: string | null;
  workspace_url: string | null; // base URL of the resource's own workspace (deep-link host)
  resource_type: string;
  resource_id: string;
  resource_name: string;
  resource_owner: string | null; // who owns the resource (billing.usage identity_metadata), null if unknown
  resource_creator: string | null; // who created it, null if unknown
  why: string;
  how: string;
  monthly_waste_usd: number;
  monthly_savings_usd: number; // point estimate (list price)
  // Phase 0 savings-status scaffold. The booked headline sums monthly_savings_low_usd
  // of savings_status==="bookable" rows only; estimated/advisory contribute zero.
  savings_status: "bookable" | "estimated" | "advisory";
  monthly_savings_low_usd: number; // conservative floor — the only value booked (list price)
  monthly_savings_high_usd: number; // upper scenario, never booked (list price)
  // FIN-008 action-aware aggregation. affected_spend_scope dedups findings that bill the
  // same spend pool (null = this resource's own spend); savings_composition says whether
  // the option is a mutually-exclusive alternative or composes with other tunings.
  affected_spend_scope?: string | null;
  savings_composition?: "exclusive" | "additive";
  // Contract pricing and cloud VM costs. All null unless account has contract prices or
  // cloud_infra_cost data. List figures above are always complete and remain the ranking basis;
  // a contract figure exists only when >= contract_min_coverage (0.95) of the resource's
  // usage had a contract price. Optional: older snapshots/APIs omit them.
  price_basis?: "list" | "contract" | null; // contract = has a contract figure; list = measured fallback; null = no contract data
  contract_price_coverage?: number | null; // 0-1 share of the resource's usage with a contract price
  monthly_savings_contract_usd?: number | null; // point estimate at contract rates
  monthly_savings_contract_low_usd?: number | null; // conservative floor at contract rates
  monthly_savings_contract_high_usd?: number | null; // upper scenario at contract rates
  cloud_cost_30d_usd?: number | null; // classic VM cost of this resource (separate from Databricks DBU)
  monthly_cloud_savings_usd?: number | null; // cloud VM saving, never added to Databricks dollars
  // Owner routing (backend finops/routing.py). finding_key =
  // sha256(rule_id|workspace_id|resource_type|resource_id)[:32]: unlike
  // recommendation_id it survives the nightly recompute, so links use it.
  // notify_recipient is who this finding goes to (lowercased email): the object owner
  // if it's a user, else the workspace owner (billing Owner tag), else null.
  finding_key: string;
  workspace_owner?: string | null;
  resource_owner_kind?: "user" | "service_principal" | "unknown" | null;
  notify_recipient?: string | null;
  recipient_source?: "object_owner" | "workspace_owner" | null;
  effort_band: "trivial" | "low" | "medium" | "high";
  effort_score: number;
  priority: "HIGH" | "MEDIUM" | "LOW";
  nba_score: number;
  evidence: Record<string, unknown>;
  computed_at: string;
  // Central (multi-account) mode only — the account dimension from
  // finops_central_recommendations. All null in single-account mode.
  databricks_account_id?: string | null;
  cloud_type?: string | null;
  salesforce_account_name?: string | null;
  // Derived server-side (not a stored column): the id of the RESOURCE group this
  // finding belongs to, so a single-finding link can open the resource page that
  // lists every applicable recommendation.
  group_id: string;
}

// A resource-grouped rollup: one entry per (workspace, resource) collapsing the
// several rules that may flag it. Savings is the MAX option, not the sum, since
// the options overlap on the same resource. See backend/finops/models/group.py.
// Per-resource "should this go serverless?" verdict (warehouses/jobs), shown on
// the detail page. `projected_monthly_savings_usd` is present ONLY when a real
// finding measured it (verdict "recommended"); "not_a_fit"/"cannot_estimate"
// deliberately carry no number. See backend/finops/models/serverless_fit.py.
export interface ServerlessFit {
  verdict: "recommended" | "already_serverless" | "not_a_fit" | "cannot_estimate";
  headline: string;
  reason: string;
  projected_monthly_savings_usd: number | null;
  group_id: string | null; // deep link to the serverless option, when recommended
}

export interface RecommendationGroup {
  group_id: string;
  workspace_id: string;
  workspace_name: string | null;
  workspace_url: string | null;
  resource_type: string;
  resource_id: string;
  resource_name: string;
  action_label: string;
  category: string;
  option_count: number;
  monthly_savings_usd: number; // max option (headline)
  monthly_waste_usd: number;
  options_savings_sum_usd: number; // naive sum of options (for context only)
  // Composed savings at "Your rates" + cloud VM layer (null without such data).
  monthly_savings_contract_usd?: number | null;
  price_basis?: "list" | "contract" | null;
  monthly_cloud_savings_usd?: number | null;
  effort_band: "trivial" | "low" | "medium" | "high";
  priority: "HIGH" | "MEDIUM" | "LOW";
  nba_score: number;
  serverless_fit?: ServerlessFit | null; // detail-page verdict (warehouses/jobs)
  options: Recommendation[]; // the individual findings, best-first
}

// --- evidence "show the data" payloads (additive; see rules/finops_rules/evidence.py) ---
export type Confidence = "high" | "medium" | "low";

export interface HourHeatmapViz {
  kind: "hour_heatmap";
  day_labels: string[];
  grid: number[][]; // rows = days, cols = 24 hours; 0=stopped 1=active 2=idle-warm
  reclaimable_hours: number;
  // absent on older snapshots means warehouse; "keepalive" = state 2 is an hour held
  // up only by trivial keep-alive statements, not idle warm time
  context?: "warehouse" | "pipeline" | "keepalive";
}
export interface BurstCompareViz {
  kind: "burst_compare";
  load: number[]; // query load per bucket, 0..1
  warm_floor: number; // classic always-on billed minimum
  idle_pct: number;
  cold_start_s: number;
}
export interface CpuAreaViz {
  kind: "cpu_area";
  cpu: number[]; // hourly CPU utilization, 0..1
  p95: number;
  window_label: string;
  ts?: number[]; // parallel unix-second hour timestamps (for a dated x-axis)
  idle_frac?: number[]; // parallel share (0..1) of the hour spent idle
  idle_threshold?: number; // CPU fraction below which a sample counts as idle
}
export interface ClusterDailyDay {
  d: string; // ISO date
  a: number; // active hours (peak CPU >= idle_threshold)
  i: number; // idle hours (ran, but peak CPU below threshold)
  pk: number; // that day's peak CPU, 0..1
}
export interface ClusterDailyViz {
  kind: "cluster_daily";
  days: ClusterDailyDay[]; // one entry per calendar day across the lookback
  lookback_days: number;
  idle_threshold: number;
  last_active: string | null; // ISO date the cluster last ran
  peak_overall: number; // highest CPU seen in the window, 0..1
}
export interface JobRunsDay {
  d: string; // ISO date
  s: number; // succeeded runs that day
  f: number; // failed runs that day
}
export interface JobRunsViz {
  kind: "job_runs";
  days: JobRunsDay[]; // per-day succeeded/failed run counts (G1)
  lookback_days: number;
  fail_rate: number; // window failure share, 0..1
  baseline_fail_rate: number; // healthy baseline drawn for reference
  failed_cost: number; // measured $ burned on failed runs / month
}
// Driver-vs-worker CPU/memory for the jobs-compute rightsize rule. worker_* is
// null for a job that ran single-node (no workers).
export interface DriverWorkerSplitViz {
  kind: "driver_worker_split";
  driver_cpu: number; // avg driver CPU %, 0..100
  worker_cpu: number | null; // avg worker CPU %, null if single-node
  driver_mem: number; // avg driver memory %, 0..100
  worker_mem: number | null; // avg worker memory %, null if single-node
  worker_count: number;
  symptom: "driver_bound" | "idle_workers" | "memory_oversize";
}
export interface WriteNoReadDay {
  d: string; // ISO date
  w: number; // write events that day
  r: number; // read events that day (0 => the finding)
}
export interface WriteNoReadViz {
  kind: "write_no_read";
  days: WriteNoReadDay[]; // per-day writes vs reads (G2)
  lookback_days: number;
  total_writes: number;
  total_reads: number; // 0 => produced but never consumed
  last_write: string | null;
}
export interface ServingTrafficViz {
  kind: "serving_traffic";
  days: WriteNoReadDay[]; // w=billed that day, r=inference requests that day
  lookback_days: number;
  days_billed: number;
  total_requests: number;
  last_request: string | null;
}
// One guard signal the right-size rule checked, as a margin: the measured value
// against the danger `limit` that would have EXCLUDED the warehouse had it crossed.
// A value far under its limit is the visible headroom that makes the downsize safe.
export interface WhRightsizeHeadroom {
  key: string; // "queue" | "spill" | "scan"
  label: string;
  value: number;
  limit: number;
  unit: string; // "%" | "GB"
  meaning: string; // what crossing the line would have meant
}
export interface WhRightsizeViz {
  kind: "wh_rightsize";
  current_size: string;
  proposed_size: string;
  headroom: WhRightsizeHeadroom[]; // the real load data the decision used
  p95_runtime_s: number; // baseline KPI to watch after the change
  peak_concurrency: number;
  // Measured Spark slot occupancy, present only when query history carried task
  // duration. The direct horsepower signal: peak slots busy vs the size's capacity.
  // When present, confidence is medium (vs low proxy-only) and a slots gauge leads.
  peak_slots_used?: number;
  size_slots?: number;
  slot_util_pct?: number;
  // The deeper size the measured headroom suggests is ultimately reachable, shown
  // as CONTEXT (dotted) — the recommendation itself is always a single step.
  // Present only when that floor is more than one step below the current size.
  floor_size?: string;
  floor_savings_usd?: number;
}
// Serverless auto-stop decision: the warehouse's idle-gap distribution, every
// candidate auto-stop value with what it reclaims vs the restarts it adds, and
// the hourly usage rhythm. Shows WHY a given value was chosen over the floor.
export interface AutostopGapBucket {
  label: string; // e.g. "5m", "10-15m", ">60m"
  lo: number;
  hi: number | null; // null = open-ended tail
  n: number; // idle gaps in this band
}
export interface AutostopCandidate {
  minutes: number;
  reclaimed_min: number;
  extra_stops: number;
  extra_stops_per_day: number;
  net_reclaimed_min: number;
  acceptable: boolean; // false => rejected as a usability regression
}
// One lever of the auto-stop saving. `enable` moves from today's setting (or OFF,
// from_minutes=null) down to a conservative baseline; `tighten` moves from that
// baseline down to the chosen short value. to_minutes is the setting after the move.
export interface AutostopTier {
  from_minutes: number | null; // null = auto-stop was OFF (never stops)
  to_minutes: number;
  monthly_savings_usd: number;
  reclaimed_hours: number;
  extra_stops_per_day?: number; // tighten tier only
}
export interface AutostopTiers {
  enable: AutostopTier | null; // null when auto-stop is already at/below baseline
  tighten: AutostopTier;
  baseline_minutes: number;
}
export interface AutostopTradeoffViz {
  kind: "autostop_tradeoff";
  gap_buckets: AutostopGapBucket[];
  candidates: AutostopCandidate[];
  current_minutes: number | null;
  chosen_minutes: number;
  median_gap_min: number;
  p90_gap_min: number;
  queries_by_hour: number[]; // 24 hourly query counts
  // 1440 per-minute query counts (index = hour*60 + minute-of-hour). Present only
  // on rows produced after the drilldown shipped; when absent the chart shows the
  // hourly view only. Slice [h*60 : h*60+60] is one hour's per-minute profile.
  queries_by_hour_minute?: number[];
  // 168 day-of-week x hour query counts (index = dow*24 + hour, dow 0=Mon..6=Sun),
  // drawn as a weekly heatmap. This is the panel that reveals the real gaps — a
  // 24-bucket hour-of-day chart sums every day together and hides that the
  // warehouse is idle every weekend / every night. Absent on older rows.
  queries_by_dow_hour?: number[];
  // The saving split into the two levers behind it, so the UI leads with the safe
  // "turn it on" win and shows "tighten" as a smaller, churny refinement. Absent
  // when not computed (older rows / other paths).
  tiers?: AutostopTiers;
  lookback_days: number;
  max_extra_stops_per_day: number; // the acceptability line
  // true => the recommended value sits ABOVE that line. Surfaced anyway because
  // the idle spend is material, but the restart cost must be stated, not hidden.
  high_churn?: boolean;
}

// Under-provisioned warehouse (scale-out): queries queue at capacity. The lever
// is max_clusters (a concurrency shortage), NOT the t-shirt size (that fixes
// spill, a per-query memory shortage). Not a savings finding — adding a cluster
// raises the busy-hour bill — so it carries no savings field; it shows the
// current vs proposed cluster ceiling and WHEN the contention happens.
export interface WhScaleOutViz {
  kind: "wh_scale_out";
  current_max_clusters: number;
  proposed_max_clusters: number;
  min_clusters: number;
  queued_pct: number; // share of queries that waited at capacity, 0..100
  p95_queue_wait_s: number;
  avg_queue_wait_s: number;
  queries: number;
  queued_queries: number;
  queries_by_hour: number[]; // 24 hourly query counts
  queued_by_hour: number[]; // 24 hourly counts that queued at capacity
  auto_stop_minutes: number | null; // added cluster auto-stops after this idle
}

// Multi-metric cluster utilization — CPU alone can't tell you whether a cluster
// is oversized, memory-bound, I/O-starved or abandoned. Percentages are 0..1;
// net/disk are normalized to their own window peak (real rates live in stats).
export interface ClusterResourceSample {
  ts: number; // unix seconds (hour bucket)
  cpu?: number;
  mem?: number;
  swap?: number;
  io_wait?: number;
  net?: number; // normalized to its own window peak
}
export interface ClusterResourcesViz {
  kind: "cluster_resources";
  series: ClusterResourceSample[];
  lookback_days: number;
  stats: Record<string, number>; // <metric>_avg_pct / _peak_pct / _peak_mb_per_min …
  cluster_kind: string | null; // "Job cluster" | "All-purpose cluster" | …
  node_type: string | null;
  worker_count: number | null;
}

export interface ClusterWeekHeatmapViz {
  kind: "cluster_week_heatmap";
  active_by_dow_hour: number[]; // 168 elements, index dow*24+hour, dow 0=Mon..6=Sun; in-use minutes
  up_by_dow_hour?: number[]; // 168 elements; minutes the cluster was UP at all. up-active = up-but-idle; up=0 => off
  active_by_hour_minute?: number[]; // 1440 elements, index hour*60+minute; in-use minutes, for the hour→minute drill
  lookback_days: number;
  idle_threshold: number;
}

export interface ClusterContentionViz {
  kind: "cluster_contention";
  // Cluster-wide saturation (%) when a single job ran (solo) vs when >=2 jobs
  // overlapped (concurrent, with p95). null = no measured minutes in that state.
  cpu_solo: number | null;
  cpu_concurrent: number | null;
  cpu_concurrent_p95: number | null;
  mem_solo: number | null;
  mem_concurrent: number | null;
  mem_concurrent_p95: number | null;
  peak_concurrent_runs: number;
  contended_minutes: number;
  contended_job_count: number;
}

export type Viz =
  | HourHeatmapViz
  | BurstCompareViz
  | CpuAreaViz
  | ClusterDailyViz
  | JobRunsViz
  | DriverWorkerSplitViz
  | WriteNoReadViz
  | ServingTrafficViz
  | WhRightsizeViz
  | WhScaleOutViz
  | AutostopTradeoffViz
  | ClusterResourcesViz
  | ClusterWeekHeatmapViz
  | ClusterContentionViz
  | DailyStackViz
  | RankedBarsViz
  | SqlFailuresViz
  | PipelineFailuresViz
  | InstancePoolViz;

// Colour tokens a generic chart may use (evidence.VIZ_COLORS); the renderer maps
// each to its CSS variable so both themes stay in lockstep.
export type VizColor = "info" | "warn" | "danger" | "savings" | "violet" | "track";

// Generic per-day stacked bars (evidence.viz_daily_stack). One entry per day of
// the window, `v` holding one value per series in stacking order (bottom first).
export interface DailyStackViz {
  kind: "daily_stack";
  title: string;
  unit: string;
  series: { label: string; color: VizColor }[];
  days: { d: string; v: number[] }[];
  marker?: { d: string; label: string }; // dashed vertical line, e.g. "last viewed"
  ref?: { value: number; label: string }; // dashed horizontal line, e.g. a floor
  note?: string;
}

// Generic horizontal ranked bars (evidence.viz_ranked_bars), largest first.
export interface RankedBarsViz {
  kind: "ranked_bars";
  title: string;
  unit: string;
  rows: { label: string; value: number; sub: string; color: VizColor }[];
  note?: string;
}

// One recurring job sharing an all-purpose cluster, for the interactive_to_job
// detail. The cluster is judged as a whole; this is the per-job supporting
// breakdown so the reader can see which jobs to migrate.
export interface JobBreakdownItem {
  job_id: string;
  runs: number;
  hours: number;
}

// One recurring job sharing an all-purpose cluster, for the interactive_to_job
// detail. The cluster is judged as a whole; this is the per-job supporting
// breakdown so the reader can see which jobs to migrate.
export interface JobBreakdownItem {
  job_id: string;
  runs: number;
  hours: number;
}

export interface Evidence {
  confidence?: Confidence;
  data_basis?: string;
  // One sentence saying what the LOW and HIGH ends of the savings band mean for
  // this finding (set by rules that widen the band; see SAVINGS_CONFIDENCE_MODEL.md).
  // Shown verbatim on the Data Quality panel and the range tooltip.
  savings_range_basis?: string;
  // A rule's own warning that the evidence may not show what it seems to (e.g. zero
  // logged serving requests on an endpoint that has never logged any — usage
  // tracking may be off). Rendered as a callout above the action + an "Unverified"
  // tag on list rows.
  data_warning?: string;
  viz?: Viz;
  // Additional charts rendered after the primary one, for findings that need
  // more than one picture (e.g. a cluster: when it ran + what it was doing).
  viz_extra?: Viz[];
  // How much observation backs this finding: distinct days the resource was seen
  // active, and the minimum required before any action is recommended (see
  // rules/finops_rules/history.py). Surfaced in the facts strip because it
  // qualifies every dollar figure next to it — a monthly number extrapolated from
  // a handful of days deserves to be read as such.
  observed_days?: number;
  min_observation_days?: number;
  [key: string]: unknown;
}

export interface Identity {
  user: string;
  role: "platform_admin" | "workspace_admin";
  workspace_ids: string[];
  all_workspaces: boolean;
  compute_mode: string;
  auth_mode: string;
  workspace_host: string;
}

/** App-wide config from /api/config (not per-user; see Identity for persona). */
export interface AppConfig {
  compute_mode: string;
  auth_mode: string;
  currency: string;
  lookback_days: number;
  /** Multi-account (Central Logfood) mode. When true the SPA shows the account
   *  gate up front; false = single-account deployment (no gate). */
  central_mode: boolean;
  /** Whether the "Ask Genie" panel is wired up (off by default). */
  genie_enabled: boolean;
  /** How the panel talks to Genie: "api" = native context-aware chat (proxied
   *  Conversation API); "iframe" = the embedded Genie space. */
  genie_mode: "api" | "iframe";
  /** iframe src for the Genie space; "" in API mode or when the panel is disabled. */
  genie_embed_url: string;
  /** Phase 4 Labs tab: true when at least one experimental rule is active. Hidden
   *  entirely when a deploy sets FINOPS_EXPERIMENTAL_RULES="". */
  experimental_enabled: boolean;
  /** Optional StopTheLeak integration: the My findings tab + recipient access.
   *  Off by default; the app is then unchanged. */
  stoptheleak_enabled?: boolean;
  /** In-app votes + weekly-email opt-out (needs stoptheleak_enabled too). */
  feedback_enabled?: boolean;
}

/** GET /api/my-findings: findings routed to the signed-in user (X-Forwarded-Email). */
export interface MyFindings {
  email: string | null; // null when the request carried no X-Forwarded-Email
  feedback_enabled: boolean;
  findings: Recommendation[]; // biggest saving first
}

export type Verdict =
  | "valid_will_fix"
  | "valid_cannot_fix"
  | "invalid"
  | "comment_only"
  | "not_my_resource"
  | "already_fixed";

export type SavingsAssessment = "too_high" | "about_right" | "too_low" | "unsure";

/** POST /api/feedback body. Voter, snapshot and relation are set server-side. */
export interface VoteRequest {
  finding_key: string;
  verdict: Verdict;
  reason_codes: string[];
  savings_assessment: SavingsAssessment | null;
  free_text: string | null;
  snooze_days: 30 | 90 | null;
  channel: "app" | "email_link";
  client_request_id: string; // one uuid per click (idempotency)
}

/** One stored row of the StopTheLeak ops.feedback table. */
export interface Vote {
  feedback_id: string;
  supersedes_id: string | null;
  finding_key: string;
  observation_date: string;
  rule_id: string;
  voter_email: string;
  voter_relation: "object_owner" | "workspace_owner" | "other";
  channel: "app" | "genie" | "email_link";
  verdict: Verdict;
  reason_codes: string[];
  savings_assessment: SavingsAssessment | null;
  free_text: string | null;
  snooze_until: string | null;
  created_at: string;
}

export interface EmailPreference {
  email: string;
  weekly_email: boolean; // false = opted out
}

/** One turn's answer from the context-aware Genie chat (POST /api/genie/ask). */
export interface GenieAskResponse {
  conversation_id: string | null;
  message_id: string | null;
  text: string;
  query: string | null;
  columns: string[];
  rows: unknown[][];
  truncated: boolean;
  error: string | null;
}

/** Context the chat sends so answers resolve against the current page. */
export interface GenieAskRequest {
  question: string;
  conversation_id?: string | null;
  workspace_id?: string | null;
  workspace_name?: string | null;
  resource_type?: string | null;
  resource_id?: string | null;
  resource_name?: string | null;
}

export interface WorkspaceSummary {
  workspace_id: string;
  workspace_name: string | null;
  monthly_savings_usd: number; // booked floor
  monthly_savings_addressable_usd: number; // booked + estimated — what the leaderboard ranks/shows
  monthly_waste_usd: number;
  recommendation_count: number;
  top_rule_id: string | null;
  top_category: string | null;
  monthly_savings_addressable_contract_usd?: number | null; // the estimate at "Your rates" (blended)
}

// The headline at "Your rates" (blended: contract where a finding has one, list
// otherwise) + the separate cloud-VM layer. Composed per spend scope like the list
// headline. Null on the parent when the snapshot has no contract / cloud data.
export interface PricedTotals {
  contract_available: boolean;
  monthly_savings_usd: number;
  monthly_savings_addressable_usd: number;
  monthly_savings_low_usd: number;
  monthly_savings_high_usd: number;
  contract_part_usd: number;
  list_part_usd: number;
  contract_findings: number;
  list_findings: number;
  cloud_available: boolean;
  monthly_cloud_savings_usd: number;
  cloud_findings: number;
  classic_findings: number;
}

// One slice of the headline estimate by trust tier — booked, or an estimated
// finding's high/medium/low confidence. Composed so the tiers sum to the estimate.
export interface SavingsTier {
  tier: "booked" | "high" | "medium" | "low";
  monthly_savings_usd: number;
}

export interface AccountOverview {
  total_monthly_savings_usd: number; // booked lower bound (bookable findings' low)
  total_monthly_savings_addressable_usd: number; // fuller estimated opportunity (>= booked) — the headline
  total_monthly_savings_low_usd: number; // conservative low of the estimate band
  total_monthly_savings_high_usd: number; // upper-scenario high of the estimate band
  savings_tiers: SavingsTier[]; // the estimate split by tier (sums to addressable)
  total_monthly_waste_usd: number;
  recommendation_count: number;
  workspace_count: number;
  workspaces: WorkspaceSummary[];
  priced?: PricedTotals | null;
}

// Tagging & Chargeback tab (see backend/finops/models/tagging.py). Governance-
// category findings relocated off the main surfaces: they carry $0 savings and
// measure UNATTRIBUTABLE spend instead, so the headline is the size of the
// governance gap, not a savings figure. Deliberately excluded from every other
// count (recommendation total, NBA, savings leaderboard).
export interface TaggingOverview {
  total_unattributable_monthly_usd: number;
  recommendation_count: number;
  workspace_count: number;
  items: Recommendation[];
}

// Labs / Experimental tab (see backend/finops/models/experimental.py). Phase 4
// net-new opportunity rules, still being validated: relocated off the main surfaces
// so they never touch the headline, the NBA ranking or the savings leaderboard.
// They are advisory ($0 booked) — the headline is ADDRESSABLE spend, not a saving.
export interface ExperimentalOverview {
  /** Each spend pool counted once (two rules on one resource don't double it). */
  total_addressable_monthly_usd: number;
  recommendation_count: number;
  /** Distinct resources behind the findings. Absent from an older backend. */
  resource_count?: number;
  rule_count: number;
  workspace_count: number;
  items: Recommendation[];
}

// Evidence viz payloads for the experimental rules (see rules/finops_rules/evidence.py).
export interface SqlFailuresViz {
  kind: "sql_failures";
  days: { d: string; t: number; f: number }[];
  lookback_days: number;
  fail_rate: number;
  failed_queries: number;
  total_queries: number;
  failed_compute_share: number;
  addressable_monthly_usd: number;
  top_failed_statement: string | null;
  top_failed_count: number;
  distinct_failed_shapes: number;
}

export interface SqlMaintenanceViz {
  kind: "sql_maintenance";
  days: { d: string; o: number; v: number }[];
  lookback_days: number;
  optimize_runs: number;
  vacuum_runs: number;
  maintenance_compute_share: number;
  addressable_monthly_usd: number;
}

// D — AI Gateway wasted inference (operational). Per-day failed vs total requests.
export interface AiGatewayErrorsViz {
  kind: "ai_gateway_errors";
  days: { d: string; t: number; f: number }[];
  lookback_days: number;
  error_rate: number;
  failed_requests: number;
  total_requests: number;
  server_errors: number;
  failed_input_tokens: number;
  top_status_code: number | null;
  top_status_count: number;
}

// C — Pipeline failed updates. Per-day failed vs total updates.
export interface PipelineFailuresViz {
  kind: "pipeline_failures";
  days: { d: string; t: number; f: number }[];
  lookback_days: number;
  fail_rate: number;
  failed_updates: number;
  total_updates: number;
  failed_compute_share: number;
  addressable_monthly_usd: number;
  failed_requests: number;
}

// G — Instance-pool warm standby (operational). Per-day launched vs acquired.
export interface InstancePoolViz {
  kind: "instance_pool";
  days: { d: string; l: number; a: number }[];
  lookback_days: number;
  min_idle_instances: number;
  idle_autotermination_minutes: number | null;
  launches: number;
  acquisitions: number;
  node_type: string;
}

// F — Delta Sharing re-materialization (operational). Per-day materialization count.
export interface SharingMaterializationViz {
  kind: "sharing_materialization";
  days: { d: string; n: number }[];
  lookback_days: number;
  materializations: number;
  distinct_tables: number;
  distinct_recipients: number;
}

// H — Storage / Predictive Optimization churn (operational). Per-day PO DBUs.
export interface StoragePoViz {
  kind: "storage_po";
  days: { d: string; n: number }[];
  lookback_days: number;
  po_dbus: number;
  operations: number;
  compaction_dbus: number;
  clustering_dbus: number;
  vacuum_dbus: number;
  top_operation: string | null;
}

// --- total spend (see backend/finops/models/spend.py) ---
// What the platform COSTS, as opposed to what a rule thinks is recoverable. Read
// from the precomputed spend snapshot, or a live billing aggregate as fallback.
export interface SkuSpend {
  sku_group: string;
  spend_usd: number;
  dbus: number;
}
export interface SpendDay {
  usage_date: string;
  spend_usd: number;
  dbus: number;
}
export interface WorkspaceSpend {
  workspace_id: string;
  workspace_name: string | null;
  lookback_days: number;
  total_spend_usd: number;
  monthly_spend_usd: number;
  total_dbus: number;
  serverless_spend_usd: number;
  classic_spend_usd: number;
  // Contract pricing when account has system.billing.account_prices data
  monthly_spend_contract_usd?: number | null; // blended: contract where available, list otherwise
  contract_priced_share?: number | null; // 0-1 share priced at contract rates
  monthly_cloud_cost_usd?: number | null; // classic VM cost
  by_sku: SkuSpend[];
  /** Day-by-day spend, oldest first. Empty when the snapshot predates the column. */
  by_day: SpendDay[];
}
export interface AccountSpend {
  total_monthly_spend_usd: number;
  total_serverless_spend_usd: number;
  total_classic_spend_usd: number;
  workspace_count: number;
  // Workspaces that billed in the window but sit outside this workspace's region,
  // so their spend is excluded from the totals. 0 for a workspace-scoped user.
  out_of_scope_workspaces: number;
  lookback_days: number;
  // true => no spend data could be read; the UI omits the figure rather than
  // rendering a misleading $0.
  unavailable: boolean;
  // Contract pricing when account has system.billing.account_prices data
  total_monthly_spend_contract_usd?: number | null; // blended: contract where available, list otherwise
  contract_priced_share?: number | null; // 0-1 share priced at contract rates
  total_monthly_cloud_cost_usd?: number | null; // classic VM cost
  workspaces: WorkspaceSpend[];
  by_sku: SkuSpend[];
  /** Account-wide daily spend (every workspace summed per day). */
  by_day: SpendDay[];
}

/** Pricing capability and metadata from GET /api/pricing. */
export interface PricingSummary {
  /** true => system.billing.account_prices has contract prices for this account. */
  contract_available: boolean;
  /** Null until at least one finding has been priced; account-level coverage. */
  contract_coverage_account: number | null;
  /** Count of findings currently priced at contract rates. */
  contract_findings: number;
  /** Count of findings that had no contract price (fell back to list). */
  list_fallback_findings: number;
  /** true => system.billing.cloud_infra_cost has data for this account. */
  cloud_available: boolean;
  /** Count of findings with cloud VM cost data. */
  cloud_findings: number;
  /** The currency findings are priced in (e.g. "USD"). */
  cloud_currency: string;
  /** Recommended default basis: 'contract' if coverage >= 95%, else 'list'. */
  default_basis: "contract" | "list";
}

// --- About Serverless (see backend/finops/models/serverless.py) ---
// Framed as classes of operational work serverless removes, each backed by this
// account's measured evidence.
export interface ServerlessIssueExample {
  resource_type: string;
  resource_id: string;
  resource_name: string;
  workspace_id: string;
  workspace_name: string | null;
  detail: string;
  monthly_savings_usd: number;
  group_id: string | null;
}
export interface ServerlessIssue {
  key: string;
  title: string;
  problem: string;
  serverless_answer: string;
  resource_count: number;
  monthly_savings_usd: number;
  evidence_note: string;
  examples: ServerlessIssueExample[];
}
export interface ServerlessReadiness {
  serverless_spend_usd: number;
  classic_spend_usd: number;
  serverless_share: number; // 0..1 of spend already serverless
  spend_available: boolean;
}
export interface DbrVersionFact {
  version: string;
  cluster_count: number;
  spend_usd: number;
}
export interface ServerlessFleet {
  lookback_days?: number;
  distinct_dbr_versions?: number;
  dbr_versions?: DbrVersionFact[];
  startup?: {
    total_queries: number;
    queries_waiting: number;
    waiting_share: number;
    total_wait_minutes: number;
    p50_wait_s: number;
    p95_wait_s: number;
    max_wait_s: number;
  };
  autoscale?: {
    clusters_scaling: number;
    resize_events: number;
    resize_hours: number;
  };
}
export interface ServerlessCase {
  total_monthly_savings_usd: number;
  affected_resource_count: number;
  workspace_count: number;
  lookback_days: number;
  readiness: ServerlessReadiness;
  issues: ServerlessIssue[];
  fleet: ServerlessFleet;
}

export interface CategoryBreakdown {
  category: string;
  monthly_savings_usd: number;
  recommendation_count: number;
}

export interface WorkspaceDetail {
  workspace_id: string;
  workspace_name: string | null;
  monthly_savings_usd: number; // booked lower bound
  monthly_savings_addressable_usd: number; // fuller estimated opportunity (>= booked) — the headline
  monthly_savings_low_usd: number;
  monthly_savings_high_usd: number;
  savings_tiers: SavingsTier[];
  monthly_waste_usd: number;
  recommendation_count: number;
  by_category: CategoryBreakdown[];
  priced?: PricedTotals | null;
}

export interface RuleMeta {
  id: string;
  version: string;
  title: string;
  category: string;
  resource_type: string;
  enabled: boolean;
  thresholds: Record<string, unknown>;
}

// --- Genie costs -------------------------------------------------------------
// Analysis-only: Genie spend never becomes a recommendation, so none of these
// carry savings, effort or NBA fields. Mirrors backend/finops/models/genie.py.
export interface GenieSurfaceUse {
  surface: string;
  channel: string;
  dbus: number;
}
export interface GenieUser {
  principal: string;
  workspace_id: string | null;
  workspace_name: string | null;
  free_dbus: number;
  paid_dbus: number;
  spend_usd: number;
  monthly_spend_usd: number;
  active_days: number;
  last_active_date: string | null;
  by_surface: GenieSurfaceUse[];
}
export interface GenieSurface {
  surface: string;
  surface_label: string;
  channel: string;
  is_free: boolean;
  dbus: number;
  spend_usd: number;
  users: number;
}
export interface GenieSpace {
  space_id: string;
  workspace_id: string | null;
  workspace_name: string | null;
  workspace_url: string | null;
  dbus: number;
  spend_usd: number;
  monthly_spend_usd: number;
  users: number;
  active_days: number;
  api_share: number;
  last_active_date: string | null;
}
export interface GenieWorkspace {
  workspace_id: string;
  workspace_name: string | null;
  spend_usd: number;
  monthly_spend_usd: number;
  free_dbus: number;
  paid_dbus: number;
  users: number;
  paid_users: number;
}
export interface GenieDay {
  usage_date: string;
  free_dbus: number;
  paid_dbus: number;
  spend_usd: number;
  users: number;
}
export interface GenieFreeTier {
  total_users: number;
  free_only_users: number;
  paid_users: number;
  free_only_pct: number;
  free_dbus: number;
  paid_dbus: number;
  free_dbus_free_only_users: number;
}
export interface GenieCosts {
  lookback_days: number;
  total_spend_usd: number;
  monthly_spend_usd: number;
  total_dbus: number;
  workspace_count: number;
  unavailable: boolean;
  no_usage: boolean;
  /** Aggregates that could not be read (e.g. a live query over its time budget).
   *  The sections they feed are empty for a reason worth stating. */
  missing_sections: string[];
  free_tier: GenieFreeTier;
  top_users: GenieUser[];
  workspaces: GenieWorkspace[];
  surfaces: GenieSurface[];
  spaces: GenieSpace[];
  daily: GenieDay[];
  /** The paid surface that dominates the bill (usually Genie Code) and its share
   *  of total paid spend, read from the surface breakdown. null when nothing is paid. */
  top_paid_surface_label: string | null;
  top_paid_surface_pct: number;
  /** Central mode: per-user/per-space attribution unavailable on central data. */
  central_note: string;
  space_coverage_note: string;
  budgets_note: string;
  data_basis: string;
}

// ---------------------------------------------------------------------------
// Databricks Apps inventory (/api/apps) — visibility WITHOUT recommendations.
//
// Deliberately carries no savings, priority or NBA field, and that is a data limit
// rather than an omission: system tables have no app request/page-view log (only
// lifecycle events), so app idleness is unknowable and any "shut this down" or
// "rightsize this" claim would be a guess. `analysis_note` explains that in the UI.
// See backend/finops/data/apps_sql.py.
export interface AppInfo {
  app_id: string;
  app_name: string | null;
  workspace_id: string | null;
  workspace_name: string | null;
  workspace_url: string | null;
  /** Serverless compute size (MEDIUM / LARGE / …) — the main configuration lever. */
  compute_size: string | null;
  /** > 1 means the app was resized inside the window, so its cost spans two configs. */
  size_changes: number;
  dbus: number;
  spend_usd: number;
  monthly_spend_usd: number;
  /** Distinct days billed. Apps are always-on while running and there is no
   *  scale-to-zero, so a count below the window is a LIFECYCLE signal (it was
   *  stopped for a while), never an idleness one. */
  days_billed: number;
  observed_days: number;
  first_seen_date: string | null;
  last_billed_date: string | null;
  last_deploy_time: string | null;
  last_start_time: string | null;
  last_stop_time: string | null;
  deploys: number;
  last_deployed_by: string | null;
}
export interface AppSizeGroup {
  compute_size: string;
  apps: number;
  dbus: number;
  spend_usd: number;
  monthly_spend_usd: number;
}
export interface AppDay {
  usage_date: string;
  apps: number;
  dbus: number;
  spend_usd: number;
}
export interface AppsInventory {
  lookback_days: number;
  total_spend_usd: number;
  monthly_spend_usd: number;
  total_dbus: number;
  app_count: number;
  workspace_count: number;
  /** Apps that billed on every day of the window. Normal for apps — a fact, not a
   *  problem. */
  always_on_count: number;
  unavailable: boolean;
  no_usage: boolean;
  missing_sections: string[];
  /** Central mode: app lifecycle history unavailable (no central audit log). */
  lifecycle_note: string;
  apps: AppInfo[];
  by_size: AppSizeGroup[];
  daily: AppDay[];
  /** Why this tab shows no recommendations. Rendered verbatim. */
  analysis_note: string;
  data_basis: string;
}

// ---------------------------------------------------------------------------
// Cost anomalies (/api/anomalies) — where spend broke away from its own baseline.
//
// Like the Apps inventory this carries no savings, priority or NBA field: an
// anomaly is a question for the owner ("was this expected?"), not a saving.
// `excess_usd` is a SIZE. See backend/finops/data/anomaly_sql.py for the method.
export type AnomalyType = "spike" | "step_change" | "new_spender";
export interface CostAnomaly {
  /** "sku" (workspace × product × SKU — covers every dollar) or "resource". */
  grain: "sku" | "resource";
  anomaly_type: AnomalyType;
  anomaly_key: string;
  workspace_id: string | null;
  workspace_name: string | null;
  workspace_url: string | null;
  product: string | null;
  sku_name: string | null;
  resource_type: string | null;
  resource_id: string | null;
  resource_name: string | null;
  first_flag_date: string | null;
  last_flag_date: string | null;
  peak_date: string | null;
  flagged_days: number;
  longest_run: number;
  peak_cost_usd: number;
  baseline_median_usd: number;
  baseline_mad_usd: number;
  baseline_active_days: number;
  /** null for a new spender — no baseline to be N sigmas above. */
  robust_z: number | null;
  /** Cost above baseline over the flagged days. A size, NOT a saving. */
  excess_usd: number;
  floor_usd: number;
  eval_cost_usd: number;
  /** Daily cost over baseline + evaluation window, oldest first. */
  series: number[];
  run_as: string | null;
  owned_by: string | null;
}
export interface AnomalyDay {
  usage_date: string;
  cost_usd: number;
}
export interface AnomalyTypeCount {
  anomaly_type: AnomalyType;
  count: number;
  excess_usd: number;
}
export interface CostAnomalies {
  baseline_days: number;
  eval_days: number;
  z_threshold: number;
  min_delta_usd: number;
  min_delta_share: number;
  eval_start: string | null;
  eval_end: string | null;
  /** From the SKU grain only — the grains overlap, so never sum both. */
  total_excess_usd: number;
  anomaly_count: number;
  workspace_count: number;
  by_type: AnomalyTypeCount[];
  unavailable: boolean;
  no_anomalies: boolean;
  missing_sections: string[];
  resource_anomalies: CostAnomaly[];
  sku_anomalies: CostAnomaly[];
  daily: AnomalyDay[];
  analysis_note: string;
  method_note: string;
  data_basis: string;
}

// --- data-source health ------------------------------------------------------
// Mirrors backend/finops/models/health.py. Answers "why did a rule find nothing?"
// — the difference between "no waste" and "no permission to look".
export interface SourceHealth {
  /** schema.table, e.g. "compute.node_timeline". */
  name: string;
  status: "PASS" | "WARN" | "FAIL";
  severity: "INFO" | "MEDIUM" | "CRITICAL";
  /** A core billing table the app cannot work without. */
  required: boolean;
  message: string;
  /** Rules that cannot run while this table is unreadable. */
  blocks_rules: string[];
}
export interface RuleAvailability {
  rule_id: string;
  missing_sources: string[];
}
export interface LastRun {
  finished_at: string | null;
  /** null => still running or unknown. */
  ok: boolean | null;
  flows_ok: number;
  flows_failed: number;
  failed_flows: string[];
  rows_written: number | null;
  /** The run log itself could not be read (no table yet, or no grant). */
  unavailable: boolean;
}
export interface HealthReport {
  checked_at: string;
  catalog: string;
  compute_mode: string;
  sources: SourceHealth[];
  unavailable_rules: RuleAvailability[];
  /** Any source is unreadable. Readability only — never "the table is empty". */
  degraded: boolean;
  /** The check itself could not run; we know nothing rather than knowing it's bad. */
  unknown: boolean;
  message: string;
  /** Latest precompute run. null in live mode (nothing is precomputed). */
  last_run: LastRun | null;
}
