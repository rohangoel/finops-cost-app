import { StarIcon } from "@heroicons/react/24/solid";

export function PriorityBadge({ priority }: { priority: string }) {
  return <span className={`badge priority priority-${priority.toLowerCase()}`}>{priority}</span>;
}

export function NbaScore({ score }: { score: number }) {
  return (
    <span className="nba-score" title="Next-Best-Action score = savings ÷ effort">
      <StarIcon className="nba-star" /> {score.toFixed(0)}
    </span>
  );
}
