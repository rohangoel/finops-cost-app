import { useState } from "react";
import type { Recommendation, SavingsAssessment, Verdict, Vote } from "../api/types";
import { useCastVote } from "../hooks/useFeedback";
import {
  REASON_CODES,
  SAVINGS_ASSESSMENTS,
  SNOOZE_CHOICES,
  VERDICTS,
  newRequestId,
  voteSummary,
  type Prefill,
} from "../lib/feedback";

/** "Is this finding right?" — the vote StopTheLeak collects, cast in the app.
 *
 *  Shown only to the finding's recipient (the backend refuses anyone else too).
 *  Voting never hides the finding: it stays listed, with "You said: …" on it.
 *  With a `prefill` (a confirm link from the StopTheLeak Genie tool) the form opens
 *  with the verdict and reason filled in, but nothing is recorded until Confirm. */
export function FindingFeedback({
  rec,
  vote,
  prefill,
}: {
  rec: Recommendation;
  vote?: Vote;
  prefill?: Prefill | null;
}) {
  const [editing, setEditing] = useState(!!prefill);
  const [verdict, setVerdict] = useState<Verdict | null>(prefill?.verdict ?? null);
  const [reasons, setReasons] = useState<string[]>([]);
  const [assessment, setAssessment] = useState<SavingsAssessment | null>(null);
  const [snooze, setSnooze] = useState<30 | 90 | null>(30);
  const [text, setText] = useState(prefill?.reason ?? "");
  const cast = useCastVote();

  if (!editing) {
    return (
      <div className="feedback-box">
        {vote ? (
          <p className="feedback-said">
            <span className="feedback-said-label">You said:</span> {voteSummary(vote)}
            {vote.free_text && <span className="feedback-said-note"> “{vote.free_text}”</span>}
            <span className="faint"> · {vote.created_at.slice(0, 10)}</span>{" "}
            <button type="button" className="btn-link" onClick={() => setEditing(true)}>
              Change
            </button>
          </p>
        ) : (
          <p className="feedback-ask">
            Is this finding right?{" "}
            <button type="button" className="btn-link" onClick={() => setEditing(true)}>
              Tell us
            </button>
          </p>
        )}
      </div>
    );
  }

  const reasonChoices = verdict ? REASON_CODES[verdict] ?? [] : [];
  const toggleReason = (code: string) =>
    setReasons((r) => (r.includes(code) ? r.filter((c) => c !== code) : [...r, code]));

  const submit = () => {
    if (!verdict) return;
    cast.mutate(
      {
        finding_key: rec.finding_key,
        verdict,
        reason_codes: reasons.filter((c) => reasonChoices.some((r) => r.value === c)),
        savings_assessment: verdict === "invalid" ? assessment : null,
        free_text: text.trim() || null,
        snooze_days: verdict === "valid_cannot_fix" ? snooze : null,
        channel: prefill ? "email_link" : "app",
        client_request_id: newRequestId(),
      },
      { onSuccess: () => setEditing(false) },
    );
  };

  return (
    <div className="feedback-box feedback-form">
      <div className="action-eyebrow">Is this finding right?</div>
      {prefill && (
        <p className="muted small">
          Filled in from your link. Check it, then press Confirm to record it.
        </p>
      )}
      <div className="reason-list" role="radiogroup" aria-label="Verdict">
        {VERDICTS.map((v) => (
          <label key={v.value} className={`reason${verdict === v.value ? " sel" : ""}`}>
            <input
              type="radio"
              name={`verdict-${rec.finding_key}`}
              checked={verdict === v.value}
              onChange={() => {
                setVerdict(v.value);
                setReasons([]);
              }}
            />
            <span className="reason-label">{v.label}</span>
            <span className="muted small">{v.hint}</span>
          </label>
        ))}
      </div>

      {reasonChoices.length > 0 && (
        <fieldset className="feedback-fieldset">
          <legend>Why?</legend>
          <div className="feedback-chips">
            {reasonChoices.map((r) => (
              <label key={r.value} className={`feedback-chip${reasons.includes(r.value) ? " sel" : ""}`}>
                <input
                  type="checkbox"
                  checked={reasons.includes(r.value)}
                  onChange={() => toggleReason(r.value)}
                />
                {r.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {verdict === "invalid" && (
        <fieldset className="feedback-fieldset">
          <legend>Is the $ figure…</legend>
          <div className="feedback-chips">
            {SAVINGS_ASSESSMENTS.map((a) => (
              <label key={a.value} className={`feedback-chip${assessment === a.value ? " sel" : ""}`}>
                <input
                  type="radio"
                  name={`assess-${rec.finding_key}`}
                  checked={assessment === a.value}
                  onChange={() => setAssessment(a.value)}
                />
                {a.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {verdict === "valid_cannot_fix" && (
        <fieldset className="feedback-fieldset">
          <legend>Remind me</legend>
          <div className="feedback-chips">
            {SNOOZE_CHOICES.map((c) => (
              <label key={String(c.value)} className={`feedback-chip${snooze === c.value ? " sel" : ""}`}>
                <input
                  type="radio"
                  name={`snooze-${rec.finding_key}`}
                  checked={snooze === c.value}
                  onChange={() => setSnooze(c.value)}
                />
                {c.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {/* Plain textarea value: a prefilled reason from a link is shown as text,
          never interpreted as markup. */}
      <textarea
        className="note-input"
        placeholder="Anything else? (optional)"
        maxLength={2000}
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      {cast.error && <p className="error small">Couldn't save: {String(cast.error.message)}</p>}
      <div className="modal-actions">
        <button type="button" className="btn-secondary" onClick={() => setEditing(false)}>
          Cancel
        </button>
        <button
          type="button"
          className="btn-primary"
          disabled={!verdict || cast.isPending}
          onClick={submit}
        >
          {cast.isPending ? "Saving…" : "Confirm"}
        </button>
      </div>
    </div>
  );
}
