/**
 * A finding's (or resource group's) savings on the selected price basis — the
 * component every savings cell renders through, so the "List price | Your rates"
 * switch applies everywhere (lib/price.ts is the arithmetic behind it).
 *
 * In "Your rates" mode a figure that has no contract price stays at list and carries
 * a small LIST marker; cloud-VM savings appear as their own sub-line, never added in.
 */

import type { Recommendation, RecommendationGroup } from "../api/types";
import { moneyExact } from "../lib/format";
import { savingsFor } from "../lib/price";
import { usePricingContext } from "../lib/PricingContext";

const LIST_MARKER_TITLE =
  "No contract price for all of this resource's usage, so this figure stays at list price.";

export function ListMarker() {
  return (
    <span className="list-marker" title={LIST_MARKER_TITLE}>
      list
    </span>
  );
}

export function CloudSubline({ usd }: { usd: number | null | undefined }) {
  if (usd == null || usd <= 0.005) return null;
  return (
    <div className="cloud-subline" title="Classic cloud VM cost this change also removes (billed by your cloud provider, not Databricks). Not included in the figure above.">
      + {moneyExact(usd)} cloud VM
    </div>
  );
}

export function PricedAmount({
  rec,
  suffix = "",
  className = "strong savings-text",
  showCloud = false,
}: {
  rec: Recommendation;
  suffix?: string;
  className?: string;
  showCloud?: boolean;
}) {
  const { basis } = usePricingContext();
  const s = savingsFor(rec, basis);
  return (
    <>
      <span className={className}>
        {moneyExact(s.value)}
        {suffix}
      </span>
      {s.fellBack && <ListMarker />}
      {showCloud && <CloudSubline usd={rec.monthly_cloud_savings_usd} />}
    </>
  );
}

/** A resource group's composed savings on the selected basis. */
export function groupSavings(g: RecommendationGroup, basis: "list" | "contract") {
  const contract = basis === "contract" && g.monthly_savings_contract_usd != null;
  return {
    value: contract ? (g.monthly_savings_contract_usd as number) : g.monthly_savings_usd,
    // Some option on the resource has no contract figure → part of this is at list.
    fellBack: basis === "contract" && g.price_basis === "list",
  };
}

export function PricedGroupAmount({
  group,
  suffix = "",
  className = "strong savings-text",
  showCloud = false,
}: {
  group: RecommendationGroup;
  suffix?: string;
  className?: string;
  showCloud?: boolean;
}) {
  const { basis } = usePricingContext();
  const s = groupSavings(group, basis);
  return (
    <>
      <span className={className}>
        {moneyExact(s.value)}
        {suffix}
      </span>
      {s.fellBack && <ListMarker />}
      {showCloud && <CloudSubline usd={group.monthly_cloud_savings_usd} />}
    </>
  );
}

/** Detail page: BOTH bases side by side, whatever the switch says —
 *  "List $1,240/mo · Your rate $967/mo (−22%)". Renders nothing without contract data. */
export function DualPrice({ rec }: { rec: Recommendation }) {
  const { pricing } = usePricingContext();
  if (!pricing?.contract_available || rec.price_basis == null) return null;
  const list = rec.monthly_savings_usd;
  const contract = rec.price_basis === "contract" ? rec.monthly_savings_contract_usd : null;
  return (
    <div className="dual-price">
      <span>
        <span className="dp-label">List</span> <strong>{moneyExact(list)}/mo</strong>
      </span>
      {contract != null ? (
        <span>
          <span className="dp-label">Your rate</span> <strong>{moneyExact(contract)}/mo</strong>
          {list > 0 && (
            <span className="dp-delta"> ({Math.round(((contract - list) / list) * 100)}%)</span>
          )}
        </span>
      ) : (
        <span className="dp-label">
          Your rate: not available — {rec.contract_price_coverage != null
            ? `only ${Math.round(rec.contract_price_coverage * 100)}% of this resource's usage has a contract price`
            : "no contract price for this resource"}
        </span>
      )}
    </div>
  );
}
