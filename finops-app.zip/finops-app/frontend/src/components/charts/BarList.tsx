import { money } from "../../lib/format";

export interface BarItem {
  key: string;
  label: string;
  value: number;
  onClick?: () => void;
}

/** Horizontal ranked bar list (workspace leaderboard, savings-by-rule, …). */
export function BarList({ items, max }: { items: BarItem[]; max?: number }) {
  const top = max ?? Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="barlist">
      {items.map((it) => (
        <div
          className="barlist-row"
          key={it.key}
          onClick={it.onClick}
          role={it.onClick ? "button" : undefined}
          style={{ cursor: it.onClick ? "pointer" : "default" }}
        >
          <span className="barlist-name">{it.label}</span>
          <span className="barlist-val savings-text">{money(it.value)}</span>
          <div className="barlist-track">
            <div
              className="barlist-fill"
              style={{ width: `${Math.max(2, (it.value / top) * 100)}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
