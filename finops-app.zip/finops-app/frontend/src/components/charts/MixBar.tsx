import type { Slice } from "../../lib/breakdown";
import { money } from "../../lib/format";

/** A single stacked bar + legend — used for the effort / priority mix. */
export function MixBar({ slices, unit = "savings" }: { slices: Slice[]; unit?: string }) {
  const total = slices.reduce((s, x) => s + x.value, 0) || 1;
  return (
    <div>
      <div className="mixbar">
        {slices.map((s) => (
          <div
            key={s.key}
            className="mixbar-seg"
            style={{ width: `${(s.value / total) * 100}%`, background: s.color }}
            title={`${s.label}: ${money(s.value)} (${s.count})`}
          />
        ))}
      </div>
      <div className="mix-legend">
        {slices.map((s) => (
          <div className="mix-legend-row" key={s.key}>
            <span className="legend-dot" style={{ background: s.color }} />
            <span style={{ textTransform: "capitalize" }}>{s.label}</span>
            <span className="strong">{money(s.value)}</span>
            <span className="faint">· {s.count}</span>
          </div>
        ))}
      </div>
      <div className="faint small" style={{ marginTop: 4 }}>
        by {unit}
      </div>
    </div>
  );
}
