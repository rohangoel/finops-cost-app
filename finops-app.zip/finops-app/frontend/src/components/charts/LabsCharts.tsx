// Per-day charts first built for the Labs (experimental) rules. They live here,
// not in pages/Labs.tsx, because a rule promoted to the main surfaces keeps its
// chart: UsageTimeline dispatches the same kinds on the detail page.
import type { ReactNode } from "react";
import type {
  AiGatewayErrorsViz,
  InstancePoolViz,
  PipelineFailuresViz,
  SharingMaterializationViz,
  SqlFailuresViz,
  SqlMaintenanceViz,
  StoragePoViz,
} from "../../api/types";
import { moneyExact } from "../../lib/format";

export type LabsViz =
  | SqlFailuresViz
  | SqlMaintenanceViz
  | AiGatewayErrorsViz
  | PipelineFailuresViz
  | InstancePoolViz
  | SharingMaterializationViz
  | StoragePoViz;

export const LABS_VIZ_KINDS: ReadonlySet<string> = new Set([
  "sql_failures",
  "sql_maintenance",
  "ai_gateway_errors",
  "pipeline_failures",
  "instance_pool",
  "sharing_materialization",
  "storage_po",
]);

export function LabsChart({ viz }: { viz: LabsViz }) {
  switch (viz.kind) {
    case "sql_failures":
      return <SqlFailuresChart v={viz} />;
    case "sql_maintenance":
      return <SqlMaintenanceChart v={viz} />;
    case "ai_gateway_errors":
      return <AiGatewayErrorsChart v={viz} />;
    case "pipeline_failures":
      return <PipelineFailuresChart v={viz} />;
    case "instance_pool":
      return <InstancePoolChart v={viz} />;
    case "sharing_materialization":
      return <SharingMaterializationChart v={viz} />;
    case "storage_po":
      return <StoragePoChart v={viz} />;
    default:
      return null;
  }
}

// Shared axis geometry for the two per-day bar charts below.
const CW = 860, CH = 200, PADL = 30, PADR = 12, PADB = 34, PADT = 14;

function dayTicks(days: { d: string }[]) {
  const n = days.length;
  const iw = CW - PADL - PADR;
  const bw = iw / Math.max(n, 1);
  const count = Math.min(6, Math.max(n - 1, 1));
  return Array.from({ length: count + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / Math.max(count, 1));
    const dt = new Date((days[i]?.d ?? "") + "T00:00:00");
    return { x: PADL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });
}

// A. sql_repeated_failures — per-day failed (red) under total (grey) query bars, so
// the recurring wall of failures reads at a glance; callout states the compute share.
function SqlFailuresChart({ v }: { v: SqlFailuresViz }) {
  const iw = CW - PADL - PADR, ih = CH - PADB - PADT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxT = Math.max(1, ...v.days.map((d) => d.t));
  const y = (r: number) => PADT + ih * (1 - Math.min(r, maxT) / maxT);
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${CW} ${CH}`} className="ut-svg" role="img"
        aria-label="Queries per day split into failed and total">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={PADL} y1={y(maxT * g)} x2={PADL + iw} y2={y(maxT * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={PADL - 6} y={y(maxT * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxT * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = PADL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const totTop = y(d.t), base = y(0), failTop = y(d.f);
          return (
            <g key={d.d}>
              <rect x={x} y={totTop} width={w} height={base - totTop} fill="var(--info)"
                opacity={0.28} rx={1}>
                <title>{`${d.d}: ${d.t} queries`}</title>
              </rect>
              {d.f > 0 && (
                <rect x={x} y={failTop} width={w} height={base - failTop} fill="var(--danger, var(--warn))" rx={1}>
                  <title>{`${d.d}: ${d.f} failed`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={PADL} y1={y(0)} x2={PADL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {dayTicks(v.days).map((t, i) => (
          <text key={i} x={t.x} y={CH - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="muted small" style={{ marginTop: 4 }}>
        {(v.fail_rate * 100).toFixed(0)}% of {v.total_queries.toLocaleString()} queries failed ·{" "}
        {(v.failed_compute_share * 100).toFixed(0)}% of Spark task-time ·{" "}
        ~{moneyExact(v.addressable_monthly_usd)}/mo addressable
        {v.top_failed_count > 1 && (
          <>
            {" "}· most-repeated failing query ran {v.top_failed_count.toLocaleString()}×
          </>
        )}
      </p>
    </div>
  );
}

// B. manual_maintenance_overlap — per-day OPTIMIZE + VACUUM statement counts, so a
// recurring maintenance cadence is visible; callout states the compute share.
function SqlMaintenanceChart({ v }: { v: SqlMaintenanceViz }) {
  const iw = CW - PADL - PADR, ih = CH - PADB - PADT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxV = Math.max(1, ...v.days.map((d) => d.o + d.v));
  const y = (r: number) => PADT + ih * (1 - Math.min(r, maxV) / maxV);
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${CW} ${CH}`} className="ut-svg" role="img"
        aria-label="OPTIMIZE and VACUUM statements per day">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={PADL} y1={y(maxV * g)} x2={PADL + iw} y2={y(maxV * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={PADL - 6} y={y(maxV * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxV * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = PADL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const optTop = y(d.o), base = y(0), topTop = y(d.o + d.v);
          return (
            <g key={d.d}>
              {d.o > 0 && (
                <rect x={x} y={optTop} width={w} height={base - optTop} fill="var(--info)" opacity={0.85} rx={1}>
                  <title>{`${d.d}: ${d.o} OPTIMIZE`}</title>
                </rect>
              )}
              {d.v > 0 && (
                <rect x={x} y={topTop} width={w} height={optTop - topTop} fill="var(--accent, var(--warn))" opacity={0.8} rx={1}>
                  <title>{`${d.d}: ${d.v} VACUUM`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={PADL} y1={y(0)} x2={PADL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {dayTicks(v.days).map((t, i) => (
          <text key={i} x={t.x} y={CH - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="muted small" style={{ marginTop: 4 }}>
        {v.optimize_runs.toLocaleString()} OPTIMIZE · {v.vacuum_runs.toLocaleString()} VACUUM ·{" "}
        {(v.maintenance_compute_share * 100).toFixed(0)}% of Spark task-time ·{" "}
        ~{moneyExact(v.addressable_monthly_usd)}/mo addressable
      </p>
    </div>
  );
}

// Shared "failed (red) under total (grey)" per-day bar chart, reused by the AI-gateway
// and pipeline failure rules (both carry days as { d, t, f }). `footer` states the
// per-rule callout under the chart.
function FailedTotalChart({
  days,
  ariaLabel,
  footer,
}: {
  days: { d: string; t: number; f: number }[];
  ariaLabel: string;
  footer: ReactNode;
}) {
  const iw = CW - PADL - PADR, ih = CH - PADB - PADT;
  const n = days.length;
  const bw = iw / Math.max(n, 1);
  const maxT = Math.max(1, ...days.map((d) => d.t));
  const y = (r: number) => PADT + ih * (1 - Math.min(r, maxT) / maxT);
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${CW} ${CH}`} className="ut-svg" role="img" aria-label={ariaLabel}>
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={PADL} y1={y(maxT * g)} x2={PADL + iw} y2={y(maxT * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={PADL - 6} y={y(maxT * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxT * g)}
            </text>
          </g>
        ))}
        {days.map((d, i) => {
          const x = PADL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const totTop = y(d.t), base = y(0), failTop = y(d.f);
          return (
            <g key={d.d}>
              <rect x={x} y={totTop} width={w} height={base - totTop} fill="var(--info)" opacity={0.28} rx={1}>
                <title>{`${d.d}: ${d.t}`}</title>
              </rect>
              {d.f > 0 && (
                <rect x={x} y={failTop} width={w} height={base - failTop} fill="var(--danger, var(--warn))" rx={1}>
                  <title>{`${d.d}: ${d.f} failed`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={PADL} y1={y(0)} x2={PADL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {dayTicks(days).map((t, i) => (
          <text key={i} x={t.x} y={CH - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="muted small" style={{ marginTop: 4 }}>{footer}</p>
    </div>
  );
}

// Single-series per-day bar chart, reused by the operational count/DBU rules (Delta
// Sharing, storage/PO). `days` carry { d, n }. `optRefLine` draws a dashed reference
// line (used by the instance-pool warm floor via a small wrapper below).
function SingleBars({
  days,
  ariaLabel,
  color,
  footer,
  fmt = (n) => String(n),
}: {
  days: { d: string; n: number }[];
  ariaLabel: string;
  color: string;
  footer: ReactNode;
  fmt?: (n: number) => string;
}) {
  const iw = CW - PADL - PADR, ih = CH - PADB - PADT;
  const n = days.length;
  const bw = iw / Math.max(n, 1);
  const maxN = Math.max(1, ...days.map((d) => d.n));
  const y = (r: number) => PADT + ih * (1 - Math.min(r, maxN) / maxN);
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${CW} ${CH}`} className="ut-svg" role="img" aria-label={ariaLabel}>
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={PADL} y1={y(maxN * g)} x2={PADL + iw} y2={y(maxN * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={PADL - 6} y={y(maxN * g) + 3} className="ut-ax" textAnchor="end">
              {fmt(Math.round(maxN * g))}
            </text>
          </g>
        ))}
        {days.map((d, i) => {
          const x = PADL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const top = y(d.n), base = y(0);
          return (
            <rect key={d.d} x={x} y={top} width={w} height={base - top} fill={color} opacity={0.8} rx={1}>
              <title>{`${d.d}: ${fmt(d.n)}`}</title>
            </rect>
          );
        })}
        <line x1={PADL} y1={y(0)} x2={PADL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {dayTicks(days).map((t, i) => (
          <text key={i} x={t.x} y={CH - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="muted small" style={{ marginTop: 4 }}>{footer}</p>
    </div>
  );
}

// D. ai_gateway_wasted_inference — per-day failed (red) under total (grey) requests.
function AiGatewayErrorsChart({ v }: { v: AiGatewayErrorsViz }) {
  return (
    <FailedTotalChart
      days={v.days}
      ariaLabel="AI-gateway requests per day split into failed and total"
      footer={
        <>
          {(v.error_rate * 100).toFixed(0)}% of {v.total_requests.toLocaleString()} requests failed
          {v.server_errors > 0 && <> · {v.server_errors.toLocaleString()} 5xx</>}
          {v.failed_input_tokens > 0 && <> · ~{v.failed_input_tokens.toLocaleString()} tokens wasted</>}
          {v.top_status_code && v.top_status_count > 1 && (
            <> · most common: HTTP {v.top_status_code} ({v.top_status_count.toLocaleString()}×)</>
          )}
        </>
      }
    />
  );
}

// C. pipeline_failed_updates — per-day failed (red) under total (grey) updates.
function PipelineFailuresChart({ v }: { v: PipelineFailuresViz }) {
  return (
    <FailedTotalChart
      days={v.days}
      ariaLabel="Pipeline updates per day split into failed and total"
      footer={
        <>
          {(v.fail_rate * 100).toFixed(0)}% of {v.total_updates.toLocaleString()} updates failed ·{" "}
          {(v.failed_compute_share * 100).toFixed(0)}% of wall-time ·{" "}
          ~{moneyExact(v.addressable_monthly_usd)}/mo addressable
          {v.failed_requests > 0 && v.failed_requests < v.failed_updates && (
            <> · {v.failed_requests.toLocaleString()} retrying attempt(s)</>
          )}
        </>
      }
    />
  );
}

// G. instance_pool_idle — per-day launched (grey) with acquired (green) overlaid, and a
// dashed warm-floor (min_idle_instances) reference line so under-use reads at a glance.
function InstancePoolChart({ v }: { v: InstancePoolViz }) {
  const iw = CW - PADL - PADR, ih = CH - PADB - PADT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxN = Math.max(1, v.min_idle_instances, ...v.days.map((d) => d.l));
  const y = (r: number) => PADT + ih * (1 - Math.min(r, maxN) / maxN);
  const warmY = y(v.min_idle_instances);
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${CW} ${CH}`} className="ut-svg" role="img"
        aria-label="Instance-pool launches and cluster acquisitions per day">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={PADL} y1={y(maxN * g)} x2={PADL + iw} y2={y(maxN * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={PADL - 6} y={y(maxN * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxN * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = PADL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const base = y(0);
          return (
            <g key={d.d}>
              {d.l > 0 && (
                <rect x={x} y={y(d.l)} width={w} height={base - y(d.l)} fill="var(--info)" opacity={0.3} rx={1}>
                  <title>{`${d.d}: ${d.l} launched`}</title>
                </rect>
              )}
              {d.a > 0 && (
                <rect x={x} y={y(d.a)} width={w} height={base - y(d.a)} fill="var(--success, var(--info))" opacity={0.85} rx={1}>
                  <title>{`${d.d}: ${d.a} acquired by a cluster`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={PADL} y1={warmY} x2={PADL + iw} y2={warmY} stroke="var(--warn)" strokeWidth={1.5}
          strokeDasharray="5 4">
          <title>{`warm floor: ${v.min_idle_instances} instances kept on at all times`}</title>
        </line>
        <line x1={PADL} y1={y(0)} x2={PADL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {dayTicks(v.days).map((t, i) => (
          <text key={i} x={t.x} y={CH - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="muted small" style={{ marginTop: 4 }}>
        Warm floor {v.min_idle_instances} × {v.node_type} (dashed) ·{" "}
        {v.acquisitions.toLocaleString()} acquired by a cluster over {v.lookback_days}d ·{" "}
        {v.idle_autotermination_minutes === 0 || v.idle_autotermination_minutes == null
          ? "no idle autotermination"
          : `autoterminates after ${v.idle_autotermination_minutes}m idle`}
      </p>
    </div>
  );
}

// F. delta_sharing_materialization — per-day materialization count.
function SharingMaterializationChart({ v }: { v: SharingMaterializationViz }) {
  return (
    <SingleBars
      days={v.days}
      ariaLabel="Delta Sharing materializations per day"
      color="var(--accent, var(--info))"
      footer={
        <>
          {v.materializations.toLocaleString()} materializations over {v.lookback_days}d ·{" "}
          {v.distinct_tables.toLocaleString()} table(s) · {v.distinct_recipients.toLocaleString()} recipient(s)
        </>
      }
    />
  );
}

// H. storage_optimization_churn — per-day Predictive Optimization DBUs.
function StoragePoChart({ v }: { v: StoragePoViz }) {
  return (
    <SingleBars
      days={v.days}
      ariaLabel="Predictive Optimization DBUs per day"
      color="var(--info)"
      fmt={(n) => Number(n).toLocaleString()}
      footer={
        <>
          ~{v.po_dbus.toLocaleString()} est. DBUs across {v.operations.toLocaleString()} PO operations
          {v.top_operation && <> · mostly {v.top_operation.toLowerCase()}</>}
          {" · "}compaction {v.compaction_dbus.toLocaleString()} · clustering {v.clustering_dbus.toLocaleString()} · vacuum {v.vacuum_dbus.toLocaleString()} DBUs
        </>
      }
    />
  );
}
