import type { Slice } from "../../lib/breakdown";
import { money } from "../../lib/format";

interface Props {
  slices: Slice[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
}

/** Dependency-free SVG donut. Segment colors are CSS vars, so it follows the
 *  active theme automatically. */
export function Donut({ slices, size = 168, thickness = 22, centerLabel = "total" }: Props) {
  const total = slices.reduce((s, x) => s + x.value, 0) || 1;
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const cx = size / 2;

  let offset = 0;
  const arcs = slices.map((s) => {
    const frac = s.value / total;
    const seg = { ...s, dash: frac * c, gap: c - frac * c, rot: (offset / total) * 360 };
    offset += s.value;
    return seg;
  });

  return (
    <div className="donut-wrap">
      <div className="donut" style={{ width: size, height: size }}>
        <svg width={size} height={size} role="img" aria-label="Savings breakdown">
          <circle
            cx={cx}
            cy={cx}
            r={r}
            fill="none"
            stroke="var(--track)"
            strokeWidth={thickness}
          />
          {arcs.map((a) => (
            <circle
              key={a.key}
              cx={cx}
              cy={cx}
              r={r}
              fill="none"
              stroke={a.color}
              strokeWidth={thickness}
              strokeDasharray={`${a.dash} ${a.gap}`}
              strokeDashoffset={0}
              strokeLinecap="butt"
              transform={`rotate(${a.rot - 90} ${cx} ${cx})`}
              style={{ transition: "stroke-dasharray 0.5s ease" }}
            />
          ))}
        </svg>
        <div className="donut-center">
          <div>
            <div className="dc-value">{money(total)}</div>
            <div className="dc-label">{centerLabel}</div>
          </div>
        </div>
      </div>
      <div className="legend">
        {slices.map((s) => (
          <div className="legend-row" key={s.key}>
            <span className="legend-dot" style={{ background: s.color }} />
            <span className="legend-name">{s.label}</span>
            <span className="legend-val">{money(s.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
