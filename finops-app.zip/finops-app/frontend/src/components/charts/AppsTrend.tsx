import type { AppDay } from "../../api/types";
import { moneyExact, compactNumber } from "../../lib/format";
import { Axis, HitColumns, TrendTooltip, barX, colCenter, niceTicks, trendGeometry, useHover } from "./chartkit";

/** Daily Databricks Apps cost: spend bars + a running-app-count line.
 *
 *  Dependency-free SVG with every colour a CSS var, like the other charts here.
 *  Two encodings in one frame for the same reason as GenieTrend: the useful question
 *  is whether cost is growing because *more* apps are running (expected) or because
 *  the same apps got more expensive (a resize), and that comparison only works if
 *  both series share the same days.
 *
 *  Dual y-axis: bars are dollars (left), the count line is on its own scale (right,
 *  tinted --info). --accent = spend, --info = the count. Apps always cost money while
 *  running, so there is no free/paid split to stack — one bar per day is the story. */
export function AppsTrend({ days }: { days: AppDay[] }) {
  if (days.length === 0) {
    return <p className="muted small">No daily apps usage in this window.</p>;
  }

  const geo = trendGeometry(days.length, { rightAxis: true });
  const { padT, plotH } = geo;
  const { hovered, setHovered, dim } = useHover();

  const maxSpend = Math.max(1, ...days.map((d) => d.spend_usd));
  const maxApps = Math.max(1, ...days.map((d) => d.apps));
  const left = niceTicks(maxSpend);
  const right = niceTicks(maxApps);

  const appY = (i: number) => padT + plotH - (days[i].apps / right.niceMax) * plotH;
  const appPts = days.map((_, i) => `${colCenter(geo, i).toFixed(1)},${appY(i).toFixed(1)}`).join(" ");

  // Label only the ends and middle: 30 dates do not fit and are not worth reading
  // individually — the shape is the point.
  const ticksX = [0, Math.floor(days.length / 2), days.length - 1];

  return (
    <div>
      <div className="chart-scroll">
        <div className="chart-wrap" onMouseLeave={() => setHovered(null)}>
          <svg className="ut-svg" viewBox={`0 0 ${geo.W} ${geo.H}`} role="img" aria-label="Daily Apps spend with running app count">
            <Axis
              geo={geo}
              ticks={left.ticks}
              max={left.niceMax}
              formatLeft={(n) => `$${compactNumber(n)}`}
              right={{ ticks: right.ticks, max: right.niceMax, format: compactNumber, color: "var(--info)" }}
            />
            {days.map((d, i) => {
              const h = (d.spend_usd / left.niceMax) * plotH || 0;
              return (
                <rect
                  key={d.usage_date}
                  x={barX(geo, i)}
                  y={padT + plotH - h}
                  width={geo.barW}
                  height={Math.max(0, h)}
                  fill="var(--accent)"
                  opacity={dim(i, 0.85)}
                  rx="1.5"
                />
              );
            })}
            <polyline points={appPts} fill="none" stroke="var(--info)" strokeWidth="2" strokeLinejoin="round" />
            {hovered !== null && (
              <circle cx={colCenter(geo, hovered)} cy={appY(hovered)} r="3.4" fill="var(--info)" stroke="var(--surface)" strokeWidth="1.4" />
            )}
            {ticksX.map((i) => (
              <text
                key={i}
                x={colCenter(geo, i)}
                y={geo.H - 6}
                textAnchor={i === 0 ? "start" : i === days.length - 1 ? "end" : "middle"}
                fontSize={10}
                fill="var(--faint)"
              >
                {days[i].usage_date.slice(5)}
              </text>
            ))}
            <HitColumns geo={geo} count={days.length} onHover={setHovered} />
          </svg>
          {hovered !== null && (
            <TrendTooltip
              geo={geo}
              index={hovered}
              title={days[hovered].usage_date}
              rows={[
                { color: "var(--accent)", label: "Spend", value: moneyExact(days[hovered].spend_usd) },
                { color: "var(--info)", label: "Apps running", value: days[hovered].apps.toLocaleString() },
              ]}
            />
          )}
        </div>
      </div>

      <div className="mix-legend">
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--accent)" }} />
          <span>Daily spend</span>
        </div>
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--info)" }} />
          <span>Apps running</span>
          <span className="faint">· peak {maxApps}</span>
        </div>
      </div>
    </div>
  );
}
