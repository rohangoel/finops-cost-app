import type { SpendDay } from "../../api/types";
import { moneyExact, compactNumber } from "../../lib/format";
import { Axis, HitColumns, TrendTooltip, barX, colCenter, niceTicks, trendGeometry, useHover } from "./chartkit";

/** Daily platform spend, with a 7-day moving average.
 *
 *  A window total answers "how much"; only the series answers "is it getting
 *  worse", which is the question a platform admin actually opens this page with.
 *
 *  The moving average is the point of the second encoding. Daily Databricks spend
 *  is dominated by a weekday/weekend cycle, so consecutive bars differ by 2-3x for
 *  reasons nobody needs to act on — reading a trend off the raw bars is guesswork.
 *  A 7-day window is exactly one weekly cycle, so it cancels that seasonality and
 *  leaves the direction that matters.
 *
 *  Single y-axis: the average is dollars on the same scale as the bars, so one
 *  left axis serves both. Dependency-free SVG; --spend = spend (neutral: the bill, not an alert), --info = the
 *  derived line. Axis, gridlines and the hover layer come from ./chartkit. */
export function SpendTrend({ days }: { days: SpendDay[] }) {
  if (days.length === 0) {
    return <p className="muted small">No daily spend in this window.</p>;
  }

  const geo = trendGeometry(days.length);
  const { padT, plotH } = geo;
  const { hovered, setHovered, dim } = useHover();

  const maxSpend = Math.max(1, ...days.map((d) => d.spend_usd));
  const { ticks, niceMax } = niceTicks(maxSpend);

  // Trailing 7-day mean. Deliberately trailing (not centred): a centred window
  // would need future days and so could not reach the most recent point — the one
  // the reader cares most about.
  const avg = days.map((_, i) => {
    const from = Math.max(0, i - 6);
    const slice = days.slice(from, i + 1);
    return slice.reduce((sum, d) => sum + d.spend_usd, 0) / slice.length;
  });
  const avgY = (i: number) => padT + plotH - (avg[i] / niceMax) * plotH;
  const avgPts = avg.map((_, i) => `${colCenter(geo, i).toFixed(1)},${avgY(i).toFixed(1)}`).join(" ");

  // Label only the ends and middle: 30 dates do not fit and the shape is the point.
  const ticksX = [0, Math.floor(days.length / 2), days.length - 1];

  const total = days.reduce((sum, d) => sum + d.spend_usd, 0);
  // Direction over the window, measured on the smoothed series so a single quiet
  // Sunday at the end cannot read as a downward trend.
  const first = avg[0] || 0;
  const last = avg[avg.length - 1] || 0;
  const deltaPct = first > 0 ? ((last - first) / first) * 100 : 0;
  const rising = deltaPct > 1;
  const falling = deltaPct < -1;

  return (
    <div>
      <div className="chart-scroll">
        <div className="chart-wrap" onMouseLeave={() => setHovered(null)}>
          <svg className="ut-svg" viewBox={`0 0 ${geo.W} ${geo.H}`} role="img" aria-label="Daily platform spend with 7-day average">
            <Axis geo={geo} ticks={ticks} max={niceMax} formatLeft={(n) => `$${compactNumber(n)}`} />
            {days.map((d, i) => {
              const h = (d.spend_usd / niceMax) * plotH || 0;
              return (
                <rect
                  key={d.usage_date}
                  x={barX(geo, i)}
                  y={padT + plotH - h}
                  width={geo.barW}
                  height={Math.max(0, h)}
                  fill="var(--spend)"
                  opacity={dim(i, 0.85)}
                  rx="1.5"
                />
              );
            })}
            <polyline points={avgPts} fill="none" stroke="var(--info)" strokeWidth="2" strokeLinejoin="round" />
            {hovered !== null && (
              <circle cx={colCenter(geo, hovered)} cy={avgY(hovered)} r="3.4" fill="var(--info)" stroke="var(--surface)" strokeWidth="1.4" />
            )}
            {ticksX.map((i) => (
              <text
                key={i}
                x={colCenter(geo, i)}
                y={geo.H - 6}
                textAnchor={i === 0 ? "start" : i === days.length - 1 ? "end" : "middle"}
                fontSize={10}
                fill="var(--faint)"
              >
                {days[i].usage_date.slice(5)}
              </text>
            ))}
            <HitColumns geo={geo} count={days.length} onHover={setHovered} />
          </svg>
          {hovered !== null && (
            <TrendTooltip
              geo={geo}
              index={hovered}
              title={days[hovered].usage_date}
              rows={[
                { color: "var(--spend)", label: "Spend", value: moneyExact(days[hovered].spend_usd) },
                { color: "var(--info)", label: "7-day avg", value: moneyExact(avg[hovered]) },
              ]}
            />
          )}
        </div>
      </div>

      <div className="mix-legend">
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--spend)" }} />
          <span>Daily spend</span>
          <span className="faint">
            · ${total.toLocaleString(undefined, { maximumFractionDigits: 0 })} over {days.length} days
          </span>
        </div>
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--info)" }} />
          <span>7-day average</span>
          <span className="faint">
            ·{" "}
            {rising
              ? `trending up ${deltaPct.toFixed(0)}%`
              : falling
                ? `trending down ${Math.abs(deltaPct).toFixed(0)}%`
                : "flat"}{" "}
            across the window
          </span>
        </div>
      </div>
    </div>
  );
}
