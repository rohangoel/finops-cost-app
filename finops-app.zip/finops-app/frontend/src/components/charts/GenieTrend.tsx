import type { GenieDay } from "../../api/types";
import { compactNumber } from "../../lib/format";
import { Axis, HitColumns, TrendTooltip, barX, colCenter, niceTicks, trendGeometry, useHover } from "./chartkit";

/** Daily Genie adoption: stacked free/paid DBU bars + an active-user line.
 *
 *  Dependency-free SVG with every colour a CSS var, like the other charts here.
 *  Two encodings in one frame on purpose — the useful question is whether *paid*
 *  DBUs are growing faster than the user base (cost per user rising) or in step
 *  with it (healthy adoption), and that comparison only works if both are visible
 *  against the same days.
 *
 *  Dual y-axis: bars are DBUs (left), the user line is on its own scale (right,
 *  tinted --info to bind it to the line). The two axes carry independent round
 *  ticks; exact values come from the hover tooltip. Semantic mapping follows
 *  UsageTimeline: --savings = free (costs nothing), --accent = paid, --info = users. */
export function GenieTrend({ days }: { days: GenieDay[] }) {
  if (days.length === 0) {
    return <p className="muted small">No daily Genie usage in this window.</p>;
  }

  const geo = trendGeometry(days.length, { rightAxis: true });
  const { padT, plotH } = geo;
  const { hovered, setHovered, dim } = useHover();

  const maxDbu = Math.max(1, ...days.map((d) => d.free_dbus + d.paid_dbus));
  const maxUsers = Math.max(1, ...days.map((d) => d.users));
  const left = niceTicks(maxDbu);
  const right = niceTicks(maxUsers);

  const userY = (i: number) => padT + plotH - (days[i].users / right.niceMax) * plotH;
  const userPts = days.map((_, i) => `${colCenter(geo, i).toFixed(1)},${userY(i).toFixed(1)}`).join(" ");

  // Label only the ends and middle: 30 dates do not fit and are not worth reading
  // individually — the shape is the point.
  const ticksX = [0, Math.floor(days.length / 2), days.length - 1];

  return (
    <div>
      <div className="chart-scroll">
        <div className="chart-wrap" onMouseLeave={() => setHovered(null)}>
          <svg className="ut-svg" viewBox={`0 0 ${geo.W} ${geo.H}`} role="img" aria-label="Daily Genie free and paid DBUs with active users">
            <Axis
              geo={geo}
              ticks={left.ticks}
              max={left.niceMax}
              formatLeft={compactNumber}
              right={{ ticks: right.ticks, max: right.niceMax, format: compactNumber, color: "var(--info)" }}
            />
            {days.map((d, i) => {
              const paidH = (d.paid_dbus / left.niceMax) * plotH || 0;
              const freeH = (d.free_dbus / left.niceMax) * plotH || 0;
              const paidY = padT + plotH - paidH;
              // 1.5px surface gap between the paid and free segments (only when there
              // is a paid segment to sit on), so the stack reads as two parts.
              const gap = paidH > 0.5 && freeH > 0 ? 1.5 : 0;
              const freeY = paidY - gap - freeH;
              return (
                <g key={d.usage_date}>
                  <rect x={barX(geo, i)} y={freeY} width={geo.barW} height={Math.max(0, freeH)} fill="var(--savings)" opacity={dim(i, 0.55)} />
                  <rect x={barX(geo, i)} y={paidY} width={geo.barW} height={Math.max(0, paidH)} fill="var(--accent)" opacity={dim(i, 1)} />
                </g>
              );
            })}

            <polyline points={userPts} fill="none" stroke="var(--info)" strokeWidth={2} strokeLinejoin="round" />
            {hovered !== null && (
              <circle cx={colCenter(geo, hovered)} cy={userY(hovered)} r="3.4" fill="var(--info)" stroke="var(--surface)" strokeWidth="1.4" />
            )}

            {ticksX.map((i) => (
              <text
                key={i}
                x={colCenter(geo, i)}
                y={geo.H - 6}
                textAnchor={i === 0 ? "start" : i === days.length - 1 ? "end" : "middle"}
                fontSize={10}
                fill="var(--faint)"
              >
                {days[i].usage_date.slice(5)}
              </text>
            ))}
            <HitColumns geo={geo} count={days.length} onHover={setHovered} />
          </svg>
          {hovered !== null && (
            <TrendTooltip
              geo={geo}
              index={hovered}
              title={days[hovered].usage_date}
              rows={[
                { color: "var(--accent)", label: "Paid DBUs", value: Math.round(days[hovered].paid_dbus).toLocaleString() },
                { color: "var(--savings)", label: "Free DBUs", value: Math.round(days[hovered].free_dbus).toLocaleString() },
                { color: "var(--info)", label: "Active users", value: days[hovered].users.toLocaleString() },
              ]}
            />
          )}
        </div>
      </div>

      <div className="mix-legend">
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--accent)" }} />
          <span>Paid DBUs</span>
        </div>
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--savings)", opacity: 0.55 }} />
          <span>Free DBUs</span>
        </div>
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--info)" }} />
          <span>Active users</span>
          <span className="faint">· peak {maxUsers}</span>
        </div>
      </div>
    </div>
  );
}
