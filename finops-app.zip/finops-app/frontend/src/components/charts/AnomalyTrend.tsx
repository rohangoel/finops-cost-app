import type { AnomalyDay } from "../../api/types";
import { compactNumber, moneyExact } from "../../lib/format";
import { Axis, HitColumns, TrendTooltip, barX, colCenter, niceTicks, trendGeometry, useHover } from "./chartkit";

/** Daily cost in scope over the baseline + evaluation window.
 *
 *  Same frame and hover layer as the other trend charts (chartkit). The one extra
 *  encoding is the split the whole tab is about: baseline days are drawn in the
 *  neutral --faint tone and the evaluation days (the ones scored) in --warn, with a
 *  soft band behind them, so "what is being compared with what" is visible at a
 *  glance. Individual anomalies are listed below the chart, each with its own
 *  sparkline — at account scale one resource's spike is invisible in the total. */
export function AnomalyTrend({ days, evalDays }: { days: AnomalyDay[]; evalDays: number }) {
  const geo = trendGeometry(days.length);
  const { padT, plotH, padL, bw } = geo;
  const { hovered, setHovered, dim } = useHover();

  if (days.length === 0) {
    return <p className="muted small">No daily cost in this window.</p>;
  }

  const max = Math.max(1, ...days.map((d) => d.cost_usd));
  const { ticks, niceMax } = niceTicks(max);
  const evalStart = Math.max(0, days.length - evalDays);
  const ticksX = [0, evalStart, days.length - 1];

  return (
    <div>
      <div className="chart-scroll">
        <div className="chart-wrap" onMouseLeave={() => setHovered(null)}>
          <svg className="ut-svg" viewBox={`0 0 ${geo.W} ${geo.H}`} role="img"
            aria-label="Daily cost, baseline days and the scored recent days">
            <rect
              x={padL + evalStart * bw}
              y={padT}
              width={(days.length - evalStart) * bw}
              height={plotH}
              fill="var(--warn-soft)"
              opacity={0.7}
            />
            <Axis geo={geo} ticks={ticks} max={niceMax} formatLeft={(n) => `$${compactNumber(n)}`} />
            {days.map((d, i) => {
              const h = (d.cost_usd / niceMax) * plotH || 0;
              return (
                <rect
                  key={d.usage_date}
                  x={barX(geo, i)}
                  y={padT + plotH - h}
                  width={geo.barW}
                  height={Math.max(0, h)}
                  fill={i >= evalStart ? "var(--warn)" : "var(--faint)"}
                  opacity={dim(i, i >= evalStart ? 0.9 : 0.6)}
                  rx="1.5"
                />
              );
            })}
            {ticksX.map((i, k) => (
              <text
                key={k}
                x={colCenter(geo, i)}
                y={geo.H - 6}
                textAnchor={k === 0 ? "start" : k === ticksX.length - 1 ? "end" : "middle"}
                fontSize={10}
                fill="var(--faint)"
              >
                {days[i].usage_date.slice(5)}
              </text>
            ))}
            <HitColumns geo={geo} count={days.length} onHover={setHovered} />
          </svg>
          {hovered !== null && (
            <TrendTooltip
              geo={geo}
              index={hovered}
              title={days[hovered].usage_date}
              rows={[{
                color: hovered >= evalStart ? "var(--warn)" : "var(--faint)",
                label: hovered >= evalStart ? "Cost (scored)" : "Cost (baseline)",
                value: moneyExact(days[hovered].cost_usd),
              }]}
            />
          )}
        </div>
      </div>
      <div className="mix-legend">
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--faint)" }} />
          <span>Baseline days</span>
        </div>
        <div className="mix-legend-row">
          <span className="legend-dot" style={{ background: "var(--warn)" }} />
          <span>Last {evalDays} days (scored)</span>
        </div>
      </div>
    </div>
  );
}

/** One anomaly's own series, small enough for a table cell: bars per day, the
 *  baseline median as a dashed line, scored days in --warn. Shows at a glance
 *  whether it is a spike, a step or something brand new. */
export function AnomalySparkline({
  series,
  median,
  evalDays,
}: {
  series: number[];
  median: number;
  evalDays: number;
}) {
  if (series.length === 0) return null;
  const W = 140, H = 32, pad = 2;
  const max = Math.max(1, median, ...series);
  const bw = (W - pad * 2) / series.length;
  const evalStart = Math.max(0, series.length - evalDays);
  const y = (v: number) => H - pad - (v / max) * (H - pad * 2);
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="img"
      aria-label="Daily cost: baseline then the scored days" className="anom-spark">
      <rect x={pad + evalStart * bw} y={0} width={(series.length - evalStart) * bw} height={H}
        fill="var(--warn-soft)" />
      {series.map((v, i) => (
        <rect
          key={i}
          x={pad + i * bw + bw * 0.12}
          y={y(v)}
          width={Math.max(0.8, bw * 0.76)}
          height={Math.max(0, H - pad - y(v))}
          fill={i >= evalStart ? "var(--warn)" : "var(--faint)"}
          opacity={i >= evalStart ? 0.95 : 0.55}
        />
      ))}
      {median > 0 && (
        <line x1={pad} x2={W - pad} y1={y(median)} y2={y(median)}
          stroke="var(--text-2)" strokeWidth={1} strokeDasharray="3 2" opacity={0.7} />
      )}
    </svg>
  );
}
