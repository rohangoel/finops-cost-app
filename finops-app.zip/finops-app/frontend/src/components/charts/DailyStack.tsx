// Generic charts for rules whose picture is "what happened each day" or "which
// items cost most" (evidence.viz_daily_stack / viz_ranked_bars). The payload
// carries its own title, series labels and colour tokens, so a new rule gets a
// chart from a builder call in Python instead of a new component here.
import type { DailyStackViz, RankedBarsViz, VizColor } from "../../api/types";
import { niceTicks } from "./chartkit";

export const vizColor = (c: VizColor | undefined): string =>
  c === "track" ? "var(--track)" : `var(--${c ?? "info"})`;

const fmt = (x: number) =>
  x >= 100 ? Math.round(x).toLocaleString() : x >= 10 ? x.toFixed(0) : x.toFixed(1).replace(/\.0$/, "");

export function DailyStack({ v }: { v: DailyStackViz }) {
  const W = 860, H = 232, padL = 40, padR = 12, padB = 30, padT = 30;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const rawMax = Math.max(v.ref?.value ?? 0, ...v.days.map((d) => d.v.reduce((a, b) => a + b, 0)));
  const { ticks, niceMax } = niceTicks(Math.max(rawMax, 1e-9));
  const top = niceMax || 1;
  const y = (x: number) => padT + ih * (1 - Math.min(x, top) / top);
  const markIdx = v.marker ? v.days.findIndex((d) => d.d === v.marker!.d) : -1;
  // A marker before the window (e.g. last viewed 40 days ago) pins to the left edge.
  const markBefore = v.marker && markIdx < 0 && n > 0 && v.marker.d < v.days[0].d;
  const tickCount = Math.min(6, Math.max(n - 1, 1));
  const xTicks = Array.from({ length: tickCount + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / tickCount);
    const dt = new Date((v.days[i]?.d ?? "") + "T00:00:00");
    return { x: padL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img" aria-label={v.title}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} y1={y(t)} x2={padL + iw} y2={y(t)} stroke="var(--border)"
              strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(t) + 3} className="ut-ax" textAnchor="end">{fmt(t)}</text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = padL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          let acc = 0;
          return (
            <g key={d.d}>
              {d.v.map((val, s) => {
                if (!(val > 0)) return null;
                const y0 = y(acc), y1 = y(acc + val);
                acc += val;
                return (
                  <rect key={s} x={x} y={y1} width={w} height={Math.max(y0 - y1, 0.5)}
                    fill={vizColor(v.series[s]?.color)} opacity={0.9} rx={1}>
                    <title>{`${d.d}: ${fmt(val)} ${v.unit} — ${v.series[s]?.label ?? ""}`}</title>
                  </rect>
                );
              })}
            </g>
          );
        })}
        {v.ref && (
          <g>
            <line x1={padL} y1={y(v.ref.value)} x2={padL + iw} y2={y(v.ref.value)}
              stroke="var(--savings)" strokeWidth={1.5} strokeDasharray="5 4" />
            <text x={padL + iw} y={y(v.ref.value) - 4} className="ut-ax" textAnchor="end"
              fill="var(--savings)">{v.ref.label}</text>
          </g>
        )}
        {(markIdx >= 0 || markBefore) && (() => {
          const mx = markIdx >= 0 ? padL + markIdx * bw + bw / 2 : padL;
          return (
            <g>
              <line x1={mx} y1={padT} x2={mx} y2={padT + ih} stroke="var(--savings)"
                strokeWidth={1.25} strokeDasharray="3 3" />
              <text x={mx + 4} y={padT - 8} className="ut-ax"
                textAnchor={mx > padL + iw * 0.7 ? "end" : "start"} fill="var(--savings)">
                {markBefore ? `← ${v.marker!.label} ${v.marker!.d}` : v.marker!.label}
              </text>
            </g>
          );
        })()}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {xTicks.map((t, i) => (
          <text key={i} x={t.x} y={H - 10} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
        <text x={4} y={11} className="ut-ax">{v.unit}</text>
      </svg>
      <div className="ut-legend">
        {v.series.map((s) => (
          <span key={s.label}>
            <i style={{ background: vizColor(s.color) }} /> {s.label}
          </span>
        ))}
        {v.marker && (
          <span>
            <i style={{ background: "var(--savings)" }} /> {v.marker.label}
          </span>
        )}
      </div>
      {v.note && <p className="muted small" style={{ marginTop: 4 }}>{v.note}</p>}
    </div>
  );
}

export function RankedBars({ v }: { v: RankedBarsViz }) {
  const max = Math.max(1e-9, ...v.rows.map((r) => r.value));
  return (
    <div className="ranked-bars">
      {v.rows.map((r, i) => (
        <div key={i} className="ranked-bar-row">
          <div className="ranked-bar-head">
            <span className="ranked-bar-label" title={r.label}>{r.label}</span>
            <span className="ranked-bar-value">
              {v.unit === "$/mo" ? `$${Math.round(r.value).toLocaleString()}/mo` : `${fmt(r.value)} ${v.unit}`}
            </span>
          </div>
          <div className="ranked-bar-track">
            <div className="ranked-bar-fill"
              style={{ width: `${Math.max(1.5, (r.value / max) * 100)}%`, background: vizColor(r.color) }} />
          </div>
          {r.sub && <div className="muted small">{r.sub}</div>}
        </div>
      ))}
      {v.note && <p className="muted small" style={{ marginTop: 4 }}>{v.note}</p>}
    </div>
  );
}
