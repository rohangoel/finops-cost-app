import { describe, it, expect } from "vitest";
import { niceTicks } from "./chartkit";

describe("niceTicks", () => {
  it("returns a safe default for non-positive or invalid maxes", () => {
    expect(niceTicks(0)).toEqual({ ticks: [0, 1], niceMax: 1 });
    expect(niceTicks(-5)).toEqual({ ticks: [0, 1], niceMax: 1 });
    expect(niceTicks(NaN)).toEqual({ ticks: [0, 1], niceMax: 1 });
  });

  it("rounds the ceiling up to a 1/2/5 x 10^n step and starts at zero", () => {
    // $80k spend axis -> step 20k
    expect(niceTicks(80000)).toEqual({ ticks: [0, 20000, 40000, 60000, 80000], niceMax: 80000 });
    // 804 active users -> step 500 (matches the rendered 0 / 500 / 1k)
    expect(niceTicks(804)).toEqual({ ticks: [0, 500, 1000], niceMax: 1000 });
    // 9 apps -> step 5 (matches the rendered 0 / 5 / 10)
    expect(niceTicks(9)).toEqual({ ticks: [0, 5, 10], niceMax: 10 });
    // a non-round max lifts to the next round ceiling above it
    expect(niceTicks(47)).toEqual({ ticks: [0, 20, 40, 60], niceMax: 60 });
  });

  it("never clips: the nice ceiling is >= the real max, ticks start at 0 and rise to it", () => {
    for (const m of [1, 3, 47, 99, 804, 1234, 55000, 987654]) {
      const { ticks, niceMax } = niceTicks(m);
      expect(niceMax).toBeGreaterThanOrEqual(m);
      expect(ticks[0]).toBe(0);
      expect(ticks[ticks.length - 1]).toBe(niceMax);
      for (let i = 1; i < ticks.length; i++) {
        expect(ticks[i]).toBeGreaterThan(ticks[i - 1]);
      }
    }
  });

  it("emits clean, drift-free tick values even when the step is fractional", () => {
    const { ticks, niceMax } = niceTicks(0.8);
    expect(niceMax).toBeCloseTo(0.8, 6);
    const expected = [0, 0.2, 0.4, 0.6, 0.8];
    expect(ticks).toHaveLength(expected.length);
    ticks.forEach((t, i) => expect(t).toBeCloseTo(expected[i], 6));
  });

  it("honours a custom tick-count target", () => {
    // asking for ~2 ticks yields a coarser step than the default ~4
    const coarse = niceTicks(100, 2);
    const fine = niceTicks(100, 4);
    expect(coarse.ticks.length).toBeLessThanOrEqual(fine.ticks.length);
    expect(coarse.niceMax).toBeGreaterThanOrEqual(100);
  });
});
