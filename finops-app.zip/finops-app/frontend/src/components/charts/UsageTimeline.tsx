import { useState } from "react";
import type {
  AutostopCandidate,
  AutostopTradeoffViz,
  BurstCompareViz,
  ClusterContentionViz,
  ClusterDailyViz,
  ClusterResourcesViz,
  ClusterWeekHeatmapViz,
  CpuAreaViz,
  DriverWorkerSplitViz,
  HourHeatmapViz,
  JobRunsViz,
  ServingTrafficViz,
  Viz,
  WhRightsizeViz,
  WhScaleOutViz,
  WriteNoReadViz,
} from "../../api/types";
import { DailyStack, RankedBars } from "./DailyStack";
import { LabsChart } from "./LabsCharts";

/** Renders the "show the data" chart for a recommendation's evidence.viz.
 *  Dependency-free SVG; every color is a CSS var so it follows the theme.
 *  Semantic mapping: --info = in-use/activity, --warn = warm-but-idle waste,
 *  --track = stopped, --savings = the reclaimable / target marker. */
/** A legend that sits directly under the ONE chart it describes. Multi-panel
 *  findings used to get a single pooled legend under the last panel, mixing
 *  colours from three charts that each meant something different. */
function InlineLegend({ items }: { items: [string, string][] }) {
  return (
    <div className="ut-legend">
      {items.map(([color, label]) => (
        <span key={label}>
          <i style={{ background: color }} /> {label}
        </span>
      ))}
    </div>
  );
}

/** Optional finding context a chart can use to draw the decision, not just the
 *  data: for a worker downsize, the current and proposed worker counts. */
export interface VizContext {
  resize?: { from: number; to: number };
}

export function UsageTimeline({ viz, context }: { viz: Viz; context?: VizContext }) {
  switch (viz.kind) {
    case "hour_heatmap":
      return <HourHeatmap v={viz} />;
    case "burst_compare":
      return <BurstCompare v={viz} />;
    case "cpu_area":
      return <CpuArea v={viz} resize={context?.resize} />;
    case "cluster_daily":
      return <ClusterDaily v={viz} />;
    case "job_runs":
      return <JobRuns v={viz} />;
    case "driver_worker_split":
      return <DriverWorkerSplit v={viz} />;
    case "write_no_read":
      return <WriteNoRead v={viz} />;
    case "serving_traffic":
      return <ServingTraffic v={viz} />;
    case "wh_rightsize":
      return <WhRightsize v={viz} />;
    case "wh_scale_out":
      return <WhScaleOut v={viz} />;
    case "autostop_tradeoff":
      return <AutostopTradeoff v={viz} />;
    case "cluster_resources":
      return <ClusterResources v={viz} />;
    case "cluster_week_heatmap":
      return <ClusterWeekHeatmap v={viz} />;
    case "cluster_contention":
      return <ClusterContention v={viz} />;
    case "daily_stack":
      return <DailyStack v={viz} />;
    case "ranked_bars":
      return <RankedBars v={viz} />;
    // Charts built for Labs rules: a promoted rule keeps its chart on the detail page.
    case "sql_failures":
    case "pipeline_failures":
    case "instance_pool":
      return <LabsChart viz={viz} />;
    default:
      return null;
  }
}

// ---- G2. warehouse scale-OUT: under-provisioned, queries queue at capacity ----
// The mirror of WhRightsize. Two panels: (1) the cluster ceiling lever — current
// vs proposed max_clusters, drawn as stacked cluster blocks so "add one more" is
// literal, with the always-on floor (min_clusters) distinguished from the added
// clusters that only spin up under load; (2) query volume by hour with the queued
// share overlaid, so it's visible that contention is concentrated in busy hours
// (the only hours the extra cluster is billed).
function WhScaleOut({ v }: { v: WhScaleOutViz }) {
  return (
    <div className="ut-stack">
      <ClusterLadder v={v} />
      {v.queries_by_hour.length === 24 && <QueueRhythm v={v} />}
    </div>
  );
}

function ClusterLadder({ v }: { v: WhScaleOutViz }) {
  const W = 860, H = 200, padT = 30, padB = 44;
  const cell = 40, gap = 8;
  // Draw two columns of stacked cluster blocks: today vs proposed. The bottom
  // min_clusters blocks are the always-on floor; blocks above are elastic (spin
  // up only under load). The proposed column's new blocks are highlighted.
  const cols = [
    { label: "Today", max: v.current_max_clusters, x: W * 0.3 },
    { label: "Recommended", max: v.proposed_max_clusters, x: W * 0.62 },
  ];
  const maxBlocks = v.proposed_max_clusters;
  const stackH = maxBlocks * (cell + gap);
  const baseY = padT + stackH;
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">The lever: raise the warehouse's cluster ceiling</h4>
      <svg viewBox={`0 0 ${W} ${Math.max(H, baseY + padB)}`} className="ut-svg" role="img"
        aria-label={`Maximum clusters today ${v.current_max_clusters} versus recommended ${v.proposed_max_clusters}`}>
        {cols.map((col) => (
          <g key={col.label}>
            {Array.from({ length: col.max }, (_, k) => {
              // k=0 is the bottom (always-on floor). Blocks at index >= today's
              // ceiling are the ones this recommendation adds.
              const isFloor = k < v.min_clusters;
              const isNew =
                col.label === "Recommended" && k >= v.current_max_clusters;
              const y = baseY - (k + 1) * (cell + gap) + gap;
              const fill = isNew
                ? "var(--savings)"
                : isFloor
                  ? "var(--info)"
                  : "var(--track)";
              return (
                <rect key={k} x={col.x} y={y} width={cell * 2.2} height={cell}
                  rx={3} fill={fill} opacity={isNew ? 0.9 : isFloor ? 0.85 : 0.55}
                  stroke={isNew ? "var(--savings)" : "var(--border)"}
                  strokeWidth={isNew ? 1.5 : 1}
                  strokeDasharray={isNew ? "4 3" : undefined}>
                  <title>
                    {isFloor
                      ? "Always-on cluster (min_clusters)"
                      : isNew
                        ? "Added cluster — spins up only while queries queue, auto-stops when the queue drains"
                        : "Elastic cluster (spins up under load)"}
                  </title>
                </rect>
              );
            })}
            <text x={col.x + cell * 1.1} y={baseY + 16} className="ut-ax"
              textAnchor="middle" fontWeight={600}>
              {col.label}: max {col.max}
            </text>
          </g>
        ))}
        {/* arrow between the two stacks */}
        <text x={W * 0.5} y={padT + stackH / 2} className="ut-ax" textAnchor="middle"
          fontSize={20} fill="var(--savings)">→</text>
        <text x={W * 0.3} y={padT - 12} className="ut-ax">
          {v.queued_pct.toFixed(0)}% of {v.queries.toLocaleString()} queries waited
          for a free cluster (p95 {v.p95_queue_wait_s.toFixed(0)}s)
        </text>
        <text x={W * 0.62} y={baseY + 34} className="ut-ax" textAnchor="middle"
          fill="var(--savings)">
          + {v.proposed_max_clusters - v.current_max_clusters} elastic
          {v.auto_stop_minutes
            ? ` · auto-stops after ${v.auto_stop_minutes}m idle`
            : " · billed only under load"}
        </text>
      </svg>
      <div className="ut-legend">
        <span><i style={{ background: "var(--info)" }} /> Always-on (min)</span>
        <span><i style={{ background: "var(--track)" }} /> Elastic (scales under load)</span>
        <span><i style={{ background: "var(--savings)" }} /> Added by this recommendation</span>
      </div>
    </div>
  );
}

function QueueRhythm({ v }: { v: WhScaleOutViz }) {
  const W = 860, H = 170, padL = 40, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const q = v.queries_by_hour;
  const qd = v.queued_by_hour.length === 24 ? v.queued_by_hour : q.map(() => 0);
  const bw = iw / 24;
  const maxQ = Math.max(1, ...q);
  const y = (c: number) => padT + ih * (1 - c / maxQ);
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">When does the queueing happen?</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Query volume by hour of day with the queued-at-capacity share overlaid">
        {q.map((count, h) => {
          const x = padL + h * bw + bw * 0.15;
          const w = Math.max(bw * 0.7, 1);
          return (
            <g key={h}>
              {/* total queries this hour (info), with the queued portion (warn) on top */}
              <rect x={x} y={y(count)} width={w} height={Math.max(0, y(0) - y(count))}
                fill="var(--info)" opacity={0.55} rx={1}>
                <title>{`${String(h).padStart(2, "0")}:00 — ${count} queries`}</title>
              </rect>
              {qd[h] > 0 && (
                <rect x={x} y={y(qd[h])} width={w} height={Math.max(0, y(0) - y(qd[h]))}
                  fill="var(--danger)" opacity={0.85} rx={1}>
                  <title>{`${String(h).padStart(2, "0")}:00 — ${qd[h]} of ${count} queued at capacity`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {[0, 4, 8, 12, 16, 20].map((h) => (
          <text key={h} x={padL + h * bw + bw / 2} y={padT + ih + 14} className="ut-ax"
            textAnchor="middle">{String(h).padStart(2, "0")}</text>
        ))}
        <text x={padL} y={H - 4} className="ut-ax">
          queries by hour (UTC) — amber = waited at capacity. Contention concentrated
          in busy hours means the extra cluster is a peak-hour cost, not a round-the-clock one.
        </text>
      </svg>
      <div className="ut-legend">
        <span><i style={{ background: "var(--info)" }} /> Queries run</span>
        <span><i style={{ background: "var(--danger)" }} /> Queued at capacity (waited)</span>
      </div>
    </div>
  );
}

// ---- H. serverless auto-stop: the trade-off behind the recommended value -----
// Panels, because the recommendation is a judgement the user should be able to
// check: (0) the reference — what auto-stop is set TODAY (OFF is the whole story
// for a warehouse that never stops), and the saving split into "turn it on" vs
// "tighten"; (1) how long this warehouse's idle gaps actually are; (2) what each
// candidate value reclaims vs restarts it forces; (3) WHEN the warehouse is busy,
// as a day-of-week x hour heatmap so weekend/overnight gaps are visible (the plain
// hour-of-day view sums all days together and hides exactly those gaps).
function AutostopTradeoff({ v }: { v: AutostopTradeoffViz }) {
  const chosen = v.candidates.find((c) => c.minutes === v.chosen_minutes);
  return (
    <div className="ut-stack">
      {/* "Current → proposed" is already the action box at the top of the card;
          only the OFF case (never stops, bills 24/7) is worth restating here. */}
      {(v.current_minutes == null || v.current_minutes === 0) && <CurrentSettingRef v={v} />}
      {/* A split needs two parts: with no "turn it on" step, a single 100% bar
          said nothing the headline didn't. */}
      {v.tiers?.enable && v.tiers.enable.monthly_savings_usd > 0 && <SavingsTiers v={v} />}
      {/* When the recommendation exceeds the comfort threshold we lead with that,
          so nobody applies it without seeing the restart cost. */}
      {v.high_churn && chosen && (
        <p className="churn-warning">
          <strong>Check before applying:</strong> something queries this warehouse on a
          regular cadence, so a {v.chosen_minutes}-minute auto-stop would restart it
          ~{chosen.extra_stops_per_day.toFixed(0)} extra times per day — above the{" "}
          {v.max_extra_stops_per_day}/day we treat as unobtrusive. The saving is real;
          take it only if nothing latency-sensitive depends on this warehouse
          responding immediately.
        </p>
      )}
      <GapHistogram v={v} />
      <CandidateTradeoff v={v} />
      {v.queries_by_dow_hour?.length === 168 && <WeeklyHeatmap v={v} />}
      {v.queries_by_hour.length > 0 && <QueryRhythm v={v} />}
    </div>
  );
}

// Panel 0a: the reference the recommendation moves FROM. For a warehouse with no
// auto-stop this is the single most important fact — it never shuts down, so it
// bills warm 24/7 — and the old chart buried it in a caption. Called out plainly.
function CurrentSettingRef({ v }: { v: AutostopTradeoffViz }) {
  const off = v.current_minutes == null || v.current_minutes === 0;
  return (
    <p className={`autostop-ref${off ? " autostop-ref-off" : ""}`}>
      <span className="autostop-ref-label">Current auto-stop:</span>{" "}
      {off ? (
        <>
          <strong>OFF — the warehouse never stops.</strong> It bills warm around the
          clock, including through every idle overnight and weekend gap below.
        </>
      ) : (
        <>
          <strong>{v.current_minutes} min.</strong> Recommendation moves it to{" "}
          {v.chosen_minutes} min.
        </>
      )}
    </p>
  );
}

// Panel 0b: the saving split. Leads with the big, low-churn "turn it on" win and
// shows "tighten into the short window" as the smaller, restart-costing refinement,
// so the reader sees that most of the money is simply enabling auto-stop — not the
// aggressive short value.
function SavingsTiers({ v }: { v: AutostopTradeoffViz }) {
  const t = v.tiers!;
  const usd = (n: number) =>
    n >= 1000 ? `$${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}k` : `$${n.toFixed(0)}`;
  const enable = t.enable;
  const tighten = t.tighten;
  const total = (enable?.monthly_savings_usd ?? 0) + tighten.monthly_savings_usd;
  const pct = (n: number) => (total > 0 ? Math.round((n / total) * 100) : 0);
  return (
    <div className="autostop-tiers">
      <h4 className="ut-sub">Where the saving comes from</h4>
      <div className="tier-bars">
        {enable && enable.monthly_savings_usd > 0 && (
          <div className="tier tier-enable">
            <div className="tier-head">
              <span className="tier-step">
                {enable.from_minutes == null ? "OFF" : `${enable.from_minutes}m`} →{" "}
                {enable.to_minutes}m
              </span>
              <span className="tier-amt">
                {usd(enable.monthly_savings_usd)}/mo{" "}
                <span className="tier-pct">({pct(enable.monthly_savings_usd)}%)</span>
              </span>
            </div>
            <div className="tier-track">
              <div className="tier-fill tier-fill-enable"
                style={{ width: `${pct(enable.monthly_savings_usd)}%` }} />
            </div>
            <p className="tier-note">
              <strong>Turn auto-stop on.</strong> A conservative {enable.to_minutes}-min
              stop reclaims ~{enable.reclaimed_hours.toLocaleString()}h of idle — the
              multi-hour overnight/weekend gaps — with almost no user-visible restarts.
              This is the safe majority of the saving.
            </p>
          </div>
        )}
        <div className="tier tier-tighten">
          <div className="tier-head">
            <span className="tier-step">
              {tighten.from_minutes == null ? "OFF" : `${tighten.from_minutes}m`} →{" "}
              {tighten.to_minutes}m
            </span>
            <span className="tier-amt">
              {usd(tighten.monthly_savings_usd)}/mo{" "}
              <span className="tier-pct">({pct(tighten.monthly_savings_usd)}%)</span>
            </span>
          </div>
          <div className="tier-track">
            <div className="tier-fill tier-fill-tighten"
              style={{ width: `${pct(tighten.monthly_savings_usd)}%` }} />
          </div>
          <p className="tier-note">
            <strong>Tighten to {tighten.to_minutes} min.</strong> A smaller further gain
            that adds ~{(tighten.extra_stops_per_day ?? 0).toFixed(1)} restarts/day — worth
            it only if nothing latency-sensitive depends on instant response.
          </p>
        </div>
      </div>
    </div>
  );
}

// Panel 3 (primary): day-of-week x hour heatmap. Rows = Mon..Sun, cols = 24 hours,
// cell shade = query volume. This is the view that answers "where are the gaps?":
// a warehouse that looks "always on" in the hour-of-day chart shows empty weekend
// rows and empty night columns here — exactly the idle the auto-stop reclaims.
const DOW_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
function WeeklyHeatmap({ v }: { v: AutostopTradeoffViz }) {
  const m = v.queries_by_dow_hour!;
  const W = 860, padL = 42, padT = 20, padR = 12, padB = 30;
  const cw = (W - padL - padR) / 24;
  const ch = 22;
  const H = padT + 7 * ch + padB;
  const max = Math.max(1, ...m);
  // Perceptual-ish shade: sqrt so light use is still visible against the dark idle.
  const shade = (n: number) => (n <= 0 ? 0 : 0.12 + 0.88 * Math.sqrt(n / max));
  const weekdayTotal = m.slice(0, 5 * 24).reduce((s, x) => s + x, 0);
  const weekendTotal = m.slice(5 * 24).reduce((s, x) => s + x, 0);
  const grand = weekdayTotal + weekendTotal;
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">When is this warehouse actually used? (by weekday &amp; hour)</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Query volume by day of week and hour of day; empty rows and columns are idle periods the auto-stop reclaims">
        {DOW_LABELS.map((lab, d) => (
          <text key={lab} x={padL - 8} y={padT + d * ch + ch / 2 + 4} className="ut-ax"
            textAnchor="end" fontWeight={d >= 5 ? 600 : 400}
            fill={d >= 5 ? "var(--savings)" : undefined}>
            {lab}
          </text>
        ))}
        {[0, 4, 8, 12, 16, 20].map((h) => (
          <text key={h} x={padL + h * cw + cw / 2} y={padT - 6} className="ut-ax"
            textAnchor="middle">{String(h).padStart(2, "0")}</text>
        ))}
        {m.map((n, k) => {
          const d = Math.floor(k / 24), h = k % 24;
          const s = shade(n);
          return (
            <rect key={k} x={padL + h * cw} y={padT + d * ch} width={cw - 1.5} height={ch - 1.5}
              rx={2} fill={n > 0 ? "var(--info)" : "var(--track)"} opacity={n > 0 ? s : 0.35}>
              <title>{`${DOW_LABELS[d]} ${String(h).padStart(2, "0")}:00 — ${n} quer${n === 1 ? "y" : "ies"}`}</title>
            </rect>
          );
        })}
        <text x={padL} y={H - 8} className="ut-ax">
          summed over {v.lookback_days} days · weekdays {grand > 0 ? Math.round((weekdayTotal / grand) * 100) : 0}% of
          queries, weekends {grand > 0 ? Math.round((weekendTotal / grand) * 100) : 0}% — dark cells are idle hours billed warm today
        </text>
      </svg>
    </div>
  );
}

function GapHistogram({ v }: { v: AutostopTradeoffViz }) {
  const W = 860, H = 200, padL = 40, padR = 12, padB = 44, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const b = v.gap_buckets;
  const n = b.length;
  const bw = iw / Math.max(n, 1);
  const maxN = Math.max(1, ...b.map((x) => x.n));
  const y = (c: number) => padT + ih * (1 - c / maxN);
  // Bars at or below the chosen setting are gaps the new value will NOT reclaim
  // (the warehouse stays warm through them) — the usability-protecting part.
  const isKept = (hi: number | null) => hi !== null && hi <= v.chosen_minutes;

  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">How long are the idle gaps between queries?</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Distribution of idle gaps between queries by length band">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(maxN * g)} x2={padL + iw} y2={y(maxN * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(maxN * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxN * g)}
            </text>
          </g>
        ))}
        {b.map((bucket, i) => {
          const x = padL + i * bw + bw * 0.14;
          const w = Math.max(bw * 0.72, 1);
          const kept = isKept(bucket.hi);
          return (
            <g key={bucket.label}>
              {bucket.n > 0 && (
                <rect x={x} y={y(bucket.n)} width={w} height={y(0) - y(bucket.n)}
                  fill={kept ? "var(--info)" : "var(--warn)"} opacity={kept ? 0.85 : 0.7} rx={1}>
                  <title>
                    {`${bucket.n} idle gap(s) of ${bucket.label}` +
                      (kept
                        ? ` — stays warm through these at ${v.chosen_minutes} min`
                        : ` — reclaimed by a ${v.chosen_minutes} min auto-stop`)}
                  </title>
                </rect>
              )}
              <text x={x + w / 2} y={padT + ih + 13} className="ut-ax" textAnchor="middle">
                {bucket.label}
              </text>
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        <text x={padL} y={H - 6} className="ut-ax">
          median gap {v.median_gap_min}m · p90 {v.p90_gap_min}m · {v.lookback_days}-day window
        </text>
      </svg>
      <InlineLegend
        items={[
          ["var(--info)", `Short gaps — stays warm at ${v.chosen_minutes} min (no restart)`],
          ["var(--warn)", `Longer gaps — a ${v.chosen_minutes}-min auto-stop reclaims these`],
        ]}
      />
    </div>
  );
}

/** Reduce the full candidate ladder (often ~15 values) to the handful worth
 *  comparing side by side, so the chart is a clear decision aid rather than a
 *  dense sweep. We keep, in ascending order of minutes:
 *   - the aggressive floor (shortest candidate, typically 5 min);
 *   - the recommended value;
 *   - the current setting, if one is set and is among the candidates;
 *   - the "restart drop-off": the value with the largest single-step fall in
 *     extra-restarts-per-day as auto-stop lengthens — the knee where more waiting
 *     stops buying meaningfully fewer cold starts.
 *  Deduplicated and sorted; nothing here changes the recommendation, it only
 *  chooses which of the already-computed candidates to draw. */
function meaningfulCandidates(v: AutostopTradeoffViz): AutostopCandidate[] {
  const c = v.candidates;
  if (c.length <= 4) return [...c].sort((a, b) => a.minutes - b.minutes);
  const byMin = [...c].sort((a, b) => a.minutes - b.minutes);
  const keep = new Set<number>();
  keep.add(byMin[0].minutes); // aggressive floor
  keep.add(v.chosen_minutes); // recommended

  // Current setting: keep the candidate at (or nearest to) today's value, so the
  // reader sees where they are on the same axis as where they'd move to.
  if (v.current_minutes != null) {
    let nearest = byMin[0];
    for (const x of byMin)
      if (Math.abs(x.minutes - v.current_minutes) < Math.abs(nearest.minutes - v.current_minutes))
        nearest = x;
    keep.add(nearest.minutes);
  }

  // Restart drop-off: biggest single-step reduction in restarts/day as the
  // setting lengthens. That knee is where the usability cost of a shorter
  // auto-stop really lives, so it earns a bar even if it's neither floor nor pick.
  let kneeMin = byMin[0].minutes;
  let kneeDrop = -Infinity;
  for (let i = 1; i < byMin.length; i++) {
    const drop = byMin[i - 1].extra_stops_per_day - byMin[i].extra_stops_per_day;
    if (drop > kneeDrop) {
      kneeDrop = drop;
      kneeMin = byMin[i].minutes;
    }
  }
  keep.add(kneeMin);

  return byMin.filter((x) => keep.has(x.minutes));
}

// The auto-stop trade-off: for the few settings that matter, how much idle each
// reclaims and how many extra restarts/day it adds. Categorical bars (equal
// width, generous gaps) rather than a swept ladder, so it reads as "compare
// these options" — the acceptability line is gone; the restart cost travels with
// each bar's own label and the recommended bar carries the verdict.
function CandidateTradeoff({ v }: { v: AutostopTradeoffViz }) {
  const c = meaningfulCandidates(v);
  if (c.length === 0) return null;
  const W = 860, H = 250, padL = 46, padR = 16, padB = 66, padT = 22;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = c.length;
  const slot = iw / n;
  const barW = Math.min(96, slot * 0.5);
  const maxReclaim = Math.max(1, ...c.map((x) => x.net_reclaimed_min));
  const yR = (m: number) => padT + ih * (1 - m / maxReclaim);
  // The bar for today's setting, labelled "today" so the reader sees where they
  // are relative to where they'd move. Exact match only: the old nearest-bar
  // rule put "today" under the 10-min bar for a warehouse that is set to 60 min.
  // When today's value isn't drawn, the caption below states it instead.
  const currentMin =
    v.current_minutes != null && c.some((x) => x.minutes === v.current_minutes)
      ? v.current_minutes
      : null;

  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">What the settings worth comparing would cost and save</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Idle time reclaimed and extra restarts per day, for the auto-stop settings worth comparing">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={padL} y1={yR(maxReclaim * g)} x2={padL + iw} y2={yR(maxReclaim * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={yR(maxReclaim * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round((maxReclaim * g) / 60)}h
            </text>
          </g>
        ))}
        {c.map((x, i) => {
          const cx = padL + slot * i + slot / 2;
          const bx = cx - barW / 2;
          const chosen = x.minutes === v.chosen_minutes;
          const isCurrent = currentMin != null && x.minutes === currentMin;
          // A chosen-but-churny value must NOT read as a clean green win: colour it
          // amber so the chart agrees with the warning above it.
          const chosenColor = v.high_churn ? "var(--warn)" : "var(--savings)";
          const fill = chosen ? chosenColor : x.acceptable ? "var(--info)" : "var(--faint)";
          const restarts = `${x.extra_stops_per_day.toFixed(x.extra_stops_per_day < 10 ? 1 : 0)}/day restarts`;
          return (
            <g key={x.minutes}>
              <rect x={bx} y={yR(x.net_reclaimed_min)} width={barW}
                height={Math.max(0, yR(0) - yR(x.net_reclaimed_min))}
                fill={fill} opacity={x.acceptable || chosen ? 0.9 : 0.4} rx={2}>
                <title>
                  {`${x.minutes} min: reclaims ${(x.net_reclaimed_min / 60).toFixed(1)}h/mo, ` +
                    `adds ${x.extra_stops_per_day.toFixed(1)} restarts/day` +
                    (x.acceptable
                      ? ""
                      : chosen
                        ? " — recommended, but a heavy restart load"
                        : " — too many restarts for everyday use")}
                </title>
              </rect>
              {chosen && (
                <text x={cx} y={yR(x.net_reclaimed_min) - 6} className="ut-ax"
                  textAnchor="middle" fill={chosenColor} fontWeight={600}>
                  {v.high_churn ? "recommended ⚠" : "recommended"}
                </text>
              )}
              {/* restarts/day now rides with the bar instead of a shared line */}
              <text x={cx} y={padT + ih + 15} className="ut-ax" textAnchor="middle"
                fontWeight={chosen ? 600 : 400}>
                {x.minutes}m
              </text>
              <text x={cx} y={padT + ih + 29} className="ut-ax" textAnchor="middle"
                fill="var(--faint)" fontSize={10}>
                {restarts}
              </text>
              {isCurrent && (
                <text x={cx} y={padT + ih + 43} className="ut-ax" textAnchor="middle"
                  fill="var(--accent)" fontSize={10} fontWeight={600}>
                  today
                </text>
              )}
            </g>
          );
        })}
        <line x1={padL} y1={yR(0)} x2={padL + iw} y2={yR(0)} stroke="var(--border)" strokeWidth={1} />
        <text x={padL} y={H - 6} className="ut-ax">
          bar height = idle reclaimed per month · restarts/day labelled under each.
          {v.current_minutes ? ` Today: ${v.current_minutes} min.` : " No auto-stop set today."}
        </text>
      </svg>
      <InlineLegend
        items={[
          [v.high_churn ? "var(--warn)" : "var(--savings)", "Recommended value"],
          ["var(--info)", "Other settings that stay usable"],
          ["var(--faint)", "Too many restarts for everyday use"],
        ]}
      />
    </div>
  );
}

// Query volume by hour of day. Clicking an hour FOCUSES it. When the payload
// carries per-minute counts (queries_by_hour_minute), the focused hour DRILLS
// DOWN into a 60-bar minute-of-hour chart, so the reader can see exactly which
// minute the queries land on (e.g. an hourly poller firing at :00, vs. genuinely
// scattered ad-hoc use). Without that data it falls back to dimming the other
// hours and showing the focused count inline. A frontend-only drill over data
// already shipped — no round trip.
function QueryRhythm({ v }: { v: AutostopTradeoffViz }) {
  const [focus, setFocus] = useState<number | null>(null);
  const W = 860, H = 168, padL = 40, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const q = v.queries_by_hour;
  const bw = iw / 24;
  const maxQ = Math.max(1, ...q);
  const total = q.reduce((s, x) => s + x, 0);
  const y = (c: number) => padT + ih * (1 - c / maxQ);
  const focused = focus != null ? q[focus] : 0;
  const focusPct = focus != null && total > 0 ? Math.round((focused / total) * 100) : 0;
  // Per-minute drill data for the focused hour: 60 counts, index == minute-of-hour.
  // Present only when the row carried queries_by_hour_minute (1440 buckets).
  const minutes =
    focus != null && v.queries_by_hour_minute?.length === 1440
      ? v.queries_by_hour_minute.slice(focus * 60, focus * 60 + 60)
      : null;

  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">
        Typical day — queries by hour (all days combined)
        {focus != null && (
          <button type="button" className="btn-link" style={{ marginLeft: 10, fontSize: 12 }}
            onClick={() => setFocus(null)}>
            {minutes ? "back to hours" : "reset to hourly"}
          </button>
        )}
      </h4>
      {focus != null && (
        <p className="ut-note" style={{ marginTop: 0 }}>
          <strong>{String(focus).padStart(2, "0")}:00–{String((focus + 1) % 24).padStart(2, "0")}:00</strong>{" "}
          — {focused.toLocaleString()} quer{focused === 1 ? "y" : "ies"} · {focusPct}% of the
          day's total.{" "}
          {minutes
            ? "Bars below are per minute within this hour."
            : "Click the bar again to clear."}
        </p>
      )}
      {minutes ? (
        <MinuteRhythm minutes={minutes} hour={focus!} lookbackDays={v.lookback_days} />
      ) : (
        <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
          aria-label="Query volume by hour of day; click an hour to focus it">
          {q.map((count, h) => {
            const active = focus == null || focus === h;
            return (
              <rect key={h} x={padL + h * bw + bw * 0.15} y={y(count)}
                width={Math.max(bw * 0.7, 1)} height={Math.max(0, y(0) - y(count))}
                fill={focus === h ? "var(--accent)" : "var(--violet)"}
                opacity={active ? 0.85 : 0.25} rx={1}
                style={{ cursor: "pointer" }}
                onClick={() => setFocus((cur) => (cur === h ? null : h))}>
                <title>{`${String(h).padStart(2, "0")}:00 — ${count} quer${count === 1 ? "y" : "ies"}${v.queries_by_hour_minute ? " (click to drill into minutes)" : " (click to focus)"}`}</title>
              </rect>
            );
          })}
          <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
          {[0, 4, 8, 12, 16, 20].map((h) => (
            <text key={h} x={padL + h * bw + bw / 2} y={padT + ih + 14} className="ut-ax"
              textAnchor="middle">
              {String(h).padStart(2, "0")}
            </text>
          ))}
          <text x={padL} y={H - 4} className="ut-ax">
            queries by hour of day (UTC) over {v.lookback_days} days —{" "}
            {v.queries_by_hour_minute
              ? "click any hour to drill into the minutes inside it"
              : "click any hour to focus it"}; concentrated usage means fewer restarts than the gap count suggests
          </text>
        </svg>
      )}
    </div>
  );
}

// The per-minute drilldown for one focused hour: 60 bars, index == minute-of-hour.
// A tight spike on a single minute (e.g. :00) is the signature of a scheduled
// poller — the thing that makes a short auto-stop churny; queries scattered across
// the hour read as genuine ad-hoc use. Ticks every 10 minutes.
function MinuteRhythm({ minutes, hour, lookbackDays }: {
  minutes: number[]; hour: number; lookbackDays: number;
}) {
  const W = 860, H = 168, padL = 40, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const bw = iw / 60;
  const maxM = Math.max(1, ...minutes);
  const y = (c: number) => padT + ih * (1 - c / maxM);
  const hh = String(hour).padStart(2, "0");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
      aria-label={`Query volume by minute within the ${hh}:00 hour`}>
      {minutes.map((count, m) => (
        <rect key={m} x={padL + m * bw + bw * 0.12} y={y(count)}
          width={Math.max(bw * 0.76, 0.8)} height={Math.max(0, y(0) - y(count))}
          fill="var(--accent)" opacity={count > 0 ? 0.85 : 0.25} rx={0.5}>
          <title>{`${hh}:${String(m).padStart(2, "0")} — ${count} quer${count === 1 ? "y" : "ies"}`}</title>
        </rect>
      ))}
      <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
      {[0, 10, 20, 30, 40, 50].map((m) => (
        <text key={m} x={padL + m * bw + bw / 2} y={padT + ih + 14} className="ut-ax"
          textAnchor="middle">
          {`${hh}:${String(m).padStart(2, "0")}`}
        </text>
      ))}
      <text x={padL} y={H - 4} className="ut-ax">
        queries by minute within {hh}:00 (UTC) over {lookbackDays} days — a spike on one
        minute is a scheduled job; spread-out bars are ad-hoc use
      </text>
    </svg>
  );
}

// ---- I. cluster multi-resource utilization ----------------------------------
// CPU alone is not diagnostic: 8% CPU can mean oversized, memory-bound, or
// I/O-starved, and each implies a different action. Drawn as SMALL MULTIPLES —
// one strip per metric on a shared time axis — not five lines on one axis: there
// the peak-normalised network line (always touching 100%) was the loudest mark
// on the chart while being the least diagnostic, and CPU/memory, the two that
// decide "can it shrink?", were buried under it. Percent metrics share a fixed
// 0–100% scale so a 5% CPU strip honestly looks empty; network (a byte rate) is
// scaled to its own peak and labelled as such.
function ClusterResources({ v }: { v: ClusterResourcesViz }) {
  const W = 860, padL = 150, padR = 12, rowH = 46, gap = 10, axisH = 20;
  const iw = W - padL - padR;
  const s = v.series;
  const n = s.length;
  if (n === 0) return null;

  const ROWS: { key: keyof typeof METRIC_META; color: string }[] = [
    { key: "cpu", color: "var(--info)" },
    { key: "mem", color: "var(--violet)" },
    { key: "swap", color: "var(--danger)" },
    { key: "io_wait", color: "var(--warn)" },
    { key: "net", color: "var(--slate)" },
  ];
  const present = ROWS.filter((l) => s.some((p) => p[l.key] !== undefined));
  const H = present.length * (rowH + gap) + axisH;

  const t0 = s[0].ts, t1 = s[n - 1].ts;
  const span = Math.max(1, t1 - t0);
  const x = (i: number) => padL + (iw * (s[i].ts - t0)) / span;

  // One path per contiguous run of samples: a gap of more than ~1.5h in the
  // timestamps is the cluster being OFF, and must read as a gap, not as a
  // straight line interpolated across the night.
  const area = (key: keyof typeof METRIC_META, top: number) => {
    const y = (val: number) => top + rowH * (1 - Math.min(Math.max(val, 0), 1));
    const segs: number[][] = [];
    let prevTs: number | null = null;
    for (let i = 0; i < n; i++) {
      if (s[i][key] === undefined) continue;
      if (prevTs === null || s[i].ts - prevTs > 5400) segs.push([]);
      segs[segs.length - 1].push(i);
      prevTs = s[i].ts;
    }
    let line = "", fill = "";
    for (const seg of segs) {
      const pts = seg.map((i, k) => `${k === 0 ? "M" : "L"}${x(i)},${y(s[i][key] as number)}`).join(" ");
      line += pts + " ";
      fill += `${pts} L${x(seg[seg.length - 1])},${top + rowH} L${x(seg[0])},${top + rowH} Z `;
    }
    return { line, fill };
  };

  const days = span / 86400;
  const ticks = Array.from({ length: 7 }, (_, k) => {
    const t = t0 + (span * k) / 6;
    const d = new Date(t * 1000);
    return {
      x: padL + (iw * k) / 6,
      label: days >= 2 ? `${d.getMonth() + 1}/${d.getDate()}`
        : `${String(d.getHours()).padStart(2, "0")}:00`,
    };
  });

  const rowStat = (key: keyof typeof METRIC_META) => {
    if (key === "net")
      return v.stats.net_peak_mb_per_min !== undefined
        ? `peak ${v.stats.net_peak_mb_per_min} MB/min`
        : "scaled to its peak";
    const avg = v.stats[`${key}_avg_pct`];
    const peak = v.stats[`${key}_peak_pct`];
    return avg !== undefined ? `avg ${avg}% · peak ${peak}%` : "";
  };

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Cluster CPU, memory, swap, I/O wait and network over time, one strip per metric">
        {ticks.map((t, i) => (
          <line key={i} x1={t.x} y1={0} x2={t.x} y2={H - axisH} stroke="var(--border)"
            strokeWidth={1} opacity={0.3} />
        ))}
        {present.map((l, r) => {
          const top = r * (rowH + gap);
          const { line, fill } = area(l.key, top);
          return (
            <g key={l.key}>
              <text x={0} y={top + 16} className="ut-ax" fill="var(--text)" fontWeight={600}
                fontSize={12}>
                {METRIC_META[l.key].label}
              </text>
              <text x={0} y={top + 31} className="ut-ax">{rowStat(l.key)}</text>
              <rect x={padL} y={top} width={iw} height={rowH} fill="var(--track)" opacity={0.45}
                rx={3} />
              {l.key !== "net" && (
                <line x1={padL} y1={top + rowH * 0.5} x2={padL + iw} y2={top + rowH * 0.5}
                  stroke="var(--border)" strokeDasharray="2 3" strokeWidth={1} />
              )}
              <path d={fill} fill={l.color} opacity={0.18} />
              <path d={line} fill="none" stroke={l.color} strokeWidth={1.3} />
            </g>
          );
        })}
        {ticks.map((t, i) => (
          <text key={i} x={t.x} y={H - 5} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
      </svg>
      <p className="ut-caption">
        Hourly, across all nodes{v.node_type ? ` · ${v.node_type}` : ""}
        {v.worker_count !== null ? ` · ${v.worker_count} worker(s)` : ""}. Each strip runs 0–100%
        (dashed line = 50%); network is scaled to its own peak. Gaps are hours the cluster was off.
      </p>
    </div>
  );
}

const METRIC_META = {
  cpu: { label: "CPU" },
  mem: { label: "Memory" },
  swap: { label: "Swap" },
  io_wait: { label: "I/O wait" },
  net: { label: "Network" },
} as const;

// ---- D. cluster idle / auto-terminate: hours-run-per-day over the lookback ---
// One stacked bar per day: active hours (peak CPU >= threshold) + idle hours.
// Honestly spans the FULL analysis window, so a rarely-used cluster reads as
// mostly-off rather than "always idle" (which hourly averaging falsely implies).
function ClusterDaily({ v }: { v: ClusterDailyViz }) {
  const W = 860, H = 240, padL = 34, padR = 12, padB = 40, padT = 14;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxH = Math.max(24, ...v.days.map((d) => d.a + d.i)); // usually 24h
  const y = (hrs: number) => padT + ih * (1 - Math.min(hrs, maxH) / maxH);
  const lastActiveIdx = v.days.findIndex((d) => d.d === v.last_active);

  // ~6 dated ticks across the window.
  const tickCount = Math.min(6, n - 1);
  const ticks = Array.from({ length: tickCount + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / Math.max(tickCount, 1));
    const dt = new Date(v.days[i].d + "T00:00:00");
    return { x: padL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Hours the cluster ran per day over the lookback, split into active and idle">
        {/* y gridlines at 0/6/12/18/24h */}
        {[0, 6, 12, 18, 24].filter((h) => h <= maxH).map((h) => (
          <g key={h}>
            <line x1={padL} y1={y(h)} x2={padL + iw} y2={y(h)} stroke="var(--border)"
              strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(h) + 3} className="ut-ax" textAnchor="end">{h}h</text>
          </g>
        ))}
        {/* per-day stacked bars: idle (amber) at bottom, active (info) on top */}
        {v.days.map((d, i) => {
          const x = padL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const idleTop = y(d.i), base = y(0);
          const activeTop = y(d.a + d.i);
          return (
            <g key={d.d}>
              {d.i > 0 && (
                <rect x={x} y={idleTop} width={w} height={base - idleTop} fill="var(--warn)"
                  opacity={0.8} rx={1}>
                  <title>{`${d.d}: ${d.i}h idle (CPU <${(v.idle_threshold * 100).toFixed(0)}%)`}</title>
                </rect>
              )}
              {d.a > 0 && (
                <rect x={x} y={activeTop} width={w} height={idleTop - activeTop} fill="var(--info)"
                  rx={1}>
                  <title>{`${d.d}: ${d.a}h active (CPU ≥${(v.idle_threshold * 100).toFixed(0)}%), peak ${(d.pk * 100).toFixed(0)}% CPU`}</title>
                </rect>
              )}
            </g>
          );
        })}
        {/* last-active marker */}
        {lastActiveIdx >= 0 && (
          <g>
            <line x1={padL + lastActiveIdx * bw + bw / 2} y1={padT}
              x2={padL + lastActiveIdx * bw + bw / 2} y2={padT + ih}
              stroke="var(--savings)" strokeWidth={1.25} strokeDasharray="3 3" />
            <text x={padL + lastActiveIdx * bw + bw / 2} y={padT - 3} className="ut-ax"
              textAnchor="middle" fill="var(--savings)">last active</text>
          </g>
        )}
        {/* baseline + dated x-axis */}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {ticks.map((t, i) => (
          <text key={i} x={t.x} y={H - 20} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
        <text x={padL} y={H - 5} className="ut-ax">
          hours run per day · {v.lookback_days}-day window · peak {(v.peak_overall * 100).toFixed(0)}% CPU when used
        </text>
      </svg>
    </div>
  );
}

// ---- C2. cluster auto-terminate: "when was it used" panels --------------------
// The cluster analog of the warehouse auto-stop rhythm charts. Two panels drawn
// from one payload: (1) a THREE-STATE weekday x hour heatmap that tells off /
// up-but-idle / in-use apart — the same active-vs-idle split the daily chart
// shows, but laid out weekly so the overnight/weekend gaps auto-termination
// reclaims are visible; (2) an hour-of-day chart that drills into the minutes
// inside a clicked hour (a :00 spike is a scheduled poller). The heatmap keys on
// the weekly rhythm the plain hour-of-day view sums away.
function ClusterWeekHeatmap({ v }: { v: ClusterWeekHeatmapViz }) {
  return (
    <div className="ut-stack">
      <ClusterWeekGrid v={v} />
      <InlineLegend
        items={[
          ["var(--info)", "In use (CPU active or a job/notebook ran)"],
          ["var(--warn)", "Up but idle (billed, reclaimable)"],
          ["var(--track)", "Off (not billed)"],
        ]}
      />
      <ClusterHourRhythm v={v} />
    </div>
  );
}

function ClusterWeekGrid({ v }: { v: ClusterWeekHeatmapViz }) {
  const active = v.active_by_dow_hour;
  // up-minutes let us distinguish "off" (up=0, not billed) from "up but idle"
  // (billed waste). Without it we fall back to the two-state view (active vs not).
  const up = v.up_by_dow_hour?.length === 168 ? v.up_by_dow_hour : null;
  const W = 860, padL = 42, padT = 20, padR = 12, padB = 30;
  const cw = (W - padL - padR) / 24;
  const ch = 22;
  const H = padT + 7 * ch + padB;
  const maxActive = Math.max(1, ...active);
  const maxIdle = up ? Math.max(1, ...up.map((u, i) => Math.max(0, u - active[i]))) : 1;
  // Shade by magnitude within each state (sqrt so light use stays visible).
  const shade = (n: number, max: number) => (n <= 0 ? 0 : 0.14 + 0.86 * Math.sqrt(n / max));
  const usedTotal = active.reduce((s, x) => s + x, 0);
  const idleTotal = up ? up.reduce((s, u, i) => s + Math.max(0, u - active[i]), 0) : 0;
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">Weekly rhythm — was it in use, idle, or off? (by weekday &amp; hour)</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Cluster state by day of week and hour of day: in use, up but idle, or off">
        {DOW_LABELS.map((lab, d) => (
          <text key={lab} x={padL - 8} y={padT + d * ch + ch / 2 + 4} className="ut-ax"
            textAnchor="end" fontWeight={d >= 5 ? 600 : 400}
            fill={d >= 5 ? "var(--savings)" : undefined}>
            {lab}
          </text>
        ))}
        {[0, 4, 8, 12, 16, 20].map((h) => (
          <text key={h} x={padL + h * cw + cw / 2} y={padT - 6} className="ut-ax"
            textAnchor="middle">{String(h).padStart(2, "0")}</text>
        ))}
        {active.map((a, k) => {
          const d = Math.floor(k / 24), h = k % 24;
          const upMin = up ? up[k] : a > 0 ? a : 0;
          const idleMin = Math.max(0, upMin - a);
          // Three states: in use (blue) if any active; else up-but-idle (amber,
          // the reclaimable waste) if it was up; else off (faint track).
          let fill = "var(--track)", opacity = 0.35, label: string;
          if (a > 0) {
            fill = "var(--info)"; opacity = shade(a, maxActive);
            label = `${a} min in use` + (up ? ` of ${upMin} up` : "");
          } else if (upMin > 0) {
            fill = "var(--warn)"; opacity = shade(idleMin, maxIdle);
            label = `up but idle — ${idleMin} billed min, no use`;
          } else {
            label = up ? "off — not billed" : "no use";
          }
          return (
            <rect key={k} x={padL + h * cw} y={padT + d * ch} width={cw - 1.5} height={ch - 1.5}
              rx={2} fill={fill} opacity={opacity}>
              <title>{`${DOW_LABELS[d]} ${String(h).padStart(2, "0")}:00 — ${label}`}</title>
            </rect>
          );
        })}
        <text x={padL} y={H - 8} className="ut-ax">
          summed over {v.lookback_days} days · {usedTotal.toLocaleString()} min in use
          {up ? ` · ${idleTotal.toLocaleString()} min up-but-idle (reclaimable) · faint cells are off (not billed)` : ""}
        </text>
      </svg>
    </div>
  );
}

// Hour-of-day active minutes, with a click-to-drill into the minutes inside the
// focused hour — the cluster twin of the warehouse QueryRhythm/MinuteRhythm.
function ClusterHourRhythm({ v }: { v: ClusterWeekHeatmapViz }) {
  const [focus, setFocus] = useState<number | null>(null);
  const W = 860, H = 168, padL = 40, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  // Collapse the 168-cell weekly matrix to 24 hour-of-day totals.
  const byHour = Array.from({ length: 24 }, (_, h) => {
    let s = 0;
    for (let d = 0; d < 7; d++) s += v.active_by_dow_hour[d * 24 + h];
    return s;
  });
  const bw = iw / 24;
  const maxH = Math.max(1, ...byHour);
  const total = byHour.reduce((s, x) => s + x, 0);
  const y = (c: number) => padT + ih * (1 - c / maxH);
  const focused = focus != null ? byHour[focus] : 0;
  const focusPct = focus != null && total > 0 ? Math.round((focused / total) * 100) : 0;
  // Per-minute drill for the focused hour: 60 counts, index == minute-of-hour.
  const minutes =
    focus != null && v.active_by_hour_minute?.length === 1440
      ? v.active_by_hour_minute.slice(focus * 60, focus * 60 + 60)
      : null;
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">
        Typical day — active minutes by hour (all days combined)
        {focus != null && (
          <button type="button" className="btn-link" style={{ marginLeft: 10, fontSize: 12 }}
            onClick={() => setFocus(null)}>
            {minutes ? "back to hours" : "reset to hourly"}
          </button>
        )}
      </h4>
      {focus != null && (
        <p className="ut-note" style={{ marginTop: 0 }}>
          <strong>{String(focus).padStart(2, "0")}:00–{String((focus + 1) % 24).padStart(2, "0")}:00</strong>{" "}
          — {focused.toLocaleString()} active min{focused === 1 ? "" : "s"} · {focusPct}% of the
          day's use.{" "}
          {minutes
            ? "Bars below are per minute within this hour — a spike on one minute is a scheduled job."
            : "Click the bar again to clear."}
        </p>
      )}
      {minutes ? (
        <ClusterMinuteRhythm minutes={minutes} hour={focus!} lookbackDays={v.lookback_days} />
      ) : (
        <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
          aria-label="Active minutes by hour of day; click an hour to focus it">
          {byHour.map((count, h) => {
            const on = focus == null || focus === h;
            return (
              <rect key={h} x={padL + h * bw + bw * 0.15} y={y(count)}
                width={Math.max(bw * 0.7, 1)} height={Math.max(0, y(0) - y(count))}
                fill={focus === h ? "var(--accent)" : "var(--violet)"}
                opacity={on ? 0.85 : 0.25} rx={1}
                style={{ cursor: "pointer" }}
                onClick={() => setFocus((cur) => (cur === h ? null : h))}>
                <title>{`${String(h).padStart(2, "0")}:00 — ${count} active min${count === 1 ? "" : "s"}${v.active_by_hour_minute ? " (click to drill into minutes)" : " (click to focus)"}`}</title>
              </rect>
            );
          })}
          <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
          {[0, 4, 8, 12, 16, 20].map((h) => (
            <text key={h} x={padL + h * bw + bw / 2} y={padT + ih + 14} className="ut-ax"
              textAnchor="middle">{String(h).padStart(2, "0")}</text>
          ))}
          <text x={padL} y={H - 4} className="ut-ax">
            active minutes by hour of day (UTC) over {v.lookback_days} days —{" "}
            {v.active_by_hour_minute
              ? "click any hour to drill into the minutes inside it"
              : "click any hour to focus it"}
          </text>
        </svg>
      )}
    </div>
  );
}

// Per-minute drilldown for one focused hour of the cluster's day: 60 bars.
function ClusterMinuteRhythm({ minutes, hour, lookbackDays }: {
  minutes: number[]; hour: number; lookbackDays: number;
}) {
  const W = 860, H = 168, padL = 40, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const bw = iw / 60;
  const maxM = Math.max(1, ...minutes);
  const y = (c: number) => padT + ih * (1 - c / maxM);
  const hh = String(hour).padStart(2, "0");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
      aria-label={`Active minutes by minute within the ${hh}:00 hour`}>
      {minutes.map((count, m) => (
        <rect key={m} x={padL + m * bw + bw * 0.12} y={y(count)}
          width={Math.max(bw * 0.76, 0.8)} height={Math.max(0, y(0) - y(count))}
          fill="var(--accent)" opacity={count > 0 ? 0.85 : 0.25} rx={0.5}>
          <title>{`${hh}:${String(m).padStart(2, "0")} — active on ${count} day${count === 1 ? "" : "s"}`}</title>
        </rect>
      ))}
      <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
      {[0, 10, 20, 30, 40, 50].map((m) => (
        <text key={m} x={padL + m * bw + bw / 2} y={padT + ih + 14} className="ut-ax"
          textAnchor="middle">{`${hh}:${String(m).padStart(2, "0")}`}</text>
      ))}
      <text x={padL} y={H - 4} className="ut-ax">
        active minutes within {hh}:00 (UTC) over {lookbackDays} days — a spike on one minute
        is a scheduled job; spread-out bars are ad-hoc use
      </text>
    </svg>
  );
}

// ---- cluster job contention: solo vs concurrent saturation ----------------
// The argument is the GAP between two bars. For CPU and for memory, we draw the
// cluster's saturation when a single job ran (solo) next to when >=2 jobs
// overlapped (concurrent, with its p95 marked). A taller concurrent bar is the
// visible evidence that jobs are competing; a concurrent bar no taller than solo
// would read as "busy regardless of overlap" (undersized, not contended) — which
// is exactly the case the rule declines to flag, so if this chart renders the
// gap is real. Semantic colors: --info = solo baseline, --warn = concurrent load.
function ClusterContention({ v }: { v: ClusterContentionViz }) {
  const metrics = [
    {
      label: "CPU",
      solo: v.cpu_solo,
      conc: v.cpu_concurrent,
      p95: v.cpu_concurrent_p95,
    },
    {
      label: "Memory",
      solo: v.mem_solo,
      conc: v.mem_concurrent,
      p95: v.mem_concurrent_p95,
    },
  ].filter((m) => m.conc != null);

  const W = 860, H = 240, padL = 44, padR = 16, padT = 40, padB = 52;
  const iw = W - padL - padR, ih = H - padT - padB;
  const y = (pct: number) => padT + ih * (1 - Math.min(100, pct) / 100);
  const groupW = iw / metrics.length;
  const barW = Math.min(90, groupW * 0.28);
  return (
    <div className="chart-scroll">
      <h4 className="ut-sub">
        Does saturation rise when jobs overlap? (solo vs concurrent)
      </h4>
      <p className="ut-note" style={{ marginTop: 0 }}>
        Up to <strong>{v.peak_concurrent_runs} job runs</strong> ran at once across{" "}
        <strong>{v.contended_minutes.toLocaleString()}</strong> overlapping minute
        {v.contended_minutes === 1 ? "" : "s"} ({v.contended_job_count} job
        {v.contended_job_count === 1 ? "" : "s"} involved). The taller the
        concurrent bar sits above the solo bar, the more the jobs are competing for
        the same fixed cores/memory.
      </p>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Cluster CPU and memory saturation, solo versus concurrent">
        {/* gridlines at 25/50/75/100% */}
        {[25, 50, 75, 100].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(g)} x2={padL + iw} y2={y(g)}
              stroke="var(--border)" strokeWidth={0.75} strokeDasharray="2 3" />
            <text x={padL - 6} y={y(g) + 3} className="ut-ax" textAnchor="end">{g}%</text>
          </g>
        ))}
        {metrics.map((m, i) => {
          const cx = padL + i * groupW + groupW / 2;
          const soloX = cx - barW - 6;
          const concX = cx + 6;
          const solo = m.solo ?? 0;
          const conc = m.conc ?? 0;
          return (
            <g key={m.label}>
              {/* solo bar */}
              {m.solo != null && (
                <rect x={soloX} y={y(solo)} width={barW} height={Math.max(0, y(0) - y(solo))}
                  fill="var(--info)" opacity={0.7} rx={2}>
                  <title>{`${m.label} solo (single job): ${solo.toFixed(0)}% avg`}</title>
                </rect>
              )}
              <text x={soloX + barW / 2} y={y(solo) - 5} className="ut-ax" textAnchor="middle">
                {m.solo != null ? `${solo.toFixed(0)}%` : "—"}
              </text>
              {/* concurrent bar */}
              <rect x={concX} y={y(conc)} width={barW} height={Math.max(0, y(0) - y(conc))}
                fill="var(--danger)" opacity={0.72} rx={2}>
                <title>{`${m.label} concurrent (>=2 jobs): ${conc.toFixed(0)}% avg`}</title>
              </rect>
              <text x={concX + barW / 2} y={y(conc) - 5} className="ut-ax" textAnchor="middle">
                {conc.toFixed(0)}%
              </text>
              {/* p95 tick on the concurrent bar — the worst-minute saturation */}
              {m.p95 != null && (
                <g>
                  <line x1={concX - 3} y1={y(m.p95)} x2={concX + barW + 3} y2={y(m.p95)}
                    stroke="var(--danger, var(--warn))" strokeWidth={2}>
                    <title>{`${m.label} concurrent p95: ${m.p95.toFixed(0)}%`}</title>
                  </line>
                  <text x={concX + barW + 6} y={y(m.p95) + 3} className="ut-ax">
                    p95 {m.p95.toFixed(0)}%
                  </text>
                </g>
              )}
              <text x={cx} y={padT + ih + 18} className="ut-ax" textAnchor="middle" fontWeight={600}>
                {m.label}
              </text>
              <text x={soloX + barW / 2} y={padT + ih + 32} className="ut-ax" textAnchor="middle">solo</text>
              <text x={concX + barW / 2} y={padT + ih + 32} className="ut-ax" textAnchor="middle">concurrent</text>
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
      </svg>
      <div className="ut-legend">
        <span><i style={{ background: "var(--info)" }} /> Single job (solo)</span>
        <span><i style={{ background: "var(--danger)" }} /> Jobs overlapping (concurrent, avg)</span>
        <span><i style={{ background: "var(--danger)" }} /> Concurrent p95 (worst minute)</span>
      </div>
    </div>
  );
}

// ---- A. warehouse auto-stop: day x hour state heatmap --------------------
function HourHeatmap({ v }: { v: HourHeatmapViz }) {
  const W = 860, H = 300, padL = 36, padT = 22, padB = 18, padR = 8;
  const days = v.grid.length;
  const cw = (W - padL - padR) / 24;
  const ch = (H - padT - padB) / days;
  const gap = 1.5;
  const fill = ["var(--track)", "var(--info)", "var(--warn)"];
  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label={v.context === "pipeline"
          ? "Pipeline updating, billed idle, and not billed by hour"
          : v.context === "keepalive"
            ? "Warehouse running real queries, held up only by keep-alive statements, and stopped by hour"
            : "Warehouse serving, warm idle, and stopped by hour"}>
        {v.grid.map((row, d) =>
          row.map((state, h) => (
            <rect key={`${d}-${h}`} x={padL + h * cw} y={padT + d * ch}
              width={cw - gap} height={ch - gap} rx={2}
              fill={fill[state]} opacity={state === 0 ? 0.5 : 1} />
          )),
        )}
        {[0, 4, 8, 12, 16, 20, 24].map((h) => (
          <text key={h} x={padL + h * cw} y={13} className="ut-ax" textAnchor="middle">
            {String(h % 24).padStart(2, "0")}
          </text>
        ))}
        {v.grid.map((_, d) => (
          <text key={d} x={padL - 8} y={padT + d * ch + ch / 2 + 3} className="ut-ax"
            textAnchor="end">
            {v.day_labels[d % v.day_labels.length]}
          </text>
        ))}
      </svg>
    </div>
  );
}

// ---- B. serverless: classic (warm floor) vs serverless (scale to zero) ---
function BurstCompare({ v }: { v: BurstCompareViz }) {
  return (
    <div className="ut-two">
      <BurstMini load={v.load} warmFloor={v.warm_floor} title="Classic (today)"
        note="Query bursts, but billed continuously through the idle gaps." />
      <BurstMini load={v.load} warmFloor={0} title="Serverless (proposed)"
        note="Same queries; compute scales to zero between bursts." />
    </div>
  );
}

function BurstMini({ load, warmFloor, title, note }: {
  load: number[]; warmFloor: number; title: string; note: string;
}) {
  const W = 400, H = 170, padL = 8, padR = 8, padB = 20, padT = 10;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = load.length, bw = iw / n;
  const y = (val: number) => padT + ih * (1 - val);
  return (
    <div className="ut-mini">
      <h3>{title}</h3>
      <p className="muted small">{note}</p>
      <div className="chart-scroll">
        <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img" aria-label={title}>
          {warmFloor > 0 && (
            <>
              <rect x={padL} y={y(warmFloor)} width={iw} height={H - padB - y(warmFloor)}
                fill="var(--warn)" opacity={0.32} />
              <line x1={padL} y1={y(warmFloor)} x2={padL + iw} y2={y(warmFloor)}
                stroke="var(--warn)" strokeWidth={1.5} strokeDasharray="3 3" />
            </>
          )}
          {load.map((val, i) =>
            val > 0.001 ? (
              <rect key={i} x={padL + i * bw} y={y(val)} width={Math.max(bw - 0.6, 0.8)}
                height={ih * val} rx={1} fill="var(--info)" />
            ) : null,
          )}
          <line x1={padL} y1={H - padB} x2={W - padR} y2={H - padB}
            stroke="var(--border)" strokeWidth={1} />
          <text x={padL} y={H - 6} className="ut-ax">3 days</text>
        </svg>
      </div>
    </div>
  );
}

// ---- C. cluster idle / right-size: CPU over time, with idle time shaded -----
function CpuArea({ v, resize }: { v: CpuAreaViz; resize?: { from: number; to: number } }) {
  const W = 860, H = 230, padL = 36, padR = 12, padB = 34, padT = 12;
  // A downsize asks "does the load still fit on fewer workers?". The same work
  // on to/from of the capacity runs at roughly from/to times the utilisation, so
  // project today's p95 onto the proposed size and draw it against the chart.
  // Linear scaling is a first-order estimate (driver-only work doesn't shrink),
  // which is why it is labelled "≈".
  const projectedP95 = resize && resize.to > 0 ? v.p95 * (resize.from / resize.to) : null;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.cpu.length;
  const y = (val: number) => padT + ih * (1 - Math.min(val, 1));
  const idleThr = v.idle_threshold ?? 0.1;

  // Real dated x-axis when timestamps are present (the series is sparse — only
  // the hours the cluster actually ran), else fall back to an even index axis.
  const ts = v.ts && v.ts.length === n ? v.ts : null;
  const t0 = ts ? ts[0] : 0;
  const t1 = ts ? ts[n - 1] : n - 1;
  const span = Math.max(1, t1 - t0);
  const x = (i: number) => padL + (iw * ((ts ? ts[i] - t0 : i)) / (ts ? span : Math.max(1, n - 1)));
  const colW = Math.max(1.5, iw / Math.max(n, 1));

  const pts = v.cpu.map((val, i) => `${x(i)},${y(val)}`);
  const usedArea = `M${x(0)},${y(0)} ${pts.map((p) => `L${p}`).join(" ")} L${x(n - 1)},${y(0)} Z`;
  const usedLine = `M${pts.map((p) => `L${p}`).join(" ").slice(1)}`;

  // Day/time ticks across the real time range.
  const ticks: { x: number; label: string }[] = [];
  if (ts) {
    const days = span / 86400;
    const count = 6;
    for (let k = 0; k <= count; k++) {
      const t = t0 + (span * k) / count;
      const d = new Date(t * 1000);
      const label =
        days >= 2
          ? `${d.getMonth() + 1}/${d.getDate()}`
          : `${String(d.getHours()).padStart(2, "0")}:00`;
      ticks.push({ x: padL + (iw * k) / count, label });
    }
  }

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Cluster CPU utilization over time with idle time shaded">
        {/* idle shading: one faint amber column per hour, opacity = idle share.
            Skipped when drawing a downsize — idleness is not the question there,
            and the stripes buried the headroom lines that are. */}
        {!projectedP95 && v.idle_frac?.map((f, i) =>
          f > 0.02 ? (
            <rect key={`idle-${i}`} x={x(i)} y={padT} width={colW} height={ih}
              fill="var(--warn)" opacity={Math.min(0.5, f * 0.5)} />
          ) : null,
        )}
        {[0, 0.25, 0.5, 0.75, 1].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(g)} x2={padL + iw} y2={y(g)} stroke="var(--border)"
              strokeWidth={1} opacity={0.5} />
            <text x={padL - 8} y={y(g) + 3} className="ut-ax" textAnchor="end">{g * 100}%</text>
          </g>
        ))}
        {/* idle threshold (idle-cluster context only) */}
        {!projectedP95 && (
          <>
            <line x1={padL} y1={y(idleThr)} x2={padL + iw} y2={y(idleThr)} stroke="var(--warn)"
              strokeWidth={1.25} strokeDasharray="2 3" />
            <text x={padL + 4} y={y(idleThr) - 4} className="ut-ax" fill="var(--warn)">
              idle below {(idleThr * 100).toFixed(0)}%
            </text>
          </>
        )}
        {projectedP95 !== null && resize && (
          <>
            <line x1={padL} y1={y(projectedP95)} x2={padL + iw} y2={y(projectedP95)}
              stroke="var(--violet)" strokeWidth={1.75} strokeDasharray="6 4" />
            <text x={padL + iw} y={y(projectedP95) - 5} className="ut-ax" textAnchor="end"
              fill="var(--violet)" fontWeight={600}>
              p95 on {resize.to} workers ≈ {Math.round(Math.min(projectedP95, 1.5) * 100)}%
            </text>
          </>
        )}
        <path d={usedArea} fill="var(--info)" opacity={0.16} />
        <path d={usedLine} fill="none" stroke="var(--info)" strokeWidth={1.75} />
        {/* p95 */}
        <line x1={padL} y1={y(v.p95)} x2={padL + iw} y2={y(v.p95)} stroke="var(--savings)"
          strokeWidth={1.5} strokeDasharray="5 4" />
        <text x={padL + iw} y={y(v.p95) - 5} className="ut-ax" textAnchor="end" fill="var(--savings)">
          p95 {(v.p95 * 100).toFixed(0)}%{resize ? ` on ${resize.from} workers today` : ""}
        </text>
        {/* dated x-axis */}
        {ticks.map((t, i) => (
          <g key={`tk-${i}`}>
            <line x1={t.x} y1={padT} x2={t.x} y2={padT + ih} stroke="var(--border)"
              strokeWidth={1} opacity={0.25} />
            <text x={t.x} y={H - 16} className="ut-ax" textAnchor="middle">{t.label}</text>
          </g>
        ))}
        <text x={padL} y={H - 4} className="ut-ax">
          {v.window_label} · hourly CPU across nodes{ts ? "" : " (index)"}
        </text>
      </svg>
    </div>
  );
}

// ---- E. failing jobs (G1): per-day succeeded vs failed runs -----------------
// Stacked bars per day — green success under red failure — so a recurring wall
// of failures is obvious. A dashed line marks the healthy baseline the finding
// compares against; the callout states the measured $ burned on failed runs.
function JobRuns({ v }: { v: JobRunsViz }) {
  const W = 860, H = 240, padL = 34, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxRuns = Math.max(1, ...v.days.map((d) => d.s + d.f));
  const y = (r: number) => padT + ih * (1 - Math.min(r, maxRuns) / maxRuns);

  const tickCount = Math.min(6, Math.max(n - 1, 1));
  const ticks = Array.from({ length: tickCount + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / Math.max(tickCount, 1));
    const dt = new Date((v.days[i]?.d ?? "") + "T00:00:00");
    return { x: padL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Job runs per day split into succeeded and failed">
        {[0, 0.25, 0.5, 0.75, 1].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(maxRuns * g)} x2={padL + iw} y2={y(maxRuns * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(maxRuns * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxRuns * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = padL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          const failTop = y(d.f), base = y(0), succTop = y(d.f + d.s);
          return (
            <g key={d.d}>
              {d.f > 0 && (
                <rect x={x} y={failTop} width={w} height={base - failTop} fill="var(--danger)" rx={1}>
                  <title>{`${d.d}: ${d.f} failed`}</title>
                </rect>
              )}
              {d.s > 0 && (
                <rect x={x} y={succTop} width={w} height={failTop - succTop} fill="var(--info)"
                  opacity={0.85} rx={1}>
                  <title>{`${d.d}: ${d.s} succeeded`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {ticks.map((t, i) => (
          <text key={i} x={t.x} y={H - 20} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
        <text x={padL} y={H - 5} className="ut-ax">
          {(v.fail_rate * 100).toFixed(0)}% of runs failed · ~${v.failed_cost.toLocaleString()}/mo
          burned on failures · healthy ≤ {(v.baseline_fail_rate * 100).toFixed(0)}%
        </text>
      </svg>
    </div>
  );
}

// ---- E2. jobs-compute rightsize: driver vs worker, side by side ------------
// Grouped bars (CPU, memory) contrasting the driver against the workers. When the
// driver bar towers over a near-zero worker bar, "the work is on the driver, the
// workers idle" is self-evident. worker_* null => single-node, draw the driver only.
function DriverWorkerSplit({ v }: { v: DriverWorkerSplitViz }) {
  const W = 860, H = 240, padL = 40, padR = 12, padB = 48, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const y = (pct: number) =>
    padT + ih * (1 - Math.min(Math.max(pct, 0), 100) / 100);
  const hasWorkers = v.worker_cpu !== null || v.worker_mem !== null;

  const groups: { label: string; driver: number; worker: number | null }[] = [
    { label: "CPU", driver: v.driver_cpu, worker: v.worker_cpu },
    { label: "Memory", driver: v.driver_mem, worker: v.worker_mem },
  ];
  const gw = iw / groups.length;
  const barW = Math.min(70, gw * (hasWorkers ? 0.28 : 0.4));
  const gap = 10;

  const callout =
    v.symptom === "idle_workers"
      ? `${v.worker_count} workers, all lightly used — cut the worker count`
      : v.symptom === "memory_oversize"
        ? "far more memory provisioned than the workload uses — move to a smaller node type"
        : `${v.worker_count} worker(s) idle while the driver does the work — go single-node`;

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Driver vs worker CPU and memory utilization">
        {[0, 25, 50, 75, 100].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(g)} x2={padL + iw} y2={y(g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(g) + 3} className="ut-ax" textAnchor="end">{g}%</text>
          </g>
        ))}
        {groups.map((grp, gi) => {
          const cx = padL + gi * gw + gw / 2;
          const pairW = hasWorkers ? barW * 2 + gap : barW;
          const x0 = cx - pairW / 2;
          return (
            <g key={grp.label}>
              <rect x={x0} y={y(grp.driver)} width={barW} height={y(0) - y(grp.driver)}
                fill="var(--info)" rx={2}>
                <title>{`Driver ${grp.label}: ${grp.driver.toFixed(1)}%`}</title>
              </rect>
              {hasWorkers && grp.worker !== null && (
                <rect x={x0 + barW + gap} y={y(grp.worker)} width={barW}
                  height={y(0) - y(grp.worker)} fill="var(--warn)" rx={2}>
                  <title>{`Workers ${grp.label}: ${grp.worker.toFixed(1)}%`}</title>
                </rect>
              )}
              <text x={cx} y={H - 30} className="ut-ax" textAnchor="middle">{grp.label}</text>
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        <text x={padL} y={H - 8} className="ut-ax">
          {hasWorkers
            ? callout
            : "single-node (no workers) — memory over-provisioned on the driver"}
        </text>
      </svg>
    </div>
  );
}

// ---- F. unused data (G2): daily writes with a flat-zero read line -----------
// A wall of write bars over a read line pinned at zero makes "produced but never
// consumed" self-evident. The callout states total writes vs the zero reads.
function WriteNoRead({ v }: { v: WriteNoReadViz }) {
  const W = 860, H = 220, padL = 34, padR = 12, padB = 40, padT = 16;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxW = Math.max(1, ...v.days.map((d) => d.w));
  const y = (val: number) => padT + ih * (1 - Math.min(val, maxW) / maxW);

  const tickCount = Math.min(6, Math.max(n - 1, 1));
  const ticks = Array.from({ length: tickCount + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / Math.max(tickCount, 1));
    const dt = new Date((v.days[i]?.d ?? "") + "T00:00:00");
    return { x: padL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Writes per day against a flat-zero read line">
        {[0, 0.5, 1].map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(maxW * g)} x2={padL + iw} y2={y(maxW * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(maxW * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxW * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = padL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.6);
          return d.w > 0 ? (
            <rect key={d.d} x={x} y={y(d.w)} width={w} height={y(0) - y(d.w)} fill="var(--violet)"
              opacity={0.7} rx={1}>
              <title>{`${d.d}: ${d.w} writes, ${d.r} reads`}</title>
            </rect>
          ) : null;
        })}
        {/* the flat-zero read line — the whole point */}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--info)" strokeWidth={2} />
        <text x={padL + iw} y={y(0) - 5} className="ut-ax" textAnchor="end" fill="var(--info)">
          reads: 0
        </text>
        {ticks.map((t, i) => (
          <text key={i} x={t.x} y={H - 20} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
        <text x={padL} y={H - 5} className="ut-ax">
          {v.total_writes.toLocaleString()} writes · {v.total_reads} reads over{" "}
          {v.lookback_days} days — output never consumed
        </text>
      </svg>
    </div>
  );
}

// ---- F2. serving endpoints: billed presence against real request traffic ---
// A billed marker appears for every day the endpoint incurred cost. Request bars
// use their own scale so a handful of requests remain visible instead of being
// flattened by the binary billed-day signal.
function ServingTraffic({ v }: { v: ServingTrafficViz }) {
  const W = 860, H = 230, padL = 36, padR = 12, padB = 42, padT = 24;
  const iw = W - padL - padR, ih = H - padB - padT;
  const n = v.days.length;
  const bw = iw / Math.max(n, 1);
  const maxRequests = Math.max(1, ...v.days.map((d) => d.r));
  const requestTicks = v.total_requests === 0 ? [0] : [0, 0.5, 1];
  const y = (requests: number) => padT + ih * (1 - Math.min(requests, maxRequests) / maxRequests);
  const tickCount = Math.min(6, Math.max(n - 1, 1));
  const ticks = Array.from({ length: tickCount + 1 }, (_, k) => {
    const i = Math.round((k * (n - 1)) / Math.max(tickCount, 1));
    const dt = new Date((v.days[i]?.d ?? "") + "T00:00:00");
    return { x: padL + i * bw + bw / 2, label: `${dt.getMonth() + 1}/${dt.getDate()}` };
  });

  return (
    <div className="chart-scroll">
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Endpoint billed days and inference requests by day">
        {requestTicks.map((g) => (
          <g key={g}>
            <line x1={padL} y1={y(maxRequests * g)} x2={padL + iw} y2={y(maxRequests * g)}
              stroke="var(--border)" strokeWidth={1} opacity={0.5} />
            <text x={padL - 6} y={y(maxRequests * g) + 3} className="ut-ax" textAnchor="end">
              {Math.round(maxRequests * g)}
            </text>
          </g>
        ))}
        {v.days.map((d, i) => {
          const x = padL + i * bw + Math.min(1, bw * 0.12);
          const w = Math.max(bw - Math.min(2, bw * 0.24), 0.8);
          return (
            <g key={d.d}>
              {d.w > 0 && (
                <rect x={x} y={padT - 10} width={w} height={5} rx={2} fill="var(--warn)">
                  <title>{`${d.d}: billed, ${d.r} request${d.r === 1 ? "" : "s"}`}</title>
                </rect>
              )}
              {d.r > 0 && (
                <rect x={x} y={y(d.r)} width={w} height={y(0) - y(d.r)} rx={1}
                  fill="var(--info)" opacity={0.9}>
                  <title>{`${d.d}: ${d.r} inference request${d.r === 1 ? "" : "s"}`}</title>
                </rect>
              )}
            </g>
          );
        })}
        <line x1={padL} y1={y(0)} x2={padL + iw} y2={y(0)} stroke="var(--border)" strokeWidth={1} />
        {ticks.map((t, i) => (
          <text key={i} x={t.x} y={H - 22} className="ut-ax" textAnchor="middle">{t.label}</text>
        ))}
        <text x={padL} y={H - 6} className="ut-ax">
          {v.days_billed} billed days, {v.total_requests.toLocaleString()} requests over {v.lookback_days} days
        </text>
      </svg>
    </div>
  );
}

// ---- G. warehouse right-size (G3): the headroom the decision actually used ---
// The old chart drew an abstract 2^i DBU-rate ladder — it said nothing about THIS
// warehouse. This shows the real load data the rule used to judge the size safe to
// drop: the three guard signals (queue / spill / scan) each as a margin, the
// measured value against the danger line it stays under. A short bar far from its
// limit is visible headroom. A compact "one notch down" header states the lever,
// and the KPIs to watch after the change sit beneath.
const sizeLabel = (s: string) =>
  s.toUpperCase().replace("XSMALL", "X_SMALL").replace(/_/g, "-").toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase()).replace("X-", "X-");

function WhRightsize({ v }: { v: WhRightsizeViz }) {
  return (
    <div className="ut-stack">
      <div className="chart-scroll">
        <h4 className="ut-sub">The lever: {sizeLabel(v.current_size)} → {sizeLabel(v.proposed_size)}</h4>
        {v.peak_slots_used != null && v.size_slots != null ? (
          <p className="ut-note">
            Each step down the ladder halves the DBU/hour rate. The primary signal here
            is <strong>measured Spark slot utilisation</strong>: at its busiest minute
            this warehouse used only <strong>~{v.peak_slots_used} of ~{v.size_slots} task
            slots ({v.slot_util_pct}%)</strong> — direct evidence of idle horsepower, not
            just the absence of stress. The other guards (queue, spill, scan) confirm it's
            safe. We recommend <strong>one step</strong> ({sizeLabel(v.current_size)} →{" "}
            {sizeLabel(v.proposed_size)}) — a bigger size also speeds each query, so change
            one notch and watch the KPIs before going further.
            {v.floor_size && (
              <>
                {" "}The utilisation suggests it could ultimately reach{" "}
                <strong>{sizeLabel(v.floor_size)}</strong>
                {v.floor_savings_usd != null && (
                  <> (~${Math.round(v.floor_savings_usd).toLocaleString()}/mo total)</>
                )}
                , reached one size at a time — not in a single jump.
              </>
            )}
          </p>
        ) : (
          <p className="ut-note">
            Each step down the ladder halves the DBU/hour rate. It's safe here because
            this warehouse's queries sit well inside the current size's headroom on every
            axis the rule can measure — shown below. No Spark task data was available, so
            size is inferred from query behaviour — a low-confidence call: try one notch
            down if you can accept slightly slower queries, then watch the KPIs.
          </p>
        )}
        <HeadroomGauges v={v} />
      </div>
    </div>
  );
}

function HeadroomGauges({ v }: { v: WhRightsizeViz }) {
  const W = 860, rowH = 46, padL = 150, padR = 90, padT = 8;
  const H = padT + v.headroom.length * rowH + 8;
  const iw = W - padL - padR;
  const fmt = (n: number, unit: string) =>
    unit === "%" ? `${n.toFixed(1)}%` : `${n.toFixed(n < 10 ? 2 : 1)} ${unit}`;
  return (
    <>
      <svg viewBox={`0 0 ${W} ${H}`} className="ut-svg" role="img"
        aria-label="Headroom on each guard signal: measured value versus its danger line">
        {v.headroom.map((h, i) => {
          const y = padT + i * rowH;
          const cy = y + rowH / 2;
          // Track spans 0..limit; the danger line sits at the right end. Bar width
          // is the measured value as a share of the limit (clamped so a rare
          // over-limit value still renders inside the track).
          const frac = h.limit > 0 ? Math.min(1, h.value / h.limit) : 0;
          const barW = Math.max(2, iw * frac);
          // Comfortable headroom (well under the line) is reassuring, not a warning.
          const fill = frac < 0.5 ? "var(--savings)" : frac < 0.85 ? "var(--info)" : "var(--danger)";
          return (
            <g key={h.key}>
              <text x={padL - 10} y={cy - 4} className="ut-ax" textAnchor="end" fontWeight={600}>
                {h.label}
              </text>
              <text x={padL - 10} y={cy + 10} className="ut-ax" textAnchor="end"
                fill="var(--faint)" fontSize={10}>
                limit {fmt(h.limit, h.unit)}
              </text>
              {/* track to the danger line */}
              <rect x={padL} y={cy - 8} width={iw} height={16} rx={3}
                fill="var(--track)" opacity={0.35} />
              {/* measured value */}
              <rect x={padL} y={cy - 8} width={barW} height={16} rx={3} fill={fill} opacity={0.9}>
                <title>{`${h.label}: ${fmt(h.value, h.unit)} — ${h.meaning}`}</title>
              </rect>
              {/* danger line */}
              <line x1={padL + iw} y1={cy - 12} x2={padL + iw} y2={cy + 12}
                stroke="var(--danger)" strokeWidth={2} strokeDasharray="3 2" />
              <text x={padL + iw + 8} y={cy + 4} className="ut-ax" fill="var(--danger)">
                {fmt(h.value, h.unit)}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="ut-legend">
        <span><i style={{ background: "var(--savings)" }} /> Comfortable headroom</span>
        <span><i style={{ background: "var(--danger)" }} /> Exclusion line (crossing it blocks the downsize)</span>
      </div>
      <p className="ut-note">
        KPIs to watch after the change: p95 query runtime (baseline {v.p95_runtime_s.toFixed(1)}s —
        expect a small rise), plus the queue and spill bars above staying near zero. Peak
        concurrency seen: {v.peak_concurrency} queries in one minute.
      </p>
    </>
  );
}
