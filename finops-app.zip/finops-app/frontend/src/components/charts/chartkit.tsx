/** Shared primitives for the daily-trend charts (SpendTrend, GenieTrend, AppsTrend).
 *
 *  Those three draw the same picture — ~30 daily bars, a line overlay, three date
 *  ticks — so the y-axis and the hover layer live here once instead of three copies.
 *  Still dependency-free SVG; every colour a CSS var, matching the rest of the app.
 *
 *  Two deliberate design points:
 *   - Bars scale to a *rounded* ceiling (niceTicks.niceMax), not the raw max, so the
 *     tallest bar stops just under a round gridline instead of touching the frame.
 *   - Dual-axis charts (Genie users, Apps count) give the right axis its OWN round
 *     ticks, tinted to the line's colour, rather than deriving them off the left
 *     gridlines — both axes then read as clean numbers. Gridlines follow the left
 *     axis only, so the plot stays uncluttered; exact values come from the tooltip. */

import { useState } from "react";

export interface Geo {
  W: number; H: number;
  padT: number; padB: number; padL: number; padR: number;
  plotW: number; plotH: number;
  bw: number; barW: number;
}

/** Fixed 720x190 frame. The left gutter holds the y-axis labels (was 4px, nowhere
 *  near enough); the right gutter widens only when a second axis is drawn. */
export function trendGeometry(n: number, opts: { rightAxis?: boolean } = {}): Geo {
  const W = 720, H = 190, padT = 10, padB = 22, padL = 46;
  const padR = opts.rightAxis ? 46 : 14;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const bw = plotW / Math.max(1, n);
  const barW = Math.max(1, bw * 0.72);
  return { W, H, padT, padB, padL, padR, plotW, plotH, bw, barW };
}

export const barX = (g: Geo, i: number) => g.padL + i * g.bw + (g.bw - g.barW) / 2;
export const colCenter = (g: Geo, i: number) => g.padL + i * g.bw + g.bw / 2;

/** Round a max up to a "nice" ceiling and return the gridline values on the way up.
 *  Steps are 1 / 2 / 5 x 10^n — the intervals people expect to see on an axis. */
export function niceTicks(max: number, target = 4): { ticks: number[]; niceMax: number } {
  if (!(max > 0)) return { ticks: [0, 1], niceMax: 1 };
  const raw = max / target;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const r = raw / mag;
  const step = mag * (r <= 1 ? 1 : r <= 2 ? 2 : r <= 5 ? 5 : 10);
  const niceMax = Math.ceil(max / step) * step;
  const ticks: number[] = [];
  for (let t = 0; t <= niceMax + step * 1e-9; t += step) {
    ticks.push(Math.round(t * 1e6) / 1e6); // kill float drift so labels read clean
  }
  return { ticks, niceMax };
}

/** Faint horizontal gridlines + left y-axis labels, and optionally a right axis.
 *  Render this BEFORE the bars so the grid sits behind the data. */
export function Axis({
  geo, ticks, max, formatLeft, right,
}: {
  geo: Geo;
  ticks: number[];
  max: number;
  formatLeft: (n: number) => string;
  right?: { ticks: number[]; max: number; format: (n: number) => string; color: string };
}) {
  const { padL, padT, plotH, W, padR } = geo;
  const yOf = (t: number, m: number) => padT + plotH - (t / m) * plotH;
  return (
    <g>
      {ticks.map((t, idx) => (
        <g key={`l${t}`}>
          <line
            x1={padL}
            x2={W - padR}
            y1={yOf(t, max)}
            y2={yOf(t, max)}
            stroke="var(--border)"
            strokeWidth={idx === 0 ? 1 : 0.6}
            opacity={idx === 0 ? 0.9 : 0.45}
          />
          <text x={padL - 6} y={yOf(t, max) + 3} textAnchor="end" fontSize={9.5} fill="var(--faint)">
            {formatLeft(t)}
          </text>
        </g>
      ))}
      {right &&
        right.ticks.map((t) => (
          <g key={`r${t}`}>
            <line
              x1={W - padR}
              x2={W - padR + 4}
              y1={yOf(t, right.max)}
              y2={yOf(t, right.max)}
              stroke={right.color}
              strokeWidth={0.8}
              opacity={0.7}
            />
            <text
              x={W - padR + 7}
              y={yOf(t, right.max) + 3}
              textAnchor="start"
              fontSize={9.5}
              fill={right.color}
            >
              {right.format(t)}
            </text>
          </g>
        ))}
    </g>
  );
}

/** Full-height transparent columns, one per day, so the hover target is the whole
 *  slot — a 1px bar is otherwise almost impossible to point at. onLeave is wired on
 *  the wrapping element by the caller. */
export function HitColumns({
  geo, count, onHover,
}: {
  geo: Geo;
  count: number;
  onHover: (i: number | null) => void;
}) {
  const { padL, padT, plotH, bw } = geo;
  return (
    <g>
      {Array.from({ length: count }).map((_, i) => (
        <rect
          key={i}
          x={padL + i * bw}
          y={padT}
          width={bw}
          height={plotH}
          fill="transparent"
          onMouseEnter={() => onHover(i)}
          onMouseMove={() => onHover(i)}
        />
      ))}
    </g>
  );
}

export interface TipRow { color: string; label: string; value: string }

/** HTML tooltip pinned above the hovered column. Positioned in percent of the frame
 *  so it tracks the bar through the SVG's responsive scaling, and anchored
 *  left / centre / right near the edges so it never spills out of the card. */
export function TrendTooltip({
  geo, index, title, rows,
}: {
  geo: Geo;
  index: number;
  title: string;
  rows: TipRow[];
}) {
  const pct = (colCenter(geo, index) / geo.W) * 100;
  const tx = pct < 18 ? "0%" : pct > 82 ? "-100%" : "-50%";
  return (
    <div className="chart-tooltip" style={{ left: `${pct}%`, transform: `translateX(${tx})` }}>
      <div className="ct-title">{title}</div>
      {rows.map((r, i) => (
        <div className="ct-row" key={i}>
          <span className="ct-dot" style={{ background: r.color }} />
          <span className="ct-label">{r.label}</span>
          <span className="ct-val">{r.value}</span>
        </div>
      ))}
    </div>
  );
}

/** Hover-index state plus the opacity a bar should take: full when it is the hovered
 *  day (or when nothing is hovered), dimmed otherwise. */
export function useHover() {
  const [hovered, setHovered] = useState<number | null>(null);
  const dim = (i: number, base = 1) => (hovered === null || hovered === i ? base : base * 0.32);
  return { hovered, setHovered, dim };
}
