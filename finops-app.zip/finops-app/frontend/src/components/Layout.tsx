import {
  AdjustmentsHorizontalIcon,
  BeakerIcon,
  BoltIcon,
  BuildingOffice2Icon,
  ChartBarSquareIcon,
  ChatBubbleLeftRightIcon,
  ListBulletIcon,
  SparklesIcon,
  Squares2X2Icon,
  UserCircleIcon,
} from "@heroicons/react/24/outline";
import { useIsFetching } from "@tanstack/react-query";
import { useEffect } from "react";
import { matchPath, NavLink, Outlet, useLocation } from "react-router-dom";
import type { Identity } from "../api/types";
import { useAccountScope } from "../hooks/useAccountScope";
import { useConfig } from "../hooks/useConfig";
import { usePricing } from "../hooks/usePricing";
import { useWorkspaceScope } from "../hooks/useWorkspaceScope";
import { PricingProvider } from "../lib/PricingContext";
import { AccountRefineBar } from "./AccountRefineBar";
import { DataHealthBanner } from "./DataHealthBanner";
import { PriceBasisSwitch } from "./PriceBasisSwitch";
import { ThemeToggle } from "./ThemeToggle";
import { WorkspaceSwitcher } from "./WorkspaceSwitcher";

export function Layout({ identity }: { identity: Identity }) {
  const isAdmin = identity.role === "platform_admin";
  const location = useLocation();
  // Genie Costs is a single-account view; in central (logfood) mode Genie spend is
  // not the surface we expose, so the tab shows only when central_mode is false.
  const { data: config } = useConfig();
  const showGenieCosts = !config?.central_mode;
  // Phase 4 Labs tab: shown only when experimental rules are active (a deploy can
  // hide it with FINOPS_EXPERIMENTAL_RULES=""). Default true so it appears until
  // config loads, matching how the other content tabs render.
  const showLabs = config?.experimental_enabled ?? true;
  const [, setScope] = useWorkspaceScope();
  // Central mode only: the account chosen at the gate. "Change account" clears it,
  // which sends App back to the gate (see App.tsx). Empty in single-account mode.
  const [accountScope, setAccountScope] = useAccountScope();
  const selectedAccount = accountScope.salesforce_account_name;
  // Any in-flight query (page load, tab change, or a scope switch that
  // invalidates every cache) drives a thin top progress bar, so the app reads as
  // "loading" rather than frozen while data refetches. > 0 = something fetching.
  const fetching = useIsFetching();
  // Fetch pricing capability data to drive the price basis switch
  const { data: pricing } = usePricing();
  // A per-workspace deep link (/workspaces/:id/...) adopts that workspace as the
  // global scope on open, so the rest of the app follows the link you clicked and
  // the switcher reflects it. Global scope is otherwise the single source of truth
  // (see lib/scope), so the nav links below stay on their plain platform paths.
  const linkedWorkspace =
    matchPath("/workspaces/:workspaceId", location.pathname)?.params.workspaceId ??
    matchPath("/workspaces/:workspaceId/:page", location.pathname)?.params.workspaceId;
  useEffect(() => {
    if (linkedWorkspace) setScope(linkedWorkspace);
  }, [linkedWorkspace, setScope]);
  const appsHref = "/apps";
  return (
    <PricingProvider pricing={pricing ?? null}>
    <div className="app-shell">
      {/* Global fetch indicator: a slim indeterminate bar pinned to the very top
          while any query is in flight. Non-blocking — the page stays interactive. */}
      <div className={`load-bar${fetching ? " load-bar-active" : ""}`} role="progressbar"
        aria-hidden={fetching ? undefined : true} aria-label="Loading" />
      {/* Header splits into two rows so nothing has to fight for width: an identity
          row (brand + account/workspace scope + user + theme) on top, and a
          dedicated full-width tab row below. Both scroll away together (one sticky
          wrapper), so the nav no longer overflows or clips the logo. */}
      <div className="site-header">
        <header className="topbar">
          <div className="brand">
            <span className="brand-logo">
              <BoltIcon />
            </span>
            <span>
              <div className="brand-name">
                FinOps <span className="beta-badge">Beta</span>
              </div>
              <div className="brand-sub">Databricks Cost Optimizer</div>
            </span>
          </div>
          <div className="topbar-right">
            {selectedAccount && (
              <div className="account-chip" title="Current account">
                <BuildingOffice2Icon className="account-chip-icon" />
                <span className="account-chip-name">{selectedAccount}</span>
                <button
                  type="button"
                  className="account-chip-change"
                  onClick={() =>
                    setAccountScope({
                      salesforce_account_name: "",
                      cloud_type: "",
                      databricks_account_id: "",
                    })
                  }
                >
                  Change
                </button>
              </div>
            )}
            <PriceBasisSwitch />
            <WorkspaceSwitcher identity={identity} />
            <div className="identity">
              <span className={`role-pill role-${identity.role}`}>
                {isAdmin
                  ? "Platform Admin"
                  : identity.workspace_ids.some((w) => w && w !== "0") || !config?.stoptheleak_enabled
                    ? "Workspace Admin"
                    : "User"}
              </span>
              <span className="user">{identity.user}</span>
              <span
                className="mode-tag"
                title={`compute=${identity.compute_mode}, auth=${identity.auth_mode}`}
              >
                {identity.compute_mode}/{identity.auth_mode}
              </span>
            </div>
            <ThemeToggle />
          </div>
        </header>
        <nav className="navbar">
          <div className="nav">
            {isAdmin && (
              <NavLink to="/" end>
                <BuildingOffice2Icon className="nav-icon" /> Overview
              </NavLink>
            )}
            {/* Optional StopTheLeak integration. Every signed-in user, admin or
                not: the findings routed to them. */}
            {config?.stoptheleak_enabled && (
              <NavLink to="/my-findings">
                <UserCircleIcon className="nav-icon" /> My findings
              </NavLink>
            )}
            <NavLink to="/next-best-actions">
              <SparklesIcon className="nav-icon" /> Next Best Actions
            </NavLink>
            <NavLink to="/recommendations">
              <ListBulletIcon className="nav-icon" /> Recommendations
            </NavLink>
            <NavLink to="/cost-anomalies">
              <ChartBarSquareIcon className="nav-icon" /> Cost Anomalies
            </NavLink>
            <NavLink to={appsHref}>
              <Squares2X2Icon className="nav-icon" /> Apps
            </NavLink>
            {showGenieCosts && (
              <NavLink to="/genie-costs">
                <ChatBubbleLeftRightIcon className="nav-icon" /> Genie Costs
              </NavLink>
            )}
            {showLabs && (
              <NavLink to="/labs">
                <BeakerIcon className="nav-icon" /> Labs
              </NavLink>
            )}
            <NavLink to="/rules">
              <AdjustmentsHorizontalIcon className="nav-icon" /> Rule Catalog
            </NavLink>
          </div>
        </nav>
      </div>
      {/* Unofficial-tool disclaimer. Sits directly under the topbar, above every
          page, so no one mistakes these estimates for an official Databricks
          product or exact figures. */}
      <div className="disclaimer-strip" role="note">
        <strong>Unofficial dashboard · Beta.</strong> Savings and cost figures are
        best-guess estimates — your actual results will vary.
      </div>
      {/* Secondary cascading filters within the selected account (central mode): cloud,
          then Databricks account id. Renders nothing when there's nothing to refine. */}
      <AccountRefineBar />
      <main className="content">
        {/* Sits above every page: incomplete findings are incomplete everywhere,
            not just on the page that happens to show a rule's output. Renders
            nothing when all sources are readable. */}
        <DataHealthBanner />
        <Outlet />
      </main>
      {/* Version tag: baked in at build time (see vite.config.ts) so it's always
          clear which build is deployed — the first thing to check when a report
          and the running app disagree. */}
      <footer className="app-footer">
        <span>
          FinOps · <span className="mono">{__APP_VERSION__}</span>
        </span>
        <a
          href="https://databricks.enterprise.slack.com/archives/C0BPLDZ2XGB"
          target="_blank"
          rel="noreferrer"
        >
          Feedback &amp; updates: #finops-app
        </a>
      </footer>
    </div>
    </PricingProvider>
  );
}
