import { ArrowRightIcon, BuildingOffice2Icon } from "@heroicons/react/24/outline";
import { useAccountScope } from "../hooks/useAccountScope";
import { useRecommendationFacets } from "../hooks/useRecommendations";

/** First screen in central (multi-account) mode: pick ONE customer account before
 *  any account data loads.
 *
 *  Why a gate rather than an always-on switcher: the app reads its precomputed data
 *  from a shared warehouse, so an unscoped "all accounts" view loads every customer's
 *  findings at once (tens of MB, the slowest request). Forcing a pick means the app
 *  only ever loads one account, the backend caches that account's result, and every
 *  subsequent surface is served warm. Swapping accounts returns here via the topbar's
 *  "Change account" button. See docs and lib/accountScope.
 *
 *  The account list comes from the account-independent facets endpoint (it lists every
 *  account regardless of the current pick), so this is the one place that must wait on
 *  facets — the rest of the app is already scoped by the time it renders. */
export function AccountGate() {
  const { data: facets, isLoading, error } = useRecommendationFacets();
  const [, setScope] = useAccountScope();
  const accounts = facets?.salesforce_account_name ?? [];

  return (
    <div className="account-gate">
      <div className="account-gate-card">
        <div className="account-gate-head">
          <span className="account-gate-logo">
            <BuildingOffice2Icon />
          </span>
          <h1>Select an account</h1>
          <p>
            Choose the customer you want to review. Only that account&rsquo;s data is
            loaded, so the app stays fast. You can switch accounts anytime from the top bar.
          </p>
        </div>

        {isLoading && <div className="account-gate-status">Loading accounts…</div>}
        {error && (
          <div className="account-gate-status error">
            Could not load the account list. {String(error)}
          </div>
        )}
        {!isLoading && !error && accounts.length === 0 && (
          <div className="account-gate-status">No accounts are available in this dataset.</div>
        )}

        {accounts.length > 0 && (
          <ul className="account-gate-list">
            {accounts.map((name) => (
              <li key={name}>
                <button
                  type="button"
                  className="account-gate-option"
                  onClick={() => setScope({ salesforce_account_name: name })}
                >
                  <BuildingOffice2Icon className="account-gate-option-icon" />
                  <span className="account-gate-option-name">{name}</span>
                  <ArrowRightIcon className="account-gate-option-go" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
