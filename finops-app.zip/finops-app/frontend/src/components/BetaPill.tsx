// A "Beta" pill for rules that are live on the main surfaces but still being
// validated: the 11 promoted out of Labs on 2026-09-23 (v0.5.0). Remove a rule
// from BETA_RULES once its findings have held up on real accounts.
// rules/finops_rules/tests/test_beta_rules.py pins this list to real, promoted
// (non-experimental) rules, so a typo or a rename fails the Python suite.
export const BETA_RULES: ReadonlySet<string> = new Set([
  "warehouse_keepalive_queries",
  "alert_hygiene",
  "warehouse_min_clusters",
  "unpruned_repeated_queries",
  "unviewed_scheduled_dashboards",
  "pipeline_failed_updates",
  "job_no_new_input",
  "sql_repeated_failures",
  "job_task_retry_waste",
  "serving_provisioned_overcapacity",
  "instance_pool_idle",
]);

export const BETA_HINT =
  "Beta rule: new in v0.5 and still being validated on real accounts. " +
  "Its logic, thresholds and dollar figures may change — check the finding " +
  "against the resource before acting on it.";

export const isBetaRule = (ruleId: string | undefined | null) =>
  !!ruleId && BETA_RULES.has(ruleId);

/** Renders nothing for a rule that isn't in beta, so callers can drop it in
 *  next to any rule title unconditionally. */
export function BetaPill({ ruleId }: { ruleId: string | undefined | null }) {
  if (!isBetaRule(ruleId)) return null;
  return (
    // data-tip drives the styled hover/focus tooltip (index.css .beta-rule); a native
    // title would show a second, delayed tooltip on top of it.
    <span className="beta-badge beta-rule" data-tip={BETA_HINT} aria-label={BETA_HINT}
      role="note" tabIndex={0} onClick={(e) => e.stopPropagation()}>
      Beta
    </span>
  );
}
