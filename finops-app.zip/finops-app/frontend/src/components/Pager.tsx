/** Page controls for a long result list.
 *
 *  The recommendation list runs to hundreds of rows on a real account, which is
 *  unusable as one table — so callers slice their data and render this beneath it.
 *  Purely presentational: it owns no state, it just reports the requested page. */
export function Pager({
  page,
  pageCount,
  pageSize,
  total,
  onPage,
  onPageSize,
  pageSizes = [25, 50],
}: {
  page: number; // 1-based
  pageCount: number;
  pageSize: number;
  total: number;
  onPage: (page: number) => void;
  onPageSize: (size: number) => void;
  pageSizes?: number[];
}) {
  if (total === 0) return null;
  const first = (page - 1) * pageSize + 1;
  const last = Math.min(page * pageSize, total);

  return (
    <div className="pager">
      <span className="pager-count">
        Showing <span className="strong">{first}</span>–<span className="strong">{last}</span>{" "}
        of <span className="strong">{total}</span>
      </span>
      <label className="pager-size">
        Per page
        <select value={pageSize} onChange={(e) => onPageSize(Number(e.target.value))}>
          {pageSizes.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </label>
      <span className="pager-nav">
        <button onClick={() => onPage(1)} disabled={page <= 1} aria-label="First page">
          «
        </button>
        <button onClick={() => onPage(page - 1)} disabled={page <= 1} aria-label="Previous page">
          ‹
        </button>
        <span className="pager-pos">
          Page {page} of {pageCount}
        </span>
        <button
          onClick={() => onPage(page + 1)}
          disabled={page >= pageCount}
          aria-label="Next page"
        >
          ›
        </button>
        <button
          onClick={() => onPage(pageCount)}
          disabled={page >= pageCount}
          aria-label="Last page"
        >
          »
        </button>
      </span>
    </div>
  );
}
