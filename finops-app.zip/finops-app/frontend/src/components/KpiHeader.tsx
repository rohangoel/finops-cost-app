import {
  ArrowTrendingDownIcon,
  BanknotesIcon,
  BuildingOffice2Icon,
  ListBulletIcon,
} from "@heroicons/react/24/outline";
import type { ComponentType, SVGProps } from "react";
import type { AccountSpend, PricedTotals, SavingsTier } from "../api/types";
import { moneyExact } from "../lib/format";
import { pct, type PricingBasis } from "../lib/price";

type Variant = "accent" | "spend" | "default";

export interface KpiBreakdownRow {
  label: string;
  value: string;
  tier: string; // booked | high | medium | low — drives the swatch colour
}

export interface Kpi {
  label: string;
  value: string;
  sub?: string;
  /** Optional amber "estimated" line under the sub — the fuller, still-estimated
   *  figure shown beneath a high-confidence booked headline (savings tile). */
  estimate?: string;
  /** Optional per-tier breakdown rendered inside the tile (savings headline): the
   *  Booked / High / Medium / Low confidence split that sums to the value. */
  breakdown?: KpiBreakdownRow[];
  /** Coverage chip under a blended "Your rates" figure; `title` is the full split. */
  chip?: { text: string; title: string };
  /** The same figure on the other price basis, one line below ("$401k at list price"). */
  alt?: string;
  /** A quiet footnote (e.g. "priced at list"). */
  note?: string;
  variant?: Variant;
}

const TIER_LABEL: Record<string, string> = {
  booked: "Booked",
  high: "High confidence",
  medium: "Medium confidence",
  low: "Low confidence",
};

const ICON: Record<Variant, ComponentType<SVGProps<SVGSVGElement>>> = {
  accent: ArrowTrendingDownIcon,
  spend: BanknotesIcon,
  default: ListBulletIcon,
};

export function KpiHeader({ kpis }: { kpis: Kpi[] }) {
  return (
    <div className="kpi-row">
      {kpis.map((k) => {
        const variant = k.variant ?? "default";
        const Icon = k.label.toLowerCase().includes("workspace")
          ? BuildingOffice2Icon
          : ICON[variant];
        return (
          <div key={k.label} className={`kpi kpi-${variant}`}>
            <div className="kpi-head">
              <span className="kpi-label">{k.label}</span>
              <span className="kpi-icon">
                <Icon />
              </span>
            </div>
            <div className="kpi-value">{k.value}</div>
            {k.sub && <div className="kpi-sub">{k.sub}</div>}
            {k.chip && (
              <div>
                <span className="basis-chip" title={k.chip.title}>{k.chip.text}</span>
              </div>
            )}
            {k.alt && <div className="basis-alt">{k.alt}</div>}
            {k.estimate && <div className="kpi-estimate">{k.estimate}</div>}
            {k.note && <div className="basis-note">{k.note}</div>}
            {k.breakdown && k.breakdown.length > 0 && (
              <details className="kpi-breakdown-details">
                <summary>Confidence split</summary>
                <ul className="kpi-breakdown">
                  {k.breakdown.map((b) => (
                    <li key={b.tier}>
                      <span className={`tier-dot tier-dot-${b.tier}`} aria-hidden="true" />
                      <span className="kpi-bd-label">{b.label}</span>
                      <span className="kpi-bd-value">{b.value}</span>
                    </li>
                  ))}
                </ul>
              </details>
            )}
          </div>
        );
      })}
    </div>
  );
}

/** The headline KPIs.
 *
 *  `totalSpend` is what the workspace/account actually costs, read from the spend
 *  source (`useSpend`). It replaces the old "wasteful spend" figure, which was a
 *  sum of per-rule waste estimates — a number that was easy to misread as a real
 *  bill and impossible to reconcile against one. Total spend is the real billed
 *  amount, and it gives the savings figure a meaningful denominator.
 *
 *  Pass `totalSpend = undefined` when spend data is unavailable, and the tile is
 *  omitted rather than rendered as $0. */
/** The savings band + per-tier split behind the headline (from AccountOverview /
 *  WorkspaceDetail). Optional so older snapshots (no band) fall back to the booked value. */
export interface SavingsBand {
  addressable: number; // the estimate (booked + estimated), the headline figure
  low: number; // conservative low of the band
  high: number; // upper-scenario high of the band
  tiers: SavingsTier[]; // split summing to `addressable`
}

export function savingsKpis(
  savings: number,
  addressable: number,
  recs: number,
  workspaces?: number,
  totalSpend?: number,
  outOfScopeWorkspaces?: number,
  band?: SavingsBand,
): Kpi[] {
  // The headline now leads with the ESTIMATE (booked + estimated), not just the booked
  // floor — so the number reflects the whole opportunity. Under it we state the band
  // (pessimistic low → optimistic high) and break the estimate into its trust tiers
  // (Booked + High/Medium/Low confidence), which sum back to the headline. When no band
  // is available (older snapshot) we fall back to the booked figure, framed as before.
  const headline = band ? band.addressable : savings;
  const share =
    totalSpend && totalSpend > 0 ? Math.round((headline / totalSpend) * 100) : undefined;
  const spendClause = share !== undefined ? ` · ${share}% of total spend` : "";

  let sub: string;
  let estimate: string | undefined;
  let breakdown: KpiBreakdownRow[] | undefined;
  if (band && band.high > band.low + 0.005) {
    // "$700k – $1.5M range" beneath the headline estimate, plus the tier split.
    sub = `${moneyExact(band.low)} – ${moneyExact(band.high)} range${spendClause}`;
    breakdown = band.tiers
      .filter((t) => t.monthly_savings_usd > 0.005)
      .map((t) => ({
        tier: t.tier,
        label: TIER_LABEL[t.tier] ?? t.tier,
        value: moneyExact(t.monthly_savings_usd),
      }));
  } else {
    // No usable band: keep the prior booked-floor framing.
    sub =
      share !== undefined
        ? `High confidence · ${share}% of total spend`
        : "High confidence · conservative booked floor";
    estimate =
      addressable > savings + 0.005 ? `Estimated ${moneyExact(addressable)}` : undefined;
  }

  const kpis: Kpi[] = [
    {
      label: "Savings potential / mo",
      value: moneyExact(headline),
      variant: "accent",
      sub,
      estimate,
      breakdown,
    },
  ];
  if (totalSpend !== undefined) {
    kpis.push({
      label: "Total spend / mo",
      value: moneyExact(totalSpend),
      variant: "spend",
      sub: "all billed usage at list price",
    });
  }
  kpis.push({ label: "Recommendations", value: String(recs), sub: "open opportunities" });
  if (workspaces !== undefined) {
    kpis.push({
      label: "Workspaces with findings",
      value: String(workspaces),
      // The label already says these are workspaces with findings. Only call out the
      // regional exclusion, and only when billing actually left some workspaces out.
      sub:
        outOfScopeWorkspaces && outOfScopeWorkspaces > 0
          ? `${outOfScopeWorkspaces} other region${outOfScopeWorkspaces === 1 ? "" : "s"} excluded`
          : undefined,
    });
  }
  return kpis;
}


const SAVINGS_LABEL = "Savings potential / mo";
const SPEND_LABEL = "Total spend / mo";

/** Re-state the headline tiles on the selected price basis (plan §A6).
 *
 *  * "Your rates": the savings tile shows the BLENDED estimate (contract where a
 *    finding has a contract figure, list otherwise) with a coverage chip whose hover
 *    gives the split, and the list figure one line below — both numbers visible
 *    without toggling. Total Spend follows the same rule when the spend snapshot
 *    carries a contract total.
 *  * "List price" with contract data: list headline, "$X at your rates" below.
 *  * No contract data: unchanged, plus one quiet "priced at list" note.
 *  * Cloud VM savings (classic compute) get their OWN tile — never added into the
 *    Databricks figure (decision D3) — and the spend tile a "+ cloud VM" sub-line. */
export function withPriceBasis(
  kpis: Kpi[],
  opts: {
    basis: PricingBasis;
    priced?: PricedTotals | null;
    spend?: Pick<
      AccountSpend,
      "total_monthly_spend_contract_usd" | "contract_priced_share" | "total_monthly_cloud_cost_usd"
    > | null;
  },
): Kpi[] {
  const { basis, priced, spend } = opts;
  const out = kpis.map((k) => ({ ...k }));
  const sav = out.find((k) => k.label === SAVINGS_LABEL);
  const contract = priced?.contract_available ? priced : null;
  if (sav) {
    if (!contract) {
      sav.note = "priced at list";
    } else {
      const total = contract.monthly_savings_addressable_usd;
      const share = total > 0 ? contract.contract_part_usd / total : 1;
      const split =
        `${moneyExact(contract.contract_part_usd)} at contract rates ` +
        `(${contract.contract_findings.toLocaleString()} findings) + ` +
        `${moneyExact(contract.list_part_usd)} at list ` +
        `(${contract.list_findings.toLocaleString()} findings without a contract price)`;
      if (basis === "contract") {
        const listValue = sav.value;
        sav.value = moneyExact(total);
        sav.sub =
          contract.monthly_savings_high_usd > contract.monthly_savings_low_usd + 0.005
            ? `${moneyExact(contract.monthly_savings_low_usd)} – ${moneyExact(contract.monthly_savings_high_usd)} range`
            : undefined;
        sav.estimate = undefined;
        // The confidence split is composed at list; don't pair it with a blended value.
        sav.breakdown = undefined;
        sav.chip = { text: `${pct(share)} at your rates`, title: split };
        sav.alt = `${listValue} at list price`;
      } else {
        sav.alt = `${moneyExact(total)} at your rates (${pct(share)} contract-priced)`;
      }
    }
  }
  const sp = out.find((k) => k.label === SPEND_LABEL);
  if (sp && spend) {
    const blended = spend.total_monthly_spend_contract_usd;
    const share = spend.contract_priced_share;
    if (blended != null && share != null && contract) {
      if (basis === "contract") {
        const listValue = sp.value;
        sp.value = moneyExact(blended);
        sp.sub = "all billed usage";
        sp.chip = {
          text: `${pct(share)} at your rates`,
          title: `${pct(share)} of spend (by list value) has a contract price; the rest is shown at list.`,
        };
        sp.alt = `${listValue} at list price`;
      } else {
        sp.alt = `${moneyExact(blended)} at your rates`;
      }
    }
    if (spend.total_monthly_cloud_cost_usd != null) {
      sp.note = `+ ${moneyExact(spend.total_monthly_cloud_cost_usd)} cloud VM (classic compute, billed by your cloud)`;
    }
  }
  if (priced?.cloud_available) {
    const at = out.findIndex((k) => k.label === SAVINGS_LABEL);
    out.splice(at + 1, 0, {
      label: "Cloud VM savings / mo",
      value: moneyExact(priced.monthly_cloud_savings_usd),
      variant: "accent",
      sub: "classic compute · not included in the Databricks figure",
      note: `${priced.cloud_findings} of ${priced.classic_findings} classic findings have cloud cost data`,
    });
  }
  return out;
}
