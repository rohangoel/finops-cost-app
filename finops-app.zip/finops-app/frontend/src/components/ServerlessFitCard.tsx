import {
  BoltIcon,
  CheckCircleIcon,
  QuestionMarkCircleIcon,
  XCircleIcon,
} from "@heroicons/react/24/outline";
import { Link } from "react-router-dom";
import type { ServerlessFit } from "../api/types";
import { moneyExact } from "../lib/format";

/** "Serverless fit" verdict for a resource, shown on the detail page above the
 *  recommendations.
 *
 *  The point is to make the engine's silent `None` explicit: serverless is the
 *  default alternative worth stating a position on, so we say whether it's
 *  recommended, already in use, not a fit, or genuinely unknowable — and show a
 *  projected saving ONLY when a real finding measured one (the backend guarantees
 *  the number is null otherwise, so we never invent one for a ruled-out workload). */
export function ServerlessFitCard({ fit }: { fit: ServerlessFit }) {
  const { icon: Icon, tone } = STYLE[fit.verdict] ?? STYLE.cannot_estimate;
  const projected = fit.projected_monthly_savings_usd;
  // Only a "recommended" verdict asks the reader to do something. The others
  // (already serverless / not a fit / can't estimate) are context: a one-line
  // verdict with the reasoning a click away, instead of a paragraph-sized card
  // competing with the actual recommendations for attention.
  if (fit.verdict !== "recommended") {
    return (
      <details className={`sf-inline sf-${tone}`}>
        <summary>
          <Icon className="sf-icon-sm" />
          <span className="sf-eyebrow">Serverless</span>
          <span className="sf-inline-headline">{fit.headline}</span>
        </summary>
        <p className="sf-reason">{fit.reason}</p>
      </details>
    );
  }
  return (
    <section className={`sf-card sf-${tone}`}>
      <div className="sf-head">
        <Icon className="sf-icon" />
        <div>
          <div className="sf-eyebrow">Serverless fit</div>
          <h3 className="sf-headline">{fit.headline}</h3>
        </div>
        {typeof projected === "number" && projected > 0 && (
          <div className="sf-proj">
            <div className="sf-proj-value">{moneyExact(projected)}</div>
            <div className="sf-proj-label">projected / month</div>
          </div>
        )}
      </div>
      <p className="sf-reason">{fit.reason}</p>
      {fit.group_id && (
        <Link className="sf-link" to={`/resources/${fit.group_id}`}>
          See the serverless option →
        </Link>
      )}
    </section>
  );
}

const STYLE: Record<string, { icon: typeof BoltIcon; tone: string }> = {
  recommended: { icon: BoltIcon, tone: "go" },
  already_serverless: { icon: CheckCircleIcon, tone: "info" },
  not_a_fit: { icon: XCircleIcon, tone: "muted" },
  cannot_estimate: { icon: QuestionMarkCircleIcon, tone: "muted" },
};
