import type { Confidence, Evidence, Recommendation } from "../api/types";
import { moneyExact } from "../lib/format";
import { savingsFor } from "../lib/price";
import { usePricingContext } from "../lib/PricingContext";

// The savings the engine reports is a POINT estimate with a conservative low and an
// upper-scenario high bound (contract: monthly_savings_low_usd / _high_usd). Most rules
// leave the band collapsed (low == point == high) because their counterfactual is a
// single measured number; the rebuilt estimate rules (right-size, serverless, photon,
// interactive→job, failing jobs, …) widen it, and THAT is the "how sure are we" signal
// this component surfaces — the range was computed end-to-end but never shown until now.

/** True when a rule actually widened the band beyond rounding noise around the point. */
export function hasRange(rec: Recommendation): boolean {
  const lo = rec.monthly_savings_low_usd;
  const hi = rec.monthly_savings_high_usd;
  const pt = rec.monthly_savings_usd;
  if (lo == null || hi == null) return false;
  // Ignore a band that is only cents wide (rounding) or degenerate.
  return hi - lo > Math.max(1, Math.abs(pt) * 0.02);
}

/** "likely $low – $high/mo" — the plausible range around the point estimate. Renders
 *  nothing when the band is collapsed (a single measured figure), so it never adds
 *  noise to a bookable finding whose low == point. The tooltip is the rule's own
 *  per-finding explanation of what the ends mean, when it supplied one. */
export function SavingsRange({
  rec,
  className,
}: {
  rec: Recommendation;
  className?: string;
}) {
  const { basis: priceBasis } = usePricingContext();
  if (!hasRange(rec)) return null;
  // The band on the selected basis (contract figures carry their own low/high).
  const s = savingsFor(rec, priceBasis);
  const lo = (s.low ?? rec.monthly_savings_low_usd) as number;
  const hi = (s.high ?? rec.monthly_savings_high_usd) as number;
  const basis = (rec.evidence as Evidence | undefined)?.savings_range_basis;
  return (
    <span
      className={className ?? "savings-range muted small"}
      title={
        basis ??
        "The plausible range around the estimate: the low end is the conservative " +
          "case, the high end the upper scenario."
      }
    >
      likely {moneyExact(lo)} – {moneyExact(hi)}/mo
    </span>
  );
}

// What each savings_status means for the totals. The headline "Savings potential"
// is booked + estimated (its "Confidence split" breaks it down); the conservative
// booked figure is the floor inside it. (This copy used to say estimated findings
// were NOT in the headline — true before the headline switched to the estimate.)
const STATUS_MEANING: Record<string, string> = {
  bookable: "Counted in the savings total and in its conservative booked floor.",
  estimated: "Counted in the savings total as an estimate, but not in the conservative booked floor.",
  advisory: "Not counted in any total — the problem is measured, the dollars it would save are not.",
};

const CONFIDENCE_MEANING: Record<Confidence, string> = {
  high: "High confidence: the data measures the thing the change affects directly.",
  medium: "Medium confidence: the data is a close proxy for what the change affects, not a direct measure.",
  low: "Low confidence: inferred from indirect signals — treat it as a lead to check.",
};

/** How much to trust this finding's number, in two short plain sentences: what its
 *  status means for the totals, and what the confidence tier says about the DATA
 *  behind it. The method itself is the explainer above it; the tables are the
 *  "Based on …" line below it. */
export function ConfidenceNote({ rec }: { rec: Recommendation }) {
  const status = rec.savings_status;
  const meaning = STATUS_MEANING[status];
  const conf = rec.evidence?.confidence as Confidence | undefined;
  const label =
    status === "bookable" ? "Booked" : status === "estimated" ? "Estimated" : "Advisory";
  if (!meaning) return null;
  return (
    <p className="confidence-note">
      <span className={`badge badge-status badge-status-${status}`}>{label}</span> {meaning}
      {conf && CONFIDENCE_MEANING[conf] ? ` ${CONFIDENCE_MEANING[conf]}` : ""}
    </p>
  );
}

/** A one-time legend explaining the three savings tiers — so a reader knows what
 *  "Booked" vs "Estimated" vs "Advisory" means and why the headline only banks some
 *  of the opportunity. Shown once at the top of the recommendations list. */
export function SavingsLegend() {
  return (
    <details className="savings-legend">
      <summary className="muted small">Booked, estimated, advisory</summary>
      <ul className="savings-legend-list small">
        <li>
          <span className="badge badge-status badge-status-bookable">Booked</span> Measured, not
          modelled. Counted in the savings total and in its conservative booked floor.
        </li>
        <li>
          <span className="badge badge-status badge-status-estimated">Estimated</span> Counted in
          the savings total as an estimate, but not in the booked floor — the reclaim isn&apos;t
          proven yet. Where a rule widened the band you&apos;ll see a <em>likely $low–$high/mo</em>.
        </li>
        <li>
          <span className="badge badge-status badge-status-advisory">Advisory</span> The signal is
          measured but the dollars it would save aren&apos;t (or can&apos;t be priced from Databricks
          billing), so it isn&apos;t counted in any total.
        </li>
      </ul>
      <p className="muted small" style={{ marginTop: 6 }}>
        The confidence tier (High / Medium / Low) on each finding says how directly the platform
        data supports it — measured (e.g. per-minute CPU) vs inferred from a proxy.
      </p>
    </details>
  );
}
