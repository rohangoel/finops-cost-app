import { FunnelIcon } from "@heroicons/react/24/outline";
import { useAccountScope } from "../hooks/useAccountScope";
import { useRecommendationFacets } from "../hooks/useRecommendations";

/** Secondary, cascading filters WITHIN the account chosen at the gate: cloud, then
 *  Databricks account id.
 *
 *  The account itself is fixed by the gate; these narrow the analysis further and are
 *  reactive — the option lists come from the DEPENDENT facets endpoint, so the cloud
 *  list holds only the clouds present for this customer, and the account-id list holds
 *  only the ids for the selected cloud. Picking a cloud therefore prunes the account-id
 *  dropdown (and clears a now-invalid account-id pick).
 *
 *  Renders nothing when there is nothing to refine (a single-cloud, single-id account),
 *  and nothing at all in single-account mode (facets are empty). */
export function AccountRefineBar() {
  const { data: facets } = useRecommendationFacets();
  const [scope, setScope] = useAccountScope();

  // Only meaningful once an account is chosen (central mode + past the gate).
  if (!scope.salesforce_account_name) return null;

  const clouds = facets?.cloud_type ?? [];
  const accountIds = facets?.databricks_account_id ?? [];
  const showCloud = clouds.length > 1;
  const showAccountId = accountIds.length > 1;
  if (!showCloud && !showAccountId) return null;

  const active = !!scope.cloud_type || !!scope.databricks_account_id;

  return (
    <div className={`account-refine-bar${active ? " account-refine-bar-active" : ""}`}
      role="region" aria-label="Refine within account">
      <span className="account-refine-label">
        <FunnelIcon /> Refine
      </span>
      {showCloud && (
        <select
          aria-label="Filter by cloud"
          value={scope.cloud_type}
          onChange={(e) =>
            // Changing cloud can invalidate the current account-id (it may belong to
            // another cloud), so clear it — the cascade re-populates the id list.
            setScope({ cloud_type: e.target.value, databricks_account_id: "" })
          }
        >
          <option value="">All clouds</option>
          {clouds.map((c) => (
            <option key={c} value={c}>
              {c.toUpperCase()}
            </option>
          ))}
        </select>
      )}
      {showAccountId && (
        <select
          aria-label="Filter by Databricks account id"
          value={scope.databricks_account_id}
          onChange={(e) => setScope({ databricks_account_id: e.target.value })}
        >
          <option value="">All account IDs</option>
          {accountIds.map((id) => (
            <option key={id} value={id}>
              {id}
            </option>
          ))}
        </select>
      )}
      {active && (
        <button
          type="button"
          className="account-refine-clear"
          onClick={() => setScope({ cloud_type: "", databricks_account_id: "" })}
        >
          Clear
        </button>
      )}
    </div>
  );
}
