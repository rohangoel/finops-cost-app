import { useState, type ReactNode } from "react";
import type { Evidence, Recommendation } from "../api/types";
import { UsageTimeline } from "./charts/UsageTimeline";
import { EffortBadge } from "./EffortBadge";
import { PriorityBadge } from "./PriorityScore";
import {
  DataWarning,
  DataWarningTag,
  JobBreakdownTable,
  META_KEYS,
  PreflightChecklist,
  VizLegend,
  vizList,
  vizTitle,
} from "./recDetailParts";
import { ConfidenceNote, SavingsRange, hasRange } from "./SavingsRange";
import { StatusBadge } from "./StatusBadge";
import { TagChecklist } from "./TagChecklist";
import { actionChange } from "../lib/action";
import { estimateExplainer } from "../lib/explain";
import { cleanProse } from "../lib/prose";
import { DualPrice, PricedAmount } from "./PricedAmount";
import { BetaPill } from "./BetaPill";

/** One optimization option within a resource group's detail view. Collapsible so
 *  a resource with several overlapping fixes stays scannable; the top (best)
 *  option opens by default.
 *
 *  The body reads in the order someone acting on it needs: WHAT to change (the
 *  setting, before → after, and where), WHY it was flagged, the charts that prove
 *  it, what to verify first, and — collapsed — how the figure was estimated. The
 *  action used to sit below every chart, so the one thing to do was the last
 *  thing on the page. */
export function OptionCard({
  rec,
  defaultOpen = false,
  tag,
  feedback,
}: {
  rec: Recommendation;
  defaultOpen?: boolean;
  /** Short marker in the header, e.g. "Largest saving" / "Quickest win". */
  tag?: string;
  /** The recipient's vote on this finding (FindingFeedback), when they may vote. */
  feedback?: ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const evidence = (rec.evidence ?? {}) as Evidence;
  const change = actionChange(rec);
  // A worker downsize lets the CPU chart draw where today's p95 lands after it.
  const wc = typeof evidence.worker_count === "number" ? evidence.worker_count : undefined;
  const tw = typeof evidence.target_workers === "number" ? evidence.target_workers : undefined;
  const vizContext = wc && tw && tw < wc ? { resize: { from: wc, to: tw } } : undefined;
  const charts = vizList(evidence);
  const rawEntries = Object.entries(evidence).filter(([k]) => !META_KEYS.has(k));

  return (
    <section className="option-card">
      <button
        className="option-head"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
      >
        <span className="option-title">
          {tag && <span className="option-best-tag">{tag}</span>}
          {rec.rule_title}
          <BetaPill ruleId={rec.rule_id} />
        </span>
        <span className="option-head-meta">
          <span className="option-savings-cell">
            <PricedAmount rec={rec} suffix="/mo" showCloud />
            {/* The plausible range around the point estimate, when the rule widened it
                (right-size, serverless, …). Collapsed bands render nothing. */}
            <SavingsRange rec={rec} />
          </span>
          {/* How much trust the headline places in THIS option's figure — booked,
              estimated, or advisory. Sits beside the dollar amount so the number is
              never read without its confidence tier. */}
          <StatusBadge status={rec.savings_status} />
          <DataWarningTag evidence={evidence} />
          <EffortBadge band={rec.effort_band} />
          <PriorityBadge priority={rec.priority} />
          <span className="option-caret">{open ? "▾" : "▸"}</span>
        </span>
      </button>

      {open && (
        <div className="option-body">
          {/* The rule's own "this evidence may be incomplete" statement leads. */}
          <DataWarning evidence={evidence} />
          {/* Both price bases side by side (only when contract data exists). */}
          <DualPrice rec={rec} />
          <div className="action-box">
            <div className="action-eyebrow">What to change</div>
            {change && (
              <div className="action-change">
                <span className="action-setting">{change.setting}</span>
                <span className="action-from">{change.from}</span>
                <span className="action-arrow" aria-hidden="true">→</span>
                <span className="action-to">{change.to}</span>
              </div>
            )}
            <p className="action-how">{cleanProse(rec.how)}</p>
          </div>

          <div className="detail-section">
            <h3>Why it was flagged</h3>
            <p>{cleanProse(rec.why)}</p>
          </div>

          {charts.map((viz, i) => (
            <div className="detail-section viz-section" key={`${viz.kind}-${i}`}>
              <h3>{vizTitle(viz)}</h3>
              <UsageTimeline viz={viz} context={vizContext} />
              <VizLegend viz={viz} />
            </div>
          ))}

          {/* Governance findings have no time series to chart; the checklist is
              their evidence. Sits where the chart sits on every other card so the
              card layout stays predictable. */}
          {rec.rule_id === "untagged_spend" && (
            <div className="detail-section viz-section">
              <h3>Which ownership tags are missing?</h3>
              <TagChecklist evidence={evidence} />
            </div>
          )}

          {/* Shared all-purpose cluster: the finding is scored on the whole
              cluster, so show which recurring jobs make it up. */}
          {rec.rule_id === "interactive_to_job" && Array.isArray(evidence.job_breakdown) && (
            <div className="detail-section viz-section">
              <h3>Which jobs run on this cluster?</h3>
              <JobBreakdownTable evidence={evidence} />
            </div>
          )}

          <PreflightChecklist ruleId={rec.rule_id} />

          {feedback}

          {/* Methodology is for the reader who wants to audit the number, not for
              the one deciding whether to act — so it is one click away, not inline. */}
          <details className="option-details">
            <summary>How this figure was estimated</summary>
            {/* Plain-language first — what was measured, what was assumed, what was
                taken off — so the reader gets a feel for the number before the
                trust tier and the table-level method. */}
            <p className="estimate-intuition">{estimateExplainer(rec)}</p>
            {typeof evidence.savings_range_basis === "string" && hasRange(rec) && (
              <p className="estimate-range">
                <span className="basis-tag">Why a range</span> {cleanProse(evidence.savings_range_basis)}
              </p>
            )}
            <ConfidenceNote rec={rec} />
            {evidence.data_basis && (
              <p className="basis-line">
                <span className="basis-tag">Based on</span> {cleanProse(evidence.data_basis)}
              </p>
            )}
          </details>

          {rawEntries.length > 0 && (
            <details className="option-evidence">
              <summary>Raw evidence</summary>
              <table className="kv-table">
                <tbody>
                  {rawEntries.map(([k, v]) => (
                    <tr key={k}>
                      <td className="kv-key">{k}</td>
                      {/* Nested values (lists, per-cloud maps) printed "[object Object]". */}
                      <td>{v !== null && typeof v === "object" ? JSON.stringify(v) : String(v)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="muted small" style={{ marginTop: 8 }}>
                Detected by rule <code>{rec.rule_id}</code> v{rec.rule_version} · snapshot{" "}
                {rec.snapshot_date}
              </p>
            </details>
          )}
        </div>
      )}
    </section>
  );
}
