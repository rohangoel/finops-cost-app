import { useState } from "react";
import {
  ChatBubbleLeftRightIcon,
  ClipboardIcon,
  CheckIcon,
} from "@heroicons/react/24/outline";
import { useConfig } from "../hooks/useConfig";
import { GenieChat, type GenieContext } from "./GenieChat";

interface Props {
  /** Card heading. */
  title?: string;
  /** One line under the heading — sets the scope of what's sensible to ask. */
  subtitle?: string;
  /** Contextual starter questions (click-to-ask in API mode, click-to-copy in iframe mode). */
  samples?: string[];
  /** iframe height in px (iframe mode only). */
  height?: number;
  /** What the page is showing. In API mode it is sent to the backend so answers
   *  resolve to THIS resource/workspace; in iframe mode it is unused (the frame
   *  can't be told), which is exactly the limitation the API mode fixes. */
  context?: GenieContext;
}

/**
 * Optional "Ask Genie" panel over the FinOps tables. Two transports, chosen by
 * the backend's `genie_mode`:
 *
 * - **api** — a native, context-aware chat (`<GenieChat>`): questions POST to
 *   `/api/genie/ask`, where the backend injects the current workspace/resource so
 *   "why is this idle?" resolves to the actual thing on the page, and answers
 *   render in the app's own bubbles. No embedding allowlist needed.
 * - **iframe** — the embedded Genie space (the original PoC). Cross-origin, so it
 *   cannot be told what the page shows; starter questions are click-to-**copy**
 *   (embedding the resource name) as the only way to carry context across.
 *
 * Feature-gated either way: renders **nothing** unless the backend reports
 * `genie_enabled`. With the toggle off — the default — the app is unchanged.
 */
export function GeniePanel({
  title = "Ask Genie",
  subtitle,
  samples = [],
  height = 620,
  context,
}: Props) {
  const { data: config } = useConfig();
  const [copied, setCopied] = useState<string | null>(null);

  if (!config?.genie_enabled) return null;
  const isApi = config.genie_mode === "api";
  if (!isApi && !config.genie_embed_url) return null;

  const copy = async (q: string) => {
    try {
      await navigator.clipboard.writeText(q);
      setCopied(q);
      setTimeout(() => setCopied((c) => (c === q ? null : c)), 1600);
    } catch {
      /* clipboard blocked — the user can still type the question by hand */
    }
  };

  return (
    <section className="genie-panel card card-pad">
      <div className="genie-head">
        <ChatBubbleLeftRightIcon className="genie-head-icon" />
        <div>
          <div className="genie-title">
            {title}
            <span className="beta-badge">PoC</span>
          </div>
          {subtitle && <div className="genie-sub">{subtitle}</div>}
        </div>
      </div>

      {isApi ? (
        <GenieChat samples={samples} context={context} />
      ) : (
        <>
          {samples.length > 0 && (
            <>
              <div className="genie-samples-label">
                Try asking — click to copy, then paste into the box below:
              </div>
              <div className="genie-samples">
                {samples.map((q) => (
                  <button
                    key={q}
                    type="button"
                    className="genie-sample"
                    onClick={() => copy(q)}
                    title="Copy question"
                  >
                    {copied === q ? (
                      <CheckIcon className="genie-sample-icon" />
                    ) : (
                      <ClipboardIcon className="genie-sample-icon" />
                    )}
                    <span>{copied === q ? "Copied" : q}</span>
                  </button>
                ))}
              </div>
            </>
          )}

          <iframe
            className="genie-frame"
            src={config.genie_embed_url}
            title="Databricks Genie"
            allow="clipboard-write"
            style={{ height }}
          />
        </>
      )}
    </section>
  );
}
