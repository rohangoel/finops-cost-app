import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import { useDataHealth } from "../hooks/useDataHealth";
import { relativeTime } from "../lib/format";

/** Tells the reader when findings are incomplete because a system table is not
 *  readable.
 *
 *  Without this, an ungranted table made the dependent rules silently return
 *  nothing and the UI said "no savings found" — a permissions gap rendered as
 *  good news, which is the one failure mode a cost tool cannot afford.
 *
 *  Renders NOTHING on a healthy workspace. A permanently-green "all sources OK"
 *  ornament would train people to ignore the row, so the banner only appears when
 *  it has something to say. */
export function DataHealthBanner() {
  const { data } = useDataHealth();
  const [open, setOpen] = useState(false);

  const run = data?.last_run ?? null;
  // A failed FLOW is worth saying even when every source is readable: the numbers
  // on screen are then missing a rule for a reason that has nothing to do with
  // grants. So the run state is a second, independent trigger for this banner.
  const runFailed = run != null && run.ok === false;

  // No data yet, or nothing worth saying. Note `unknown` DOES warrant a message:
  // "we could not check" is not the same as "everything is fine".
  if (!data) return null;
  if (!data.degraded && !data.unknown && !runFailed) return null;

  const blocked = data.unavailable_rules;
  const failingCore = data.sources.filter((s) => s.required && s.status === "FAIL");
  // A core billing failure means no findings at all are possible; anything else is
  // a partial view. The distinction changes what the reader should do next.
  const severity = failingCore.length > 0 ? "critical" : "warn";

  return (
    <div className={`health-banner health-${severity}`}>
      <ExclamationTriangleIcon className="icon" />
      <div className="health-body">
        <span>
          {data.message ||
            (runFailed
              ? "The last precompute run did not finish cleanly; some findings may be missing."
              : "Some data sources are unavailable; findings may be incomplete.")}
        </span>
        {/* How fresh the numbers are, and which flows failed producing them. Only
            rendered when the run log is readable — an unavailable log is the
            expected state on a fresh install and not worth a line. */}
        {run && !run.unavailable && (
          <span className="health-run">
            Last precompute run
            {run.finished_at ? ` ${relativeTime(run.finished_at)}` : ""}:{" "}
            {run.flows_ok + run.flows_failed > 0
              ? `${run.flows_ok} of ${run.flows_ok + run.flows_failed} flows OK`
              : "no completed flows"}
            {run.rows_written != null
              ? ` · ${run.rows_written.toLocaleString()} recommendations written`
              : ""}
            {run.failed_flows.length > 0 && (
              <>
                {" · failed: "}
                {run.failed_flows.map((f) => (
                  <code key={f} className="health-src">
                    {f}
                  </code>
                ))}
              </>
            )}
          </span>
        )}
        {blocked.length > 0 && (
          <button type="button" className="btn-link" onClick={() => setOpen(!open)}>
            {open ? "Hide details" : `Show ${blocked.length} affected rule(s)`}
          </button>
        )}
        {open && (
          <ul className="health-detail">
            {blocked.map((r) => (
              <li key={r.rule_id}>
                <code>{r.rule_id}</code> needs{" "}
                {r.missing_sources.map((s) => (
                  <code key={s} className="health-src">
                    {data.catalog}.{s}
                  </code>
                ))}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
