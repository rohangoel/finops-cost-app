import {
  ArrowPathIcon,
  BellAlertIcon,
  CircleStackIcon,
  ClockIcon,
  CpuChipIcon,
  PresentationChartBarIcon,
  ServerStackIcon,
  ShareIcon,
  SignalIcon,
  TableCellsIcon,
} from "@heroicons/react/24/outline";
import type { ComponentType, SVGProps } from "react";

type IconType = ComponentType<SVGProps<SVGSVGElement>>;

const RESOURCE_ICON: Record<string, IconType> = {
  cluster: CpuChipIcon,
  warehouse: CircleStackIcon,
  job: ClockIcon,
  serving_endpoint: SignalIcon,
  // A DLT / Lakeflow Declarative Pipeline. The recycle arrows read as "flowing
  // data", which is what distinguishes it from a job's clock.
  pipeline: ArrowPathIcon,
  // Phase 4 (Labs) resource types.
  instance_pool: ServerStackIcon,   // a pool of warm VMs
  share: ShareIcon,                  // a Delta Share
  table: TableCellsIcon,             // a UC table
  alert: BellAlertIcon,              // a SQL alert
  dashboard: PresentationChartBarIcon, // an AI/BI dashboard
};

// Resource types whose slug is not what an admin would call it.
const RESOURCE_LABEL: Record<string, string> = {
  serving_endpoint: "endpoint",
  instance_pool: "pool",
};

/** Display label for a resource type slug ("serving_endpoint" -> "endpoint"). */
export function resourceLabel(type: string): string {
  return RESOURCE_LABEL[type] ?? type;
}

export function ResourceIcon({ type, className }: { type: string; className?: string }) {
  const Icon = RESOURCE_ICON[type] ?? CpuChipIcon;
  return <Icon className={className ?? "icon"} aria-hidden="true" />;
}

export function ResourceChip({ type }: { type: string }) {
  return (
    <span className={`chip chip-${type}`}>
      <ResourceIcon type={type} className="chip-icon" />
      {RESOURCE_LABEL[type] ?? type}
    </span>
  );
}
