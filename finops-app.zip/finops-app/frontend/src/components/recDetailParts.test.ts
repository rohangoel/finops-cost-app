import { describe, expect, it } from "vitest";
import type { Evidence, HourHeatmapViz, ServingTrafficViz } from "../api/types";
import { resourceFacts, vizTitle } from "./recDetailParts";

/** The cluster facts strip surfaces the current (latest observed) auto-termination
 *  setting, so a reader sees what it is NOW — not just what the finding says to
 *  change it to. off = null or 0; otherwise the minutes. Absent when the rule
 *  didn't read it (e.g. interactive_to_job), so we don't imply "off" from silence. */
describe("resourceFacts cluster auto-termination", () => {
  const facts = (ev: Partial<Evidence>) =>
    resourceFacts("cluster", ev as Evidence, 100);
  const autoterm = (ev: Partial<Evidence>) =>
    facts(ev).find((f) => f.label === "Auto-termination");

  it("shows the minutes when a timeout is set", () => {
    expect(autoterm({ auto_termination_minutes: 180 })).toEqual({
      label: "Auto-termination",
      value: "180 min",
    });
  });

  it("shows 'off' when auto-termination is disabled (null)", () => {
    expect(autoterm({ auto_termination_minutes: null })?.value).toBe("off");
  });

  it("shows 'off' when the timeout is 0", () => {
    expect(autoterm({ auto_termination_minutes: 0 })?.value).toBe("off");
  });

  it("omits the row when the rule did not observe the setting", () => {
    expect(autoterm({ cluster_kind: "All-purpose cluster" })).toBeUndefined();
  });
});

describe("visualization labels follow the evidence context", () => {
  const heatmap = (context: "warehouse" | "pipeline"): HourHeatmapViz => ({
    kind: "hour_heatmap",
    context,
    day_labels: ["Mon"],
    grid: [[0, 1, 2]],
    reclaimable_hours: 1,
  });

  it("does not describe pipeline updates as warehouse queries", () => {
    expect(vizTitle(heatmap("pipeline"))).toContain("pipeline updating");
    expect(vizTitle(heatmap("warehouse"))).toContain("warehouse serving queries");
  });

  it("uses a serving-specific title", () => {
    const viz: ServingTrafficViz = {
      kind: "serving_traffic",
      days: [],
      lookback_days: 30,
      days_billed: 30,
      total_requests: 0,
      last_request: null,
    };
    expect(vizTitle(viz)).toBe("Billed days versus inference requests");
  });
});
