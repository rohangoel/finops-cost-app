import { Link } from "react-router-dom";
import type { Evidence, Recommendation } from "../api/types";
import { actionChange, firstSentence } from "../lib/action";
import { EffortBadge } from "./EffortBadge";
import { ResourceChip } from "./ResourceChip";
import { SavingsRange } from "./SavingsRange";
import { StatusBadge } from "./StatusBadge";
import { PricedAmount } from "./PricedAmount";
import { DataWarningTag } from "./recDetailParts";
import { BetaPill } from "./BetaPill";

/** One ranked action. Reads left to right the way a triage does: WHAT to change
 *  (the setting, before → after), ON WHAT (resource, workspace NAME, owner), WHY
 *  (the lead sentence of the finding's evidence), then what it is worth and what
 *  it costs to do. The unitless ★ NBA score and the raw workspace id are gone —
 *  the rank already encodes the score, and nobody recognises a workspace by id. */
export function RecommendationCard({ rec, rank }: { rec: Recommendation; rank?: number }) {
  const change = actionChange(rec);
  return (
    <Link to={`/recommendations/${rec.recommendation_id}`} className="nba-row">
      {rank !== undefined && <span className="rec-rank">{rank}</span>}
      <div className="nba-main">
        <div className="nba-action">
          {change ? (
            <>
              {change.setting} <span className="nba-from">{change.from}</span>
              <span className="nba-arrow"> → </span>
              <span className="nba-to">{change.to}</span>
            </>
          ) : (
            rec.rule_title
          )}
          <BetaPill ruleId={rec.rule_id} />
        </div>
        <div className="nba-target">
          <ResourceChip type={rec.resource_type} />
          <span className="strong">{rec.resource_name}</span>
          <span className="muted">· {rec.workspace_name ?? `workspace ${rec.workspace_id}`}</span>
          {rec.resource_owner && <span className="muted">· {rec.resource_owner}</span>}
          {change && <span className="faint">· {rec.rule_title}</span>}
        </div>
        <div className="nba-why">{firstSentence(rec.why)}</div>
      </div>
      <div className="nba-value">
        <div>
          <PricedAmount rec={rec} suffix="/mo" className="savings-text nba-amount" showCloud />
        </div>
        <SavingsRange rec={rec} />
        <div className="nba-badges">
          <StatusBadge status={rec.savings_status} />
          <DataWarningTag evidence={rec.evidence as Evidence | undefined} />
          <EffortBadge band={rec.effort_band} />
        </div>
      </div>
    </Link>
  );
}
