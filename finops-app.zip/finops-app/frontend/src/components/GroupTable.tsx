import { useNavigate } from "react-router-dom";
import type { RecommendationGroup } from "../api/types";
import { actionChange } from "../lib/action";
import { EFFORT_LABEL } from "../lib/format";
import { PriorityBadge } from "./PriorityScore";
import { ResourceChip } from "./ResourceChip";
import { StatusBadge } from "./StatusBadge";
import { PricedGroupAmount } from "./PricedAmount";
import { BetaPill } from "./BetaPill";

/** Overview table, harmonized: one row per RESOURCE, not per finding. A resource
 *  with several overlapping fixes shows its best option's action plus "+N more"
 *  and its best-option savings (never the sum). Clicking opens the resource
 *  detail, where the options are laid out to pick from.
 *
 *  The "what to do" cell leads with the concrete setting change ("Auto-stop
 *  60 min → 5 min") when the finding carries one — that is what an engineer acts
 *  on — with the rule title beneath it. The owner sits under the resource name,
 *  because "who do I ask?" is the next question after "what is it?". The unitless
 *  NBA score column is gone: the list is already sorted by it. */
export function GroupTable({
  groups,
  showWorkspace = true,
}: {
  groups: RecommendationGroup[];
  /** Off on a single-workspace page, where the column would repeat one name. */
  showWorkspace?: boolean;
}) {
  const navigate = useNavigate();
  if (groups.length === 0)
    return <p className="empty">No recommendations match the current filters.</p>;

  return (
    <div className="table-wrap">
      <div className="table-scroll">
        <table className="data-table">
          <thead>
            <tr>
              <th>Resource</th>
              {showWorkspace && <th>Workspace</th>}
              <th>What to do</th>
              <th className="num">Savings / mo</th>
              <th>Effort</th>
              <th>Priority</th>
            </tr>
          </thead>
          <tbody>
            {groups.map((g) => {
              const best = g.options[0];
              const change = best ? actionChange(best) : null;
              const owner = best?.resource_owner;
              const more = g.option_count - 1;
              return (
                <tr
                  key={g.group_id}
                  onClick={() => navigate(`/resources/${g.group_id}`)}
                  title={`Next-best-action score ${g.nba_score.toFixed(0)} (savings ÷ effort)`}
                >
                  <td>
                    <span className="cell-primary">
                      <ResourceChip type={g.resource_type} />
                      {g.resource_name}
                    </span>
                    {owner && <div className="cell-sub">{owner}</div>}
                  </td>
                  {showWorkspace && <td className="muted">{g.workspace_name ?? g.workspace_id}</td>}
                  <td>
                    {change ? (
                      <>
                        <div className="cell-action">
                          {change.setting} <span className="muted">{change.from}</span> →{" "}
                          <span className="strong">{change.to}</span>
                          <BetaPill ruleId={best.rule_id} />
                        </div>
                        <div className="cell-sub">
                          {best.rule_title}
                          {more > 0 && ` · +${more} more option${more === 1 ? "" : "s"}`}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="cell-action">
                          {best?.rule_title ?? g.action_label}
                          <BetaPill ruleId={best?.rule_id} />
                        </div>
                        {more > 0 && (
                          <div className="cell-sub">
                            +{more} more option{more === 1 ? "" : "s"}
                          </div>
                        )}
                      </>
                    )}
                  </td>
                  <td className="num">
                    <div>
                      <PricedGroupAmount group={g} showCloud />
                    </div>
                    {best && (
                      <div className="cell-sub">
                        <StatusBadge status={best.savings_status} />
                      </div>
                    )}
                  </td>
                  {/* Effort and priority of the option this row shows, so the row
                      reads as one recommendation. (The group-level effort is the
                      EASIEST option's — paired with the BEST option's saving, it
                      described two different fixes as if they were one.) */}
                  <td>
                    <span className={`badge effort effort-${best?.effort_band ?? g.effort_band}`}>
                      {EFFORT_LABEL[best?.effort_band ?? g.effort_band] ?? g.effort_band}
                    </span>
                  </td>
                  <td>
                    <PriorityBadge priority={best?.priority ?? g.priority} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
