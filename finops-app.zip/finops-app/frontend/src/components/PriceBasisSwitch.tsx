/**
 * Top-bar "List price | Your rates" segmented switch. Rendered only when the
 * findings carry contract figures (system.billing.account_prices); the choice is
 * global, persisted and synced across windows (lib/pricingBasis.ts).
 */

import { usePricingContext } from "../lib/PricingContext";
import { setPricingBasis } from "../lib/pricingBasis";
import type { PricingBasis } from "../lib/price";

const OPTIONS: { value: PricingBasis; label: string; title: string }[] = [
  { value: "list", label: "List price", title: "Every figure at Databricks list price" },
  {
    value: "contract",
    label: "Your rates",
    title:
      "Figures at your contract rates where every SKU of the resource has one; the rest stay at list and are marked",
  },
];

export function PriceBasisSwitch() {
  const { pricing, basis } = usePricingContext();
  if (!pricing?.contract_available) return null;
  return (
    <div className="price-basis-switch" role="group" aria-label="Price basis">
      {OPTIONS.map((o) => (
        <button
          key={o.value}
          type="button"
          className={basis === o.value ? "active" : ""}
          aria-pressed={basis === o.value}
          title={o.title}
          onClick={() => setPricingBasis(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
