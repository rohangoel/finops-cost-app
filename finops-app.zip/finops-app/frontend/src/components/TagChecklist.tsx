import { CheckCircleIcon, XCircleIcon } from "@heroicons/react/24/outline";
import type { Evidence } from "../api/types";

/** Present/missing status for each required ownership tag, for `untagged_spend`.
 *
 *  Deliberately a checklist rather than a chart. The finding is categorical — five
 *  tags, each there or not — so a bar or a series would be decoration around a
 *  fact that a list states exactly. What the reader needs is (a) which tags to add
 *  and (b) how much spend is unattributable until they do, which is the header.
 *
 *  Renders nothing unless the evidence carries the tag keys, so it costs nothing on
 *  every other rule's card. */
export function TagChecklist({ evidence }: { evidence: Evidence }) {
  const missing = Array.isArray(evidence.missing_tags)
    ? (evidence.missing_tags as string[])
    : [];
  const present = Array.isArray(evidence.present_tags)
    ? (evidence.present_tags as string[])
    : [];
  if (missing.length === 0 && present.length === 0) return null;

  const unattributable =
    typeof evidence.unattributable_monthly_usd === "number"
      ? (evidence.unattributable_monthly_usd as number)
      : undefined;
  // Show them in the config's own order (owner, team, project, environment,
  // cost_center) rather than alphabetically, so the list reads the same on every
  // finding and a reader learns its shape.
  const ORDER = ["owner", "team", "project", "environment", "cost_center"];
  const rank = (t: string) => {
    const i = ORDER.indexOf(t);
    return i === -1 ? ORDER.length : i;
  };
  const rows = [
    ...missing.map((t) => ({ tag: t, ok: false })),
    ...present.map((t) => ({ tag: t, ok: true })),
  ].sort((a, b) => rank(a.tag) - rank(b.tag) || a.tag.localeCompare(b.tag));

  return (
    <div className="tag-checklist">
      <table className="kv-table">
        <tbody>
          {rows.map(({ tag, ok }) => (
            <tr key={tag}>
              <td>
                <code>{tag}</code>
              </td>
              <td className={ok ? "tag-ok" : "tag-missing"}>
                {ok ? (
                  <>
                    <CheckCircleIcon className="tag-icon" /> present
                  </>
                ) : (
                  <>
                    <XCircleIcon className="tag-icon" /> missing
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {unattributable !== undefined && (
        <p className="basis-line">
          <span className="basis-tag">Unattributable</span> $
          {unattributable.toLocaleString(undefined, { maximumFractionDigits: 0 })}/mo of
          spend on this resource cannot be charged back until the missing tag(s) are
          added. Tagging does not reduce the bill — it makes the spend attributable.
        </p>
      )}
    </div>
  );
}
