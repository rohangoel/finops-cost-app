import { BuildingOffice2Icon } from "@heroicons/react/24/outline";
import { matchPath, useLocation, useNavigate } from "react-router-dom";
import type { Identity } from "../api/types";
import { useWorkspaces } from "../hooks/useWorkspaces";
import { useWorkspaceScope } from "../hooks/useWorkspaceScope";

const PLATFORM_LABEL = "Platform · all workspaces";

/** Top-bar workspace scope switcher.
 *
 *  Picking a workspace sets the GLOBAL scope (lib/scope), which every page reads
 *  through the `?workspace_id=` param apiGet appends — so one selection filters
 *  recommendations, the overview, spend, Genie and Apps together, and (via the
 *  browser `storage` event) stays in sync across separate browser windows. `""`
 *  scope is the all-workspaces Platform view.
 *
 *  Only a platform admin sees the "Platform" option and the full workspace list; a
 *  workspace admin sees just the workspaces they own. Scope is still enforced
 *  server-side (Scope.narrowed_to) — this only drives the view filter.
 *
 *  The merged per-workspace routes (`/workspaces/:id/...`) still work as deep links;
 *  Layout syncs their id INTO the global scope on open. When the user switches while
 *  on such a pinned URL, we navigate to the page's platform form so the URL stops
 *  pinning a now-stale workspace and localStorage remains the single source of truth. */
export function WorkspaceSwitcher({ identity }: { identity: Identity }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { data: workspaces = [] } = useWorkspaces();
  const [scope, setScope] = useWorkspaceScope();
  const isAdmin = identity.role === "platform_admin";

  // "" scope => platform view; the input shows the platform label for it.
  const current = scope || "platform";

  // A workspace admin scoped to a single workspace has nothing to switch.
  if (!isAdmin && workspaces.length <= 1) return null;

  const labelFor = (id: string) =>
    id === "platform"
      ? PLATFORM_LABEL
      : workspaces.find((w) => w.workspace_id === id)?.workspace_name ?? `Workspace ${id}`;

  // If we're on a workspace-pinned URL, the equivalent platform-form path — so a
  // scope switch doesn't leave the URL pinning the workspace we just left.
  const dePinnedPath = (): string | null => {
    const scoped = matchPath("/workspaces/:workspaceId/:page", location.pathname);
    if (scoped) return `/${scoped.params.page}`;
    if (matchPath("/workspaces/:workspaceId", location.pathname)) return "/";
    return null;
  };

  const go = (id: string) => {
    const next = id === "platform" ? "" : id;
    setScope(next);
    // Only navigate to de-pin a workspace-pinned URL; otherwise stay put — the page
    // refetches under the new scope in place.
    const platformPath = dePinnedPath();
    if (platformPath) navigate(platformPath);
  };

  // Resolve whatever the user typed or pasted — a workspace name, a workspace id, or
  // the platform label — to a workspace id, then set scope. Matching trims and is
  // case-insensitive so a copy-pasted name with stray spaces or casing still lands; a
  // unique prefix also resolves so a partial paste works. On no match we restore the
  // box to the current scope so it never displays a view we're not actually on.
  const resolveAndGo = (input: HTMLInputElement) => {
    const q = input.value.trim();
    if (!q) {
      input.value = labelFor(current);
      return;
    }
    if (isAdmin && q.toLowerCase() === PLATFORM_LABEL.toLowerCase()) {
      go("platform");
      return;
    }
    const lower = q.toLowerCase();
    const prefix = workspaces.filter((w) => (w.workspace_name ?? "").toLowerCase().startsWith(lower));
    const hit =
      workspaces.find((w) => (w.workspace_name ?? "").toLowerCase() === lower) ??
      workspaces.find((w) => w.workspace_id === q) ??
      (prefix.length === 1 ? prefix[0] : undefined);
    if (hit) go(hit.workspace_id);
    else input.value = labelFor(current);
  };

  // A workspace scope is active (not the all-workspaces platform view). Drives the
  // "filtered" styling + the clear button, so it's obvious a filter is set.
  const filtered = scope !== "";

  return (
    <label
      className={`ws-switcher${filtered ? " ws-switcher-active" : ""}`}
      title={filtered ? `Filtered to ${labelFor(current)} — click × to clear` : "Switch view — type or paste a workspace name"}
    >
      <BuildingOffice2Icon />
      {/* Combobox, not a plain select: a platform admin can pick from the list OR
          type / paste a workspace name (or id) directly — useful with hundreds of
          workspaces. `key` remounts the input so it re-syncs to the current scope
          when it changes (here or in another window) and once names finish loading. */}
      <input
        key={`${current}:${workspaces.length}`}
        list="ws-switcher-options"
        aria-label="Switch view — type or paste a workspace name"
        defaultValue={labelFor(current)}
        placeholder="Search or paste a workspace name…"
        spellCheck={false}
        // CLEAR on focus, don't just select(): a native datalist filters its
        // options by the input's current text, so while the box still reads
        // "Platform · all workspaces" no workspace name matches and the dropdown
        // shows nothing — the switcher looked stuck on Platform. Emptying it lets
        // the full list appear; resolveAndGo restores the label on blur if the
        // user picks nothing.
        onFocus={(e) => {
          e.currentTarget.value = "";
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") e.currentTarget.blur();
        }}
        onBlur={(e) => resolveAndGo(e.currentTarget)}
      />
      {/* One-click reset to the all-workspaces view. Only shown while a workspace
          filter is active, so the affordance to "get out" is always visible when
          you're in a narrowed view (mousedown, not click: it fires before the
          input's blur/resolveAndGo, which would otherwise re-set the old value). */}
      {filtered && isAdmin && (
        <button
          type="button"
          className="ws-switcher-clear"
          aria-label="Clear workspace filter — back to all workspaces"
          title="Back to all workspaces"
          onMouseDown={(e) => {
            e.preventDefault();
            go("platform");
          }}
        >
          ×
        </button>
      )}
      <datalist id="ws-switcher-options">
        {isAdmin && <option value={PLATFORM_LABEL} />}
        {workspaces.map((w) => (
          <option key={w.workspace_id} value={w.workspace_name ?? `Workspace ${w.workspace_id}`} />
        ))}
      </datalist>
    </label>
  );
}
