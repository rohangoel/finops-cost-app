import { describe, expect, it } from "vitest";
import charts from "./charts/UsageTimeline.tsx?raw";

describe("semantic chart palette", () => {
  it("uses danger for failed runs and queueing", () => {
    expect(charts).toContain('fill="var(--danger)"');
    expect(charts).toContain('Queued at capacity (waited)');
  });
});
