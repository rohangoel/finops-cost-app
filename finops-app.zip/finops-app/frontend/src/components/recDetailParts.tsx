// Shared building blocks for the recommendation/resource detail views: the
// resource deep-link, the auditable "facts strip", and the per-chart title +
// legend. Extracted so both the single-recommendation detail and the grouped
// resource detail (which lists several options) render identically.
import type { Confidence, Evidence, JobBreakdownItem, Viz } from "../api/types";
import { ExclamationTriangleIcon } from "@heroicons/react/24/solid";
import { moneyExact } from "../lib/format";
import { cleanProse } from "../lib/prose";

/** Deep link to the actual resource in the Databricks workspace.
 *
 *  The account spans many workspaces, each on its OWN host, so we must link to
 *  the resource's own workspace URL (carried on the recommendation), NOT the
 *  host the app happens to run on. We only fall back to the app's host (with the
 *  legacy ?o= org param) when the recommendation predates this field. */
export function resourceUrl(
  workspaceUrl: string | null | undefined,
  fallbackHost: string | undefined,
  resourceType: string,
  resourceId: string,
  workspaceId: string,
  resourceName?: string | null,
): string | null {
  const path =
    resourceType === "warehouse"
      ? `sql/warehouses/${resourceId}`
      : resourceType === "cluster"
        ? `compute/clusters/${resourceId}`
        : resourceType === "job"
          ? `jobs/${resourceId}`
          : // Serving endpoints are addressed by NAME in the workspace UI, not by
            // the endpoint_id the recommendation keys on — so this is the one type
            // that links via resourceName. Without a name there is no valid URL.
            resourceType === "serving_endpoint"
            ? resourceName
              ? `ml/endpoints/${encodeURIComponent(resourceName)}`
              : null
            : resourceType === "pipeline"
              ? `pipelines/${resourceId}`
              : resourceType === "alert"
                ? `sql/alerts-v2/${resourceId}`
                : resourceType === "dashboard"
                  ? `dashboardsv3/${resourceId}/published`
                  : null;
  if (!path) return null;
  const base = (workspaceUrl ?? "").replace(/\/+$/, "");
  if (base) return `${base}/${path}`;
  if (fallbackHost) return `https://${fallbackHost}/${path}?o=${workspaceId}`;
  return null;
}

export const CONFIDENCE_LABEL: Record<Confidence, string> = {
  high: "High confidence",
  medium: "Medium confidence",
  low: "Low confidence",
};

// Keys the "show the data" block owns — rendered as chart/basis, not raw kv rows.
// job_breakdown is an array of objects rendered by JobBreakdownTable, so it must
// not fall through to the raw String(v) dump (which would print [object Object]).
export const META_KEYS = new Set([
  "confidence",
  "data_basis",
  "viz",
  "viz_extra",
  "job_breakdown",
  "data_warning",
]);

/** A rule's own statement that the evidence may not show what it seems to (e.g. an
 *  endpoint with zero logged requests that has never logged any — usage tracking may
 *  be off). Shown ABOVE the action, because acting on the finding without reading it
 *  is exactly the mistake it exists to prevent. Renders nothing when absent. */
export function DataWarning({ evidence }: { evidence: Evidence }) {
  const text = evidence.data_warning;
  if (typeof text !== "string" || !text) return null;
  return (
    <div className="data-warning" role="note">
      <ExclamationTriangleIcon className="data-warning-icon" aria-hidden="true" />
      <div>
        <div className="data-warning-title">Check before acting — the data may be incomplete</div>
        <p>{cleanProse(text)}</p>
      </div>
    </div>
  );
}

/** Compact marker for list rows, so the doubt is visible before anyone clicks in. */
export function DataWarningTag({ evidence }: { evidence: Evidence | undefined }) {
  if (typeof evidence?.data_warning !== "string" || !evidence.data_warning) return null;
  return (
    <span className="data-warning-tag" title={cleanProse(evidence.data_warning)}>
      <ExclamationTriangleIcon className="data-warning-tag-icon" aria-hidden="true" />
      Unverified
    </span>
  );
}

/** The per-job breakdown of a shared all-purpose cluster (interactive_to_job).
 *  The recommendation is scored on the cluster as a whole; this table shows the
 *  constituent recurring jobs so the reader knows which ones to migrate. */
export function JobBreakdownTable({ evidence }: { evidence: Evidence }) {
  const raw = evidence.job_breakdown;
  if (!Array.isArray(raw) || raw.length === 0) return null;
  const jobs = raw as JobBreakdownItem[];
  return (
    <table className="kv-table">
      <thead>
        <tr>
          <th className="kv-key">Job ID</th>
          <th>Runs</th>
          <th>Runtime (h)</th>
        </tr>
      </thead>
      <tbody>
        {jobs.map((j) => (
          <tr key={j.job_id}>
            <td className="kv-key">
              <code>{j.job_id}</code>
            </td>
            <td>{Number(j.runs).toLocaleString()}</td>
            <td>{Number(j.hours).toLocaleString(undefined, { maximumFractionDigits: 1 })}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** The charts for a finding, primary first: `viz` plus any `viz_extra`. Lets the
 *  detail views render a multi-chart finding without knowing which rule it came
 *  from. */
export function vizList(ev: Evidence): Viz[] {
  const out: Viz[] = [];
  if (ev.viz) out.push(ev.viz);
  for (const v of ev.viz_extra ?? []) if (v) out.push(v);
  return out;
}

/** Auditable resource facts so the dollar figures are believable — for
 *  warehouses: size + DBUs + effective $/DBU (× DBUs = the monthly cost). */
export function resourceFacts(
  resourceType: string,
  ev: Evidence,
  monthlyCost: number,
): { label: string; value: string }[] {
  const num = (k: string) => (typeof ev[k] === "number" ? (ev[k] as number) : undefined);
  const out: { label: string; value: string }[] = [];
  if (resourceType === "warehouse") {
    const size = ev.warehouse_size;
    const proposed = ev.proposed_size;
    const dbus = num("dbus_30d");
    const cost = num("cost_30d_usd") ?? monthlyCost;
    if (typeof size === "string")
      out.push({
        label: "Warehouse size",
        value: typeof proposed === "string" ? `${size} → ${proposed}` : String(size),
      });
    if (dbus !== undefined)
      out.push({ label: "DBUs (30d)", value: dbus.toLocaleString(undefined, { maximumFractionDigits: 0 }) });
    if (dbus && cost) out.push({ label: "Effective $ / DBU", value: `$${(cost / dbus).toFixed(2)}` });
    out.push({ label: "Cost / 30d", value: moneyExact(cost) });
  } else if (resourceType === "job") {
    const failPct = num("fail_rate_pct");
    const totalRuns = num("total_runs");
    const failedRuns = num("failed_runs");
    const writes = num("total_writes");
    const reads = num("total_reads");
    if (failPct !== undefined) out.push({ label: "Failure rate", value: `${failPct}%` });
    if (totalRuns !== undefined && failedRuns !== undefined)
      out.push({ label: "Runs (failed / total)", value: `${failedRuns} / ${totalRuns}` });
    if (writes !== undefined && reads !== undefined)
      out.push({ label: "Writes / reads", value: `${writes.toLocaleString()} / ${reads}` });
    out.push({ label: "Cost / 30d", value: moneyExact(num("cost_30d_usd") ?? monthlyCost) });
  } else if (resourceType === "serving_endpoint") {
    // The whole finding rests on "billed on N days, served M requests", so those
    // two numbers lead — and min_concurrency names the cause.
    const reqs = num("requests_window");
    const billed = num("days_billed");
    const minConc = num("min_concurrency");
    const dbus = num("dbus_window");
    if (typeof ev.entity_type === "string")
      out.push({ label: "Endpoint type", value: String(ev.entity_type) });
    if (billed !== undefined)
      out.push({ label: "Days billed", value: String(billed) });
    if (reqs !== undefined)
      out.push({ label: "Requests", value: reqs.toLocaleString() });
    if (ev.provisioned_throughput === true)
      out.push({ label: "Provisioned throughput", value: "yes (no scale-to-zero)" });
    else if (minConc !== undefined)
      out.push({ label: "Min concurrency", value: `${minConc} (scale-to-zero off)` });
    if (typeof ev.compute_type === "string")
      out.push({ label: "Compute", value: String(ev.compute_type) });
    if (dbus !== undefined)
      out.push({ label: "DBUs", value: dbus.toLocaleString(undefined, { maximumFractionDigits: 0 }) });
    out.push({ label: "Cost / 30d", value: moneyExact(num("cost_window_usd") ?? monthlyCost) });
  } else if (resourceType === "cluster") {
    const wc = num("worker_count");
    const tw = num("target_workers");
    // Lead with WHAT this cluster is — a job cluster and an all-purpose cluster
    // with the same idle time call for completely different actions.
    if (typeof ev.cluster_kind === "string")
      out.push({ label: "Cluster type", value: String(ev.cluster_kind) });
    if (typeof ev.node_type === "string")
      out.push({ label: "Node type", value: String(ev.node_type) });
    if (wc !== undefined) out.push({ label: "Workers", value: tw !== undefined ? `${wc} → ${tw}` : String(wc) });
    // The current (latest observed) auto-termination setting — the config the
    // "enable / shorten auto-termination" and idle-cluster findings are about, so
    // the reader sees what it is now, not just what to change it to. The key is
    // present (as a number or null) only on the rules that read it; null or 0 = off.
    if ("auto_termination_minutes" in ev) {
      const mins = num("auto_termination_minutes");
      out.push({ label: "Auto-termination", value: mins && mins > 0 ? `${mins} min` : "off" });
    }
    // CPU and memory always lead — together they say whether the cluster is
    // oversized. Swap and I/O wait are shown only when they are high enough to
    // change the decision (memory pressure / storage-bound: don't shrink); at
    // "0% avg · 0% peak" they were strip filler. Every metric stays in the chart.
    const pctFact = (key: string, label: string, notableAtPeak = 0) => {
      const avg = num(`${key}_avg_pct`);
      const peak = num(`${key}_peak_pct`);
      if (avg === undefined) return;
      if ((peak ?? avg) < notableAtPeak) return;
      out.push({
        label,
        value: peak !== undefined ? `${avg}% avg · ${peak}% peak` : `${avg}%`,
      });
    };
    const avgCpu = num("avg_cpu_pct");
    if (num("cpu_avg_pct") !== undefined) pctFact("cpu", "CPU");
    else if (avgCpu !== undefined) out.push({ label: "CPU (avg)", value: `${avgCpu}%` });
    pctFact("mem", "Memory");
    pctFact("swap", "Swap", 5);
    pctFact("io_wait", "I/O wait", 15);
  } else if (resourceType === "pipeline") {
    // The whole finding rests on "billed N hours, ran for M of them", so those two
    // lead — and the update cadence is what tells the reader whether moving to a
    // triggered schedule is acceptable for their freshness requirement.
    const billed = num("billed_hours");
    const active = num("active_hours");
    const idlePct = num("idle_pct");
    const updates = num("updates_30d");
    const avgMin = num("avg_update_minutes");
    const failed = num("failed_updates");
    if (typeof ev.edition === "string")
      out.push({ label: "Edition", value: String(ev.edition) });
    out.push({
      label: "Mode",
      value: ev.is_serverless === true ? "continuous · serverless" : "continuous · classic",
    });
    if (billed !== undefined && active !== undefined)
      out.push({
        label: "Hours billed / running",
        value: `${billed.toLocaleString()} / ${active.toLocaleString()}`,
      });
    if (idlePct !== undefined)
      out.push({ label: "Billed while idle", value: `${idlePct}%` });
    if (updates !== undefined)
      out.push({ label: "Updates", value: updates.toLocaleString() });
    if (avgMin !== undefined)
      out.push({ label: "Avg update", value: `${avgMin} min` });
    // Only worth a row when non-zero: a healthy pipeline showing "0 failed" is
    // noise, but a failing one changes how the reader reads the idle time.
    if (failed !== undefined && failed > 0)
      out.push({ label: "Failed updates", value: String(failed) });
    out.push({ label: "Cost / 30d", value: moneyExact(num("cost_30d_usd") ?? monthlyCost) });
  }
  // How much observation backs the numbers above, for every resource type. A
  // monthly figure extrapolated from a few days should be read differently from
  // one measured across a month, so the sample size sits next to the dollars
  // rather than buried in the raw evidence table.
  const obs = num("observed_days");
  if (obs !== undefined)
    out.push({ label: "Observed activity", value: `${obs} day${obs === 1 ? "" : "s"}` });
  return out;
}

/** Pre-flight checks to eyeball before acting on a recommendation, keyed by rule.
 *
 *  System tables are the only evidence the engine has, and they are blind to
 *  whole classes of legitimate activity — a Structured Streaming query pins a
 *  cluster busy while showing no job-task minutes and no notebook commands; an
 *  endpoint may back a customer-facing app that polls rarely but must not go
 *  cold. These bullets tell the admin what to confirm with their own knowledge
 *  before applying a change, so a conservative estimate is never mistaken for a
 *  safe-to-automate certainty. Empty list => no rule-specific caveats worth a
 *  checklist (the generic disclaimer still applies). */
const PREFLIGHT_CHECKS: Record<string, string[]> = {
  interactive_to_job: [
    "Check for Structured Streaming or continuously-running notebooks on this cluster — they keep it busy but show no job-task time, so the migratable share here is a floor, not the whole story.",
    "Confirm the jobs don't depend on libraries, init scripts or a shared session state that only exists on this all-purpose cluster.",
    "Check whether people also attach notebooks to this cluster interactively — job compute is per-job and won't serve that.",
  ],
  cluster_autotermination: [
    "Check for Structured Streaming jobs or long-running notebook sessions — these look idle to system tables (low CPU, no job task) but are real work you don't want auto-terminated.",
    "Confirm no one relies on this cluster staying warm for fast interactive response during working hours.",
    "Check for scheduled jobs that assume the cluster is already running when they fire.",
  ],
  idle_zombie_clusters: [
    "Check for Structured Streaming or scheduled/interactive work before terminating — 'idle' here means system tables saw no CPU or job activity, which they can't see for every workload.",
    "Confirm the cluster isn't a shared team resource someone spins up on demand.",
    "Check that no pinned libraries, mounts or local state on it would be lost.",
  ],
  rightsize_underutilized: [
    "Downsizing trades headroom for cost — confirm the cluster has no periodic spikes (month-end, backfills) outside the observation window that need the larger size.",
    "Check for memory-bound stages (spill, OOM history) that a smaller node would worsen even when average CPU looks low.",
    "Roll out to one workload first and watch runtime / spill before applying broadly.",
  ],
  warehouse_rightsize: [
    "A smaller warehouse means fewer clusters and slower peak concurrency — confirm the current p95 queue time and query latency are acceptable to lose a little of.",
    "Check for scheduled dashboard refreshes or batch queries outside the sampled window that lean on the larger size.",
    "Downsize one notch, then watch queued %, spill and query latency before going further.",
  ],
  warehouse_scale_out: [
    "Adding a cluster raises the bill during busy hours — confirm the queue wait is actually hurting users before trading dollars for latency.",
    "Check that the queueing is concurrency (many queries at once), not one heavy query: if queries also spill to disk, a larger size may be the better lever than more clusters.",
    "Confirm auto-stop is set so the added cluster stops when the queue drains, or the extra capacity will bill through idle hours too.",
    "Raise the ceiling one step, then watch the queued-query share and p95 queue wait before widening further.",
  ],
  enable_serverless: [
    "Serverless bills a higher per-DBU rate; the saving assumes the idle warm-pool time actually disappears — confirm the workload really is bursty, not steadily busy.",
    "Check whether cold-start latency between bursts is acceptable for this warehouse's users.",
    "Confirm no dependency on classic-only features (instance profiles, custom cluster config) that serverless doesn't offer.",
  ],
  warehouse_autostop: [
    "A shorter auto-stop means more cold starts — confirm users can tolerate the occasional startup wait between query bursts.",
    "Check for scheduled jobs or dashboards that fire on a cadence longer than the proposed auto-stop and would pay a restart each time.",
  ],
  warehouse_autostop_serverless: [
    "A shorter auto-stop adds start/stop cycles — confirm the extra restarts per day (shown above) are acceptable for this warehouse's users.",
    "Check for hourly (or slower) polling dashboards that would restart the warehouse each time.",
  ],
  idle_serving_endpoints: [
    "Confirm no customer-facing app or downstream service depends on this endpoint staying warm, even if it's polled rarely.",
    "Check for scale-to-zero cold-start latency tolerance before disabling min-concurrency.",
    "Check that usage tracking is on for this endpoint: the request log in system tables only records endpoints with usage tracking enabled, so zero logged requests can mean nobody calls it OR nobody records the calls. The endpoint's Metrics tab shows the real traffic.",
    "Verify the request count reflects real traffic and not just a quiet observation window.",
  ],
  unviewed_scheduled_dashboards: [
    "Check for readers the audit log can't see — PDF/email snapshot subscribers, exports, and apps or APIs reading the dashboard's cached results — before pausing the schedule.",
    "Pause the refresh schedule first rather than deleting the dashboard, and ask the owner.",
  ],
  warehouse_min_clusters: [
    "With min_clusters = 1, queries arriving right as the warehouse wakes may queue briefly until autoscaling adds a cluster — confirm that start-of-burst latency is acceptable.",
    "If a service queries the warehouse every few minutes around the clock, batching those queries or moving them to a small dedicated warehouse also stops the wake-ups.",
  ],
  job_no_new_input: [
    "Confirm the job has no input lineage can't see — API calls, JDBC sources, files outside Unity Catalog, or generated data — before switching it to a table-update trigger.",
  ],
  instance_generation_modernize: [
    "Check the new instance type is available in the cluster's region and zone, and that the runtime version supports it (Graviton needs a recent runtime and no x86-only libraries).",
    "Switch one cluster or job first and compare runtime and cost before moving the rest.",
  ],
  unused_scheduled_jobs: [
    "Confirm the job is genuinely obsolete and not simply paused between seasonal / ad-hoc runs.",
    "Check for downstream consumers of anything it produced before removing it.",
  ],
  unused_data_jobs: [
    "Confirm nothing reads this job's output through a path the lineage in system tables can't see (external tools, dashboards, exports).",
    "Check whether the data is a compliance / audit retention requirement even if unread.",
  ],
  spot_fallback: [
    "Confirm the workload tolerates node eviction — long shuffles or non-idempotent steps may replay work and erode the saving.",
    "Keep on-demand fallback enabled so a spot shortage doesn't fail the job outright.",
  ],
  failing_jobs: [
    "Confirm the failures are the job's own fault and not an upstream dependency or transient infra issue.",
    "Check whether retries are masking a real problem worth fixing rather than retiring.",
  ],
};

export function preflightChecks(ruleId: string): string[] {
  return PREFLIGHT_CHECKS[ruleId] ?? [];
}

/** "Before you act" checklist for a recommendation. Renders nothing when the
 *  rule has no specific caveats. */
export function PreflightChecklist({ ruleId }: { ruleId: string }) {
  const checks = preflightChecks(ruleId);
  if (checks.length === 0) return null;
  return (
    <div className="preflight">
      <p className="preflight-lead">
        System tables don't see everything. Before you act, verify:
      </p>
      <ul className="preflight-list">
        {checks.map((c, i) => (
          <li key={i}>{c}</li>
        ))}
      </ul>
    </div>
  );
}

export function vizTitle(viz: Viz): string {
  switch (viz.kind) {
    case "hour_heatmap":
      return viz.context === "pipeline"
        ? "When was this pipeline updating versus billed idle?"
        : viz.context === "keepalive"
          ? "Which hours were held up only by keep-alive statements?"
          : "When was this warehouse serving queries versus warm idle?";
    case "burst_compare":
      return "Why serverless fits this usage pattern";
    case "cpu_area":
      return "Does the load still fit after the downsize?";
    case "cluster_daily":
      return "When did this cluster actually run?";
    case "job_runs":
      return "How often is this job failing?";
    case "driver_worker_split":
      return "Is the work stuck on the driver while the workers idle?";
    case "write_no_read":
      return "Data written every run, with no observed reads";
    case "serving_traffic":
      return "Billed days versus inference requests";
    case "wh_rightsize":
      return "Warehouse headroom and the KPIs to watch";
    case "wh_scale_out":
      return "This warehouse is under-provisioned: queries are queuing";
    case "autostop_tradeoff":
      return "Why this auto-stop value, and not a shorter one";
    case "cluster_resources":
      return "What this cluster is actually doing (CPU, memory, I/O, network)";
    case "cluster_week_heatmap":
      return "When was this cluster actually used?";
    case "cluster_contention":
      return "Are concurrent jobs starving each other?";
    case "daily_stack":
    case "ranked_bars":
      return viz.title;
    case "sql_failures":
      return "Failed versus total queries per day";
    case "pipeline_failures":
      return "Failed versus total pipeline updates per day";
    case "instance_pool":
      return "Pool launches and cluster acquisitions versus the warm floor";
    default:
      return "Usage pattern";
  }
}

export function VizLegend({ viz }: { viz: Viz }) {
  const kind = viz.kind;
  // These kinds draw their own legend inline (cluster_resources depends on which
  // metrics the node timeline returned; wh_scale_out labels its two panels;
  // wh_rightsize's headroom gauges carry their own), so nothing static here.
  if (
    kind === "cluster_resources" ||
    kind === "wh_scale_out" ||
    kind === "wh_rightsize" ||
    kind === "cluster_contention" || // draws its own legend inline
    kind === "autostop_tradeoff" || // each of its panels carries its own legend
    kind === "cluster_week_heatmap" || // legend sits under the heatmap, not the rhythm chart
    kind === "daily_stack" || // series labels travel in the payload; drawn by the chart
    kind === "ranked_bars" ||
    kind === "instance_pool" || // the Labs charts state their key in the footer line
    kind === "sql_failures" ||
    kind === "pipeline_failures"
  )
    return null;
  const items =
    kind === "hour_heatmap"
      ? viz.context === "pipeline"
        ? [
            ["var(--info)", "Update running"],
            ["var(--warn)", "Billed idle (reclaimable)"],
            ["var(--track)", "Not billed"],
          ]
        : viz.context === "keepalive"
          ? [
              ["var(--info)", "Real queries running"],
              ["var(--warn)", "Only keep-alive statements (reclaimable)"],
              ["var(--track)", "Stopped (not billed)"],
            ]
          : [
            ["var(--info)", "Serving queries"],
            ["var(--warn)", "Warm but idle (reclaimable)"],
            ["var(--track)", "Stopped (not billed)"],
          ]
      : kind === "burst_compare"
        ? [
            ["var(--info)", "Query load"],
            ["var(--warn)", "Billed idle (classic warm pool)"],
          ]
        : kind === "cluster_daily"
          ? [
              ["var(--info)", "Active time (CPU ≥ 10%)"],
              ["var(--warn)", "Idle time (CPU < 10%)"],
              ["var(--savings)", "Last active"],
            ]
          : kind === "job_runs"
            ? [
                ["var(--info)", "Succeeded runs"],
                ["var(--danger)", "Failed runs (wasted compute)"],
              ]
            : kind === "driver_worker_split"
            ? [
                ["var(--info)", "Driver (working)"],
                ["var(--warn)", "Workers (idle)"],
              ]
            : kind === "write_no_read"
              ? [
                  ["var(--violet)", "Writes (data produced)"],
                  ["var(--info)", "Reads (never happened)"],
                ]
              : kind === "serving_traffic"
                ? [
                    ["var(--warn)", "Billed day"],
                    ["var(--info)", "Inference requests"],
                  ]
              : [
                  // cpu_area is the right-size chart: today's load, today's p95, and
                  // where that p95 lands on the proposed worker count.
                  ["var(--info)", "CPU used (hourly, all nodes)"],
                  ["var(--savings)", "p95 today"],
                  ["var(--violet)", "p95 after the downsize (≈ linear)"],
                ];
  return (
    <div className="ut-legend">
      {items.map(([color, label]) => (
        <span key={label}>
          <i style={{ background: color }} /> {label}
        </span>
      ))}
    </div>
  );
}
