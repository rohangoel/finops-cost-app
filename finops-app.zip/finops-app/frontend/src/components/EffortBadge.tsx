import { EFFORT_LABEL } from "../lib/format";

export function EffortBadge({ band }: { band: string }) {
  return (
    <span className={`badge effort effort-${band}`} title={`Effort: ${EFFORT_LABEL[band] ?? band}`}>
      {EFFORT_LABEL[band] ?? band} effort
    </span>
  );
}
