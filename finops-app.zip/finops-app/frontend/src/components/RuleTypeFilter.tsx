import { FunnelIcon } from "@heroicons/react/24/outline";
import { useEffect, useMemo, useRef, useState } from "react";
import type { RuleMeta } from "../api/types";
import { useRules } from "../hooks/useWorkspaces";
import { ResourceIcon, resourceLabel } from "./ResourceChip";

/** Multi-select "recommendation type" filter for the recommendations overview.
 *
 *  Semantics are conjunctive (ALL): selecting several types keeps only resources
 *  where EVERY selected recommendation applies — the overlap, e.g. clusters that
 *  are BOTH running jobs on interactive compute AND oversized. That matches the
 *  backend's `rule_ids` group filter (recommendation_service.list_grouped).
 *
 *  A popover of checkboxes rather than a native <select multiple>, because the
 *  native control is awkward (ctrl-click, no labels) and we want the human rule
 *  titles grouped by resource type. Rules are read from the live catalog so the
 *  list stays correct as rules are added — no hardcoded enum to drift. */
export function RuleTypeFilter({
  selected,
  onChange,
}: {
  selected: string[];
  onChange: (next: string[]) => void;
}) {
  const { data: rules = [] } = useRules();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click / Escape, like any popover.
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  // Only enabled rules can produce findings, so only they can meaningfully filter.
  // Group by resource type so the list reads the way the catalog does.
  const grouped = useMemo(() => {
    const byType = new Map<string, RuleMeta[]>();
    for (const r of rules) {
      if (!r.enabled) continue;
      const list = byType.get(r.resource_type) ?? [];
      list.push(r);
      byType.set(r.resource_type, list);
    }
    for (const list of byType.values()) list.sort((a, b) => a.title.localeCompare(b.title));
    return [...byType.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [rules]);

  const titleById = useMemo(
    () => new Map(rules.map((r) => [r.id, r.title])),
    [rules],
  );

  const selectedSet = new Set(selected);
  const toggle = (id: string) => {
    const next = new Set(selectedSet);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    onChange([...next]);
  };

  const count = selected.length;
  const label =
    count === 0
      ? "All types"
      : count === 1
        ? (titleById.get(selected[0]) ?? selected[0])
        : `${count} types`;

  return (
    <div className="ruletype-filter" ref={ref}>
      <button
        type="button"
        className={`ruletype-trigger${count > 0 ? " ruletype-trigger-active" : ""}`}
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        title={
          count > 1
            ? "Showing resources where ALL selected types apply"
            : "Filter by recommendation type"
        }
      >
        <FunnelIcon className="ruletype-icon" />
        <span className="ruletype-label">{label}</span>
        {count > 0 && (
          <span
            className="ruletype-clear"
            role="button"
            aria-label="Clear type filter"
            title="Clear type filter"
            onClick={(e) => {
              e.stopPropagation();
              onChange([]);
            }}
          >
            ×
          </span>
        )}
      </button>

      {open && (
        <div className="ruletype-menu" role="menu">
          <div className="ruletype-menu-head">
            Recommendation type
            {count > 1 && (
              <span className="ruletype-and" title="Resources must match every selected type">
                match ALL
              </span>
            )}
          </div>
          <div className="ruletype-menu-body">
            {grouped.length === 0 ? (
              <p className="muted small" style={{ padding: "6px 10px", margin: 0 }}>
                No rules available.
              </p>
            ) : (
              grouped.map(([type, list]) => (
                <div key={type} className="ruletype-group">
                  <div className="ruletype-group-head">
                    <ResourceIcon type={type} className="chip-icon" />
                    {resourceLabel(type)}
                  </div>
                  {list.map((r) => (
                    <label key={r.id} className="ruletype-item">
                      <input
                        type="checkbox"
                        checked={selectedSet.has(r.id)}
                        onChange={() => toggle(r.id)}
                      />
                      <span>{r.title}</span>
                    </label>
                  ))}
                </div>
              ))
            )}
          </div>
          {count > 0 && (
            <div className="ruletype-menu-foot">
              <button type="button" className="btn-link" onClick={() => onChange([])}>
                Clear {count} selected
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
