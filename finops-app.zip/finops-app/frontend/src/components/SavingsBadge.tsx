import { ArrowTrendingDownIcon } from "@heroicons/react/24/solid";
import { money } from "../lib/format";

export function SavingsBadge({ value }: { value: number }) {
  return (
    <span className="badge badge-savings" title={`${money(value)} / month potential savings`}>
      <ArrowTrendingDownIcon className="badge-icon" />
      {money(value)}/mo
    </span>
  );
}
