import { useRef, useState } from "react";
import { PaperAirplaneIcon } from "@heroicons/react/24/outline";
import { apiPost } from "../api/client";
import type { GenieAskRequest, GenieAskResponse } from "../api/types";

/** Page context woven into every question by the backend (see genie_conversation). */
export interface GenieContext {
  workspace_id?: string | null;
  workspace_name?: string | null;
  resource_type?: string | null;
  resource_id?: string | null;
  resource_name?: string | null;
}

interface Turn {
  role: "user" | "genie";
  text: string;
  answer?: GenieAskResponse; // present on genie turns that carried a table
  error?: boolean;
}

interface Props {
  /** Contextual starter questions, shown as click-to-ask chips. */
  samples?: string[];
  /** What the page is showing — sent so answers resolve to THIS resource. */
  context?: GenieContext;
}

/**
 * The native, context-aware "Ask Genie" chat (FINOPS_GENIE_MODE=api).
 *
 * Unlike the embedded iframe, this posts to `/api/genie/ask`, where the backend
 * injects the current workspace/resource into the prompt and runs the Genie
 * Conversation API as the signed-in user. Answers render in the app's own bubbles
 * (no cross-origin frame, no embedding allowlist), and the conversation id is
 * threaded back on every turn so follow-ups keep context.
 */
export function GenieChat({ samples = [], context }: Props) {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  // Threaded across turns so the backend continues the same conversation.
  const conversationId = useRef<string | null>(null);

  const ask = async (question: string) => {
    const q = question.trim();
    if (!q || busy) return;
    setInput("");
    setTurns((t) => [...t, { role: "user", text: q }]);
    setBusy(true);
    try {
      const body: GenieAskRequest = {
        question: q,
        conversation_id: conversationId.current,
        ...context,
      };
      const res = await apiPost<GenieAskResponse>("/api/genie/ask", body);
      if (res?.conversation_id) conversationId.current = res.conversation_id;
      if (!res || res.error) {
        setTurns((t) => [
          ...t,
          { role: "genie", text: res?.error ?? "No answer.", error: true },
        ]);
      } else {
        setTurns((t) => [...t, { role: "genie", text: res.text || "(no answer)", answer: res }]);
      }
    } catch {
      setTurns((t) => [
        ...t,
        { role: "genie", text: "Genie could not answer that just now.", error: true },
      ]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="genie-chat">
      {turns.length === 0 && samples.length > 0 && (
        <>
          <div className="genie-samples-label">Try asking:</div>
          <div className="genie-samples">
            {samples.map((q) => (
              <button
                key={q}
                type="button"
                className="genie-sample"
                onClick={() => ask(q)}
                disabled={busy}
              >
                <span>{q}</span>
              </button>
            ))}
          </div>
        </>
      )}

      {turns.length > 0 && (
        <div className="genie-thread">
          {turns.map((t, i) => (
            <div key={i} className={`genie-turn genie-turn-${t.role}`}>
              <div className={`genie-bubble${t.error ? " genie-bubble-error" : ""}`}>
                {t.text}
                {t.answer?.query && (
                  <details className="genie-sql">
                    <summary>SQL</summary>
                    <pre>{t.answer.query}</pre>
                  </details>
                )}
                {t.answer && t.answer.columns.length > 0 && (
                  <GenieResultTable answer={t.answer} />
                )}
              </div>
            </div>
          ))}
          {busy && (
            <div className="genie-turn genie-turn-genie">
              <div className="genie-bubble genie-bubble-thinking">Thinking…</div>
            </div>
          )}
        </div>
      )}

      <form
        className="genie-input-row"
        onSubmit={(e) => {
          e.preventDefault();
          ask(input);
        }}
      >
        <input
          className="genie-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question about this…"
          disabled={busy}
        />
        <button className="genie-send" type="submit" disabled={busy || !input.trim()}>
          <PaperAirplaneIcon className="genie-send-icon" />
        </button>
      </form>
    </div>
  );
}

/** Small preview table for an answer that ran a query. Capped server-side. */
function GenieResultTable({ answer }: { answer: GenieAskResponse }) {
  return (
    <div className="genie-result">
      <table className="kv-table">
        <thead>
          <tr>
            {answer.columns.map((c) => (
              <th key={c}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {answer.rows.map((row, ri) => (
            <tr key={ri}>
              {row.map((cell, ci) => (
                <td key={ci}>{cell === null ? "—" : String(cell)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {answer.truncated && <div className="muted genie-result-note">Showing the first rows.</div>}
    </div>
  );
}
