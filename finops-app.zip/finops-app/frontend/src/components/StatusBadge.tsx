// Savings-status pill (Phase 0.3). Tells the reader how much trust the headline
// places in a finding: `bookable` is booked into the conservative headline floor,
// `estimated` is shown and rankable but not booked, `advisory` books no dollars.
// See docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md.

const LABEL: Record<string, string> = {
  bookable: "Booked",
  estimated: "Estimated",
  advisory: "Advisory",
};

const TITLE: Record<string, string> = {
  bookable: "Counted in the savings total and in its conservative booked floor.",
  estimated: "Estimate — counted in the savings total, not in the booked floor.",
  advisory: "Not counted in any total — the problem is measured, the dollars are not.",
};

export function StatusBadge({ status }: { status: string }) {
  // The contract types savings_status as non-null, but guard anyway: a missing
  // value should render nothing rather than an empty, unstyled `badge-status-null`.
  if (!status) return null;
  const label = LABEL[status] ?? status;
  return (
    <span
      className={`badge badge-status badge-status-${status}`}
      title={TITLE[status] ?? label}
    >
      {label}
    </span>
  );
}
