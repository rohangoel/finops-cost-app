import { CheckCircleIcon, ExclamationTriangleIcon } from "@heroicons/react/24/outline";
import { Link } from "react-router-dom";
import type { ServerlessFleet, ServerlessIssue } from "../api/types";
import { MixBar } from "../components/charts/MixBar";
import { ResourceChip } from "../components/ResourceChip";
import { useServerlessCase } from "../hooks/useServerlessCase";
import { moneyExact } from "../lib/format";

/** "About Serverless" — the case for moving, built from this account's own data.
 *
 *  Written for a platform admin, so the argument is operational rather than
 *  promotional: each section names a class of work they are doing today (sizing,
 *  idle-timeout tuning, runtime upgrades, spot handling), shows what it is costing
 *  in their estate, and states what serverless does about it. Every figure is
 *  measured; where the evidence is weaker we say so inline instead of rounding up. */
export function AboutServerless() {
  const { data, isLoading, error } = useServerlessCase();

  if (isLoading) return <p className="muted">Analysing your estate…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  const { readiness, fleet, issues } = data;
  const sharePct = Math.round(readiness.serverless_share * 100);

  return (
    <div>
      <div className="construction-banner" role="alert">
        <ExclamationTriangleIcon className="icon" />
        <div>
          <strong>Under construction: do not rely on this tab yet.</strong>
          <span className="con-body">
            The figures and the serverless narrative on this page are not accurate yet
            and are still being validated. Treat everything here as a work in progress,
            and do not use these numbers in a customer conversation until this notice is
            removed.
          </span>
        </div>
      </div>

      <div className="page-head">
        <div>
          <h1>About Serverless</h1>
          <p className="subtitle">
            Self-managed compute cost, last {data.lookback_days} days.
          </p>
        </div>
      </div>

      <div className="kpi-row">
        <div className="kpi kpi-accent">
          <div className="kpi-head">
            <span className="kpi-label">Addressable / mo</span>
          </div>
          <div className="kpi-value">{moneyExact(data.total_monthly_savings_usd)}</div>
          <div className="kpi-sub">
            across {data.affected_resource_count} resources in {data.workspace_count}{" "}
            workspace{data.workspace_count === 1 ? "" : "s"}
          </div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Already serverless</span>
          </div>
          <div className="kpi-value">{readiness.spend_available ? `${sharePct}%` : "—"}</div>
          <div className="kpi-sub">
            {readiness.spend_available
              ? `${moneyExact(readiness.serverless_spend_usd)} of ${moneyExact(
                  readiness.serverless_spend_usd + readiness.classic_spend_usd,
                )} spend`
              : "spend data unavailable"}
          </div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Problem areas found</span>
          </div>
          <div className="kpi-value">{issues.length}</div>
          <div className="kpi-sub">classes of work serverless removes</div>
        </div>
      </div>

      {readiness.spend_available && (
        <div className="card card-pad" style={{ marginTop: 20 }}>
          <div className="card-head">
            <span className="card-title">Where your compute spend sits today</span>
            <span className="card-hint">serverless vs self-managed</span>
          </div>
          <div style={{ marginTop: 16 }}>
            <MixBar
              slices={[
                {
                  key: "serverless",
                  label: "Serverless",
                  value: Math.round(readiness.serverless_spend_usd),
                  count: 0,
                  color: "var(--savings)",
                },
                {
                  key: "classic",
                  label: "Self-managed (classic)",
                  value: Math.round(readiness.classic_spend_usd),
                  count: 0,
                  color: "var(--info)",
                },
              ]}
            />
          </div>
        </div>
      )}

      <FleetFacts fleet={fleet} />

      <h2 style={{ marginTop: 28 }}>What you're managing today</h2>
      <div className="issue-list">
        {issues.map((issue) => (
          <IssueCard key={issue.key} issue={issue} />
        ))}
        {issues.length === 0 && (
          <p className="empty">
            No self-managed compute problems found in scope — either the estate is already
            serverless, or there is not enough usage data yet.
          </p>
        )}
      </div>
    </div>
  );
}

/** Fleet-level facts that aren't per-resource findings. Each card is rendered only
 *  when its metric was actually readable, so a workspace without the relevant
 *  system schema shows fewer cards rather than zeros. */
function FleetFacts({ fleet }: { fleet: ServerlessFleet }) {
  const hasAny = fleet.dbr_versions?.length || fleet.startup || fleet.autoscale;
  if (!hasAny) return null;

  const oldDbrSpend = (fleet.dbr_versions ?? [])
    .filter((d) => {
      const major = parseInt(d.version, 10);
      return !Number.isNaN(major) && major < 13;
    })
    .reduce((s, d) => s + d.spend_usd, 0);

  return (
    <>
      <h2 style={{ marginTop: 28 }}>Platform upkeep you're carrying</h2>
      <div className="grid-3">
        {fleet.dbr_versions && fleet.dbr_versions.length > 0 && (
          <div className="card card-pad">
            <div className="card-head">
              <span className="card-title">Runtime versions in flight</span>
            </div>
            <div className="fleet-value">{fleet.distinct_dbr_versions}</div>
            <p className="muted small">
              distinct Databricks Runtimes across your clusters — each one is a version
              somebody has to keep patched and current.
              {oldDbrSpend > 0 && (
                <>
                  {" "}
                  <span className="strong">{moneyExact(oldDbrSpend)}</span> of spend is on
                  runtimes older than DBR 13.
                </>
              )}
            </p>
            <ul className="fleet-list">
              {fleet.dbr_versions.slice(0, 5).map((d) => (
                <li key={d.version}>
                  <code>{d.version}</code>
                  <span className="muted">
                    {d.cluster_count} cluster{d.cluster_count === 1 ? "" : "s"} ·{" "}
                    {moneyExact(d.spend_usd)}
                  </span>
                </li>
              ))}
            </ul>
            <p className="fleet-answer">
              <CheckCircleIcon className="icon" /> Serverless runs a current runtime with
              Photon, upgraded for you.
            </p>
          </div>
        )}

        {fleet.startup && fleet.startup.queries_waiting > 0 && (
          <div className="card card-pad">
            <div className="card-head">
              <span className="card-title">Users waiting for compute</span>
            </div>
            <div className="fleet-value">
              {Math.round(fleet.startup.total_wait_minutes / 60).toLocaleString()}h
            </div>
            <p className="muted small">
              total time queries spent waiting for compute to become available —{" "}
              {fleet.startup.queries_waiting.toLocaleString()} of{" "}
              {fleet.startup.total_queries.toLocaleString()} queries (
              {Math.round(fleet.startup.waiting_share * 100)}%). Typical wait{" "}
              {fleet.startup.p50_wait_s}s, worst {Math.round(fleet.startup.max_wait_s)}s.
            </p>
            <p className="muted small">
              This is the cost your users feel rather than a line on the bill — and the
              reason short idle timeouts are unpopular.
            </p>
            <p className="fleet-answer">
              <CheckCircleIcon className="icon" /> Serverless compute is available in
              seconds, so short idle settings stop being a trade-off.
            </p>
          </div>
        )}

        {fleet.autoscale && fleet.autoscale.resize_events > 0 && (
          <div className="card card-pad">
            <div className="card-head">
              <span className="card-title">Autoscaling churn</span>
            </div>
            <div className="fleet-value">
              {fleet.autoscale.resize_events.toLocaleString()}
            </div>
            <p className="muted small">
              cluster resize events across {fleet.autoscale.clusters_scaling} clusters —
              time spent adding and removing nodes to chase load you configured bounds for.
            </p>
            <p className="fleet-answer">
              <CheckCircleIcon className="icon" /> Serverless scales without min/max
              worker bounds for you to tune.
            </p>
          </div>
        )}
      </div>
    </>
  );
}

function IssueCard({ issue }: { issue: ServerlessIssue }) {
  return (
    <section className="card card-pad issue-card">
      <div className="issue-head">
        <h3>{issue.title}</h3>
        <span className="issue-savings">
          <span className="strong savings-text">{moneyExact(issue.monthly_savings_usd)}</span>
          <span className="muted small">/mo · {issue.resource_count} resources</span>
        </span>
      </div>

      <details className="about-data">
        <summary>What changes on serverless</summary>
        <div className="about-data-body">
          <p>
            <strong>Today.</strong> {issue.problem}
          </p>
          <p>
            <strong>On serverless.</strong> {issue.serverless_answer}
          </p>
          {issue.evidence_note && (
            <p>
              <strong>Based on.</strong> {issue.evidence_note}
            </p>
          )}
        </div>
      </details>

      {issue.examples.length > 0 && (
        <details className="issue-examples">
          <summary>
            Affected resources ({issue.resource_count}
            {issue.resource_count > issue.examples.length
              ? `, showing top ${issue.examples.length}`
              : ""}
            )
          </summary>
          <ul>
            {issue.examples.map((ex) => (
              <li key={`${ex.workspace_id}-${ex.resource_id}`}>
                <span className="issue-ex-head">
                  <ResourceChip type={ex.resource_type} />
                  {ex.group_id ? (
                    <Link to={`/resources/${ex.group_id}`}>{ex.resource_name}</Link>
                  ) : (
                    <span className="strong">{ex.resource_name}</span>
                  )}
                  <span className="muted small">
                    · {ex.workspace_name ?? `ws ${ex.workspace_id}`}
                  </span>
                  <span className="strong savings-text">
                    {moneyExact(ex.monthly_savings_usd)}/mo
                  </span>
                </span>
                <span className="muted small issue-ex-detail">{ex.detail}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}
