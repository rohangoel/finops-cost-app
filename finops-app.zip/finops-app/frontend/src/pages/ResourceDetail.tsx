import { ArrowLeftIcon, ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import { Link, useParams, useSearchParams } from "react-router-dom";
import type { Evidence } from "../api/types";
import { EffortBadge } from "../components/EffortBadge";
import { GeniePanel } from "../components/GeniePanel";
import { OptionCard } from "../components/OptionCard";
import { ResourceChip } from "../components/ResourceChip";
import { ServerlessFitCard } from "../components/ServerlessFitCard";
import { SavingsRange } from "../components/SavingsRange";
import { StatusBadge } from "../components/StatusBadge";
import { resourceFacts, resourceUrl } from "../components/recDetailParts";
import { FindingFeedback } from "../components/FindingFeedback";
import { useConfig } from "../hooks/useConfig";
import { useMyFindings, useMyVotes } from "../hooks/useFeedback";
import { useMe } from "../hooks/useMe";
import { isRecipient, matchesFocus, parsePrefill } from "../lib/feedback";
import { useRecommendationGroup } from "../hooks/useRecommendations";
import { moneyExact } from "../lib/format";
import { DualPrice, PricedGroupAmount } from "../components/PricedAmount";

/** Grouped resource detail: one resource, every recommendation that applies to it.
 *
 *  Rarely does only one thing apply — an oversized cluster often warrants both a
 *  downsize AND a move to serverless — so this page lists all valid findings one
 *  after another, ordered by monthly savings with the biggest first (and expanded).
 *  Each carries its own savings, effort, evidence and charts so the user can
 *  compare and pick. The headline savings is the best single option, never the sum:
 *  the options overlap on one resource, so you can only bank one. */
export function ResourceDetail() {
  const { groupId = "" } = useParams();
  const [params] = useSearchParams();
  // Set when arriving from a single-finding link, so that option opens expanded
  // even if it is not the top-savings one.
  // `focus` is a finding_key (email / Genie links, stable across snapshots) or an
  // older recommendation_id; both resolve.
  const focus = params.get("focus");
  // A confirm link (…&verdict=…&reason=…) opens the focused finding's vote form
  // prefilled. Nothing is recorded until the user presses Confirm.
  const prefill = parsePrefill(params);
  const { data: group, isLoading, error } = useRecommendationGroup(groupId);
  const { data: me } = useMe();
  const { data: config } = useConfig();
  // Votes are the optional StopTheLeak integration; the backend reports
  // feedback_enabled only when it (and the feedback store) is on.
  const feedbackOn = !!(config?.stoptheleak_enabled && config?.feedback_enabled);
  // The caller's email as the backend sees it (X-Forwarded-Email), which decides
  // who may vote. Only fetched when feedback is on.
  const { data: mine } = useMyFindings(feedbackOn);
  const { data: votes } = useMyVotes(feedbackOn);
  const myEmail = feedbackOn ? mine?.email ?? null : null;

  if (isLoading) return <p className="muted">Loading…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!group) return null;

  const options = group.options;
  // Facts come from the best option's evidence (the resource-level metrics —
  // size, workers, cost — are the same across a resource's options).
  const best = options[0];
  const facts = best
    ? resourceFacts(group.resource_type, (best.evidence ?? {}) as Evidence, group.monthly_waste_usd)
    : [];
  const openUrl = resourceUrl(
    group.workspace_url,
    me?.workspace_host,
    group.resource_type,
    group.resource_id,
    group.workspace_id,
    group.resource_name,
  );
  const multi = options.length > 1;
  const resName = group.resource_name ?? group.resource_id;
  const wsName = group.workspace_name ?? `workspace ${group.workspace_id}`;
  // Ownership is a resource-level attribute; every option on a group carries the
  // same values (they describe the resource, not the finding), so read the best one.
  const owner = best?.resource_owner ?? null;
  const creator = best?.resource_creator ?? null;

  // The page's one summary number: the best single option (never the sum — the
  // options overlap), put against what the resource costs so the reader can
  // judge scale at a glance.
  const spend = group.monthly_waste_usd;
  const sharePct = spend > 0 ? Math.round((group.monthly_savings_usd / spend) * 100) : null;
  const overlap = multi && options.some((o) => o.savings_composition !== "additive");
  // The quickest win is worth pointing out when it isn't also the biggest saving:
  // "the largest option is high-effort, but this trivial one gets you most of it".
  const EFFORT_RANK: Record<string, number> = { trivial: 0, low: 1, medium: 2, high: 3 };
  const quickest = multi
    ? [...options]
        .filter((o) => o.savings_status !== "advisory" && o.monthly_savings_usd > 0)
        .sort(
          (a, b) =>
            (EFFORT_RANK[a.effort_band] ?? 9) - (EFFORT_RANK[b.effort_band] ?? 9) ||
            b.monthly_savings_usd - a.monthly_savings_usd,
        )[0]
    : undefined;
  const quickestId =
    quickest && best && quickest.recommendation_id !== best.recommendation_id &&
    (EFFORT_RANK[quickest.effort_band] ?? 9) < (EFFORT_RANK[best.effort_band] ?? 9)
      ? quickest.recommendation_id
      : null;

  return (
    <div className="detail">
      <Link to="/next-best-actions" className="back-link">
        <ArrowLeftIcon className="icon" /> Back
      </Link>
      {/* The resource is the subject of this page, so it is the title. The rule
          title ("Enable / shorten cluster auto-termination") lives on each option
          below, where it describes that option. */}
      <div className="res-head">
        <div className="res-title">
          <ResourceChip type={group.resource_type} />
          <h1>{resName}</h1>
        </div>
        {openUrl && (
          <a className="open-resource" href={openUrl} target="_blank" rel="noreferrer">
            Open in Databricks <ArrowTopRightOnSquareIcon className="icon" />
          </a>
        )}
      </div>
      <div className="res-meta muted">
        <span>
          Workspace <span className="strong">{wsName}</span>
        </span>
        {/* Who to talk to about this resource. Resolved from billing usage identity,
            so it can be unknown — said explicitly, because "who do I ask?" is the
            first question before changing someone else's compute. */}
        <span>
          Owner{" "}
          {owner ? <span className="strong">{owner}</span> : <span className="faint">unknown</span>}
        </span>
        {creator && creator !== owner && (
          <span>
            Created by <span className="strong">{creator}</span>
          </span>
        )}
      </div>

      <div className="res-summary">
        <div className="res-sum-main">
          <div className="res-sum-label">{multi ? "Best option saves" : "Saves"}</div>
          <div className="res-sum-value">
            <PricedGroupAmount group={group} suffix="/mo" className="savings-text" showCloud />
          </div>
          {best && <DualPrice rec={best} />}
          {best && (
            <div className="res-sum-status">
              <StatusBadge status={best.savings_status} />
              <SavingsRange rec={best} />
            </div>
          )}
        </div>
        <div className="res-sum-item">
          <div className="res-sum-label">Resource spend</div>
          <div className="res-sum-value">{moneyExact(spend)}/mo</div>
          {sharePct !== null && (
            <div className="res-sum-sub">saving = {sharePct}% of it</div>
          )}
        </div>
        <div className="res-sum-item">
          <div className="res-sum-label">{multi ? `${options.length} options` : "Effort"}</div>
          <div className="res-sum-value res-sum-small">
            {multi ? (overlap ? "Overlapping — pick one" : "Can be combined") : <EffortBadge band={group.effort_band} />}
          </div>
          {multi && (
            <div className="res-sum-sub">
              {overlap ? "savings don't add up" : "savings add up"}
            </div>
          )}
        </div>
      </div>

      {facts.length > 0 && (
        <div className="facts-strip">
          {facts.map((f) => (
            <div className="fact" key={f.label}>
              <div className="fact-value">{f.value}</div>
              <div className="fact-label">{f.label}</div>
            </div>
          ))}
        </div>
      )}

      <section className="options-list">
        {options.map((rec, i) => (
          <OptionCard
            key={rec.recommendation_id}
            rec={rec}
            // Open the requested finding when deep-linked; otherwise the
            // highest-saving one, which the backend orders first.
            defaultOpen={focus ? matchesFocus(rec, focus) : i === 0}
            tag={
              multi && i === 0
                ? "Largest saving"
                : rec.recommendation_id === quickestId
                  ? "Quickest win"
                  : undefined
            }
            feedback={
              isRecipient(rec, myEmail) ? (
                <FindingFeedback
                  rec={rec}
                  vote={votes?.[rec.finding_key]}
                  // Only the focused finding takes the prefill, and only for its
                  // recipient: anyone else sees the finding without a form.
                  prefill={matchesFocus(rec, focus) ? prefill : null}
                />
              ) : undefined
            }
          />
        ))}
      </section>

      {group.serverless_fit && <ServerlessFitCard fit={group.serverless_fit} />}

      <GeniePanel
        subtitle={`Ask deeper questions about this ${group.resource_type}.`}
        context={{
          workspace_id: group.workspace_id,
          workspace_name: group.workspace_name,
          resource_type: group.resource_type,
          resource_id: group.resource_id,
          resource_name: group.resource_name,
        }}
        samples={[
          `Show every recommendation for ${group.resource_type} "${resName}" and its monthly savings.`,
          `How does the spend of "${resName}" compare with other ${group.resource_type}s in ${wsName}?`,
          `What has the 30-day spend trend been for "${resName}"?`,
          `What else is costly in ${wsName}?`,
        ]}
      />
    </div>
  );
}
