import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import type { GenieSurface, GenieWorkspace } from "../api/types";
import { GenieTrend } from "../components/charts/GenieTrend";
import { Pager } from "../components/Pager";
import { useGenieCosts } from "../hooks/useGenieCosts";
import { useWorkspaces } from "../hooks/useWorkspaces";
import { useWorkspaceScope } from "../hooks/useWorkspaceScope";
import { money, moneyExact } from "../lib/format";

const WS_PAGE_SIZE = 25;

/** "Genie Costs" — platform-level analysis of AI/BI Genie spend.
 *
 *  Intentionally separate from the recommendation flow: nothing here is a finding,
 *  carries a savings figure, or feeds the NBA ranking. It answers the questions a
 *  platform admin asks about Genie specifically — who spends the most, how many
 *  people never leave the free tier, which surface the bill actually comes from,
 *  and which spaces cost money.
 *
 *  The free/paid split is a fact rather than an estimate: the free allowance bills
 *  as its own zero-priced SKU, so "still free" means "never generated a paid Genie
 *  record", not "spent less than some threshold". */
export function GenieCosts() {
  // The workspace to scope to: the deep-link path param if present, else the global
  // switcher scope ("" = platform/all workspaces). Either way the fetch and the
  // header label agree on which workspace is in view.
  const { workspaceId: pathWorkspaceId } = useParams();
  const [scope, setScope] = useWorkspaceScope();
  const workspaceId = pathWorkspaceId || scope || undefined;
  const { data, isLoading, error } = useGenieCosts(workspaceId);
  const { data: workspaces = [] } = useWorkspaces();
  const workspaceName = workspaceId
    ? (workspaces.find((w) => w.workspace_id === workspaceId)?.workspace_name ??
       `Workspace ${workspaceId}`)
    : undefined;

  if (isLoading) return <p className="muted">Analysing Genie usage…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  if (data.unavailable) {
    return (
      <div>
        <Head lookback={data.lookback_days} workspaceName={workspaceName} />
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            Genie usage data could not be read. This needs <code>SELECT</code> on{" "}
            <code>system.billing.usage</code> and <code>system.billing.list_prices</code>
            {" "}(or a Genie snapshot written by the precompute pipeline). No figures are
            shown rather than a misleading $0.
          </p>
        </div>
      </div>
    );
  }

  if (data.no_usage) {
    return (
      <div>
        <Head lookback={data.lookback_days} workspaceName={workspaceName} />
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            No Genie usage was billed in the last {data.lookback_days} days. Nothing to
            report — this is a genuine zero, not missing data.
          </p>
        </div>
      </div>
    );
  }

  const ft = data.free_tier;
  const paidSurfaces = data.surfaces.filter((s) => !s.is_free && s.spend_usd > 0);
  const paidTotal = paidSurfaces.reduce((s, x) => s + x.spend_usd, 0);

  // The per-workspace breakdown only earns its space in the account-wide view; a
  // single-workspace scope has exactly one row, which the KPIs already state.
  const showWorkspaces = !workspaceId && data.workspaces.length > 1;
  // Resolve a friendly workspace name: snapshot rows carry one, live rows don't —
  // fall back to the account workspace list, then to the id.
  const nameFor = (w: { workspace_id: string; workspace_name: string | null }) =>
    w.workspace_name ??
    workspaces.find((x) => x.workspace_id === w.workspace_id)?.workspace_name ??
    `Workspace ${w.workspace_id}`;

  return (
    <div>
      <Head lookback={data.lookback_days} workspaceName={workspaceName} />

      {data.missing_sections.length > 0 && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <p className="muted small" style={{ margin: 0 }}>
            <strong>Partial data.</strong> These aggregates could not be read this
            time: {data.missing_sections.map(SECTION_LABEL).join(", ")}. The sections
            below that depend on them are empty for that reason, not because there is
            no usage. In live mode this usually means the query exceeded its time
            budget — the precomputed snapshot has the full picture.
          </p>
        </div>
      )}

      {data.central_note && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <p className="muted small" style={{ margin: 0 }}>
            <strong>Attribution limited on central data.</strong> {data.central_note}
          </p>
        </div>
      )}

      <div className="kpi-row">
        <div className="kpi kpi-spend">
          <div className="kpi-head">
            <span className="kpi-label">Genie spend / mo</span>
          </div>
          <div className="kpi-value">{moneyExact(data.monthly_spend_usd)}</div>
          <div className="kpi-sub">
            {Math.round(data.total_dbus).toLocaleString()} DBUs across{" "}
            {data.workspace_count} workspace{data.workspace_count === 1 ? "" : "s"}
          </div>
        </div>
        <div className="kpi kpi-accent">
          <div className="kpi-head">
            <span className="kpi-label">Still on the free tier</span>
          </div>
          <div className="kpi-value">{ft.free_only_pct}%</div>
          <div className="kpi-sub">
            {ft.free_only_users} of {ft.total_users} users never went paid
          </div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Paying users</span>
          </div>
          <div className="kpi-value">{ft.paid_users}</div>
          <div className="kpi-sub">
            drive {moneyExact(data.monthly_spend_usd)} of billed Genie usage
          </div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Free DBUs absorbed</span>
          </div>
          <div className="kpi-value">
            {Math.round(ft.free_dbus).toLocaleString()}
          </div>
          <div className="kpi-sub">billed at $0</div>
        </div>
      </div>

      {/* The trend is the one chart worth full width: it answers "is this growing?",
          which is the question that decides whether any of the rest matters. */}
      <div className="card card-pad" style={{ marginTop: 16 }}>
        <div className="card-head">
          <span className="card-title">Genie adoption &amp; spend</span>
          <span className="card-hint">
            daily, last {data.lookback_days} days · free vs paid DBUs
          </span>
        </div>
        <GenieTrend days={data.daily} />
      </div>

      <div className="grid-2" style={{ marginTop: 16 }}>
        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Where the Genie bill comes from</span>
            <span className="card-hint">paid spend by surface</span>
          </div>
          {paidSurfaces.length === 0 ? (
            <p className="muted small" style={{ marginTop: 10 }}>
              All Genie usage in this window was inside the free allowance.
            </p>
          ) : (
            <>
              <SurfaceBars surfaces={paidSurfaces} total={paidTotal} />
            </>
          )}
        </div>

        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Free tier vs paid</span>
            <span className="card-hint">by user count</span>
          </div>
          <div className="mixbar" style={{ marginTop: 12 }}>
            <div
              className="mixbar-seg"
              style={{
                width: `${ft.total_users ? (ft.free_only_users / ft.total_users) * 100 : 0}%`,
                background: "var(--savings)",
              }}
              title={`Free only: ${ft.free_only_users}`}
            />
            <div
              className="mixbar-seg"
              style={{
                width: `${ft.total_users ? (ft.paid_users / ft.total_users) * 100 : 0}%`,
                background: "var(--accent)",
              }}
              title={`Paid: ${ft.paid_users}`}
            />
          </div>
          <div className="mix-legend">
            <div className="mix-legend-row">
              <span className="legend-dot" style={{ background: "var(--savings)" }} />
              <span>Free tier only</span>
              <span className="strong">{ft.free_only_users}</span>
              <span className="faint">
                · {Math.round(ft.free_dbus_free_only_users).toLocaleString()} DBUs at $0
              </span>
            </div>
            <div className="mix-legend-row">
              <span className="legend-dot" style={{ background: "var(--accent)" }} />
              <span>Went paid</span>
              <span className="strong">{ft.paid_users}</span>
              <span className="faint">
                · {Math.round(ft.paid_dbus).toLocaleString()} paid DBUs
              </span>
            </div>
          </div>
        </div>
      </div>

      {showWorkspaces && (
        <WorkspaceSpendTable
          rows={data.workspaces}
          nameFor={nameFor}
          onPick={(id) => setScope(id)}
        />
      )}

      <h2 className="section-head">Highest Genie spenders</h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>User / principal</th>
                <th>Surfaces used</th>
                <th className="num">Paid DBUs</th>
                <th className="num">Free DBUs</th>
                <th className="num">Active days</th>
                <th className="num">Spend / mo</th>
              </tr>
            </thead>
            <tbody>
              {data.top_users.filter((u) => u.spend_usd > 0).length === 0 ? (
                <tr>
                  <td colSpan={6} className="muted">
                    No paid Genie usage in this window.
                  </td>
                </tr>
              ) : (
                data.top_users
                  .filter((u) => u.spend_usd > 0)
                  .map((u) => (
                    <tr key={u.principal} style={{ cursor: "default" }}>
                      <td>
                        <span className="mono small">{u.principal}</span>
                      </td>
                      <td className="faint small">
                        {u.by_surface
                          .slice(0, 3)
                          .map((s) => `${surfaceShort(s.surface)}${s.channel === "API" ? " (API)" : ""}`)
                          .join(", ") || "—"}
                      </td>
                      <td className="num">{Math.round(u.paid_dbus).toLocaleString()}</td>
                      <td className="num faint">{Math.round(u.free_dbus).toLocaleString()}</td>
                      <td className="num faint">{u.active_days}</td>
                      <td className="num savings-text">{moneyExact(u.monthly_spend_usd)}</td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <h2 className="section-head">Cost per Genie Space</h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Space</th>
                <th className="num">Users</th>
                <th className="num">DBUs</th>
                <th className="num">API share</th>
                <th className="num">Active days</th>
                <th className="num">Spend / mo</th>
              </tr>
            </thead>
            <tbody>
              {data.spaces.length === 0 ? (
                <tr>
                  <td colSpan={6} className="muted">
                    No Genie Space usage in this window.
                  </td>
                </tr>
              ) : (
                data.spaces.map((s) => (
                  <tr key={s.space_id} style={{ cursor: "default" }}>
                    <td>
                      <span className="mono small">{s.space_id.slice(0, 16)}…</span>
                      {s.workspace_name && (
                        <span className="faint small"> · {s.workspace_name}</span>
                      )}
                    </td>
                    <td className="num">{s.users}</td>
                    <td className="num">{Math.round(s.dbus).toLocaleString()}</td>
                    <td className="num faint">
                      {s.api_share > 0 ? `${Math.round(s.api_share * 100)}%` : "—"}
                    </td>
                    <td className="num faint">{s.active_days}</td>
                    <td className="num savings-text">
                      {s.spend_usd > 0 ? moneyExact(s.monthly_spend_usd) : "free"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <h2 className="section-head">Surface breakdown</h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Surface</th>
                <th>Channel</th>
                <th>Tier</th>
                <th className="num">Users</th>
                <th className="num">DBUs</th>
                <th className="num">Spend</th>
              </tr>
            </thead>
            <tbody>
              {data.surfaces.map((s) => (
                <tr
                  key={`${s.surface}-${s.channel}-${s.is_free}`}
                  style={{ cursor: "default" }}
                >
                  <td>{s.surface_label}</td>
                  <td className="faint">{s.channel}</td>
                  <td>
                    <span className={`role-pill ${s.is_free ? "" : "role-platform_admin"}`}>
                      {s.is_free ? "free" : "paid"}
                    </span>
                  </td>
                  <td className="num">{s.users}</td>
                  <td className="num">{Math.round(s.dbus).toLocaleString()}</td>
                  <td className="num savings-text">
                    {s.spend_usd > 0 ? money(s.spend_usd) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <details className="about-data">
        <summary>About this data</summary>
        <div className="about-data-body">
          <p>Reported here only — Genie never enters the recommendations or savings totals.</p>
          <p>
            The free allowance is billed as its own zero-priced SKU (GENIE_FREE_USAGE), so
            the free/paid split is read from billing rather than inferred from a spend
            threshold.
          </p>
          {data.top_paid_surface_label && (
            <p>
              <strong>{data.top_paid_surface_label}</strong> is {data.top_paid_surface_pct}%
              of paid Genie spend. That is often not the surface with the most users.
            </p>
          )}
          <p>{data.budgets_note}</p>
          <p>
            Highest spenders are ranked by billed Genie spend. Users who never left the
            free tier are excluded — they cost nothing.
          </p>
          <p>{data.space_coverage_note}</p>
          {showWorkspaces && (
            <p>
              All-free workspaces stay in the workspace table and sink to the bottom. Click
              a workspace to scope the app to it.
            </p>
          )}
          <p>
            <strong>Data basis:</strong> {data.data_basis}
          </p>
        </div>
      </details>
    </div>
  );
}

function Head({ lookback, workspaceName }: { lookback: number; workspaceName?: string }) {
  return (
    <div className="page-head">
      <div>
        <h1>Genie Costs</h1>
        <p className="subtitle">
          AI/BI Genie spend{" "}
          {workspaceName ? (
            <>
              in <strong>{workspaceName}</strong>
            </>
          ) : (
            "across the account"
          )}
          , last {lookback} days.
        </p>
      </div>
    </div>
  );
}

/** Genie spend ranked by workspace. Paginated because a real account has many
 *  workspaces (hundreds), and rows are clickable to scope the whole app. */
function WorkspaceSpendTable({
  rows,
  nameFor,
  onPick,
}: {
  rows: GenieWorkspace[];
  nameFor: (w: GenieWorkspace) => string;
  onPick: (workspaceId: string) => void;
}) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(WS_PAGE_SIZE);
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const visible = useMemo(
    () => rows.slice((page - 1) * pageSize, page * pageSize),
    [rows, page, pageSize],
  );
  return (
    <>
      <h2 className="section-head">Genie spend by workspace</h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Workspace</th>
                <th className="num">Users</th>
                <th className="num">Paying users</th>
                <th className="num">Paid DBUs</th>
                <th className="num">Free DBUs</th>
                <th className="num">Spend / mo</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((w) => (
                <tr
                  key={w.workspace_id}
                  onClick={() => onPick(w.workspace_id)}
                  style={{ cursor: "pointer" }}
                  title="Scope the whole app to this workspace"
                >
                  <td className="strong">{nameFor(w)}</td>
                  <td className="num">{w.users}</td>
                  <td className="num faint">{w.paid_users}</td>
                  <td className="num">{Math.round(w.paid_dbus).toLocaleString()}</td>
                  <td className="num faint">{Math.round(w.free_dbus).toLocaleString()}</td>
                  <td className="num savings-text">
                    {w.spend_usd > 0 ? moneyExact(w.monthly_spend_usd) : "free"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Pager
        page={page}
        pageCount={pageCount}
        pageSize={pageSize}
        total={rows.length}
        onPage={setPage}
        onPageSize={(s) => {
          setPageSize(s);
          setPage(1);
        }}
      />
    </>
  );
}

/** Paid spend per surface as a ranked bar list, with the user count alongside —
 *  the point being that spend rank and user rank usually disagree. */
function SurfaceBars({ surfaces, total }: { surfaces: GenieSurface[]; total: number }) {
  const max = Math.max(1, ...surfaces.map((s) => s.spend_usd));
  return (
    <div className="barlist" style={{ marginTop: 8 }}>
      {surfaces.map((s) => (
        <div className="barlist-row" key={`${s.surface}-${s.channel}`}>
          <span className="barlist-name">
            {s.surface_label}
            {s.channel === "API" && <span className="faint"> · API</span>}
          </span>
          <span className="barlist-val savings-text">{money(s.spend_usd)}</span>
          <div className="barlist-track">
            <div
              className="barlist-fill"
              style={{ width: `${Math.max(2, (s.spend_usd / max) * 100)}%` }}
              title={`${s.users} users · ${Math.round((s.spend_usd / (total || 1)) * 100)}% of paid spend`}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

/** Aggregate keys are backend-internal; name them the way the tab does. */
function SECTION_LABEL(kind: string): string {
  if (kind === "user") return "per-user spend";
  if (kind === "surface") return "surface breakdown";
  if (kind === "space") return "per-space cost";
  if (kind === "daily") return "adoption trend";
  return kind;
}

function surfaceShort(surface: string): string {
  if (surface === "GENIE_CODE") return "Code";
  if (surface === "GENIE_AGENTS") return "Spaces";
  if (surface === "GENIE_ONE") return "One";
  return surface.replace("GENIE_", "");
}
