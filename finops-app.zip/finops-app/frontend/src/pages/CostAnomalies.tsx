import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import type { AnomalyType, CostAnomaly } from "../api/types";
import { AnomalySparkline, AnomalyTrend } from "../components/charts/AnomalyTrend";
import { Pager } from "../components/Pager";
import { useCostAnomalies } from "../hooks/useCostAnomalies";
import { useWorkspaces } from "../hooks/useWorkspaces";
import { useWorkspaceScope } from "../hooks/useWorkspaceScope";
import { money, moneyExact } from "../lib/format";

const DEFAULT_PAGE_SIZE = 25;

const TYPE_LABEL: Record<AnomalyType, string> = {
  step_change: "Step change",
  spike: "Spike",
  new_spender: "New spender",
};

const TYPE_HINT: Record<AnomalyType, string> = {
  step_change: "3+ days in a row above baseline",
  spike: "1–2 unusual days",
  new_spender: "no spend at all in the baseline",
};

const RESOURCE_LABEL: Record<string, string> = {
  job: "Job",
  pipeline: "Pipeline",
  warehouse: "SQL warehouse",
  app: "App",
  serving_endpoint: "Serving endpoint",
  vector_search_endpoint: "Vector Search endpoint",
  lakebase_project: "Lakebase project",
  cluster: "Cluster",
};

/** "Cost Anomalies" — where spend broke away from its own recent normal.
 *
 *  Analysis, not advice: an anomaly may be a backfill, a launch or a mistake, and
 *  only the owner knows which. So the tab carries no savings figure, no priority and
 *  no NBA score; it answers "what moved, by how much, since when, and who drove it",
 *  which is the question to take to that owner. `excess_usd` is labelled "above
 *  baseline" everywhere — it is a size, never a saving.
 *
 *  Two views of the same events: by resource (the thing to go and look at) and by
 *  product & SKU (covers every dollar exactly once, so the headline total comes from
 *  it). The views overlap, which is why nothing sums across them. */
export function CostAnomalies() {
  const { workspaceId: pathWorkspaceId } = useParams();
  const [scope] = useWorkspaceScope();
  const workspaceId = pathWorkspaceId || scope || undefined;
  const { data, isLoading, error } = useCostAnomalies(workspaceId);
  const { data: workspaces = [] } = useWorkspaces();
  const workspaceName = workspaceId
    ? (workspaces.find((w) => w.workspace_id === workspaceId)?.workspace_name ??
       `Workspace ${workspaceId}`)
    : undefined;

  const [grain, setGrain] = useState<"resource" | "sku">("resource");
  const [typeFilter, setTypeFilter] = useState<AnomalyType | "">("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  const source = grain === "resource" ? data?.resource_anomalies : data?.sku_anomalies;
  const rows = useMemo(
    () => (source ?? []).filter((a) => !typeFilter || a.anomaly_type === typeFilter),
    [source, typeFilter],
  );
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  useEffect(() => {
    setPage(1);
  }, [grain, typeFilter, pageSize]);
  const visible = useMemo(
    () => rows.slice((page - 1) * pageSize, page * pageSize),
    [rows, page, pageSize],
  );

  if (isLoading) return <p className="muted">Looking for cost anomalies…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  const windowLabel = data.eval_start && data.eval_end
    ? `${data.eval_start.slice(5)} – ${data.eval_end.slice(5)}`
    : `last ${data.eval_days} days`;
  const head = (
    <Head window={windowLabel} baseline={data.baseline_days} workspaceName={workspaceName} />
  );

  if (data.unavailable) {
    return (
      <div>
        {head}
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            Cost anomaly data could not be read. The tab reads the snapshot written by the
            precompute pipeline (<code>finops_cost_anomalies</code>); without one it scans
            {" "}{data.baseline_days + data.eval_days} days of{" "}
            <code>system.billing.usage</code> live, which needs <code>SELECT</code> on it
            and on <code>system.billing.list_prices</code> — and on a large account can take
            longer than the page's time budget. No figures are shown rather than a
            misleading &quot;no anomalies&quot;.
          </p>
        </div>
      </div>
    );
  }

  const byType = Object.fromEntries(data.by_type.map((t) => [t.anomaly_type, t]));
  const resourceMissing = data.missing_sections.includes("anomaly");

  return (
    <div>
      {head}

      {data.missing_sections.length > 0 && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <p className="muted small" style={{ margin: 0 }}>
            <strong>Partial data.</strong> These parts could not be read this time:{" "}
            {data.missing_sections.join(", ")}.{" "}
            {resourceMissing
              ? "The anomaly list is empty for that reason, not because nothing moved. " +
                "Detection scans five weeks of billing, which usually misses the live time " +
                "budget on a large account — the precomputed snapshot has the full picture."
              : "The sections that depend on them are empty for that reason."}
          </p>
        </div>
      )}

      <div className="kpi-row">
        {/* --warn stripe, not the green savings accent: this is a size, not a saving. */}
        <div className="kpi kpi-warn">
          <div className="kpi-head">
            <span className="kpi-label">Above baseline</span>
          </div>
          <div className="kpi-value">{moneyExact(data.total_excess_usd)}</div>
          <div className="kpi-sub">
            {data.anomaly_count} product/SKU anomal{data.anomaly_count === 1 ? "y" : "ies"}
            {!workspaceId && ` · ${data.workspace_count} workspace${data.workspace_count === 1 ? "" : "s"}`}
          </div>
        </div>
        {(["step_change", "spike", "new_spender"] as AnomalyType[]).map((t) => (
          <button
            type="button"
            key={t}
            className={`kpi kpi-button${typeFilter === t ? " kpi-selected" : ""}`}
            onClick={() => setTypeFilter((cur) => (cur === t ? "" : t))}
            title={`Show only ${TYPE_LABEL[t].toLowerCase()}s`}
          >
            <div className="kpi-head">
              <span className="kpi-label">
                <span className={`anom-dot anom-dot-${t}`} /> {TYPE_LABEL[t]}s
              </span>
            </div>
            <div className="kpi-value">{byType[t]?.count ?? 0}</div>
            <div className="kpi-sub">
              {money(byType[t]?.excess_usd ?? 0)} above baseline · {TYPE_HINT[t]}
            </div>
          </button>
        ))}
      </div>

      <details className="about-data">
        <summary>About this data</summary>
        <div className="about-data-body">
          <p>{data.analysis_note}</p>
          <p>
            <strong>How an anomaly is found:</strong> {data.method_note}
          </p>
          <p>
            The totals come from the product &amp; SKU view, which counts every dollar once.
            The resource view shows the same events at a finer grain, so the two views
            overlap and are never added together.
          </p>
          <p>
            <strong>Data basis:</strong> {data.data_basis}
          </p>
        </div>
      </details>

      <div className="card card-pad" style={{ marginTop: 16 }}>
        <div className="card-head">
          <span className="card-title">Daily cost</span>
          <span className="card-hint">
            {data.baseline_days}-day baseline, then the {data.eval_days} scored days
          </span>
        </div>
        <AnomalyTrend days={data.daily} evalDays={data.eval_days} />
      </div>

      <div className="anom-toolbar">
        <h2 style={{ margin: 0 }}>Anomalies</h2>
        <div className="price-basis-switch" role="group" aria-label="Group anomalies by">
          <button type="button" className={grain === "resource" ? "active" : ""}
            onClick={() => setGrain("resource")}>
            By resource · {data.resource_anomalies.length}
          </button>
          <button type="button" className={grain === "sku" ? "active" : ""}
            onClick={() => setGrain("sku")}>
            By product &amp; SKU · {data.sku_anomalies.length}
          </button>
        </div>
        {typeFilter && (
          <span className="faint small">
            {TYPE_LABEL[typeFilter]}s only ·{" "}
            <button className="btn-link" onClick={() => setTypeFilter("")}>clear</button>
          </span>
        )}
      </div>

      {data.no_anomalies || rows.length === 0 ? (
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            {data.no_anomalies
              ? `Nothing broke away from its baseline between ${windowLabel}. This is a real ` +
                "result from the data, not missing data."
              : "No anomalies of this type in this view."}
          </p>
        </div>
      ) : (
        <>
          <div className="table-wrap">
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>{grain === "resource" ? "Resource" : "Product · SKU"}</th>
                    {!workspaceId && <th>Workspace</th>}
                    <th>When</th>
                    <th>Pattern</th>
                    <th className="num">Normal / day</th>
                    <th className="num">Peak / day</th>
                    <th className="num">Above baseline</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((a) => (
                    <AnomalyRow key={a.anomaly_key} a={a} evalDays={data.eval_days}
                      showWorkspace={!workspaceId} />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <Pager
            page={page}
            pageCount={pageCount}
            pageSize={pageSize}
            total={rows.length}
            onPage={setPage}
            onPageSize={setPageSize}
          />
        </>
      )}
    </div>
  );
}

function Head({
  window,
  baseline,
  workspaceName,
}: {
  window: string;
  baseline: number;
  workspaceName?: string;
}) {
  return (
    <div className="page-head">
      <div>
        <h1>Cost Anomalies</h1>
        <p className="subtitle">
          Where spend broke away from its own normal{" "}
          {workspaceName ? (
            <>
              in <strong>{workspaceName}</strong>
            </>
          ) : (
            "across the account"
          )}
          : {window}, compared with the {baseline} days before. Not savings — questions
          for the owner.
        </p>
      </div>
    </div>
  );
}

/** Deep link to the resource in its own workspace, where the type has a stable URL. */
function resourceHref(a: CostAnomaly): string | undefined {
  if (!a.workspace_url || !a.resource_id) return undefined;
  const base = a.workspace_url.replace(/\/$/, "");
  switch (a.resource_type) {
    case "job": return `${base}/jobs/${a.resource_id}`;
    case "pipeline": return `${base}/pipelines/${a.resource_id}`;
    case "warehouse": return `${base}/sql/warehouses/${a.resource_id}`;
    case "cluster": return `${base}/compute/clusters/${a.resource_id}`;
    case "serving_endpoint": return `${base}/ml/endpoints/${a.resource_id}`;
    default: return undefined;
  }
}

function AnomalyRow({
  a,
  evalDays,
  showWorkspace,
}: {
  a: CostAnomaly;
  evalDays: number;
  showWorkspace: boolean;
}) {
  const href = resourceHref(a);
  const label = a.grain === "resource"
    ? (a.resource_name || a.resource_id || "—")
    : (a.sku_name || "—");
  const sub = a.grain === "resource"
    ? `${RESOURCE_LABEL[a.resource_type ?? ""] ?? a.resource_type ?? ""}${a.product ? ` · ${a.product}` : ""}`
    : (a.product ?? "");
  const when = a.first_flag_date === a.last_flag_date
    ? (a.first_flag_date ?? "").slice(5)
    : `${(a.first_flag_date ?? "").slice(5)} – ${(a.last_flag_date ?? "").slice(5)}`;
  const who = a.run_as || a.owned_by;
  return (
    <tr>
      <td>
        <span className={`anom-type anom-type-${a.anomaly_type}`}>
          {TYPE_LABEL[a.anomaly_type] ?? a.anomaly_type}
        </span>
      </td>
      <td className="strong">
        {href ? <a href={href} target="_blank" rel="noreferrer">{label}</a> : label}
        {sub && <div className="faint small" style={{ fontWeight: 400 }}>{sub}</div>}
        {/* The "who" sits with the resource: it is the person to ask. */}
        <div className="muted small" style={{ fontWeight: 400 }}
          title="Identity behind the largest usage record on the peak day (identity_metadata.run_as / owned_by)">
          {who ? <>by {who}</> : <span className="faint">no identity in billing</span>}
          {a.run_as && a.owned_by && a.owned_by !== a.run_as && <> · owner {a.owned_by}</>}
        </div>
      </td>
      {showWorkspace && (
        <td className="muted">{a.workspace_name ?? a.workspace_id ?? "—"}</td>
      )}
      <td className="muted anom-nowrap">
        {when}
        <div className="faint small">
          {a.flagged_days} unusual day{a.flagged_days === 1 ? "" : "s"}
        </div>
      </td>
      <td>
        <AnomalySparkline series={a.series} median={a.baseline_median_usd} evalDays={evalDays} />
      </td>
      <td className="num">{moneyExact(a.baseline_median_usd)}</td>
      <td className="num">
        {moneyExact(a.peak_cost_usd)}
        {a.robust_z !== null && (
          <div className="faint small" title="Robust z-score of the most unusual day (how many robust standard deviations above the baseline median)">
            {/* A near-zero baseline makes z astronomically large; past 100 the exact
                value carries no information. */}
            z {a.robust_z >= 100 ? "100+" : a.robust_z.toFixed(1)}
          </div>
        )}
      </td>
      <td className="num strong">{moneyExact(a.excess_usd)}</td>
    </tr>
  );
}
