import { CheckCircleIcon, NoSymbolIcon } from "@heroicons/react/24/solid";
import { ResourceIcon, resourceLabel } from "../components/ResourceChip";
import { useRules } from "../hooks/useWorkspaces";
import { BetaPill } from "../components/BetaPill";

/** "min_monthly_cost_usd" -> "Min monthly cost (USD)". Thresholds are shown to
 *  platform admins deciding whether to trust a rule, so they should read as
 *  settings, not as YAML keys. */
function thresholdLabel(key: string): string {
  const words = key
    .replace(/_usd$/, "_(USD)")
    .replace(/_pct$/, "_(%)")
    .replace(/_frac$/, "_(fraction)")
    .split("_");
  const text = words.join(" ").replace(/\bdbu\b/gi, "DBU").replace(/\bcpu\b/gi, "CPU");
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/** Nested values (e.g. a per-cloud rate map) printed "[object Object]". */
function thresholdValue(v: unknown): string {
  if (v !== null && typeof v === "object")
    return Object.entries(v as Record<string, unknown>)
      .map(([k, x]) => `${k}: ${String(x)}`)
      .join(" · ");
  return String(v);
}

export function RuleCatalog() {
  const { data, isLoading, error } = useRules();

  if (isLoading) return <p className="muted">Loading rules…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;

  return (
    <div>
      <h1>Rule Catalog</h1>
      <p className="subtitle">
        Every check this app runs, with the thresholds a finding must cross before it is shown.
      </p>
      <div className="rule-grid">
        {(data ?? []).map((r) => (
          <div key={r.id} className={`rule-card ${r.enabled ? "" : "rule-disabled"}`}>
            <div className="rule-card-head">
              <span className={`chip chip-${r.resource_type}`}>
                <ResourceIcon type={r.resource_type} className="chip-icon" />
                {resourceLabel(r.resource_type)}
              </span>
              {r.enabled ? (
                <CheckCircleIcon className="status-icon status-on" title="Enabled" />
              ) : (
                <NoSymbolIcon className="status-icon status-off" title="Disabled" />
              )}
            </div>
            <div className="rule-title">
              {r.title}
              <BetaPill ruleId={r.id} />
            </div>
            <div className="muted small">{r.category} · {r.id} · v{r.version}</div>
            {Object.keys(r.thresholds).length > 0 && (
              <details className="rule-thresholds">
                <summary>Thresholds ({Object.keys(r.thresholds).length})</summary>
                <table className="kv-table small">
                  <tbody>
                    {Object.entries(r.thresholds).map(([k, v]) => (
                      <tr key={k} title={k}>
                        <td className="kv-key">{thresholdLabel(k)}</td>
                        <td>{thresholdValue(v)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </details>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
