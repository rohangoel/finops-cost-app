import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { WorkspaceSummary } from "../api/types";
import { BarList } from "../components/charts/BarList";
import { GeniePanel } from "../components/GeniePanel";
import { Donut } from "../components/charts/Donut";
import { SpendTrend } from "../components/charts/SpendTrend";
import { MixBar } from "../components/charts/MixBar";
import { KpiHeader, savingsKpis, withPriceBasis, type Kpi } from "../components/KpiHeader";
import { Pager } from "../components/Pager";
import { useAccountOverview } from "../hooks/useAccountOverview";
import { useRecommendations } from "../hooks/useRecommendations";
import { useSpend } from "../hooks/useSpend";
import {
  collapseToResources,
  countedTowardHeadline,
  quickWins,
  ruleTitles,
  savingsByCategory,
  savingsByEffort,
  savingsByPriority,
  savingsByRule,
} from "../lib/breakdown";
import { moneyExact } from "../lib/format";
import { usePricingContext } from "../lib/PricingContext";

const DEFAULT_PAGE_SIZE = 25;

/** Swap the "Workspaces with findings" tile — a count nobody acts on, already in
 *  the subtitle — for Quick wins: what trivial/low-effort changes save. That is
 *  the first question a FinOps lead brings to this page ("what can we do this
 *  week?"). The workspace count moves into the Recommendations tile. */
function withQuickWins(kpis: Kpi[], quick: { value: number; count: number }, workspaces: number): Kpi[] {
  const out = kpis
    .filter((k) => k.label !== "Workspaces with findings")
    .map((k) =>
      k.label === "Recommendations"
        ? { ...k, sub: `across ${workspaces} workspace${workspaces === 1 ? "" : "s"}` }
        : k,
    );
  out.push({
    label: "Quick wins / mo",
    value: moneyExact(quick.value),
    variant: "default",
    sub: `${quick.count} trivial or low-effort change${quick.count === 1 ? "" : "s"}`,
  });
  return out;
}

export function AccountOverview() {
  const { data, isLoading, error } = useAccountOverview();
  const { data: rawRecs = [] } = useRecommendations({ sort: "savings" });
  const { data: spend } = useSpend();
  const { basis } = usePricingContext();
  const navigate = useNavigate();
  // The leaderboard is one row per workspace, which is 400+ on a real account —
  // the same "unusable as one table" problem the recommendation list has.
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  const workspaces = data?.workspaces ?? [];
  const pageCount = Math.max(1, Math.ceil(workspaces.length / pageSize));
  // A smaller page size can leave us past the last page; snap back so the user
  // never lands on an empty table.
  useEffect(() => {
    setPage(1);
  }, [pageSize]);
  const visibleWorkspaces = useMemo(
    () => workspaces.slice((page - 1) * pageSize, page * pageSize),
    [workspaces, page, pageSize],
  );

  if (isLoading) return <p className="muted">Loading account overview…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  // Collapse overlapping fixes on the same resource so the breakdown charts
  // reconcile with the (grouped) headline totals instead of double-counting, and
  // drop advisory findings (which book $0 in the headline) so every chart on the
  // page sums to the same number as the KPI above it.
  const recs = collapseToResources(countedTowardHeadline(rawRecs));
  const titles = ruleTitles(rawRecs);
  const byRule = savingsByRule(recs, basis)
    .slice(0, 6)
    .map((s) => ({
      key: s.key,
      label: titles[s.key] ?? s.key,
      value: s.value,
      // Click a lever to open the recommendations list pre-filtered to that rule,
      // sorted by savings so the resources behind this bar are actionable up top.
      onClick: () =>
        navigate(`/recommendations?rule_ids=${encodeURIComponent(s.key)}&sort=savings`),
    }));
  // Spend is a separate source and may be unavailable, so the leaderboard cell
  // degrades to a dash instead of implying the workspace costs nothing.
  const spendByWs = new Map(
    (spend?.workspaces ?? []).map((w) => [w.workspace_id, w.monthly_spend_usd]),
  );
  const spendFor = (workspaceId: string) => {
    const value = spendByWs.get(workspaceId);
    return value === undefined ? <span className="faint">—</span> : moneyExact(value);
  };
  // Savings as a share of the workspace's own bill — the number a FinOps lead
  // actually compares workspaces on (a $20k saving on a $25k workspace is a very
  // different conversation from $20k on $400k). Above 100% the two sources
  // disagree, so it is flagged rather than shown as a confident ratio.
  const shareOfSpend = (w: WorkspaceSummary) => {
    const spendUsd = spendByWs.get(w.workspace_id);
    if (!spendUsd) return <span className="faint">—</span>;
    const pct = (wsSavings(w) / spendUsd) * 100;
    if (pct > 100)
      return (
        <span className="warn-text" title="Savings exceed this workspace's billed spend — the spend and recommendation snapshots disagree; check both.">
          &gt;100% ⚠
        </span>
      );
    return `${pct < 1 ? pct.toFixed(1) : Math.round(pct)}%`;
  };
  // Rank/show the fuller estimate (booked + estimated high/medium/low-confidence), not
  // just the booked floor, so a workspace whose opportunity is mostly estimated isn't
  // hidden. Falls back to the booked value on an older snapshot with no estimate field.
  const wsSavings = (w: WorkspaceSummary) =>
    (basis === "contract" && w.monthly_savings_addressable_contract_usd != null
      ? w.monthly_savings_addressable_contract_usd
      : null) ??
    (w.monthly_savings_addressable_usd || w.monthly_savings_usd);
  const byWorkspace = data.workspaces.slice(0, 8).map((w) => ({
    key: w.workspace_id,
    label: w.workspace_name ?? `Workspace ${w.workspace_id}`,
    value: Math.round(wsSavings(w)),
    onClick: () => navigate(`/workspaces/${w.workspace_id}`),
  }));

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>Account Overview</h1>
          <p className="subtitle">
            Cost-saving opportunities across {data.workspace_count} workspaces with findings.
          </p>
        </div>
      </div>

      <KpiHeader
        kpis={withPriceBasis(withQuickWins(savingsKpis(
          data.total_monthly_savings_usd,
          data.total_monthly_savings_addressable_usd,
          data.recommendation_count,
          data.workspace_count,
          // Omitted (tile hidden) when spend data isn't readable, rather than
          // showing a confident $0.
          spend && !spend.unavailable ? spend.total_monthly_spend_usd : undefined,
          // How many workspaces the regional filter excludes from those totals.
          spend && !spend.unavailable ? spend.out_of_scope_workspaces : undefined,
          // The estimate band + per-tier split behind the headline.
          {
            addressable: data.total_monthly_savings_addressable_usd,
            low: data.total_monthly_savings_low_usd,
            high: data.total_monthly_savings_high_usd,
            tiers: data.savings_tiers,
          },
        ), quickWins(recs, basis), data.workspace_count), {
          basis,
          priced: data.priced,
          spend: spend && !spend.unavailable ? spend : null,
        })}
      />

      {/* Spend direction before savings breakdown: "is the bill growing?" is the
          question that decides whether any of the rest is urgent. Rendered only
          when the series is available — an older snapshot has no by_day column,
          and a flat line at zero would read as "spend stopped". */}
      {spend && !spend.unavailable && spend.by_day.length > 0 && (
        <div className="card card-pad" style={{ marginTop: 20 }}>
          <div className="card-head">
            <span className="card-title">Platform spend trend</span>
            <span className="card-hint">
              daily, last {spend.lookback_days} days · list price
            </span>
          </div>
          <div style={{ marginTop: 14 }}>
            <SpendTrend days={spend.by_day} />
          </div>
        </div>
      )}

      <div className="grid-2" style={{ marginTop: 20 }}>
        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Savings by category</span>
            <span className="card-hint">monthly · same basis as the headline</span>
          </div>
          <div style={{ marginTop: 14 }}>
            <Donut slices={savingsByCategory(recs, basis)} centerLabel="savings / mo" />
          </div>
        </div>

        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Top workspaces by savings potential</span>
            <span className="card-hint">click to drill in</span>
          </div>
          <div style={{ marginTop: 14 }}>
            <BarList items={byWorkspace} />
          </div>
        </div>
      </div>

      <div className="grid-2" style={{ marginTop: 16 }}>
        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Biggest savings levers</span>
            <span className="card-hint">by rule · click to filter</span>
          </div>
          <div style={{ marginTop: 14 }}>
            <BarList items={byRule} />
          </div>
        </div>

        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Where the savings sit</span>
          </div>
          <div style={{ marginTop: 16 }}>
            <div className="faint small" style={{ marginBottom: 4 }}>
              BY PRIORITY
            </div>
            <MixBar slices={savingsByPriority(recs, basis)} />
          </div>
          <div style={{ marginTop: 18 }}>
            <div className="faint small" style={{ marginBottom: 4 }}>
              BY EFFORT TO FIX
            </div>
            <MixBar slices={savingsByEffort(recs, basis)} />
          </div>
        </div>
      </div>

      <h2>Workspace leaderboard</h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Workspace</th>
                <th className="num">Total spend / mo</th>
                <th className="num">Savings potential / mo</th>
                <th className="num">% of spend</th>
                <th className="num">Recommendations</th>
                <th>Top opportunity</th>
              </tr>
            </thead>
            <tbody>
              {visibleWorkspaces.map((w, i) => (
                <tr key={w.workspace_id} onClick={() => navigate(`/workspaces/${w.workspace_id}`)}>
                  <td>
                    {/* Rank is the position in the whole leaderboard, not on this
                        page — otherwise page 2 would restart at #1. */}
                    <span className="rank-badge">{(page - 1) * pageSize + i + 1}</span>
                  </td>
                  <td className="strong">{w.workspace_name ?? `Workspace ${w.workspace_id}`}</td>
                  <td className="num">{spendFor(w.workspace_id)}</td>
                  <td className="num strong savings-text">{moneyExact(wsSavings(w))}</td>
                  <td className="num">{shareOfSpend(w)}</td>
                  <td className="num">{w.recommendation_count}</td>
                  <td className="muted">{titles[w.top_rule_id ?? ""] ?? w.top_rule_id ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Pager
        page={page}
        pageCount={pageCount}
        pageSize={pageSize}
        total={workspaces.length}
        onPage={setPage}
        onPageSize={setPageSize}
      />

      <GeniePanel
        subtitle="Free-form questions across every workspace, over the FinOps analysis tables."
        samples={[
          "Which 5 workspaces have the highest total spend this month?",
          "What are the top 10 recommendations by monthly savings across the account?",
          "Which rule recovers the most estimated savings account-wide?",
          "How much of the account's spend is already serverless vs classic?",
          "Compare total Genie spend to Apps spend by workspace.",
        ]}
      />
    </div>
  );
}
