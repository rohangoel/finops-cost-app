import { useMemo } from "react";
import { ChevronRightIcon } from "@heroicons/react/24/solid";
import { KpiHeader, type Kpi } from "../components/KpiHeader";
import { PriorityBadge } from "../components/PriorityScore";
import { ResourceChip } from "../components/ResourceChip";
import type { Recommendation } from "../api/types";
import { LabsChart, type LabsViz } from "../components/charts/LabsCharts";
import { cleanProse } from "../lib/prose";
import { useExperimental } from "../hooks/useExperimental";
import { moneyExact } from "../lib/format";

// Labs (Experimental) tab. Phase 4 net-new opportunity rules that are still being
// validated (docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md §"Phase 4"). They are
// relocated OFF the main surfaces: they never count toward the headline savings
// total, never rank in Next Best Actions, and never appear as an option on an
// optimizable resource. They are advisory — the number shown is ADDRESSABLE spend
// (compute the finding flags as potentially avoidable), never a booked saving.

// A one-line framing per experimental rule, so a reader knows what they're looking
// at and how much to trust it. Keyed by rule_id.
const RULE_BLURB: Record<string, string> = {
  sql_repeated_failures:
    "Warehouses running the same query to failure over and over. Failed queries " +
    "still burn warehouse compute but produce nothing — directly avoidable work. " +
    "The dollar figure is the failed-query compute (addressable), not a booked saving.",
  manual_maintenance_overlap:
    "Warehouses running manual OPTIMIZE / VACUUM that Predictive Optimization may " +
    "already do automatically. If PO covers those tables the maintenance is redundant " +
    "— verify in Catalog Explorer before removing. Advisory, no booked saving.",
  pipeline_failed_updates:
    "DLT / Lakeflow pipelines burning compute on updates that end FAILED / TIMED_OUT. " +
    "A failed update runs compute but commits nothing. The dollar figure is the " +
    "failed-update compute (addressable), not a booked saving.",
  ai_gateway_wasted_inference:
    "Serving endpoints fronted by the AI Gateway returning a high rate of errors " +
    "(HTTP >= 400) — a broken client integration burning inference on requests that " +
    "return nothing. Operational: gateway token cost isn't split per endpoint in " +
    "billing, so the metric is failed requests + wasted tokens, not dollars.",
  instance_pool_idle:
    "Instance pools keeping warm VMs on standby (min_idle_instances). Warm pool " +
    "instances are cloud VMs billed continuously, outside Databricks DBUs — so the " +
    "metric is the warm-instance count. Savings land on your cloud bill, not DBUs.",
  delta_sharing_materialization:
    "Delta Sharing shares re-materialized over and over (recompute + cross-region " +
    "egress). Operational: the event table records no cost, so the metric is the " +
    "materialization count, not dollars.",
  storage_optimization_churn:
    "Tables that Predictive Optimization must maintain heavily (compaction / " +
    "clustering / vacuum) — usually a fragmenting write pattern worth fixing at the " +
    "source. Operational: the DBUs shown are PO's own estimate, not booked dollars.",
  warehouse_keepalive_queries:
    "SQL warehouses kept billed by trivial statements (SHOW / USE / SET / cache hits) — " +
    "a BI tool, poller or job pinging often enough that auto-stop never fires. The fix " +
    "is on the client, not the auto-stop setting. The dollar figure is the keep-alive " +
    "hours' cost (addressable), not a booked saving.",
  job_runaway_no_timeout:
    "Jobs without a working timeout whose runs sometimes hang for hours. Only the cost " +
    "of runaway runs above a normal run is counted, so a job that just waits longer " +
    "cheaply shows little. Recommends a timeout from the job's own p95 duration.",
  job_task_retry_waste:
    "Jobs whose runs succeed only after task retries. The failed attempts are billed " +
    "compute that produced nothing — invisible to the failing-jobs rule because the run " +
    "ends SUCCEEDED. Excess over a normal retry rate is counted (addressable).",
  pipeline_full_refresh_churn:
    "Pipelines doing repeated full refreshes where an incremental update would do. The " +
    "figure is each full refresh's cost above the pipeline's median incremental update. " +
    "Some refreshes are deliberate backfills — check before changing the schedule.",
  serving_provisioned_overcapacity:
    "Provisioned-throughput serving endpoints billed through long stretches with no " +
    "logged request. A lower bound: over-capacity during busy hours isn't measurable " +
    "from system tables. Zero-traffic endpoints are left to the idle-endpoint rule.",
  allpurpose_shape_mismatch:
    "All-purpose clusters with the wrong shape: driver-bound (workers idle while the " +
    "driver works → single node) or a memory-optimized family using a fraction of its " +
    "memory. Priced from the DBU rates actually billed in this account per node type.",
  alert_hygiene:
    "SQL alerts that error on every run, notify nobody, or are the only thing keeping a " +
    "warehouse running — a schedule shorter than the warehouse's auto-stop holds it up " +
    "around the clock.",
  unviewed_scheduled_dashboards:
    "AI/BI dashboards whose scheduled refreshes keep running while nobody has opened them " +
    "for 14+ days — priced as their share of the warehouse-hours they query in. Exports, " +
    "email snapshots and API reads aren't audited, so confirm before pausing.",
  warehouse_min_clusters:
    "min_clusters > 1 keeps extra clusters running (and brings them all up on every " +
    "restart) although one cluster covers the load almost all the time. Autoscaling still " +
    "adds clusters on demand.",
  instance_generation_modernize:
    "Classic clusters, jobs and pipelines still on a previous-generation instance family " +
    "(i3, m5d, r5d…), with the like-for-like current or Graviton successor. The figure is " +
    "spend on the old nodes, not a saving.",
  job_no_new_input:
    "Scheduled job runs where no table the job reads was written since its previous run — " +
    "they recompute the same answer. A table-update trigger would skip them. Lineage can't " +
    "see API/JDBC/non-UC inputs, so check before switching.",
  unpruned_repeated_queries:
    "Repeated dashboard, alert and saved-query SELECTs that scan almost every file (no " +
    "pruning → liquid clustering or a materialized view), or an identical query re-run " +
    "many times a day that never hits the result cache. Shows what the query shape costs.",
};

export function Labs() {
  const { data, isLoading, error } = useExperimental();
  const items = data?.items ?? [];

  // Group findings by rule so each experimental opportunity gets its own section.
  const groups = useMemo(() => {
    const by = new Map<string, Recommendation[]>();
    for (const r of items) {
      const arr = by.get(r.rule_id) ?? [];
      arr.push(r);
      by.set(r.rule_id, arr);
    }
    return [...by.entries()].sort(
      (a, b) =>
        b[1].reduce((s, r) => s + r.monthly_waste_usd, 0) -
        a[1].reduce((s, r) => s + r.monthly_waste_usd, 0),
    );
  }, [items]);

  const kpis: Kpi[] = data
    ? [
        {
          label: "Addressable spend / mo",
          value: moneyExact(data.total_addressable_monthly_usd),
          variant: "spend",
          sub: "compute these findings flag as potentially avoidable, each resource's spend counted once",
        },
        {
          label: "Experimental findings",
          value: String(data.recommendation_count),
          sub:
            data.resource_count && data.resource_count !== data.recommendation_count
              ? `on ${data.resource_count} resources · not in the recommendation total`
              : "not counted in the recommendation total",
        },
        {
          label: "Opportunities",
          value: String(data.rule_count),
          sub: "net-new rule types under evaluation",
        },
        {
          label: "Workspaces",
          value: String(data.workspace_count),
          sub: "with an experimental finding",
        },
      ]
    : [];

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>
            Labs <span className="beta-badge">Experimental</span>
          </h1>
          <p className="subtitle">Experimental findings, not counted in savings.</p>
        </div>
      </div>

      {isLoading ? (
        <p className="muted">Loading…</p>
      ) : error ? (
        <p className="error">Failed to load: {String(error)}</p>
      ) : (
        <>
          <KpiHeader kpis={kpis} />
          <details className="about-data">
            <summary>About this data</summary>
            <div className="about-data-body">
              <p>
                These ideas are still being validated. They stay out of the main
                recommendations, the savings headline, and Next Best Actions — the signal
                is measured, but the reclaimable dollars are not modelled yet. Each finding
                shows addressable spend to investigate, not a booked saving.
              </p>
            </div>
          </details>
          {groups.length === 0 && (
            <p className="muted">
              No experimental findings in this scope — nothing to investigate yet.
            </p>
          )}
          {/* Each rule is collapsed to just its headline row by default — the tab
              lists ~7 opportunities and rendering every finding at once buried the
              overview. Click a row to expand its findings + charts. */}
          {groups.map(([ruleId, recs]) => {
            const total = recs.reduce((s, r) => s + r.monthly_waste_usd, 0);
            return (
              <details key={ruleId} className="labs-group card">
                <summary className="labs-group-summary">
                  <ChevronRightIcon className="labs-caret" aria-hidden="true" />
                  <div className="rec-card-title" style={{ flex: 1, minWidth: 0 }}>
                    <div className="rec-rule">{recs[0].rule_title}</div>
                    <div className="muted small">
                      {recs.length} finding{recs.length === 1 ? "" : "s"} ·{" "}
                      {ruleId}
                    </div>
                  </div>
                  {total > 0 ? (
                    <span className="badge badge-spend" title="Total addressable monthly spend">
                      {moneyExact(total)}/mo addressable
                    </span>
                  ) : (
                    <span
                      className="badge"
                      title="Operational finding — the waste is real but not priceable from Databricks DBUs (cloud VMs, tokens, or storage). No dollars are booked or addressed."
                    >
                      operational · {recs.length} finding{recs.length === 1 ? "" : "s"}
                    </span>
                  )}
                </summary>
                <div className="labs-group-body">
                  {RULE_BLURB[ruleId] && (
                    <details className="about-data">
                      <summary>About this rule</summary>
                      <div className="about-data-body">
                        <p>{cleanProse(RULE_BLURB[ruleId])}</p>
                      </div>
                    </details>
                  )}
                  <div className="nba-list">
                    {recs.map((rec) => (
                      <LabsFinding key={rec.recommendation_id} rec={rec} />
                    ))}
                  </div>
                </div>
              </details>
            );
          })}
        </>
      )}
    </div>
  );
}

function LabsFinding({ rec }: { rec: Recommendation }) {
  const viz = rec.evidence?.viz as LabsViz | undefined;
  return (
    <div className="rec-card" style={{ cursor: "default" }}>
      <div className="rec-card-head">
        <div className="rec-card-title">
          <div className="rec-resource">
            <ResourceChip type={rec.resource_type} />
            {rec.resource_name}
            <span className="muted"> · ws {rec.workspace_id}</span>
          </div>
        </div>
        {rec.monthly_waste_usd > 0 ? (
          <span className="badge badge-spend" title="Addressable monthly spend (not a booked saving)">
            {moneyExact(rec.monthly_waste_usd)}/mo
          </span>
        ) : (
          <span className="badge" title="Operational finding: not priceable from Databricks DBUs">
            operational
          </span>
        )}
      </div>
      {viz && <LabsChart viz={viz} />}
      <details className="about-data">
        <summary>Details</summary>
        <div className="about-data-body">
          <p>{cleanProse(rec.why)}</p>
          <p>{cleanProse(rec.how)}</p>
        </div>
      </details>
      <div className="rec-card-foot">
        <PriorityBadge priority={rec.priority} />
      </div>
    </div>
  );
}
