import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { GroupTable } from "../components/GroupTable";
import { Pager } from "../components/Pager";
import { RuleTypeFilter } from "../components/RuleTypeFilter";
import {
  useRecommendationGroups,
  type RecommendationFilters,
} from "../hooks/useRecommendations";
import { useRules } from "../hooks/useWorkspaces";
import { moneyExact } from "../lib/format";
import { savingsValue } from "../lib/price";
import { usePricingContext } from "../lib/PricingContext";

const DEFAULT_PAGE_SIZE = 25;

// Query params let another surface (e.g. the overview's "biggest savings levers")
// deep-link into this list pre-filtered. Read once to seed initial state; the page
// owns the filters after mount so the user can freely refine.
function filtersFromParams(params: URLSearchParams): RecommendationFilters {
  const ruleIds = params.get("rule_ids");
  const sort = params.get("sort");
  return {
    sort: sort === "savings" || sort === "nba" ? sort : "nba",
    rule_ids: ruleIds ? ruleIds.split(",").filter(Boolean) : undefined,
    resource_type: params.get("resource_type") || undefined,
    priority: params.get("priority") || undefined,
  };
}

export function Recommendations() {
  const { basis } = usePricingContext();
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState<RecommendationFilters>(() =>
    filtersFromParams(searchParams),
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const { data, isLoading, error } = useRecommendationGroups(filters);
  const { data: rules } = useRules();
  // The account / cloud / Databricks-account-id filters are GLOBAL now (the account
  // scope bar under the topbar, applied server-side to every surface), so this page
  // only carries the resource/type/priority/sort controls.

  const update = (patch: Partial<RecommendationFilters>) =>
    setFilters((f) => ({ ...f, ...patch }));

  // rule_id -> resource_type, from the live catalog (stays correct as rules are added).
  const typeByRule = useMemo(
    () => new Map((rules ?? []).map((r) => [r.id, r.resource_type])),
    [rules],
  );

  // Picking recommendation type(s) should keep the resource-type dropdown honest:
  // if every selected rule targets one resource type, reflect it; if they span
  // several (or the selection is cleared), fall back to "All resources" so the two
  // controls can never contradict. Driven one-way from the rule filter.
  const onRuleTypesChange = (rule_ids: string[]) => {
    const types = new Set(rule_ids.map((id) => typeByRule.get(id)).filter(Boolean));
    const resource_type = types.size === 1 ? [...types][0] : undefined;
    update({ rule_ids: rule_ids.length ? rule_ids : undefined, resource_type });
  };

  const groups = data ?? [];
  // Each group's headline is the best single option — safe to sum across
  // distinct resources (no double-counting within a resource). Advisory options
  // book $0 in the headline KPI, so they are left out here too; otherwise this
  // total disagreed with the Overview headline for the very same findings.
  const countedSavings = (g: (typeof groups)[number]) =>
    Math.max(
      0,
      ...g.options.filter((o) => o.savings_status !== "advisory").map((o) => savingsValue(o, basis)),
    );
  const totalSavings = groups.reduce((s, g) => s + countedSavings(g), 0);
  const advisoryOnly = groups.filter((g) => countedSavings(g) === 0).length;

  const pageCount = Math.max(1, Math.ceil(groups.length / pageSize));
  // Changing a filter can shrink the list below the current page; snap back so
  // the user never lands on an empty page.
  useEffect(() => {
    setPage(1);
  }, [filters, pageSize]);
  const visible = useMemo(
    () => groups.slice((page - 1) * pageSize, page * pageSize),
    [groups, page, pageSize],
  );

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>All Recommendations</h1>
          <p className="subtitle">One row per resource.</p>
        </div>
      </div>

      <div className="filter-bar">
        <select
          value={filters.resource_type ?? ""}
          onChange={(e) => update({ resource_type: e.target.value || undefined })}
        >
          <option value="">All resources</option>
          <option value="cluster">Clusters</option>
          <option value="warehouse">Warehouses</option>
          <option value="job">Jobs</option>
          <option value="serving_endpoint">Serving endpoints</option>
        </select>
        <RuleTypeFilter selected={filters.rule_ids ?? []} onChange={onRuleTypesChange} />
        <select
          value={filters.priority ?? ""}
          onChange={(e) => update({ priority: e.target.value || undefined })}
        >
          <option value="">Any priority</option>
          <option value="HIGH">High</option>
          <option value="MEDIUM">Medium</option>
          <option value="LOW">Low</option>
        </select>
        <select
          value={filters.sort}
          onChange={(e) => update({ sort: e.target.value as RecommendationFilters["sort"] })}
        >
          <option value="nba">Sort: Next Best Action</option>
          <option value="savings">Sort: Savings</option>
        </select>
        <span className="filter-spacer" />
        {!isLoading && !error && (
          <span className="result-count">
            {(filters.rule_ids?.length ?? 0) > 1 && (
              <span className="filter-hint" title="Resources must match every selected type">
                all {filters.rule_ids!.length} types ·{" "}
              </span>
            )}
            <span className="strong">{groups.length}</span> resources ·{" "}
            <span className="savings-text">{moneyExact(totalSavings)}/mo</span>
            {advisoryOnly > 0 && (
              <span
                className="faint"
                title="Advisory findings are real issues whose dollar figure is not trusted enough to count toward any total."
              >
                {" "}
                · {advisoryOnly} advisory-only, not counted
              </span>
            )}
          </span>
        )}
      </div>

      {isLoading ? (
        <p className="muted">Loading…</p>
      ) : error ? (
        <p className="error">Failed to load: {String(error)}</p>
      ) : (
        <>
          <GroupTable groups={visible} />
          <Pager
            page={page}
            pageCount={pageCount}
            pageSize={pageSize}
            total={groups.length}
            onPage={setPage}
            onPageSize={setPageSize}
          />
        </>
      )}
    </div>
  );
}
