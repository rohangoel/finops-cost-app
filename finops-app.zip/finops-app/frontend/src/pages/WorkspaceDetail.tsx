import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { Link, useParams } from "react-router-dom";
import { Donut } from "../components/charts/Donut";
import { MixBar } from "../components/charts/MixBar";
import { KpiHeader, savingsKpis, withPriceBasis } from "../components/KpiHeader";
import { GeniePanel } from "../components/GeniePanel";
import { GroupTable } from "../components/GroupTable";
import { useRecommendationGroups, useRecommendations } from "../hooks/useRecommendations";
import { useSpend } from "../hooks/useSpend";
import { useWorkspaceDetail } from "../hooks/useWorkspaces";
import { CATEGORY_COLOR, collapseToResources, savingsByEffort } from "../lib/breakdown";
import type { Slice } from "../lib/breakdown";
import { usePricingContext } from "../lib/PricingContext";

export function WorkspaceDetail() {
  const { workspaceId = "" } = useParams();
  const detail = useWorkspaceDetail(workspaceId);
  // recs (flat) drives the by-effort mix chart; groups drive the harmonized table.
  const recs = useRecommendations({ workspace_id: workspaceId, sort: "nba" });
  const groups = useRecommendationGroups({ workspace_id: workspaceId, sort: "nba" });
  const { data: spend } = useSpend();
  const wsSpend = spend?.workspaces.find((w) => w.workspace_id === workspaceId);
  const { basis } = usePricingContext();

  if (detail.isLoading) return <p className="muted">Loading workspace…</p>;
  if (detail.error) return <p className="error">Failed to load: {String(detail.error)}</p>;
  const d = detail.data;
  if (!d) return null;

  const wsName = d.workspace_name ?? `workspace ${d.workspace_id}`;

  const categorySlices: Slice[] = d.by_category.map((c) => ({
    key: c.category,
    label: c.category,
    value: Math.round(c.monthly_savings_usd),
    count: c.recommendation_count,
    color: CATEGORY_COLOR[c.category] ?? "var(--info)",
  }));

  return (
    <div>
      <Link to="/" className="back-link">
        <ArrowLeftIcon className="icon" /> Account overview
      </Link>
      <h1>{d.workspace_name ?? `Workspace ${d.workspace_id}`}</h1>
      <p className="subtitle">Workspace-level cost-saving opportunities.</p>

      <KpiHeader
        kpis={withPriceBasis(savingsKpis(
          d.monthly_savings_usd,
          d.monthly_savings_addressable_usd,
          d.recommendation_count,
          undefined,
          wsSpend?.monthly_spend_usd,
          undefined,
          {
            addressable: d.monthly_savings_addressable_usd,
            low: d.monthly_savings_low_usd,
            high: d.monthly_savings_high_usd,
            tiers: d.savings_tiers,
          },
        ), {
          basis,
          priced: d.priced,
          spend: wsSpend
            ? {
                total_monthly_spend_contract_usd: wsSpend.monthly_spend_contract_usd,
                contract_priced_share: wsSpend.contract_priced_share,
                total_monthly_cloud_cost_usd: wsSpend.monthly_cloud_cost_usd,
              }
            : null,
        })}
      />

      <div className="grid-2" style={{ marginTop: 20 }}>
        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">Savings by category</span>
          </div>
          <div style={{ marginTop: 14 }}>
            <Donut slices={categorySlices} centerLabel="savings / mo" />
          </div>
        </div>
        <div className="card card-pad">
          <div className="card-head">
            <span className="card-title">By effort to fix</span>
          </div>
          <div style={{ marginTop: 20 }}>
            <MixBar slices={savingsByEffort(collapseToResources(recs.data ?? []), basis)} />
          </div>
        </div>
      </div>

      <h2>Recommendations</h2>
      {groups.isLoading ? (
        <p className="muted">Loading…</p>
      ) : (
        <GroupTable groups={groups.data ?? []} showWorkspace={false} />
      )}

      <GeniePanel
        subtitle={`Ask about ${wsName}'s spend, resources and savings.`}
        context={{ workspace_id: d.workspace_id, workspace_name: d.workspace_name }}
        samples={[
          `What are the biggest savings opportunities in ${wsName}?`,
          `What is ${wsName}'s total spend and its top SKUs?`,
          `Which resources in ${wsName} are idle or oversized?`,
          `How much could ${wsName} save by moving eligible warehouses to serverless?`,
        ]}
      />
    </div>
  );
}
