import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import type { Recommendation, Vote } from "../api/types";
import { EffortBadge } from "../components/EffortBadge";
import { ResourceChip } from "../components/ResourceChip";
import { useConfig } from "../hooks/useConfig";
import {
  useEmailPreference,
  useMyFindings,
  useMyVotes,
  useSetWeeklyEmail,
} from "../hooks/useFeedback";
import { groupMyFindings, voteSummary } from "../lib/feedback";
import { moneyExact } from "../lib/format";

/** My findings: every finding routed to the signed-in user, for anyone who can open
 *  the app, admin or not.
 *
 *  A finding is yours when you own the resource, or when a service principal (or
 *  nobody) owns it and you own the workspace (billing Owner tag); see the backend's
 *  finops/routing.py. The two are listed separately so it's clear why each is here.
 *  Advisory findings are included: the StopTheLeak weekly email leaves them out, so
 *  this is where they show up. The `#email` anchor (the email footer's link) scrolls
 *  to the opt-out. */
export function MyFindings() {
  const { data, isLoading, error } = useMyFindings();
  const { data: config } = useConfig();
  const feedbackOn = !!(config?.feedback_enabled && data?.feedback_enabled);
  const { data: votes } = useMyVotes(feedbackOn);
  const location = useLocation();

  // The setting renders only once both /api/my-findings and /api/config are in, so
  // wait for both before scrolling to it.
  const emailShown = feedbackOn && !!data?.email;
  useEffect(() => {
    if (location.hash === "#email" && emailShown) {
      document.getElementById("email")?.scrollIntoView({ block: "start" });
    }
  }, [location.hash, emailShown]);

  if (isLoading) return <p className="muted">Loading…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  const { owned, viaWorkspace } = groupMyFindings(data.findings);
  const total = data.findings.length;

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>My findings</h1>
          <p className="subtitle">
            {data.email ? (
              <>
                Findings on resources you own, and on resources in workspaces you own. Signed in
                as <span className="strong">{data.email}</span>.
              </>
            ) : (
              "We couldn't tell who you are, so there is nothing to show."
            )}
          </p>
        </div>
      </div>

      {data.email && total === 0 && (
        <div className="card empty">Nothing is routed to you right now.</div>
      )}

      {owned.length > 0 && (
        <FindingSection
          title="Resources you own"
          hint="You're the owner of these resources."
          findings={owned}
          votes={votes}
        />
      )}
      {viaWorkspace.length > 0 && (
        <FindingSection
          title="In workspaces you own"
          hint="A service principal (or nobody) owns these resources. As the workspace owner you can change them."
          findings={viaWorkspace}
          votes={votes}
        />
      )}

      {emailShown && <EmailSetting />}
    </div>
  );
}

function FindingSection({
  title,
  hint,
  findings,
  votes,
}: {
  title: string;
  hint: string;
  findings: Recommendation[];
  votes?: Record<string, Vote>;
}) {
  return (
    <section>
      <h2 className="section-head">
        {title} <span className="muted">({findings.length})</span>
      </h2>
      <p className="muted small my-hint">{hint}</p>
      <div className="card table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Resource</th>
              <th>Finding</th>
              <th>Workspace</th>
              <th className="num">Saves / month</th>
              <th>Effort</th>
            </tr>
          </thead>
          <tbody>
            {findings.map((f) => {
              const vote = votes?.[f.finding_key];
              return (
                <tr key={f.finding_key}>
                  <td>
                    <div className="cell-primary">
                      <ResourceChip type={f.resource_type} />{" "}
                      <Link to={`/resources/${f.group_id}?focus=${f.finding_key}`}>
                        {f.resource_name || f.resource_id}
                      </Link>
                    </div>
                  </td>
                  <td>
                    <div>{f.rule_title}</div>
                    {vote && (
                      <div className="cell-sub">
                        <span className="feedback-said-label">You said:</span> {voteSummary(vote)}
                      </div>
                    )}
                  </td>
                  <td className="muted">{f.workspace_name ?? f.workspace_id}</td>
                  <td className="num">
                    {f.savings_status === "advisory" ? (
                      <span className="muted small">Worth a look, no $ estimate booked</span>
                    ) : (
                      <span className="savings-text">{moneyExact(f.monthly_savings_usd)}</span>
                    )}
                  </td>
                  <td>
                    <EffortBadge band={f.effort_band} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function EmailSetting() {
  const { data: pref, isLoading } = useEmailPreference(true);
  const set = useSetWeeklyEmail();
  const on = pref?.weekly_email ?? true;
  return (
    <section id="email" className="card card-pad my-email">
      <h2 className="section-head my-email-head">Weekly email</h2>
      <p className="muted small">
        StopTheLeak emails you once a week about the findings above that carry a saving.
      </p>
      {isLoading ? (
        <p className="muted small">Loading…</p>
      ) : (
        <p>
          {on ? "You get the weekly email." : "You've stopped the weekly email."}{" "}
          <button
            type="button"
            className={on ? "btn-secondary" : "btn-primary"}
            disabled={set.isPending}
            onClick={() => set.mutate(!on)}
          >
            {on ? "Stop the weekly StopTheLeak email" : "Send it again"}
          </button>
        </p>
      )}
      {set.error && <p className="error small">Couldn't save: {String(set.error.message)}</p>}
    </section>
  );
}
