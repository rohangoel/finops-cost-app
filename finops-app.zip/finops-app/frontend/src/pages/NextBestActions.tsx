import { RecommendationCard } from "../components/RecommendationCard";
import { SavingsLegend } from "../components/SavingsRange";
import { useNextBestActions } from "../hooks/useNextBestActions";

export function NextBestActions() {
  const { data, isLoading, error } = useNextBestActions(15);

  if (isLoading) return <p className="muted">Ranking best actions…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;

  return (
    <div>
      <h1>Next Best Actions</h1>
      <p className="subtitle">
        The {data?.length ?? 15} changes with the most savings per unit of effort, across every
        workspace in scope. Open one for the evidence and the exact steps.
      </p>
      <SavingsLegend />
      <div className="nba-list">
        {(data ?? []).map((rec, i) => (
          <RecommendationCard key={rec.recommendation_id} rec={rec} rank={i + 1} />
        ))}
        {data && data.length === 0 && <p className="muted">No recommendations found.</p>}
      </div>
    </div>
  );
}
