import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import type { AppInfo, AppSizeGroup } from "../api/types";
import { AppsTrend } from "../components/charts/AppsTrend";
import { Pager } from "../components/Pager";
import { useAppsInventory } from "../hooks/useAppsInventory";
import { useWorkspaces } from "../hooks/useWorkspaces";
import { useWorkspaceScope } from "../hooks/useWorkspaceScope";
import { money, moneyExact } from "../lib/format";

const DEFAULT_PAGE_SIZE = 25;

/** "Apps" — the Databricks Apps inventory.
 *
 *  Visibility WITHOUT recommendations, and the absence is the point worth
 *  understanding: system tables carry no app request or page-view log (only lifecycle
 *  events), so whether anyone actually uses an app is unknowable, and an "idle app"
 *  or "rightsize this app" verdict would be a guess. Rather than omit the surface or
 *  fabricate advice, the tab shows what exists, what it costs and how it is
 *  configured, states the limitation explicitly, and lets a human make the call.
 *
 *  Everything here is therefore neutral by construction: no savings column, no
 *  priority pill, no NBA score. `days_billed` is labelled as a lifecycle fact
 *  ("always on") because apps have no scale-to-zero — a full-window count is normal,
 *  not a problem. */
export function Apps() {
  // The workspace to scope to: the deep-link path param if present, else the global
  // switcher scope ("" = platform/all workspaces), so the fetch and header agree.
  const { workspaceId: pathWorkspaceId } = useParams();
  const [scope] = useWorkspaceScope();
  const workspaceId = pathWorkspaceId || scope || undefined;
  const { data, isLoading, error } = useAppsInventory(workspaceId);
  const { data: workspaces = [] } = useWorkspaces();
  const workspaceName = workspaceId
    ? (workspaces.find((w) => w.workspace_id === workspaceId)?.workspace_name ??
       `Workspace ${workspaceId}`)
    : undefined;

  const [sizeFilter, setSizeFilter] = useState<string>("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  const allApps = data?.apps ?? [];
  const apps = useMemo(
    () => (sizeFilter ? allApps.filter((a) => a.compute_size === sizeFilter) : allApps),
    [allApps, sizeFilter],
  );
  const pageCount = Math.max(1, Math.ceil(apps.length / pageSize));
  useEffect(() => {
    setPage(1);
  }, [sizeFilter, pageSize]);
  const visible = useMemo(
    () => apps.slice((page - 1) * pageSize, page * pageSize),
    [apps, page, pageSize],
  );

  if (isLoading) return <p className="muted">Loading apps inventory…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!data) return null;

  if (data.unavailable) {
    return (
      <div>
        <Head lookback={data.lookback_days} workspaceName={workspaceName} />
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            Apps usage data could not be read. This needs <code>SELECT</code> on{" "}
            <code>system.billing.usage</code> and <code>system.billing.list_prices</code>
            {" "}(or an apps snapshot written by the precompute pipeline). No figures are
            shown rather than a misleading $0.
          </p>
        </div>
      </div>
    );
  }

  if (data.no_usage) {
    return (
      <div>
        <Head lookback={data.lookback_days} workspaceName={workspaceName} />
        <div className="card card-pad">
          <p className="muted" style={{ margin: 0 }}>
            No Databricks Apps billed in the last {data.lookback_days} days. Nothing to
            report — this is a genuine zero, not missing data.
          </p>
        </div>
      </div>
    );
  }

  const largest = data.by_size[0];

  return (
    <div>
      <Head lookback={data.lookback_days} workspaceName={workspaceName} />

      {data.missing_sections.length > 0 && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <p className="muted small" style={{ margin: 0 }}>
            <strong>Partial data.</strong> These aggregates could not be read this
            time: {data.missing_sections.join(", ")}. The sections below that depend on
            them are empty for that reason, not because there is nothing to show. The
            per-app table joins the audit log and is the slowest, so in live mode it is
            the one most likely to miss its time budget — the precomputed snapshot has
            the full picture.
          </p>
        </div>
      )}

      {data.lifecycle_note && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <p className="muted small" style={{ margin: 0 }}>
            <strong>Lifecycle unavailable on central data.</strong> {data.lifecycle_note}
          </p>
        </div>
      )}

      <div className="kpi-row">
        <div className="kpi kpi-spend">
          <div className="kpi-head">
            <span className="kpi-label">Apps spend / mo</span>
          </div>
          <div className="kpi-value">{moneyExact(data.monthly_spend_usd)}</div>
          <div className="kpi-sub">
            {Math.round(data.total_dbus).toLocaleString()} DBUs over{" "}
            {data.lookback_days} days
          </div>
        </div>
        <div className="kpi kpi-accent">
          <div className="kpi-head">
            <span className="kpi-label">Apps running</span>
          </div>
          <div className="kpi-value">{data.app_count}</div>
          <div className="kpi-sub">
            across {data.workspace_count} workspace
            {data.workspace_count === 1 ? "" : "s"}
          </div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Always on</span>
          </div>
          <div className="kpi-value">{data.always_on_count}</div>
          {/* Stated as a fact, NOT as a problem: apps have no scale-to-zero, so
              billing every day is the expected behaviour for a running app. */}
          <div className="kpi-sub">billed every day</div>
        </div>
        <div className="kpi">
          <div className="kpi-head">
            <span className="kpi-label">Most common size</span>
          </div>
          <div className="kpi-value">{largest?.compute_size ?? "—"}</div>
          <div className="kpi-sub">
            {largest ? `${largest.apps} apps · ${money(largest.monthly_spend_usd)}/mo` : ""}
          </div>
        </div>
      </div>

      <details className="about-data">
        <summary>About this data</summary>
        <div className="about-data-body">
          <p>
            Reported here only — apps never enter the recommendations or savings totals.
          </p>
          <p>{data.analysis_note}</p>
          <p>
            A full-window &quot;always on&quot; count is normal: apps have no scale-to-zero, so a
            running app bills every day.
          </p>
          <p>
            <strong>Data basis:</strong> {data.data_basis}
          </p>
        </div>
      </details>

      <div className="card card-pad" style={{ marginTop: 16 }}>
        <div className="card-head">
          <span className="card-title">Apps cost &amp; count</span>
          <span className="card-hint">
            daily, last {data.lookback_days} days
          </span>
        </div>
        <AppsTrend days={data.daily} />
      </div>

      <div className="card card-pad" style={{ marginTop: 16 }}>
        <div className="card-head">
          <span className="card-title">How the estate is configured</span>
          <span className="card-hint">by compute size · click to filter</span>
        </div>
        <SizeBars
          groups={data.by_size}
          active={sizeFilter}
          onPick={(s) => setSizeFilter((cur) => (cur === s ? "" : s))}
        />
      </div>

      <h2>
        Apps
        {sizeFilter && (
          <>
            {" "}
            <span className="faint" style={{ fontWeight: 400, fontSize: 14 }}>
              · {sizeFilter} only ·{" "}
              <button className="btn-link" onClick={() => setSizeFilter("")}>
                clear
              </button>
            </span>
          </>
        )}
      </h2>
      <div className="table-wrap">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>App</th>
                {!workspaceId && <th>Workspace</th>}
                <th>Size</th>
                <th className="num">Cost / mo</th>
                <th className="num">DBUs</th>
                <th className="num">Days billed</th>
                <th>Last deploy</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((a) => (
                <AppRow
                  key={a.app_id}
                  app={a}
                  lookback={data.lookback_days}
                  showWorkspace={!workspaceId}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Pager
        page={page}
        pageCount={pageCount}
        pageSize={pageSize}
        total={apps.length}
        onPage={setPage}
        onPageSize={setPageSize}
      />

    </div>
  );
}

function Head({ lookback, workspaceName }: { lookback: number; workspaceName?: string }) {
  return (
    <div className="page-head">
      <div>
        <h1>Apps</h1>
        <p className="subtitle">
          Cost and size{" "}
          {workspaceName ? (
            <>
              in <strong>{workspaceName}</strong>
            </>
          ) : (
            "across the account"
          )}
          , last {lookback} days.
        </p>
      </div>
    </div>
  );
}

/** One app. Deliberately shows configuration and cost side by side — that pairing is
 *  the whole point of the tab, since it is what a human needs to judge sizing. */
function AppRow({
  app,
  lookback,
  showWorkspace,
}: {
  app: AppInfo;
  lookback: number;
  showWorkspace: boolean;
}) {
  const alwaysOn = app.days_billed >= lookback;
  const href =
    app.workspace_url && app.app_name
      ? `${app.workspace_url}/apps/${app.app_name}`
      : undefined;
  return (
    <tr>
      <td className="strong">
        {href ? (
          <a href={href} target="_blank" rel="noreferrer">
            {app.app_name ?? app.app_id}
          </a>
        ) : (
          (app.app_name ?? app.app_id)
        )}
        {app.size_changes > 1 && (
          <span className="faint small" title="Resized during this window — the cost below spans more than one configuration">
            {" "}· resized
          </span>
        )}
      </td>
      {showWorkspace && (
        <td className="muted">{app.workspace_name ?? app.workspace_id ?? "—"}</td>
      )}
      <td>
        <span className="role-pill">{app.compute_size ?? "unknown"}</span>
      </td>
      <td className="num strong">{moneyExact(app.monthly_spend_usd)}</td>
      <td className="num">{Math.round(app.dbus).toLocaleString()}</td>
      <td className="num">
        {app.days_billed}
        {alwaysOn ? (
          <span className="faint small" title="Billed on every day of the window. Normal for a running app — apps have no scale-to-zero.">
            {" "}· always on
          </span>
        ) : null}
      </td>
      <td className="muted">
        {app.last_deploy_time ? (
          <>
            {app.last_deploy_time.slice(0, 10)}
            {app.last_deployed_by && (
              <span className="faint small"> · {app.last_deployed_by}</span>
            )}
          </>
        ) : (
          // Absence means "not deployed inside this window", not "abandoned" — most
          // apps have no lifecycle event in a given 30 days.
          <span className="faint" title="No deploy recorded inside this window">
            —
          </span>
        )}
      </td>
    </tr>
  );
}

/** Compute-size mix as a ranked bar list, with the app count alongside — the point
 *  being that the cheapest size usually holds the most apps, so the cost story and
 *  the count story disagree. */
function SizeBars({
  groups,
  active,
  onPick,
}: {
  groups: AppSizeGroup[];
  active: string;
  onPick: (size: string) => void;
}) {
  if (groups.length === 0) {
    return <p className="muted small">No size information in this window.</p>;
  }
  const max = Math.max(1, ...groups.map((g) => g.monthly_spend_usd));
  const total = groups.reduce((s, g) => s + g.monthly_spend_usd, 0);
  return (
    <div className="barlist" style={{ marginTop: 8 }}>
      {groups.map((g) => (
        <div
          className="barlist-row"
          key={g.compute_size}
          onClick={() => onPick(g.compute_size)}
          style={{
            cursor: "pointer",
            opacity: active && active !== g.compute_size ? 0.45 : 1,
          }}
        >
          <span className="barlist-name">
            {g.compute_size}
            <span className="faint"> · {g.apps} apps</span>
          </span>
          <span className="barlist-val">{money(g.monthly_spend_usd)}</span>
          <div className="barlist-track">
            <div
              className="barlist-fill"
              style={{ width: `${Math.max(2, (g.monthly_spend_usd / max) * 100)}%` }}
              title={`${g.apps} apps · ${Math.round(
                (g.monthly_spend_usd / (total || 1)) * 100,
              )}% of apps spend`}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
