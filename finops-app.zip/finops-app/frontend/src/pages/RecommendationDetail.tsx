import { Navigate, useParams } from "react-router-dom";
import { useRecommendation } from "../hooks/useRecommendations";

/** Single-recommendation deep link.
 *
 *  A resource usually matches SEVERAL rules at once (an oversized cluster can
 *  often be downsized *and* moved to serverless), and showing one finding in
 *  isolation hides the alternatives — the user acts on a partial picture. So this
 *  route resolves the finding to its resource and hands off to the grouped
 *  resource detail, which lists every applicable recommendation in sequence,
 *  highest saving first. Existing links (and bookmarks) keep working. */
export function RecommendationDetail() {
  const { id = "" } = useParams();
  const { data: rec, isLoading, error } = useRecommendation(id);

  if (isLoading) return <p className="muted">Loading…</p>;
  if (error) return <p className="error">Failed to load: {String(error)}</p>;
  if (!rec) return null;

  // `focus` tells the resource page which finding was asked for, so it opens that
  // option expanded even when it is not the top-savings one.
  return (
    <Navigate to={`/resources/${rec.group_id}?focus=${rec.recommendation_id}`} replace />
  );
}
