import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { KpiHeader, type Kpi } from "../components/KpiHeader";
import { Pager } from "../components/Pager";
import { PriorityBadge } from "../components/PriorityScore";
import { ResourceChip } from "../components/ResourceChip";
import { useTagging } from "../hooks/useTagging";
import { moneyExact } from "../lib/format";

const DEFAULT_PAGE_SIZE = 25;

// The Tagging & Chargeback tab. Governance findings (untagged_spend) live only
// here — they don't count toward the recommendation total, don't appear as an
// option on an optimizable resource, and don't enter the Next Best Actions
// ranking. Their headline metric is UNATTRIBUTABLE spend (money that can't be
// charged back to an owner/cost-centre), not savings: tagging changes attribution,
// not the bill, so these carry $0 savings by design.
export function Tagging() {
  const { data, isLoading, error } = useTagging();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  const items = data?.items ?? [];
  const pageCount = Math.max(1, Math.ceil(items.length / pageSize));
  useEffect(() => {
    setPage(1);
  }, [pageSize, data]);
  const visible = useMemo(
    () => items.slice((page - 1) * pageSize, page * pageSize),
    [items, page, pageSize],
  );

  const kpis: Kpi[] = data
    ? [
        {
          label: "Unattributable spend / mo",
          value: moneyExact(data.total_unattributable_monthly_usd),
          variant: "spend",
          sub: "billed usage with no owner / cost-centre tag",
        },
        {
          label: "Untagged resources",
          value: String(data.recommendation_count),
          sub: "not counted in the recommendation total",
        },
        {
          label: "Workspaces",
          value: String(data.workspace_count),
          sub: "with untagged spend",
        },
      ]
    : [];

  return (
    <div>
      <div className="page-head">
        <div>
          <h1>Tagging &amp; Chargeback</h1>
          <p className="subtitle">Spend missing an owner or cost-centre tag.</p>
        </div>
      </div>

      {isLoading ? (
        <p className="muted">Loading…</p>
      ) : error ? (
        <p className="error">Failed to load: {String(error)}</p>
      ) : (
        <>
          <KpiHeader kpis={kpis} />
          <details className="about-data">
            <summary>About this data</summary>
            <div className="about-data-body">
              <p>
                These findings carry no dollar savings — tagging changes who the bill goes
                to, not the size of it — so they are kept out of the savings recommendations.
              </p>
            </div>
          </details>
          <div className="nba-list">
            {visible.map((rec) => {
              const missing = (rec.evidence?.missing_tags as string[] | undefined) ?? [];
              return (
                <Link
                  key={rec.recommendation_id}
                  to={`/recommendations/${rec.recommendation_id}`}
                  className="rec-card"
                >
                  <div className="rec-card-head">
                    <div className="rec-card-title">
                      <div className="rec-rule">{rec.rule_title}</div>
                      <div className="rec-resource">
                        <ResourceChip type={rec.resource_type} />
                        {rec.resource_name}
                        <span className="muted"> · ws {rec.workspace_id}</span>
                      </div>
                    </div>
                    <span className="badge badge-spend" title="Unattributable monthly spend">
                      {moneyExact(rec.monthly_waste_usd)}/mo
                    </span>
                  </div>
                  <div className="rec-card-foot">
                    {missing.length > 0 && (
                      <span className="muted">
                        Missing: {missing.join(", ")}
                      </span>
                    )}
                    <span className="filter-spacer" />
                    <PriorityBadge priority={rec.priority} />
                  </div>
                </Link>
              );
            })}
            {items.length === 0 && (
              <p className="muted">No untagged spend found — everything is attributed.</p>
            )}
          </div>
          {items.length > pageSize && (
            <Pager
              page={page}
              pageCount={pageCount}
              pageSize={pageSize}
              total={items.length}
              onPage={setPage}
              onPageSize={setPageSize}
            />
          )}
        </>
      )}
    </div>
  );
}
