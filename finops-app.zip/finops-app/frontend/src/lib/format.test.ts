import { describe, it, expect } from "vitest";
import { compactNumber } from "./format";

describe("compactNumber", () => {
  it("leaves values under 1000 as plain rounded integers", () => {
    expect(compactNumber(0)).toBe("0");
    expect(compactNumber(7)).toBe("7");
    expect(compactNumber(804)).toBe("804");
    expect(compactNumber(999)).toBe("999");
  });

  it("rounds sub-1000 values to the nearest integer", () => {
    expect(compactNumber(612.4)).toBe("612");
    expect(compactNumber(612.6)).toBe("613");
  });

  it("uses k for thousands and trims a trailing .0 (so a round tick reads 1k, not 1.0k)", () => {
    expect(compactNumber(1000)).toBe("1k");
    expect(compactNumber(2000)).toBe("2k");
    expect(compactNumber(80000)).toBe("80k");
    expect(compactNumber(1200)).toBe("1.2k");
  });

  it("uses M for millions", () => {
    expect(compactNumber(1_000_000)).toBe("1M");
    expect(compactNumber(3_000_000)).toBe("3M");
    expect(compactNumber(1_200_000)).toBe("1.2M");
  });
});
