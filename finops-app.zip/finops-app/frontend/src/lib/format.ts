export function money(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `$${(value / 1_000).toFixed(1)}k`;
  return `$${value.toFixed(0)}`;
}

export function moneyExact(value: number): string {
  return value.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 });
}

/** Compact, unit-less number for y-axis tick labels: "804", "1.2k", "3M".
 *  Trailing ".0" is trimmed so a round tick reads "1k", not "1.0k". Prefix "$"
 *  at the call site for a money axis. */
export function compactNumber(value: number): string {
  const abs = Math.abs(value);
  const trim = (n: number) => n.toFixed(1).replace(/\.0$/, "");
  if (abs >= 1_000_000) return `${trim(value / 1_000_000)}M`;
  if (abs >= 1_000) return `${trim(value / 1_000)}k`;
  return `${Math.round(value)}`;
}

export const EFFORT_LABEL: Record<string, string> = {
  trivial: "Trivial",
  low: "Low",
  medium: "Medium",
  high: "High",
};

/** "2h ago" / "3d ago" for a timestamp, or "" when it can't be parsed.
 *
 *  Used by the data-health banner: how STALE the precompute run is matters more
 *  than its exact clock time, and an absolute UTC timestamp makes the reader do
 *  the subtraction themselves. Returns "" rather than "Invalid Date" so a
 *  malformed value degrades to silence.
 *
 *  Note the event log stores UTC; `Date.parse` handles the trailing Z, but a
 *  timestamp with no zone would be read as local — so we only trust ISO strings. */
export function relativeTime(iso: string): string {
  const then = Date.parse(iso.endsWith("Z") || /[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`);
  if (Number.isNaN(then)) return "";
  const mins = Math.round((Date.now() - then) / 60000);
  if (mins < 0) return "just now"; // clock skew; never render a negative age
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 48) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}
