import { describe, expect, it } from "vitest";
import type { Recommendation } from "../api/types";
import { estimateExplainer } from "./explain";

const rec = (
  rule_id: string,
  evidence: Record<string, unknown>,
  extra: Partial<Recommendation> = {},
) =>
  ({
    rule_id,
    evidence,
    savings_status: "estimated",
    monthly_waste_usd: 3000,
    monthly_savings_usd: 1000,
    monthly_savings_high_usd: 1000,
    ...extra,
  }) as unknown as Recommendation;

describe("estimateExplainer", () => {
  it("states the measured hours and the hourly rate for auto-termination", () => {
    const text = estimateExplainer(
      rec("cluster_autotermination", {
        running_hours: 600,
        reclaimable_hours: 300,
        proposed_auto_termination_minutes: 60,
      }),
    );
    expect(text).toContain("600h");
    expect(text).toContain("300h");
    expect(text).toContain("60 min");
    expect(text).toContain("$5.00/hour"); // 3000 / 600
  });

  it("falls back to a number-free sentence on an older snapshot", () => {
    const text = estimateExplainer(rec("cluster_autotermination", {}));
    expect(text).toContain("the proposed timeout");
    expect(text).not.toContain("undefined");
    expect(text).not.toContain("NaN");
  });

  it("explains $0 for a stopped zombie cluster", () => {
    const text = estimateExplainer(rec("idle_zombie_clusters", {}, { savings_status: "advisory" }));
    expect(text).toContain("$0");
  });

  it("projects the right-size peak onto the target workers", () => {
    const text = estimateExplainer(
      rec("rightsize_underutilized", {
        worker_count: 8,
        target_workers: 4,
        viz: { kind: "cpu_area", p95: 0.21 },
      }),
    );
    expect(text).toContain("8 workers");
    expect(text).toContain("21%");
    expect(text).toContain("4 workers");
  });

  it("gives every rule, known or not, a non-empty explanation", () => {
    for (const id of [
      "warehouse_autostop",
      "warehouse_autostop_serverless",
      "enable_serverless",
      "warehouse_rightsize",
      "warehouse_scale_out",
      "spot_fallback",
      "interactive_to_job",
      "serverless_cost_optimized",
      "continuous_pipeline",
      "failing_jobs",
      "unused_data_jobs",
      "idle_serving_endpoints",
      "idle_apps",
      "jobs_compute_rightsize",
      "gpu_wrong_runtime",
      "cluster_job_contention",
      "untagged_spend",
      "warehouse_keepalive_queries",
      "warehouse_min_clusters",
      "alert_hygiene",
      "job_no_new_input",
      "job_task_retry_waste",
      "serving_provisioned_overcapacity",
      "unpruned_repeated_queries",
      "unviewed_scheduled_dashboards",
      "pipeline_failed_updates",
      "sql_repeated_failures",
      "instance_pool_idle",
      "job_runaway_no_timeout",
      "pipeline_full_refresh_churn",
      "allpurpose_shape_mismatch",
      "instance_generation_modernize",
      "some_future_rule",
    ]) {
      const text = estimateExplainer(rec(id, {}));
      expect(text.length).toBeGreaterThan(40);
      expect(text).not.toMatch(/undefined|NaN/);
    }
  });

  // Rules promoted out of Labs used to fall through to the generic default, whose
  // advisory branch ("can't be reliably priced") was wrong for them: their dollars
  // ARE priced, they just aren't what a fix saves.
  it("says why a priced advisory rule still counts nothing", () => {
    for (const id of ["pipeline_failed_updates", "sql_repeated_failures", "unpruned_repeated_queries",
                      "unviewed_scheduled_dashboards"]) {
      const text = estimateExplainer(rec(id, {}, { savings_status: "advisory" }));
      expect(text).not.toContain("can't be reliably priced");
      expect(text).toMatch(/[Nn]othing is counted/);
    }
  });

  it("states the floor-only cluster-hours and the measured rate for min_clusters", () => {
    const text = estimateExplainer(
      rec("warehouse_min_clusters", {
        excess_cluster_hours: 700,
        actual_cluster_hours: 1440,
        min_clusters: 2,
        usd_per_cluster_hour: 8.4,
      }),
    );
    expect(text).toContain("700h of 1,440h");
    expect(text).toContain("min_clusters is 2");
    expect(text).toContain("$8.40/hour");
  });

  it("separates the warm-warehouse alert from the $0 hygiene-only one", () => {
    const warm = estimateExplainer(rec("alert_hygiene", { warm_hours: 300, history_days: 14 }));
    expect(warm).toContain("300h in 14 days");
    const hygiene = estimateExplainer(rec("alert_hygiene", {}, { savings_status: "advisory" }));
    expect(hygiene).toContain("no dollar figure is counted");
  });

  it("explains the lineage blind spot when no_new_input is advisory", () => {
    const est = estimateExplainer(rec("job_no_new_input", { no_new_input_share_pct: 83.3 }));
    expect(est).toContain("83%");
    const adv = estimateExplainer(rec("job_no_new_input", {}, { savings_status: "advisory" }));
    expect(adv).toContain("outside Databricks");
  });

  it("uses the keep-alive hours and the auto-stop tail", () => {
    const text = estimateExplainer(
      rec("warehouse_keepalive_queries", { keepalive_hours: 297, billed_hours: 336, auto_stop_minutes: 10 }),
    );
    expect(text).toContain("297h of 336h");
    expect(text).toContain("10 min tail");
  });
});
