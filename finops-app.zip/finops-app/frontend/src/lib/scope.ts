// Global workspace scope — the single "which workspace am I looking at" selection
// that every page shares.
//
// It lives in localStorage (not the URL or React state alone) for two reasons the
// URL can't cover: it applies to EVERY tab of the app from one pick, and it
// survives — and stays in sync — across separate browser windows/tabs of the same
// app, because a write in one window fires a `storage` event the others listen for.
//
// `""` (or absence) means "all workspaces in my access" — the platform view. Any
// other value is a workspace id; the server still enforces access (see
// deps.get_view_scope + Scope.narrowed_to), so this is a view preference, never a
// grant.

const KEY = "finops.workspaceScope";

type Listener = (workspaceId: string) => void;
const listeners = new Set<Listener>();

/** The currently selected workspace id, or "" for the all-workspaces platform view. */
export function getScope(): string {
  try {
    return localStorage.getItem(KEY) ?? "";
  } catch {
    // localStorage can throw in private-mode/sandboxed contexts; degrade to the
    // platform view rather than crashing the whole app.
    return "";
  }
}

/** Select a workspace ("" = all workspaces). Persists, then notifies this window's
 *  subscribers. Other windows are notified by the browser's `storage` event. */
export function setScope(workspaceId: string): void {
  const next = workspaceId || "";
  if (next === getScope()) return; // no-op: don't churn caches on a re-pick
  try {
    if (next) localStorage.setItem(KEY, next);
    else localStorage.removeItem(KEY);
  } catch {
    /* ignore persistence failure; still notify so the current window updates */
  }
  notify(next);
}

function notify(workspaceId: string): void {
  for (const l of listeners) l(workspaceId);
}

/** Subscribe to scope changes from THIS window (via setScope) and from OTHER
 *  windows (via the browser `storage` event). Returns an unsubscribe function. */
export function subscribeScope(listener: Listener): () => void {
  listeners.add(listener);
  const onStorage = (e: StorageEvent) => {
    // Only our key, and only cross-window events (same-window writes already went
    // through notify()). `e.key === null` is a localStorage.clear() — treat as reset.
    if (e.key === KEY || e.key === null) listener(getScope());
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}
