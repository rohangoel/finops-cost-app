// A plain-language "how did you get this number?" for each finding: one or two
// sentences, in the finding's own figures, that give the reader an intuitive
// feel for the method — what was measured, what was assumed, and what was taken
// off. It sits above the technical "Based on …" line (tables + method), which
// stays for anyone auditing the figure.
//
// Each explanation mirrors the rule's savings logic in rules/finops_rules
// (savings.py and the rule's score()). When a rule changes how it prices a
// finding, update its sentence here. Every figure is optional: an older snapshot
// or a sparser rule falls back to the same sentence without the number.
import type { Recommendation } from "../api/types";
import { sizeName } from "./action";
import { moneyExact } from "./format";

type Ev = Record<string, unknown>;

const num = (ev: Ev, ...keys: string[]): number | undefined => {
  for (const k of keys) if (typeof ev[k] === "number" && Number.isFinite(ev[k])) return ev[k] as number;
  return undefined;
};
const vizOf = (ev: Ev): Ev => (ev.viz && typeof ev.viz === "object" ? (ev.viz as Ev) : {});
const h = (x: number) => `${Math.round(x).toLocaleString()}h`;
const pct = (x: number) => `${x < 10 ? x.toFixed(1).replace(/\.0$/, "") : Math.round(x)}%`;
const mins = (m: number | undefined) => (m && m > 0 ? `${m} min` : undefined);
// An hourly rate needs cents: whole-dollar rounding showed a cheap cluster as "$0/hour".
// Same currency style as moneyExact (locale-aware "US$"/"$"), with cents below $10.
const perHourUsd = (x: number) =>
  `${new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: x < 10 ? 2 : 0,
    maximumFractionDigits: x < 10 ? 2 : 0,
  }).format(x)}/hour`;

export function estimateExplainer(rec: Recommendation): string {
  const ev = (rec.evidence ?? {}) as Ev;
  const v = vizOf(ev);
  const spend = rec.monthly_waste_usd;
  const status = rec.savings_status;

  switch (rec.rule_id) {
    case "cluster_autotermination": {
      const run = num(ev, "running_hours");
      const reclaim = num(ev, "reclaimable_hours");
      const to = mins(num(ev, "proposed_auto_termination_minutes")) ?? "the proposed timeout";
      const perHour = run && run > 0 ? spend / run : undefined;
      const measured =
        run && reclaim
          ? `The cluster ran ${h(run)} in the last 30 days, and ${h(reclaim)} of that was idle in stretches longer than ${to} — exactly when a ${to} timeout would have shut it down.`
          : `We found the stretches where the cluster sat idle for longer than ${to} — exactly when that timeout would have shut it down.`;
      return `${measured} Those hours are priced at the cluster's average running cost${perHour ? ` (about ${perHourUsd(perHour)})` : ""}, minus a few minutes per extra restart.`;
    }

    case "idle_zombie_clusters": {
      if (status === "advisory")
        return "This cluster isn't running now, so terminating it saves nothing going forward — we count $0. Its past idle spend is shown only to explain why it was flagged.";
      const idleW = num(ev, "recent_idle_windows", "idle_windows");
      const totW = num(ev, "recent_windows", "total_windows");
      const share = idleW !== undefined && totW ? (idleW / totW) * 100 : undefined;
      return `${share !== undefined ? `Recently, the cluster was idle (CPU under 10%) about ${pct(share)} of the time it was up.` : "Recently, the cluster was idle (CPU under 10%) most of the time it was up."} We take that share of its current bill as what terminating it saves — but don't bank it, because a quiet notebook or stream can also look idle.`;
    }

    case "rightsize_underutilized": {
      const wc = num(ev, "worker_count");
      const tw = num(ev, "target_workers");
      const p95 = typeof v.p95 === "number" ? (v.p95 as number) * 100 : num(ev, "p95_cpu", "p95_cpu_pct");
      const target = num(ev, "target_utilization");
      const cap = num(ev, "max_savings_fraction");
      const peak = p95 !== undefined && wc ? `On ${wc} workers its busy hours (p95) only reach ~${pct(p95)} CPU. ` : "Its busy hours (p95) use only a small part of its CPU. ";
      return `${peak}We shrink it until that same peak would sit near ${pct((target ?? 0.6) * 100)}${tw ? ` (${tw} workers)` : ""}; the saving is the cost of the workers removed, capped at ${pct((cap ?? 0.6) * 100)} of the bill because memory or I/O can run out before CPU does.`;
    }

    case "warehouse_autostop": {
      const to = mins(num(ev, "target_autostop_minutes")) ?? "10 min";
      // Only the full-window key: a sample-window count (e.g. *_14d) would read as monthly.
      const idle = num(ev, "idle_warm_hours");
      return `From query history we rebuilt when the warehouse was running with no queries${idle ? ` (~${h(idle)})` : ""}. Every idle stretch longer than ${to} would have been stopped instead, so that time is priced at the warehouse's running cost, minus the extra cold starts.`;
    }

    case "warehouse_autostop_serverless": {
      const gaps = num(ev, "idle_gaps_analyzed");
      const to = mins(num(v, "chosen_minutes") ?? num(ev, "proposed_autostop_minutes")) ?? "the proposed value";
      const from = mins(num(v, "current_minutes") ?? num(ev, "auto_stop_minutes"));
      const reclaim = num(ev, "reclaimable_hours");
      const restarts = num(ev, "extra_restarts_per_day");
      return `We measured ${gaps ? `all ${gaps.toLocaleString()} gaps` : "every gap"} between queries: in each gap longer than ${to}, the warehouse would have stopped after ${to}${from ? ` instead of ${from}` : ""}${reclaim ? ` — ${h(reclaim)} a month in total` : ""}. That time is priced at its hourly cost, minus a restart charge${restarts ? ` for the ~${restarts.toFixed(1)} extra restarts a day` : ""}.`;
    }

    case "enable_serverless": {
      const idle = num(ev, "idle_hours_pct");
      return `${idle !== undefined ? `For about ${pct(idle)} of the time` : "For much of the time"} this warehouse was running it had no queries — classic and pro warehouses bill for that, serverless stops within seconds. The saving is that idle time's cost minus serverless's higher rate on the busy hours.`;
    }

    case "warehouse_rightsize": {
      const util = num(ev, "slot_util_pct") ?? num(v, "slot_util_pct");
      const to = typeof v.proposed_size === "string" ? v.proposed_size : ev.proposed_size;
      return `${util !== undefined ? `At its busiest, this warehouse used only ~${pct(util)} of its compute capacity` : "At its busiest, this warehouse used a small part of its capacity"}, with almost no queueing or spill — so one size down${typeof to === "string" ? ` (${sizeName(to)})` : ""} still fits. One size step halves the hourly DBU rate; we then allow for queries running a little longer on the smaller size, so the saving is at most half the current bill.`;
    }

    case "warehouse_scale_out": {
      const wait = num(ev, "monthly_queue_wait_hours");
      return `This change adds cost rather than saving it: an extra cluster bills while the queue is busy. No dollar figure is counted; the benefit is the ${wait ? `~${h(wait)} a month` : "time"} queries now spend waiting in the queue.`;
    }

    case "spot_fallback":
      return "Spot VMs are much cheaper than on-demand, but that discount shows up on your cloud-provider bill — Databricks bills the same DBUs either way. So it can't be measured from system tables, and nothing is counted toward any total.";

    case "interactive_to_job": {
      const tail =
        status === "estimated"
          ? " The low end is $0 because people also use this cluster interactively, so moving the jobs may not let it shrink."
          : status === "advisory"
            ? " The jobs-compute price wasn't available for this cloud, so the figure is a rough share of the spend and isn't counted."
            : "";
      return `We measured how much of this cluster's time went to scheduled job runs and re-priced those runs at the cheaper jobs-compute rate — the saving is the price difference.${tail}`;
    }

    case "serverless_cost_optimized":
      return `Standard mode uses fewer DBUs than performance-optimized mode but starts slower. The reduction is a typical default${typeof (rec.evidence ?? {}).dbu_reduction === "number" ? ` (~${pct(((rec.evidence ?? {}).dbu_reduction as number) * 100)} fewer DBUs)` : ""}, not measured on this job, so nothing is counted${rec.monthly_savings_high_usd > 0 ? `; ${moneyExact(rec.monthly_savings_high_usd)}/mo is the most it could save` : ""}.`;

    case "continuous_pipeline": {
      const billed = num(ev, "billed_hours");
      const active = num(ev, "active_hours");
      return `${billed && active !== undefined ? `The pipeline was billed for ${h(billed)} but was processing updates for only ${h(active)}.` : "The pipeline was billed around the clock but processed updates only part of the time."} In triggered mode it runs only for the updates, so the saving is the idle hours' cost minus the start-up time each triggered run adds.`;
    }

    case "failing_jobs": {
      const failed = num(v, "failed_cost") ?? num(ev, "failed_cost");
      const base = num(v, "baseline_fail_rate") ?? num(ev, "baseline_fail_rate");
      return `We added up what the failed runs cost${failed ? ` (${moneyExact(failed)}/mo)` : ""}, kept only the failures above a normal ${pct((base ?? 0.05) * 100)} failure rate, and subtracted what those runs would still cost if they succeeded — fixing the job stops paying for runs that get thrown away, it doesn't make the job free.`;
    }

    case "unused_data_jobs":
      return `Lineage shows this job writing tables that nothing reads, so pausing it would save its producing cost (~${moneyExact(rec.monthly_savings_usd || spend)}/mo). It counts as $0 until someone confirms, because readers outside Databricks (exports, external tools) don't show up in lineage.`;

    case "idle_serving_endpoints": {
      const req = num(ev, "requests_window");
      const days = num(ev, "days_billed");
      const frac = num(ev, "low_traffic_reclaim_frac");
      if (ev.is_low_traffic === true) {
        const rpd = num(ev, "requests_per_day");
        return `It serves only ${rpd !== undefined ? `~${Math.round(rpd)}` : "a few"} requests a day — far too few for always-warm capacity. With scale-to-zero we count ${pct((frac ?? 0.7) * 100)} of the always-on cost as saved, leaving the rest to cover the moments it's actually called.`;
      }
      return `The endpoint billed${days ? ` on ${days} days of the window` : " every day"} but served ${req !== undefined ? req.toLocaleString() : "no"} requests, so its whole always-on cost is avoidable. The request count comes straight from serving logs, not from a proxy.`;
    }

    case "idle_apps":
      return "The app bills for its compute around the clock and showed no recorded use in the window, so stopping it saves its full cost.";

    case "jobs_compute_rightsize": {
      const wc = num(ev, "worker_count");
      const wcpu = num(ev, "worker_cpu_pct");
      const frac = num(ev, "worker_cost_fraction");
      const share = frac !== undefined ? ` (~${pct(frac * 100)} of the cost)` : "";
      const sym = ev.symptom;
      const base =
        sym === "driver_bound"
          ? `The driver does the work while ${wc ? `${wc} workers` : "the workers"} sit near idle${wcpu !== undefined ? ` (${pct(wcpu)} CPU)` : ""}, so running it single-node removes the workers' share of the bill${share}.`
          : sym === "idle_workers"
            ? `The workers are mostly idle, so roughly halving them removes about half of the workers' share of the bill${share}.`
            : "Memory use is far below what the nodes provide, so a smaller-memory node type removes a fixed slice of the bill.";
      return `${base} A safety haircut is applied on top, since job runs vary.`;
    }

    case "gpu_wrong_runtime":
      return "GPU nodes cost more than CPU nodes, but most of that premium is on the cloud-VM bill, which Databricks billing doesn't show — so no dollar figure is counted.";

    case "cluster_job_contention": {
      const solo = num(v, "cpu_solo") ?? num(ev, "cpu_pct_solo");
      const conc = num(v, "cpu_concurrent") ?? num(ev, "cpu_pct_concurrent");
      return `This is about speed and reliability, not cost: jobs slow each other down on the shared cluster${solo !== undefined && conc !== undefined ? ` (CPU ${pct(solo)} with one job vs ${pct(conc)} with several)` : ""}. The money is counted under "Move scheduled work off all-purpose clusters", so it isn't counted twice here.`;
    }

    case "untagged_spend":
      return "Tagging doesn't lower the bill, so the saving is $0. The figure shown is the spend that can't be charged back to a team today.";

    // ---- rules promoted out of Labs (2026-09-23) ----
    case "warehouse_keepalive_queries": {
      const ka = num(ev, "keepalive_hours");
      const billed = num(ev, "billed_hours");
      const to = mins(num(ev, "auto_stop_minutes"));
      return `From query history we found the billed hours in which the only statements were trivial pings (metadata calls, cache hits, SELECT 1)${ka && billed ? ` — ${h(ka)} of ${h(billed)}` : ""}. Without them the warehouse would have auto-stopped, so those hours are priced at its hourly cost, minus one ${to ?? "auto-stop"} tail per stretch that it bills anyway after the last real query.`;
    }

    case "warehouse_min_clusters": {
      const ex = num(ev, "excess_cluster_hours");
      const act = num(ev, "actual_cluster_hours");
      const mc = num(ev, "min_clusters");
      const rate = num(ev, "usd_per_cluster_hour");
      return `We rebuilt, minute by minute, how many clusters were running and how many the queries needed (one per ~10 concurrent queries)${ex && act ? `: ${h(ex)} of ${h(act)} cluster-hours were held only because min_clusters is ${mc ?? "above 1"}` : ""}. Those cluster-hours are priced at the warehouse's own measured cost per cluster-hour${rate ? ` (about ${perHourUsd(rate)})` : ""}; clusters autoscaling added on demand are not counted, because it would still add them.`;
    }

    case "alert_hygiene": {
      if (status === "advisory")
        return "The alert is failing or notifies nobody, but its own queries cost next to nothing on a warehouse that runs anyway — so no dollar figure is counted. Fixing or deleting it is about trust in monitoring, not cost.";
      const wh = num(ev, "warm_hours");
      const days = num(ev, "history_days");
      return `We found the billed warehouse hours in which this alert's evaluations were the only thing running${wh ? ` (${h(wh)} in ${days ?? 14} days)` : ""}. Without them the warehouse would have been stopped, so those hours are priced at its hourly cost (shared between alerts when several ran in the same hour), minus one auto-stop tail per stretch, and scaled to a month.`;
    }

    case "job_no_new_input": {
      if (status === "advisory")
        return "Some of what this job reads is never shown as written in lineage (a table fed from outside Databricks, or a static reference table), so we can't prove its runs had no new input — no dollar figure is counted. The spend shown is what those runs cost.";
      const share = num(ev, "no_new_input_share_pct");
      return `Lineage shows every table this job reads and every write to them. ${share !== undefined ? `In ${pct(share)} of its scheduled runs` : "In many of its scheduled runs"} nothing it reads had changed since the run before, so it recomputed the same answer. The saving is what those runs were billed; a table-update trigger would skip them.`;
    }

    case "job_task_retry_waste": {
      const rate = num(ev, "retry_rate_pct");
      const base = num(ev, "baseline_retry_rate_pct");
      return `${rate !== undefined ? `${pct(rate)} of this job's successful runs` : "Many of this job's successful runs"} needed a task retry first. Each run's bill is split across its task attempts by how long they ran, and the failed attempts' share is counted — only for retries above a normal ${pct(base ?? 5)} rate, since some flakiness is expected.`;
    }

    case "serving_provisioned_overcapacity": {
      const idle = num(ev, "reclaimable_idle_hours");
      const billed = num(ev, "billed_hours");
      return `Serving logs show long stretches with no requests at all while the endpoint kept billing${idle && billed ? ` — ${h(idle)} of ${h(billed)} billed hours` : ""}. With scale-to-zero those hours would not bill, so they're priced at the endpoint's own hourly cost. How much capacity it reserves isn't in system tables, so shrinking it during busy hours isn't counted.`;
    }

    case "unpruned_repeated_queries":
      return "We added up what the repeated query shapes cost — their share of the warehouse's compute time. That is what they cost today, not what a fix saves: how much clustering the table or rewriting the query cuts depends on the data, so nothing is counted toward any total.";

    case "unviewed_scheduled_dashboards": {
      const sh = num(ev, "active_hours_share_pct");
      return `In each warehouse hour this dashboard's refreshes ran in, we took its share of the work${sh !== undefined ? ` (${pct(sh)} overall)` : ""} and priced that share of the hour. Nothing is counted, because the bill only drops if the warehouse then runs less — on a warehouse that's busy anyway, pausing the refresh frees capacity, not money.`;
    }

    case "pipeline_failed_updates":
      return "We priced the share of this pipeline's compute spent on updates that failed. Nothing is counted: fixing the failure makes the same work succeed instead — it still runs and still bills — so the figure shows what failures cost today, not what a fix saves.";

    case "sql_repeated_failures":
      return "We priced the failed queries' share of this warehouse's compute time. Nothing is counted: once fixed, most of those queries still run, and succeed — so the figure shows what failing costs today, not what a fix saves.";

    case "instance_pool_idle":
      return "The pool keeps warm VMs running for clusters that rarely come. Those VMs bill on your cloud-provider account, not in Databricks billing, and what they cost isn't in any system table — so no dollar figure is shown. The warm floor itself is measured.";

    // ---- Labs rules (experimental: out of every total) ----
    case "job_runaway_no_timeout":
      return "We compared this job's unusually long runs with its median run: what the long runs cost above a normal run is the figure shown. A timeout would stop a hung run earlier, but not every long run is a hang, so nothing is counted.";

    case "pipeline_full_refresh_churn":
      return "We compared what this pipeline's full refreshes cost with its median incremental update. The difference is what full refreshing costs; nothing is counted, because some full refreshes are needed (a schema change, a backfill).";

    case "allpurpose_shape_mismatch":
      return ev.symptom === "driver_bound"
        ? "The driver does the work while the workers sit near idle, so the workers' share of the cluster's bill is shown as addressable. Nothing is counted: an interactive cluster's load changes from one user to the next."
        : "Memory use on the workers is far below what the node type provides. The figure is the difference between the current and a smaller-memory node's measured rate; nothing is counted while this rule is in Labs.";

    case "instance_generation_modernize":
      return "Newer node types list at the same or a higher hourly price as the old ones (only Graviton / ARM is cheaper), so the saving comes from jobs finishing faster — which system tables can't predict. No dollar figure is counted; the spend on old node types is shown for scale.";

    default:
      return status === "advisory"
        ? "The problem is measured, but the dollars it would save can't be reliably priced from Databricks billing, so nothing is counted toward any total."
        : `Priced from this resource's own billed usage over the last 30 days (~${moneyExact(spend)}/mo), scaled to the part of it the change removes.`;
  }
}
