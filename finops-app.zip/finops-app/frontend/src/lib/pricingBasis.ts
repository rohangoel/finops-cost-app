/**
 * Global price basis — "List price" vs "Your rates" (contract). Works like the
 * workspace scope (lib/scope.ts): persisted in localStorage and synced across windows.
 *
 * Only an EXPLICIT user choice is stored. With nothing stored, the basis follows the
 * backend's `default_basis` (decision D1: "Your rates" only when ≥95 % of spend is
 * contract-priced), so a later change in coverage can still move the default.
 */

import type { PricingBasis } from "./price";

const KEY = "finops.pricingBasis";

type Listener = (basis: PricingBasis | null) => void;
const listeners = new Set<Listener>();

/** The user's explicit choice, or null when they never picked one. */
export function getStoredBasis(): PricingBasis | null {
  try {
    const v = localStorage.getItem(KEY);
    return v === "contract" || v === "list" ? v : null;
  } catch {
    // localStorage can throw in private-mode / sandboxed contexts.
    return null;
  }
}

export function setPricingBasis(basis: PricingBasis): void {
  try {
    localStorage.setItem(KEY, basis);
  } catch {
    /* persistence failure: still notify so this window updates */
  }
  for (const l of listeners) l(basis);
}

/** Subscribe to changes from this window and (via `storage`) from other windows. */
export function subscribePricingBasis(listener: Listener): () => void {
  listeners.add(listener);
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY || e.key === null) listener(getStoredBasis());
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}
