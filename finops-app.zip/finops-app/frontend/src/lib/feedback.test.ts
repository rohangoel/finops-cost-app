import { describe, expect, it } from "vitest";
import type { Recommendation, Vote } from "../api/types";
import {
  PREFILL_REASON_MAX,
  groupMyFindings,
  isRecipient,
  matchesFocus,
  newRequestId,
  parsePrefill,
  voteSummary,
} from "./feedback";

const rec = (over: Partial<Recommendation>) =>
  ({
    recommendation_id: "rid-today",
    finding_key: "622d20174256dc76c9969c57130422f4",
    notify_recipient: "ana@example.com",
    recipient_source: "object_owner",
    ...over,
  }) as unknown as Recommendation;

describe("parsePrefill (confirm links from the StopTheLeak Genie tool)", () => {
  it("reads the contract's example link", () => {
    const p = new URLSearchParams(
      "focus=622d20174256dc76c9969c57130422f4&verdict=valid_cannot_fix&reason=customer+demo",
    );
    expect(parsePrefill(p)).toEqual({ verdict: "valid_cannot_fix", reason: "customer demo" });
  });

  it("ignores a verdict that isn't one of the six", () => {
    expect(parsePrefill(new URLSearchParams("verdict=delete_everything&reason=x"))).toBeNull();
    expect(parsePrefill(new URLSearchParams("focus=abc"))).toBeNull();
  });

  it("caps the reason and keeps markup as plain text", () => {
    const long = "<img src=x onerror=alert(1)>" + "a".repeat(600);
    const p = parsePrefill(new URLSearchParams({ verdict: "invalid", reason: long }));
    expect(p?.reason.length).toBe(PREFILL_REASON_MAX);
    // Unchanged characters: the form puts it in a <textarea> value, never innerHTML.
    expect(p?.reason.startsWith("<img")).toBe(true);
  });
});

describe("finding identity", () => {
  it("focus matches the stable finding_key and the old recommendation_id", () => {
    const r = rec({});
    expect(matchesFocus(r, "622d20174256dc76c9969c57130422f4")).toBe(true);
    expect(matchesFocus(r, "rid-today")).toBe(true);
    expect(matchesFocus(r, "something-else")).toBe(false);
    expect(matchesFocus(r, null)).toBe(false);
  });

  it("only the recipient may vote, case-insensitively", () => {
    expect(isRecipient(rec({}), "Ana@Example.com")).toBe(true);
    expect(isRecipient(rec({}), "bob@example.com")).toBe(false);
    expect(isRecipient(rec({ notify_recipient: null }), "ana@example.com")).toBe(false);
    expect(isRecipient(rec({}), null)).toBe(false);
  });
});

describe("My findings tab", () => {
  it("splits by why the finding is yours, keeping order", () => {
    const a = rec({ finding_key: "a" });
    const b = rec({ finding_key: "b", recipient_source: "workspace_owner" });
    const c = rec({ finding_key: "c" });
    const g = groupMyFindings([a, b, c]);
    expect(g.owned.map((f) => f.finding_key)).toEqual(["a", "c"]);
    expect(g.viaWorkspace.map((f) => f.finding_key)).toEqual(["b"]);
  });

  it("summarises a stored vote", () => {
    const vote = {
      verdict: "invalid",
      reason_codes: ["wrong_numbers"],
      savings_assessment: "too_high",
      snooze_until: null,
    } as unknown as Vote;
    expect(voteSummary(vote)).toBe("Not valid · the numbers are wrong · $ figure: too high");
  });

  it("makes a new UUID per click", () => {
    const a = newRequestId();
    expect(a).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(newRequestId()).not.toBe(a);
  });
});
