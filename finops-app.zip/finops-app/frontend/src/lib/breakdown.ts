// Small client-side roll-ups + a shared color palette for the charts. Colors
// are CSS custom properties so every chart follows the active light/dark theme.
import { type PricingBasis, savingsValue } from "./price";
import type { Recommendation } from "../api/types";

export interface Slice {
  key: string;
  label: string;
  value: number;
  count: number;
  color: string;
}

// One distinct hue per category. Green (--savings) and red (--accent) are kept
// out on purpose: they mean "saving" and "alert" everywhere else in the app.
export const CATEGORY_COLOR: Record<string, string> = {
  compute: "var(--info)",
  sql: "var(--violet)",
  jobs: "var(--warn)",
  serving: "var(--teal)",
  apps: "var(--pink)",
  pipelines: "var(--slate)",
};

// Display names — category ids are lowercase slugs ("sql"), and CSS capitalize
// rendered them as "Sql".
export const CATEGORY_LABEL: Record<string, string> = {
  compute: "Clusters",
  sql: "SQL warehouses",
  jobs: "Jobs",
  serving: "Model serving",
  apps: "Apps",
  pipelines: "Pipelines",
  sharing: "Delta Sharing",
  storage: "Storage",
  governance: "Governance",
};

export const PRIORITY_COLOR: Record<string, string> = {
  HIGH: "var(--accent)",
  MEDIUM: "var(--warn)",
  LOW: "var(--faint)",
};

export const EFFORT_COLOR: Record<string, string> = {
  trivial: "var(--savings)",
  low: "var(--info)",
  medium: "var(--warn)",
  high: "var(--accent)",
};

const FALLBACK = ["var(--slate)", "var(--teal)", "var(--pink)", "var(--info)", "var(--violet)"];

/** Only findings whose dollars count toward the headline. Advisory findings book
 *  $0 in the headline KPI, so a breakdown that summed their point estimate showed
 *  a bigger total than the KPI above it ($221k vs $194k) and the two could never
 *  be reconciled. Every breakdown and list total runs on this basis. */
export function countedTowardHeadline(recs: Recommendation[]): Recommendation[] {
  return recs.filter((r) => r.savings_status !== "advisory");
}

/** Collapse to one recommendation per (workspace, resource_type, resource_id):
 *  its single best (max-savings) option. Overlapping fixes on one resource are
 *  mutually exclusive, so summing them would double-count. Every breakdown chart
 *  runs on this collapsed set so the slices reconcile with the grouped headline
 *  totals. Mirrors the backend `aggregation._collapse_to_resources`. */
export function collapseToResources(recs: Recommendation[]): Recommendation[] {
  const best = new Map<string, Recommendation>();
  for (const r of recs) {
    const key = `${r.workspace_id}|${r.resource_type}|${r.resource_id}`;
    const cur = best.get(key);
    // Ties (several $0 advisory options) keep the one with the most spend behind it.
    if (
      !cur ||
      r.monthly_savings_usd > cur.monthly_savings_usd ||
      (r.monthly_savings_usd === cur.monthly_savings_usd && r.monthly_waste_usd > cur.monthly_waste_usd)
    )
      best.set(key, r);
  }
  return [...best.values()];
}

function rollup(
  recs: Recommendation[],
  keyOf: (r: Recommendation) => string,
  colors: Record<string, string>,
  labelOf?: (k: string) => string,
  basis: PricingBasis = "list",
): Slice[] {
  const sums = new Map<string, { value: number; count: number }>();
  for (const r of recs) {
    const k = keyOf(r);
    const cur = sums.get(k) ?? { value: 0, count: 0 };
    cur.value += savingsValue(r, basis);
    cur.count += 1;
    sums.set(k, cur);
  }
  return [...sums.entries()]
    .map(([key, v], i) => ({
      key,
      label: labelOf ? labelOf(key) : key,
      value: Math.round(v.value),
      count: v.count,
      color: colors[key] ?? FALLBACK[i % FALLBACK.length],
    }))
    .sort((a, b) => b.value - a.value);
}

export const savingsByCategory = (recs: Recommendation[], basis: PricingBasis = "list") =>
  rollup(recs, (r) => r.category, CATEGORY_COLOR, (k) => CATEGORY_LABEL[k] ?? k, basis);

// Ordinal scales read in their natural order (HIGH → LOW, trivial → high), not
// sorted by size: sorted by value, "Low, Medium, Trivial, High" left the reader
// to re-sort the effort ladder in their head.
const inOrder = (order: string[]) => (a: Slice, b: Slice) =>
  (order.indexOf(a.key) + 99) % 99 - (order.indexOf(b.key) + 99) % 99;

export const savingsByPriority = (recs: Recommendation[], basis: PricingBasis = "list") =>
  rollup(recs, (r) => r.priority, PRIORITY_COLOR, (k) => k.charAt(0) + k.slice(1).toLowerCase(), basis).sort(
    inOrder(["HIGH", "MEDIUM", "LOW"]),
  );

export const savingsByEffort = (recs: Recommendation[], basis: PricingBasis = "list") =>
  rollup(recs, (r) => r.effort_band, EFFORT_COLOR, (k) => k.charAt(0).toUpperCase() + k.slice(1), basis).sort(
    inOrder(["trivial", "low", "medium", "high"]),
  );

/** Savings reachable with trivial/low-effort changes — the "what can we do this
 *  week" figure a FinOps lead asks for first. Same basis as the headline (pass
 *  the collapsed, headline-counted set). */
export function quickWins(
  recs: Recommendation[],
  basis: PricingBasis = "list",
): { value: number; count: number } {
  const quick = recs.filter((r) => r.effort_band === "trivial" || r.effort_band === "low");
  return { value: quick.reduce((s, r) => s + savingsValue(r, basis), 0), count: quick.length };
}

export const savingsByRule = (recs: Recommendation[], basis: PricingBasis = "list") =>
  rollup(recs, (r) => r.rule_id, {}, undefined, basis);

/** Rule id -> human title, harvested from the recommendation set. */
export function ruleTitles(recs: Recommendation[]): Record<string, string> {
  const m: Record<string, string> = {};
  for (const r of recs) m[r.rule_id] = r.rule_title;
  return m;
}
