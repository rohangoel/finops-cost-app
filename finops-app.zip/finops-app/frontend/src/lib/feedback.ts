// Votes on findings (StopTheLeak). The verdicts and reason codes are the contract's
// (StopTheLeak docs/FINOPS_APP_CONTRACT.md §3); the backend rejects anything else
// (backend/finops/models/feedback.py). Kept free of React so it is unit-testable.

import type { Recommendation, SavingsAssessment, Verdict, Vote } from "../api/types";

export const VERDICTS: { value: Verdict; label: string; hint: string }[] = [
  { value: "valid_will_fix", label: "Valid, I'll fix it", hint: "The finding is right and you'll act on it." },
  {
    value: "valid_cannot_fix",
    label: "Valid, but I can't fix it",
    hint: "Right, but there's a reason it has to stay this way.",
  },
  { value: "invalid", label: "Not valid", hint: "The finding is wrong." },
  { value: "already_fixed", label: "Already fixed", hint: "You changed it since the snapshot." },
  { value: "not_my_resource", label: "Not my resource", hint: "It shouldn't have come to you." },
  { value: "comment_only", label: "Just a comment", hint: "No verdict, just a note." },
];

export const VERDICT_LABEL: Record<Verdict, string> = Object.fromEntries(
  VERDICTS.map((v) => [v.value, v.label]),
) as Record<Verdict, string>;

export const REASON_CODES: Partial<Record<Verdict, { value: string; label: string }[]>> = {
  invalid: [
    { value: "wrong_numbers", label: "The numbers are wrong" },
    { value: "resource_is_needed", label: "The resource is needed as it is" },
    { value: "data_incomplete", label: "The data is incomplete" },
    { value: "wrong_resource_type", label: "Wrong resource type" },
    { value: "duplicate_of_other_finding", label: "Duplicate of another finding" },
    { value: "other", label: "Other" },
  ],
  valid_cannot_fix: [
    { value: "sla_latency", label: "SLA / latency" },
    { value: "customer_demo", label: "Customer demo" },
    { value: "compliance", label: "Compliance" },
    { value: "owned_by_other_team", label: "Owned by another team" },
    { value: "planned_decommission", label: "Decommission planned" },
    { value: "other", label: "Other" },
  ],
};

export const SAVINGS_ASSESSMENTS: { value: SavingsAssessment; label: string }[] = [
  { value: "too_high", label: "Too high" },
  { value: "about_right", label: "About right" },
  { value: "too_low", label: "Too low" },
  { value: "unsure", label: "Not sure" },
];

export const SNOOZE_CHOICES: { value: 30 | 90 | null; label: string }[] = [
  { value: 30, label: "Ask again in 30 days" },
  { value: 90, label: "Ask again in 90 days" },
  { value: null, label: "Don't ask again" },
];

/** Cap on the prefilled reason from a confirm link (contract §4). */
export const PREFILL_REASON_MAX = 500;

export interface Prefill {
  verdict: Verdict;
  reason: string;
}

/** Read `verdict` / `reason` from a confirm link (…?focus=<key>&verdict=…&reason=…).
 *
 *  An unknown verdict is ignored (null: no prefill). The reason is capped and later
 *  rendered as text in a textarea, never as HTML. Nothing is recorded from this:
 *  the user still has to press Confirm. */
export function parsePrefill(params: URLSearchParams): Prefill | null {
  const verdict = params.get("verdict");
  if (!verdict || !VERDICTS.some((v) => v.value === verdict)) return null;
  const reason = (params.get("reason") ?? "").slice(0, PREFILL_REASON_MAX);
  return { verdict: verdict as Verdict, reason };
}

/** True when `rec` is routed to `email` (the only person who may vote on it). */
export function isRecipient(rec: Recommendation, email: string | null | undefined): boolean {
  return !!email && !!rec.notify_recipient && rec.notify_recipient.toLowerCase() === email.toLowerCase();
}

/** Does this deep-link `focus` value name this finding? Accepts the stable
 *  finding_key (email / Genie links) and the older, daily recommendation_id. */
export function matchesFocus(rec: Recommendation, focus: string | null): boolean {
  return !!focus && (rec.finding_key === focus || rec.recommendation_id === focus);
}

/** "You said: …" line for a stored vote. */
export function voteSummary(vote: Vote): string {
  const parts = [VERDICT_LABEL[vote.verdict] ?? vote.verdict];
  const reasons = (REASON_CODES[vote.verdict] ?? [])
    .filter((r) => vote.reason_codes.includes(r.value))
    .map((r) => r.label.toLowerCase());
  if (reasons.length) parts.push(reasons.join(", "));
  if (vote.savings_assessment) {
    const a = SAVINGS_ASSESSMENTS.find((s) => s.value === vote.savings_assessment);
    if (a) parts.push(`$ figure: ${a.label.toLowerCase()}`);
  }
  if (vote.snooze_until) parts.push(`ask again after ${vote.snooze_until}`);
  return parts.join(" · ");
}

/** My findings, split by WHY each is yours: resources you own, and resources in a
 *  workspace you own that a service principal (or nobody) owns. Order is kept. */
export function groupMyFindings(findings: Recommendation[]): {
  owned: Recommendation[];
  viaWorkspace: Recommendation[];
} {
  return {
    owned: findings.filter((f) => f.recipient_source === "object_owner"),
    viaWorkspace: findings.filter((f) => f.recipient_source === "workspace_owner"),
  };
}

/** A fresh idempotency id per click. */
export function newRequestId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  // Fallback for non-secure contexts (e.g. http://<lan-ip>): RFC 4122 v4 from Math.random.
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}
