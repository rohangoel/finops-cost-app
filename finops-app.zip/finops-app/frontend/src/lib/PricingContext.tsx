/**
 * Pricing capabilities (`/api/pricing`) + the EFFECTIVE price basis for every page.
 *
 * The effective basis is "contract" only when the data actually carries contract
 * figures — a stale "Your rates" choice from another deployment can never make a
 * list-only snapshot claim contract pricing.
 */

import { createContext, type ReactNode, useContext, useEffect, useState } from "react";
import type { PricingSummary } from "../api/types";
import type { PricingBasis } from "./price";
import { getStoredBasis, subscribePricingBasis } from "./pricingBasis";

interface PricingContextValue {
  pricing: PricingSummary | null;
  /** The basis to render in: always "list" unless contract data is available. */
  basis: PricingBasis;
}

const PricingCtx = createContext<PricingContextValue>({ pricing: null, basis: "list" });

export function PricingProvider({
  pricing,
  children,
}: {
  pricing: PricingSummary | null;
  children: ReactNode;
}) {
  const [stored, setStored] = useState<PricingBasis | null>(getStoredBasis());
  useEffect(() => subscribePricingBasis(setStored), []);
  const basis: PricingBasis = pricing?.contract_available
    ? stored ?? pricing.default_basis
    : "list";
  return <PricingCtx.Provider value={{ pricing, basis }}>{children}</PricingCtx.Provider>;
}

/** Pricing data + effective basis. Outside a provider: list basis, no pricing. */
export function usePricingContext(): PricingContextValue {
  return useContext(PricingCtx);
}
