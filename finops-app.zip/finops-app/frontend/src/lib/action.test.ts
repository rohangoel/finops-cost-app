import { describe, expect, it } from "vitest";
import type { Recommendation } from "../api/types";
import { actionChange, firstSentence, sizeName } from "./action";

const rec = (rule_id: string, evidence: Record<string, unknown>) =>
  ({ rule_id, evidence }) as unknown as Recommendation;

describe("actionChange", () => {
  it("reads auto-termination off -> proposed", () => {
    expect(
      actionChange(
        rec("cluster_autotermination", {
          auto_termination_minutes: null,
          proposed_auto_termination_minutes: 60,
        }),
      ),
    ).toEqual({ setting: "Auto-termination", from: "off", to: "60 min" });
  });

  it("returns null for an older snapshot without the proposed value", () => {
    expect(actionChange(rec("cluster_autotermination", { auto_termination_minutes: 120 }))).toBeNull();
  });

  it("prefers the serverless auto-stop chart's chosen value", () => {
    expect(
      actionChange(
        rec("warehouse_autostop_serverless", {
          auto_stop_minutes: 60,
          viz: { kind: "autostop_tradeoff", current_minutes: 60, chosen_minutes: 5 },
        }),
      ),
    ).toEqual({ setting: "Auto-stop", from: "60 min", to: "5 min" });
  });

  it("formats warehouse sizes", () => {
    expect(
      actionChange(rec("warehouse_rightsize", { warehouse_size: "X_LARGE", proposed_size: "LARGE" })),
    ).toEqual({ setting: "Cluster size", from: "X-Large", to: "Large" });
    expect(sizeName("2X_SMALL")).toBe("2X-Small");
  });

  it("returns null for rules with no structured setting", () => {
    expect(actionChange(rec("failing_jobs", {}))).toBeNull();
    expect(actionChange(rec("warehouse_keepalive_queries", {}))).toBeNull();
    expect(actionChange(rec("job_task_retry_waste", {}))).toBeNull();
  });

  it("lowers min_clusters to the proposed floor", () => {
    expect(
      actionChange(rec("warehouse_min_clusters", { min_clusters: 3, proposed_min_clusters: 1 })),
    ).toEqual({ setting: "Minimum clusters", from: "3", to: "1" });
    expect(actionChange(rec("warehouse_min_clusters", {}))).toBeNull();
  });

  it("only gives an alert a setting change when it keeps a warehouse warm", () => {
    expect(
      actionChange(rec("alert_hygiene", {
        issues: ["keeps_warehouse_warm"], schedule: "0 0/5 * * * ?", auto_stop_minutes: 10,
      })),
    ).toEqual({ setting: "Alert schedule", from: "0 0/5 * * * ?", to: "every > 10 min" });
    expect(actionChange(rec("alert_hygiene", { issues: ["always_erroring"] }))).toBeNull();
  });

  it("formats a runaway job's recommended timeout", () => {
    expect(
      actionChange(rec("job_runaway_no_timeout", { recommended_timeout_seconds: 5400, job_timeout_seconds: 0 })),
    ).toEqual({ setting: "Job timeout", from: "none", to: "1.5 h" });
  });

  it("names the pool's warm floor", () => {
    expect(actionChange(rec("instance_pool_idle", { min_idle_instances: 4 }))).toEqual({
      setting: "Min idle instances",
      from: "4",
      to: "0",
    });
  });
});

describe("firstSentence", () => {
  it("does not split on decimals", () => {
    expect(firstSentence("CPU averaged 12.1% over 8 workers. Memory was fine.")).toBe(
      "CPU averaged 12.1% over 8 workers.",
    );
  });
  it("truncates very long leads", () => {
    expect(firstSentence("x".repeat(300), 20)).toHaveLength(20);
  });
});
