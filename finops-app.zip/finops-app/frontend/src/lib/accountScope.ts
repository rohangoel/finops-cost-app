// Global account scope — the "which account / cloud / Databricks account am I
// looking at" selection that EVERY page shares in central (multi-account) mode.
//
// It is the sibling of lib/scope.ts (the workspace scope) and works the same way:
// it lives in localStorage so one pick applies to every tab of the app and stays in
// sync across separate browser windows (a write fires a `storage` event the others
// listen for). The frontend appends the set values to every GET (see api/client.ts),
// and the backend applies them at the recommendation source's fetch boundary — so a
// selected account isolates that customer on EVERY surface (overview, next best
// actions, the list, the groups, detail), and two customers' findings can never mix.
//
// All three empty = "all accounts", the unfiltered central view. In single-account
// mode the UI never shows the switcher, so nothing is ever set here.

const KEY = "finops.accountScope";

export interface AccountScope {
  salesforce_account_name: string;
  cloud_type: string;
  databricks_account_id: string;
}

const EMPTY: AccountScope = {
  salesforce_account_name: "",
  cloud_type: "",
  databricks_account_id: "",
};

type Listener = (scope: AccountScope) => void;
const listeners = new Set<Listener>();

// Cached snapshot: `getAccountScope` MUST return a stable object reference while the
// stored value is unchanged, or `useSyncExternalStore` (which compares snapshots by
// Object.is) sees a "change" on every render and loops until React throws — a blank
// screen. So we parse only when the raw localStorage string actually differs and
// otherwise hand back the same object. (The workspace scope avoids this for free by
// returning a string.)
let cacheRaw: string | null = null;
let cache: AccountScope = EMPTY;

/** The current account scope. Missing/blank fields mean "all" for that dimension.
 *  Returns a STABLE reference until the stored value changes (see note above). */
export function getAccountScope(): AccountScope {
  let raw: string | null;
  try {
    raw = localStorage.getItem(KEY);
  } catch {
    // localStorage can throw in private-mode/sandboxed contexts — degrade to the
    // unfiltered all-accounts view, with a stable reference.
    return EMPTY;
  }
  if (raw === cacheRaw) return cache; // unchanged -> same reference, no re-render churn
  cacheRaw = raw;
  if (!raw) {
    cache = EMPTY;
    return cache;
  }
  try {
    const parsed = JSON.parse(raw) as Partial<AccountScope>;
    cache = {
      salesforce_account_name: parsed.salesforce_account_name || "",
      cloud_type: parsed.cloud_type || "",
      databricks_account_id: parsed.databricks_account_id || "",
    };
  } catch {
    cache = EMPTY;
  }
  return cache;
}

function isEmpty(s: AccountScope): boolean {
  return !s.salesforce_account_name && !s.cloud_type && !s.databricks_account_id;
}

function equal(a: AccountScope, b: AccountScope): boolean {
  return (
    a.salesforce_account_name === b.salesforce_account_name &&
    a.cloud_type === b.cloud_type &&
    a.databricks_account_id === b.databricks_account_id
  );
}

/** Merge a partial selection into the scope. Persists, then notifies this window's
 *  subscribers; other windows are notified by the browser's `storage` event. */
export function setAccountScope(patch: Partial<AccountScope>): void {
  const next: AccountScope = { ...getAccountScope(), ...normalize(patch) };
  if (equal(next, getAccountScope())) return; // no-op: don't churn caches on a re-pick
  try {
    if (isEmpty(next)) localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* ignore persistence failure; still notify so the current window updates */
  }
  notify(next);
}

/** Clear every account filter (back to the all-accounts central view). */
export function clearAccountScope(): void {
  setAccountScope(EMPTY);
}

function normalize(patch: Partial<AccountScope>): Partial<AccountScope> {
  const out: Partial<AccountScope> = {};
  for (const k of Object.keys(patch) as (keyof AccountScope)[]) {
    out[k] = patch[k] || "";
  }
  return out;
}

function notify(scope: AccountScope): void {
  for (const l of listeners) l(scope);
}

/** Subscribe to account-scope changes from THIS window (via setAccountScope) and
 *  from OTHER windows (via the browser `storage` event). Returns an unsubscribe fn. */
export function subscribeAccountScope(listener: Listener): () => void {
  listeners.add(listener);
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY || e.key === null) listener(getAccountScope());
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}
