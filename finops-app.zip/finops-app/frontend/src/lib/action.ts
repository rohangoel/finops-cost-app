// The concrete change a recommendation asks for, as data: "Auto-termination:
// off → 60 min", "Workers: 8 → 4". Engineers act on a setting, not on a rule
// title, and the setting was otherwise only findable inside the `how` prose.
// Derived from evidence keys the rules already emit; returns null when a rule
// carries no structured before/after, and callers fall back to the `how` text.
import type { Recommendation } from "../api/types";

export interface ActionChange {
  setting: string; // what to change, e.g. "Auto-termination"
  from: string; // today's value
  to: string; // the recommended value
}

type Ev = Record<string, unknown>;

const num = (ev: Ev, ...keys: string[]): number | undefined => {
  for (const k of keys) if (typeof ev[k] === "number") return ev[k] as number;
  return undefined;
};
const str = (ev: Ev, ...keys: string[]): string | undefined => {
  for (const k of keys) if (typeof ev[k] === "string" && ev[k]) return ev[k] as string;
  return undefined;
};
const viz = (ev: Ev): Ev => (ev.viz && typeof ev.viz === "object" ? (ev.viz as Ev) : {});

/** 0 / null / absent minutes = the setting is off (never stops). */
const minutes = (m: number | undefined | null) => (m && m > 0 ? `${m} min` : "off");

/** "X_LARGE" -> "X-Large", "2X_LARGE" -> "2X-Large". */
export const sizeName = (s: string) =>
  s
    .split("_")
    .map((p) => (/^\d*X$/.test(p) ? p : p.charAt(0) + p.slice(1).toLowerCase()))
    .join("-");

export function actionChange(rec: Recommendation): ActionChange | null {
  const ev = (rec.evidence ?? {}) as Ev;
  const v = viz(ev);
  switch (rec.rule_id) {
    case "cluster_autotermination": {
      const to = num(ev, "proposed_auto_termination_minutes");
      if (to === undefined) return null;
      return {
        setting: "Auto-termination",
        from: minutes(num(ev, "auto_termination_minutes", "autotermination_minutes")),
        to: minutes(to),
      };
    }
    case "warehouse_autostop": {
      const to = num(ev, "target_autostop_minutes");
      const from = num(ev, "auto_stop_minutes", "autostop_minutes");
      if (to === undefined && from === undefined) return null;
      return { setting: "Auto-stop", from: minutes(from), to: to !== undefined ? minutes(to) : "10 min" };
    }
    case "warehouse_autostop_serverless": {
      const to = num(v, "chosen_minutes") ?? num(ev, "proposed_autostop_minutes");
      if (to === undefined) return null;
      return {
        setting: "Auto-stop",
        from: minutes(num(v, "current_minutes") ?? num(ev, "auto_stop_minutes")),
        to: minutes(to),
      };
    }
    case "warehouse_rightsize": {
      const from = str(v, "current_size") ?? str(ev, "warehouse_size");
      const to = str(v, "proposed_size") ?? str(ev, "proposed_size");
      if (!from || !to) return null;
      return { setting: "Cluster size", from: sizeName(from), to: sizeName(to) };
    }
    case "warehouse_scale_out": {
      const from = num(v, "current_max_clusters") ?? num(ev, "max_clusters");
      const to = num(v, "proposed_max_clusters") ?? num(ev, "proposed_max_clusters");
      if (from === undefined || to === undefined) return null;
      return { setting: "Max clusters", from: String(from), to: String(to) };
    }
    case "rightsize_underutilized": {
      const from = num(ev, "worker_count");
      const to = num(ev, "target_workers");
      if (from === undefined || to === undefined) return null;
      return { setting: "Workers", from: String(from), to: String(to) };
    }
    case "enable_serverless": {
      const from = str(ev, "warehouse_type");
      return { setting: "Warehouse type", from: from ? sizeName(from) : "Classic / Pro", to: "Serverless" };
    }
    case "idle_serving_endpoints": {
      const mc = num(ev, "min_concurrency");
      if (ev.provisioned_throughput === true)
        return { setting: "Endpoint", from: "provisioned, always on", to: "scale-to-zero or delete" };
      return mc ? { setting: "Min concurrency", from: String(mc), to: "0 (scale to zero)" } : null;
    }
    case "continuous_pipeline":
      return { setting: "Pipeline mode", from: "Continuous", to: "Triggered (scheduled)" };
    case "spot_fallback":
      return { setting: "Worker availability", from: "On-demand", to: "Spot with fallback" };
    case "interactive_to_job":
      return { setting: "Compute for scheduled runs", from: "All-purpose cluster", to: "Job clusters" };
    // idle_zombie_clusters: "terminate it" is an action, not a setting — the rule
    // title says it better than a forced before/after would.
    case "serverless_cost_optimized":
      return { setting: "Performance target", from: "Performance-optimized", to: "Standard" };
    case "jobs_compute_rightsize": {
      const wc = num(ev, "worker_count");
      if (str(ev, "symptom") === "driver_bound" && wc)
        return { setting: "Workers", from: String(wc), to: "0 (single node)" };
      return null;
    }
    case "gpu_wrong_runtime":
      return { setting: "Node type", from: "GPU", to: "CPU" };
    case "unused_data_jobs":
      return { setting: "Job schedule", from: "Active", to: "Paused" };
    // ---- rules promoted out of Labs (2026-09-23) ----
    case "warehouse_min_clusters": {
      const from = num(ev, "min_clusters");
      if (from === undefined) return null;
      return { setting: "Minimum clusters", from: String(from), to: String(num(ev, "proposed_min_clusters") ?? 1) };
    }
    case "job_no_new_input":
      return { setting: "Job trigger", from: "Schedule (cron)", to: "Table update" };
    case "unviewed_scheduled_dashboards":
      return { setting: "Dashboard refresh schedule", from: "Active", to: "Paused" };
    case "serving_provisioned_overcapacity":
      return { setting: "Scale to zero", from: "Off (always billed)", to: "On" };
    case "alert_hygiene": {
      const issues = Array.isArray(ev.issues) ? (ev.issues as string[]) : [];
      // Only the warm-warehouse case is a setting; erroring / unheard alerts are a
      // fix-or-delete decision the rule title states better than a before/after.
      if (!issues.includes("keeps_warehouse_warm")) return null;
      const sched = str(ev, "schedule");
      const stop = num(ev, "auto_stop_minutes");
      return {
        setting: "Alert schedule",
        from: sched ?? "frequent",
        to: stop && stop > 0 ? `every > ${stop} min` : "less often",
      };
    }
    // warehouse_keepalive_queries / job_task_retry_waste / unpruned_repeated_queries /
    // pipeline_failed_updates / sql_repeated_failures: the fix is in a client or the
    // code, not a setting — the `how` text says where to look.
    case "instance_pool_idle": {
      const n = num(ev, "min_idle_instances");
      return n !== undefined ? { setting: "Min idle instances", from: String(n), to: "0" } : null;
    }
    // ---- Labs ----
    case "job_runaway_no_timeout": {
      const s = num(ev, "recommended_timeout_seconds");
      if (s === undefined) return null;
      const cur = num(ev, "job_timeout_seconds");
      const hrs = (x: number) => (x >= 3600 ? `${(x / 3600).toFixed(1).replace(/\.0$/, "")} h` : `${Math.round(x / 60)} min`);
      return { setting: "Job timeout", from: cur ? hrs(cur) : "none", to: hrs(s) };
    }
    case "allpurpose_shape_mismatch": {
      const tgt = str(ev, "target_node_type");
      const cur = str(ev, "worker_node_type");
      if (tgt && cur) return { setting: "Worker node type", from: cur, to: tgt };
      return null;
    }
    default:
      return null;
  }
}

/** First sentence of a prose field — the lead the list views show as a teaser.
 *  Splits on sentence punctuation followed by a space and a capital/quote, so
 *  decimals ("12.1%") and abbreviations inside a sentence don't cut it short. */
export function firstSentence(text: string | null | undefined, max = 220): string {
  if (!text) return "";
  const t = text.trim();
  const m = t.match(/^(.+?[.!?])(?=\s+["'‘“A-Z(])/);
  const lead = m ? m[1] : t;
  return lead.length > max ? `${lead.slice(0, max - 1).trimEnd()}…` : lead;
}
