/** Normalize legacy recommendation prose at the presentation boundary.
 *
 * Older precomputed snapshots contain AI-style em/en dash separators. Keeping
 * this in the UI means those rows improve immediately, without waiting for the
 * next pipeline refresh. Numeric ranges keep a plain hyphen.
 */
export function cleanProse(value: string): string {
  return value
    .replace(/\s+[—–]\s+/g, "; ")
    .replace(/[—–]/g, "-");
}
