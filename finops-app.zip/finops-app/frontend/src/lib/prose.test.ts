import { describe, expect, it } from "vitest";
import { cleanProse } from "./prose";

describe("cleanProse", () => {
  it("removes long dash separators from legacy recommendation copy", () => {
    expect(cleanProse("Measured fact — recommended action – material trade-off"))
      .toBe("Measured fact; recommended action; material trade-off");
  });

  it("keeps ranges readable without Unicode dashes", () => {
    expect(cleanProse("5–10 minutes")).toBe("5-10 minutes");
  });
});
