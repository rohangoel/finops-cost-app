import { describe, expect, it } from "vitest";
import { savingsFor, totalFor } from "./price";

const base = {
  monthly_savings_usd: 1000,
  monthly_savings_low_usd: 800,
  monthly_savings_high_usd: 1200,
};
const contract = {
  ...base,
  price_basis: "contract" as const,
  monthly_savings_contract_usd: 780,
  monthly_savings_contract_low_usd: 624,
  monthly_savings_contract_high_usd: 936,
};
const fallback = { ...base, price_basis: "list" as const, monthly_savings_contract_usd: null };
const noData = { ...base, price_basis: null };

describe("savingsFor", () => {
  it("list basis always reads the list figures", () => {
    expect(savingsFor(contract, "list")).toMatchObject({ value: 1000, low: 800, basisUsed: "list", fellBack: false });
  });
  it("your rates uses the contract figure and its own band", () => {
    expect(savingsFor(contract, "contract")).toMatchObject({ value: 780, low: 624, high: 936, basisUsed: "contract" });
  });
  it("marks only a MEASURED fallback", () => {
    expect(savingsFor(fallback, "contract")).toMatchObject({ value: 1000, basisUsed: "list", fellBack: true });
    expect(savingsFor(noData, "contract").fellBack).toBe(false);
  });
  it("a zero contract figure is a real figure, not missing", () => {
    const zero = { ...contract, monthly_savings_contract_usd: 0 };
    expect(savingsFor(zero, "contract")).toMatchObject({ value: 0, basisUsed: "contract" });
  });
});

describe("totalFor", () => {
  it("blended total = contract part + list part", () => {
    const t = totalFor([contract, fallback, noData], "contract");
    expect(t.contractPart).toBe(780);
    expect(t.listPart).toBe(2000);
    expect(t.value).toBe(t.contractPart + t.listPart);
    expect([t.contractCount, t.listCount]).toEqual([1, 2]);
  });
});
