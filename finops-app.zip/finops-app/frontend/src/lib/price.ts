/**
 * The ONE money path for savings figures under the global price basis
 * ("List price" | "Your rates"). Components read a finding's savings through
 * `savingsFor` instead of `rec.monthly_savings_usd` so the switch applies everywhere.
 *
 * Rules: list figures are always complete; a contract figure exists only where the
 * backend's coverage gate passed (price_basis = "contract"). In "Your rates" mode a
 * finding without one stays at list and is flagged `fellBack` (the UI shows a small
 * "list" marker). Ranking never uses this — NBA order stays on list (decision D2).
 */

import type { Recommendation } from "../api/types";

export type PricingBasis = "list" | "contract";

type SavingsFields = Pick<
  Recommendation,
  | "monthly_savings_usd"
  | "monthly_savings_low_usd"
  | "monthly_savings_high_usd"
  | "price_basis"
  | "monthly_savings_contract_usd"
  | "monthly_savings_contract_low_usd"
  | "monthly_savings_contract_high_usd"
>;

export interface SavingsResult {
  value: number;
  low: number | null;
  high: number | null;
  /** The basis the figure is actually in. */
  basisUsed: PricingBasis;
  /** "Your rates" requested but this finding has no contract figure → shown at list. */
  fellBack: boolean;
}

export function hasContract(rec: Partial<SavingsFields>): boolean {
  return rec.price_basis === "contract" && rec.monthly_savings_contract_usd != null;
}

export function savingsFor(rec: SavingsFields, basis: PricingBasis): SavingsResult {
  if (basis === "contract" && hasContract(rec)) {
    return {
      value: rec.monthly_savings_contract_usd as number,
      low: rec.monthly_savings_contract_low_usd ?? rec.monthly_savings_contract_usd ?? null,
      high: rec.monthly_savings_contract_high_usd ?? rec.monthly_savings_contract_usd ?? null,
      basisUsed: "contract",
      fellBack: false,
    };
  }
  return {
    value: rec.monthly_savings_usd,
    low: rec.monthly_savings_low_usd,
    high: rec.monthly_savings_high_usd,
    basisUsed: "list",
    // Only a MEASURED fallback is marked: price_basis null = no contract data at all.
    fellBack: basis === "contract" && rec.price_basis === "list",
  };
}

/** Point savings in the chosen basis (the common case). */
export function savingsValue(rec: SavingsFields, basis: PricingBasis): number {
  return savingsFor(rec, basis).value;
}

export interface TotalResult {
  value: number;
  contractPart: number;
  listPart: number;
  contractCount: number;
  listCount: number;
}

/** Plain (non-deduplicated) sum across findings in the chosen basis, with its split.
 *  Headline totals come from the backend's scope-composed `priced` block instead. */
export function totalFor(recs: SavingsFields[], basis: PricingBasis): TotalResult {
  const out: TotalResult = { value: 0, contractPart: 0, listPart: 0, contractCount: 0, listCount: 0 };
  for (const r of recs) {
    const s = savingsFor(r, basis);
    out.value += s.value;
    if (s.basisUsed === "contract") {
      out.contractPart += s.value;
      out.contractCount += 1;
    } else {
      out.listPart += s.value;
      out.listCount += 1;
    }
  }
  return out;
}

export function pct(share: number): string {
  return `${Math.round(share * 100)}%`;
}
