# Tech stack & rationale

## Backend — FastAPI (Python)
- Async, typed, tiny; pydantic models double as the API contract.
- Reuses the Databricks connection pattern from `pocs/simple_table_editor`
  (`databricks-sql-connector`, OBO token, `/health`).
- Serves the built SPA as static files, so the whole app deploys as one
  Databricks App.

## Rule engine — a standalone Python package (`finops_rules`)
- Kept separate from the web app so the **scheduled precompute job** reuses the
  exact same rule logic (guaranteeing live/precompute parity).
- Plugin discovery via package walk → adding a rule never edits shared code.
- Rules are SQL (pushed to the warehouse) + pure-Python scoring (unit-testable).

## Frontend — React + TypeScript + Vite
- Chosen over Dash/Streamlit (the other PoCs) for **modern UX** and, crucially,
  a **modular component/hook/page structure** so multiple people/agents can work
  in parallel — the same motivation as the plugin rule engine on the backend.
- React Query for data fetching/caching; React Router for persona-aware routing.
- No heavyweight component library — a small custom CSS design system keeps the
  dependency surface minimal for a PoC. Icons are **Heroicons**
  (`@heroicons/react`, MIT, SVG-only, tree-shakable) — see `components/ResourceChip.tsx`
  for the resource-type icon mapping. TanStack Table / a component lib can be
  added later if the grids need virtualization at extreme scale.

## Data — Databricks system tables
- Account-wide, keyed by `workspace_id`, so multi-workspace is a `GROUP BY`.
- Dollars via `system.billing.usage × system.billing.list_prices`.

## Why two modes instead of one
- **Live** keeps the dev loop simple (no job to run) and is the reference
  execution path for a rule.
- **Precompute** is the only thing that scales to 100s of workspaces cheaply; the
  app then does a single scoped SELECT. A parity test keeps them honest.

## Testing
`pytest` with fixture rows (no warehouse needed). The parity test simulates both
sources over identical data. 103 tests today (14 rules + backend layers).
