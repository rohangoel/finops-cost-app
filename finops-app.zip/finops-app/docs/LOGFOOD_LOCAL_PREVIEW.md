# Running the app on Central Logfood data (internal SA preview)

> **Want the step-by-step local run?** See
> **[`LOCAL_CENTRAL_DEPLOY.md`](LOCAL_CENTRAL_DEPLOY.md)** for the current, mirror-free
> flow (account gate, cascading filters, workspace-scoped spend, the performance slice).
> This document is the background/reference on how central mode works and its known gaps.


How to run the FinOps app **locally, on a real customer's data**, using Databricks'
internal **Central Logfood** system tables instead of a customer-deployed app reading
their own `system.*` tables. This lets an SA explore a customer's cost profile without
deploying anything into the customer's workspace.

> **Internal only.** This reads `main.centralized_system_tables.*` in the logfood
> workspace, which aggregates system-table data across many customer accounts. Treat
> everything you see as customer-confidential. This is a *preview / analysis* setup, not
> a product feature — see [Known gaps](#what-would-make-this-a-real-feature) for what a
> productized "central mode" would need.

---

## TL;DR

1. Central Logfood stores system tables under a **flat namespace**:
   `system.<schema>.<table>` → `main.centralized_system_tables.<schema>_<table>`,
   and every table carries `account_id` (and usually `workspace_id`) so you scope to
   one customer with `WHERE account_id = '<uuid>'`.
2. The app expects the real `system` layout (`{catalog}.billing.usage`, …). Rather than
   refactor every query, we **mirror** one customer's data into a `system`-shaped set of
   schemas in a writable catalog, then point the app at that catalog (`FINOPS_CATALOG`).
3. Run the app in **`live` mode** against the mirror. It's the *real* rule engine and UI
   — no faked data.
4. Two central tables don't exist (`access.audit`, `access.table_lineage`), so two
   surfaces degrade in a known, graceful way.

Result: the actual dashboard, actual recommendations, actual numbers — for any customer
whose data is in Central Logfood.

---

## How Central Logfood differs from `system.*`

| | Customer's own `system` tables | Central Logfood |
|---|---|---|
| Namespace | `system.billing.usage` | `main.centralized_system_tables.billing_usage` |
| Schema shape | nested (`schema.table`) | flat (`schema_table`) in one schema |
| Scope | one account, one region | **all** accounts/regions in one table |
| Row filter | (none needed) | `account_id = '<uuid>'` per customer |
| `billing_list_prices` | keyed by workspace region | multi-account; **dedup + join on `account_id`** |
| Names/URLs | `system.access.workspaces_latest` | `main.certified.workspaces_latest` (has `salesforce_account_name`) |

The internal skill **`centralized-system-tables-translator`** codifies the mapping and is
the source of truth for the namespace rules. It corresponds to the Confluence page
"Central Logfood System Tables Reference".

### Tables present (verified)
`billing_usage`, `billing_list_prices`, `compute_clusters`, `compute_node_timeline`,
`compute_warehouses`, `compute_warehouse_events`, `lakeflow_jobs`,
`lakeflow_job_run_timeline`, `lakeflow_job_task_run_timeline`, `lakeflow_pipelines`,
`lakeflow_pipeline_update_timeline`, `query_history`, `serving_endpoint_usage`,
`serving_served_entities`, `access_workspaces_latest` — plus `compute_node_types`,
storage/marketplace tables the app doesn't use.

### Tables MISSING (and the impact)
| Missing table | App impact | Handling |
|---|---|---|
| `access.audit` | **Apps tab** can't join app lifecycle (deploy/start/stop/deployer) — and the whole apps query *errors* without a guard. `autotermination`'s optional notebook-activity signal (`use_audit_activity`, **off by default**) also can't run. | Set `FINOPS_NO_AUDIT=true` → the apps query drops the lifecycle join (lifecycle columns come back NULL, cost/config intact). Leave `use_audit_activity: false`. |
| `access.table_lineage` | `unused_data_jobs` rule can't run → shows as WARN on the Data Health page. | Nothing to do — the rule fails-and-skips; the amber "1 rule cannot run" banner is expected/correct. |

### Column gotchas (differ from the obvious guess)
- `lakeflow_pipeline_update_timeline` uses **`period_start_time`** (not `start_time`).
- `serving_endpoint_usage` uses **`request_time`** (there is no `usage_date`) — which the
  `idle_serving_endpoints` rule already reads, so it matches.
- `compute_warehouses` size column is **`warehouse_size`** (values `2X_SMALL`, `X_SMALL`,
  `SMALL`…`X_LARGE`, `2X_LARGE`…`5X_LARGE`), not `cluster_size`.

---

## Get it running locally

### Prerequisites
- Databricks CLI authed to logfood as a profile:
  `databricks auth login --host https://adb-2548836972759138.18.azuredatabricks.net --profile logfood`
- **Read access to `main.centralized_system_tables.*`** — request it via **Opal**: grant
  **`datasets.main.centralized_system_tables.read`** at [go/opal/tile](https://go/opal/tile)
  (search for that group). It's a time-bounded grant, so you'll re-request when it expires.
  You'll also want read on `main.certified.workspaces_latest` (for names + the
  Salesforce-account → `account_id` lookup); request the corresponding `certified` dataset
  group the same way if you don't already have it.
- A SQL warehouse in logfood you can use (e.g. a shared X-Large). **These are heavily
  contended** — see [Operational notes](#operational-notes).
- A **writable catalog** for the mirror. Your personal home catalog
  (`home_<you>`, 30-day retention) works and needs no grants.
- A Python env with the app's deps (fastapi, databricks-sql-connector, jinja2, uvicorn,
  pydantic, python-dotenv). **PyPI is usually blocked on the corp network and the internal
  mirror needs SSO**, so if `make install` can't reach an index, reuse an existing venv
  that already has these (the deps are common). `pyarrow` is **optional** (see the
  ARRAY/JSON note below).

### Step 1 — find the customer's `account_id`
```sql
-- by Salesforce account name
SELECT DISTINCT account_id, salesforce_account_name
FROM main.certified.workspaces_latest
WHERE lower(salesforce_account_name) LIKE '%<customer>%';
```
A customer may map to several `account_id`s — pick the one whose workspaces/billing match.
(You can also get it from the customer's own account console.)

### Step 2 — mirror the customer into a `system`-shaped catalog
For each system schema, create it in your catalog and `CREATE OR REPLACE TABLE` from the
central table, **filtered to the customer** (and a lookback window to keep timeline tables
small). Scoping by `account_id` alone captures **all** the customer's workspaces; add
`workspace_id IN (...)` to focus on a subset.

```sql
CREATE SCHEMA IF NOT EXISTS home_me.billing;   -- and compute, lakeflow, query, serving, access
-- account-global fact, windowed:
CREATE OR REPLACE TABLE home_me.billing.usage AS
  SELECT * FROM main.centralized_system_tables.billing_usage
  WHERE account_id = :acct AND usage_date >= date_sub(current_date(), 30);
-- prices: whole account (small), used with the account_id join:
CREATE OR REPLACE TABLE home_me.billing.list_prices AS
  SELECT * FROM main.centralized_system_tables.billing_list_prices WHERE account_id = :acct;
-- …repeat for the 13 other tables (see the mapping + column gotchas above).
```
Windowing columns per table: `billing_usage` → `usage_date`; `compute_warehouse_events` →
`event_time`; `compute_node_timeline`, `query_history` → `start_time`;
`lakeflow_*_timeline` and `lakeflow_pipeline_update_timeline` → `period_start_time`;
`serving_endpoint_usage` → `request_time`. Entity/latest tables
(`compute_clusters/warehouses`, `lakeflow_jobs/pipelines`, `serving_served_entities`,
`access_workspaces_latest`) take no window. **Skip** `access.audit` and
`access.table_lineage` (they don't exist centrally).

> The heavy tables are `compute_node_timeline` and `query_history` — filter them by both
> `account_id` and the window, and expect them to be the slow steps.

### Step 3 — point the app at the mirror
`.env`:
```bash
FINOPS_COMPUTE_MODE=live
FINOPS_AUTH_MODE=obo
DATABRICKS_SERVER_HOSTNAME=adb-2548836972759138.18.azuredatabricks.net
DATABRICKS_WAREHOUSE_ID=/sql/1.0/warehouses/<warehouse_id>
DATABRICKS_CONFIG_PROFILE=logfood      # SDK uses this OAuth profile — no PAT needed
FINOPS_CATALOG=home_me                 # the mirror catalog
FINOPS_LIVE_LOOKBACK_DAYS=30
FINOPS_DEV_ROLE=platform_admin         # see all workspaces
FINOPS_NO_AUDIT=true                   # central has no access.audit (see gaps)
FINOPS_LIVE_CACHE_TTL=43200            # cache rule results 12h (see caching note)
```

> **`thresholds.yaml` wins over `FINOPS_CATALOG`.** `live_source` reads the catalog from
> `rules/finops_rules/config/thresholds.yaml` first (`catalog: system`), so you must also
> set `catalog: home_me` there, or the rules will hit `system.*` and fail with
> INSUFFICIENT_PRIVILEGES. (A productized central mode should remove this override.)

### Step 4 — run
```bash
PYTHONPATH=rules:backend <python> -m uvicorn finops.main:app --port 8000
```
The backend serves the **pre-built** SPA from `backend/finops/static/`, so just open
**http://127.0.0.1:8000** — no separate Vite server needed. (Run `make build` first only
if you changed the frontend.)

### Step 5 — warm the cache (optional but recommended)
The first hit of each surface recomputes live (tens of seconds to a few minutes for a big
account). `curl` each endpoint once so the browser is instant afterwards:
`/api/recommendations` (do this first — it populates the shared cache),
`/api/recommendation-groups`, `/api/spend`, `/api/apps`, `/api/genie`,
`/api/serverless-case`, `/api/data-health`, and any `/api/recommendation-groups/<id>` you
want to open directly.

---

## Non-customer-specific lessons

### Auth
- **No PAT required.** With `DATABRICKS_CONFIG_PROFILE=logfood` set, the app's
  `get_connection` SP path authenticates the SQL connector via the SDK
  (`cfg.authenticate`) using the CLI OAuth profile. The Python SQL connector is reliable;
  the **`databricks api` CLI submission itself intermittently hangs** under load — prefer
  the Python connector for ad-hoc queries.

### The app was already ~90% ready for a mirror
The whole data layer threads a single `catalog` variable (`{catalog}.schema.table`), so
pointing it at a `system`-shaped mirror needs **zero rule changes** — only that
`thresholds.yaml` reads its own `catalog:` (the one override to change). A true "central
mode" would instead introduce a table-name resolver so queries can emit the flat
`schema_table` form directly and drop the mirror step.

### pyarrow changes result types
`databricks-sql-connector` ≥ 4.0 returns ARRAY/MAP/STRUCT columns as **native Python
objects only when `pyarrow` is installed**; without it they come back as **JSON strings**,
which breaks viz code that iterates them (e.g. `queries_by_hour`). Because pyarrow is often
unavailable here, `sql_client.py` has a guarded fallback (`_DecodingConnection`) that
JSON-decodes only the cells the server declares as complex types — leaving the app's own
`to_json(...)` string columns untouched. If you install pyarrow, the fallback disables
itself.

### Caching / "loads forever"
`live` mode recomputes **all rules per request** — the recommendation service is *not* a
process singleton. Two independent cache layers matter:
- the rule-result cache (`FINOPS_LIVE_CACHE_TTL`, env var, off by default), and
- per-source caches in `spend/genie/apps_source.py` (300s) and `fleet_source.py` /
  `health_service.py` (900s).

When **any** of these lapse mid-session, the next page silently recomputes and the browser
appears to hang. For a browse-later preview, set a long `FINOPS_LIVE_CACHE_TTL` and (for
this preview) the source TTLs are bumped too. For anything durable, use **precompute mode**
(snapshot to a Delta table → reads are always fast single SELECTs, no expiry) rather than
fighting cache windows.

### Performance
The central timeline tables are enormous (all accounts). Always filter by `account_id`
**early**, and expect `compute_node_timeline` / `query_history` to dominate build time.
A single-workspace mirror is small and fast; a whole large account's `query_history` can
take minutes to copy.

### A real cost finding about the estate (not app-specific)
While hunting for a demo warehouse we found: **large classic SQL warehouses with auto-stop
disabled are effectively extinct among customers.** Across all accounts only a handful of
2XL–4XL no-auto-stop classic warehouses exist, and none had query activity (dormant
shells). Customers have moved to serverless (auto-stops by default) or already set
auto-stop on big classic warehouses. The addressable warehouse waste has shifted to
**serverless auto-stop tightening** and **rightsizing**, not "turn on auto-stop for a giant
warehouse."

---

## Operational notes
- **Shared logfood warehouses are heavily contended.** Statement queues fill up; a submit
  can sit for minutes or bounce with "queue full". Submit async (`wait_timeout=0s`) and
  poll, or just use the Python connector with a long socket timeout. Don't block a thread
  waiting.
- **Home-catalog retention is 30 days** — the mirror auto-expires, which is fine for a
  preview. Rebuild when you come back.
- **Ingestion lag:** your own queries won't appear in the centralized `query_history` for
  hours, so you can't measure your preview's own cost from it same-day. In practice the
  cost is negligible: the shared warehouses are always-on and billed for other users, so
  a mirror build + browse adds no material incremental spend.

## What would make this a real feature
The preview leans on 4 uncommitted local edits (a JSON-decode fallback, a live-result
cache, a `FINOPS_NO_AUDIT` apps guard, and the `thresholds.yaml` catalog). To productize a
"central mode" cleanly:
1. A **table-name resolver** so rules/queries emit `catalog.schema_table` (flat) under a
   `FINOPS_TABLE_NAMESPACE=central` flag — removing the mirror step and the
   `thresholds.yaml` override.
2. **`account_id` scoping** as a first-class filter (fold into `region.py`, keyed by
   `FINOPS_ACCOUNT_NAME`/id) instead of the mirror's `WHERE`.
3. `billing_list_prices` **dedup + `account_id` join** in the price macro.
4. Names/URLs from `main.certified.workspaces_latest`.
5. Make `FINOPS_NO_AUDIT` and the lineage-rule disable automatic when central tables are
   detected; ship the pyarrow-absent decoder unconditionally.

## Next steps / open work

### 1. Discover the *full* logfood surface for a customer
We only mirrored the 15 tables **this app already uses**. Central Logfood (and the wider
logfood metastore) holds much more about a customer than `centralized_system_tables` —
worth an explicit discovery pass before deciding what else the app could surface:
- Enumerate everything available: `SHOW SCHEMAS IN main`, `SHOW TABLES IN
  main.centralized_system_tables`, and the `main.certified.*` / `main.fin_live_gold.*`
  schemas the internal dashboards use (e.g. `paid_usage_metering` for **actual, discounted**
  cost vs. the list price the app currently shows — see the translator skill's discount CTE).
- For a chosen `account_id`, profile what's actually populated: which SKUs/products, how
  many workspaces, serverless vs classic mix, which rules *could* fire — so we know the
  customer's cost story before opening the app, and spot data the app doesn't yet use
  (storage/predictive-optimization tables, marketplace, zerobus, node_types for exact
  DBU/VM rates, etc.).
- Decide whether "actual cost" (discounted, from `fin_live_gold`) should be an internal-mode
  option alongside list price — it's the number the customer actually pays.

### 2. Find replacements for the lost `access.*` signals
The two missing central tables cost the app real signal. Before shipping central mode,
hunt for substitutes:
- **`access.audit` (Apps lifecycle: deploy/start/stop/deployer)** — check whether logfood
  exposes an audit slice anywhere (a different table name, a certified view, or a
  telemetry/eventlog source) that carries `service_name='apps'` events. If nothing exists,
  fall back to **billing-derived proxies** already present: `first_seen_date` /
  `last_billed_date` from `billing_usage` approximate "last active" and staleness, and the
  app can relabel the Apps tab to lead with those instead of deploy history. Note
  `last_deployed_by` (the identity) has **no** substitute without the audit log.
- **`access.audit` (autotermination notebook-activity signal, `use_audit_activity`)** —
  same hunt; if unavailable, the rule still works on CPU + job-task activity (the default),
  it just can't credit light interactive notebook use. Confirm that's acceptable or find
  an alternate activity signal.
- **`access.table_lineage` (drives `unused_data_jobs`: writes with no reads)** — look for a
  lineage or table-metrics source centrally. `storage_table_metrics_history` (present in
  the central schema, unused by the app) carries per-table `active_bytes` / read/write-ish
  metrics and might reconstruct a weaker "written but never read" proxy — worth evaluating
  as a partial replacement so the rule isn't simply disabled.
- General approach: for each blocked rule, decide **replace, proxy, or disable** — and make
  the Data Health page say *why* a rule is off (missing table X, no substitute) rather than
  just "cannot run".
