# FinOpsApp docs

- [ARCHITECTURE.md](ARCHITECTURE.md) — system design, layers, request flow, dual modes
- [ADDING_A_RULE.md](ADDING_A_RULE.md) — **start here to extend the app**: how to add a cost-saving rule
- [DATA_MODEL.md](DATA_MODEL.md) — the recommendation schema contract (4 mirrors)
- [AUTH_AND_SCOPING.md](AUTH_AND_SCOPING.md) — OBO vs service principal, persona scoping security boundary
- [TECH_STACK.md](TECH_STACK.md) — framework choices & rationale
- [DEPLOYMENT.md](DEPLOYMENT.md) — local dev, precompute job, and app deployment
- [GUI_DEPLOYMENT.md](GUI_DEPLOYMENT.md) — deploying via the workspace UI (no CLI/git); packaging playbook + lessons learned from a live customer deploy
- [GENIE_PANEL.md](GENIE_PANEL.md) — optional embedded "Ask Genie" panel (feature-toggled PoC)
- [LOGFOOD_LOCAL_PREVIEW.md](LOGFOOD_LOCAL_PREVIEW.md) — **internal SAs**: run the app locally on a customer's Central Logfood data (no customer deploy); mirror setup, gaps, and lessons

See also [../AGENTS.md](../AGENTS.md) for the contribution rules and boundaries.
