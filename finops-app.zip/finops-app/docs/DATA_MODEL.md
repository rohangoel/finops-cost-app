# Data model — the recommendation contract

One recommendation is described by a single schema with **four mirrors that must
stay in sync**. Changes are **additive only** (append columns; never rename/repurpose).

| Mirror | File |
|--------|------|
| Producer (rule output) | `rules/finops_rules/contract.py` → `RuleFinding` |
| API model (source of truth) | `backend/finops/models/recommendation.py` |
| Delta table (precompute) | `precompute/ddl/finops_recommendations.sql` |
| TypeScript (UI) | `frontend/src/api/types.ts` |

## Columns
| Column | Type | Meaning |
|--------|------|---------|
| `recommendation_id` | STRING | `sha256(rule_id\|workspace_id\|resource_id\|snapshot_date)[:32]` — idempotent key |
| `snapshot_date` | DATE | day the recommendation was computed |
| `rule_id` / `rule_version` | STRING | which rule + its logic version (lets you re-score history) |
| `rule_title` | STRING | denormalized for display |
| `category` | STRING | `compute` \| `sql` \| `jobs` \| `serving` \| `pipelines` \| `governance` |
| `workspace_id` / `workspace_name` | STRING | scoping key + label |
| `workspace_url` | STRING | base URL of the resource's own workspace, from `system.access.workspaces_latest`; the UI deep-links to this host (the account spans many workspaces, each on its own host) |
| `resource_type` | STRING | `cluster` \| `warehouse` \| `job` \| `serving_endpoint` \| `pipeline` |
| `resource_id` / `resource_name` | STRING | the exact resource |
| `resource_owner` / `resource_creator` | STRING | who owns / created the resource, resolved at precompute time from `billing.usage.identity_metadata` (`owned_by`/`run_as` → owner, `created_by` → creator). **Nullable** — some resource types carry no identity on their usage rows; an unknown owner never suppresses the finding. See `backend/finops/data/owner_sql.py`. |
| `why` | STRING | why it wastes money (human explanation) |
| `how` | STRING | the action to take |
| `monthly_waste_usd` | DECIMAL(12,2) | the resource's own billed spend / month (see "Total workspace spend" below — this is NOT an account-level waste figure) |
| `monthly_savings_usd` | DECIMAL(12,2) | **point** estimate of $ saved if applied (kept for compatibility) |
| `monthly_savings_low_usd` | DECIMAL(12,2) | conservative lower bound; the **only** value the booked headline totals, and only for `savings_status='bookable'` rows. `<= monthly_savings_usd`. Defaults to the point estimate until a rule widens the band |
| `monthly_savings_high_usd` | DECIMAL(12,2) | upper scenario; shown for range context, **never** booked. `>= monthly_savings_usd` |
| `savings_status` | STRING | `bookable` (its `low` is booked into the headline lower bound) \| `estimated` (shown & rankable, contributes 0 to the booked total) \| `advisory` (no dollars booked). Phase 0.3 classification (see `docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md`): currently `bookable` = `cluster_autotermination` + `idle_serving_endpoints` (zero-traffic tier only) + `interactive_to_job` (job-DEDICATED clusters only — per-finding, FIN-010); most others are `estimated` (right-size / auto-stop family, plus `interactive_to_job`'s shared-cluster default tier, `idle_zombie_clusters` while a cluster is still running idle, and `failing_jobs` REPAIR findings — per-finding, FIN-017/FIN-020) or `advisory` (photon, spot, (un)used jobs, serverless, governance, plus `idle_zombie_clusters` for a STOPPED cluster whose forward saving is $0, and `failing_jobs` RETIRE findings for a job that never succeeded — booked only on an owner/obsolescence decision — per-finding, FIN-017/FIN-020); `idle_apps` is disabled entirely. Rules return to `bookable` as their counterfactuals are rebuilt in Phases 1-3 |
| `effort_band` / `effort_score` | STRING / INT | trivial/low/medium/high and its weight (1/2/3/5) |
| `priority` | STRING | HIGH \| MEDIUM \| LOW |
| `nba_score` | DOUBLE | Next-Best-Action rank = `savings / effort_score × priority_mult` |
| `evidence` | STRING (JSON) | raw metrics that triggered the rule |
| `computed_at` | TIMESTAMP | run timestamp |
| `price_basis` | STRING | `contract` (has a contract-rate figure) \| `list` (contract data existed, but < `contract_min_coverage` of this resource's usage had a contract price — shown at list with a marker) \| NULL (no contract data this run). See "Contract rates + cloud VM cost" below |
| `contract_price_coverage` | DOUBLE | share (0–1) of the resource's usage priced by `system.billing.account_prices` (and list) |
| `monthly_savings_contract_usd` / `_low_usd` / `_high_usd` | DECIMAL(12,2) | the savings point / band at contract rates; NULL below the coverage gate |
| `cloud_cost_30d_usd` | DECIMAL(12,2) | the resource's classic cloud VM cost (`system.billing.cloud_infra_cost`), NULL without data |
| `monthly_cloud_savings_usd` | DECIMAL(12,2) | the cloud VM saving of the action — a separate layer, **never** added to the Databricks dollars |
| `finding_key` | STRING | `sha256(rule_id\|workspace_id\|resource_type\|resource_id)[:32]`, lowercase hex. Snapshot-independent (unlike `recommendation_id`), one per rule × resource, so a link built from it still works tomorrow. StopTheLeak recomputes it and compares daily: **don't change the formula**. See "Owner routing" below |
| `workspace_owner` | STRING | lowercased, most common email in the billing custom tag `FINOPS_WORKSPACE_OWNER_TAG` (default `Owner`) on the workspace's usage over the lookback. NULL when the tag is absent, turned off, or in central mode |
| `resource_owner_kind` | STRING | `user` (owner is an email) \| `service_principal` (a UUID application id) \| `unknown` |
| `notify_recipient` | STRING | lowercased email the finding is routed to: the object owner if it's a user, else the workspace owner, else NULL (nobody; not shown in anyone's My findings) |
| `recipient_source` | STRING | `object_owner` \| `workspace_owner` \| NULL — why `notify_recipient` is who it is |

## Owner routing — `finding_key`, `notify_recipient` (My findings, StopTheLeak)
**Core vs optional.** `finding_key` and `?focus=<finding_key>` links are core: always
computed, always resolvable. The routing columns are always in the schema (so it
never changes with a flag) and always routed on the object owner. Everything else
is the **optional StopTheLeak integration**, off by default and not needed to run
the app: the My findings tab + API and recipient access to resource pages
(`FINOPS_STOPTHELEAK_ENABLED`), the workspace-owner tag lookup (bundle variable
`workspace_owner_tag`, default `""`), and votes / opt-out (`FINOPS_FEEDBACK_ENABLED`
plus Lakebase, and the optional `psycopg` extra). `deploy/config.env`:
`STOPTHELEAK_ENABLED`, `FEEDBACK_ENABLED`.

StopTheLeak (a separate project) emails resource owners about their findings and
collects a vote on each; the app's **My findings** tab shows the same set. Both read
who a finding belongs to from these columns, so they can't disagree. The definitions
live in `backend/finops/routing.py`, twice: `route()` in Python (live/demo mode, old
snapshots) and `ROUTING_SQL`, which the pipeline applies **after** its owner join
(the scoring UDF sees `resource_owner` before billing fills it). `test_routing.py`
runs the SQL on SQLite and checks it agrees with `route()` case for case.

* **Routing rule:** object owner if it's an email → else the workspace owner → else
  nobody. Only 23 % of findings have an email owner (measured on
  `fevm-finops-stable-us`, 2026-09-28); most of the rest are owned by a service
  principal (FEVM's provisioning SP "owns" every Serverless Starter Warehouse).
  Workspace admins inherit CAN_MANAGE on SP-owned warehouses, so the workspace owner
  can fix them. With the workspace owner, 7,534 of 8,114 findings have a recipient.
* **Workspace owner** (`data/workspace_owner_sql.py`): FEVM stamps an `Owner` tag on
  every billing row, single-valued in 99 % of workspaces. A per-workspace map
  (one row per workspace), broadcast-joined in the pipeline. Ties between two
  values break on the value, so the result is stable run to run (StopTheLeak's
  `v_workspace_owner` doesn't break ties). Tag key: bundle variable
  `workspace_owner_tag` (pipeline conf `finops.workspace_owner_tag`); `""`, the
  default, skips the lookup (no extra billing scan, `workspace_owner` NULL).
  `deploy.sh` passes `Owner` when `STOPTHELEAK_ENABLED=yes`.
* **Old snapshots** without these columns still load: the model derives
  `finding_key` and routes on `resource_owner` alone.
* **Access:** `/api/my-findings` and the recipient path into
  `/api/recommendation-groups/{id}` take the email **only** from
  `X-Forwarded-Email`. A recipient without workspace scope sees only the findings on
  that resource that are routed to them. Tests: `test_my_findings.py`.
* **Deep links:** `/resources/<group_id>?focus=<finding_key>`; `focus` still accepts
  a `recommendation_id` for old links.

### Votes and the email opt-out (Lakebase, StopTheLeak-owned)
Behind `FINOPS_STOPTHELEAK_ENABLED` **and** `FINOPS_FEEDBACK_ENABLED` (either off =
no vote buttons, no Postgres connection, no `psycopg` needed).
The store is StopTheLeak's Lakebase database, attached as the app database resource
`feedback-db`: `ops.feedback` (append-only votes) and `ops.opt_outs`. The app SP's
Postgres role needs `USAGE ON SCHEMA ops`, `SELECT, INSERT` on both tables, and
`DELETE` on `ops.opt_outs` (undoing an opt-out). The DDL the tests run is
`backend/finops/tests/feedback_ddl.sql`, a copy of StopTheLeak
`docs/FINOPS_APP_CONTRACT.md` §3/§5.

* `POST /api/feedback`: only the finding's recipient may vote (others get 403 if
  they can see it, 404 if not). `voter_email`, `observation_date` (the finding's
  `snapshot_date`), `rule_id` and `voter_relation` (`recipient_source`) are set
  server-side; the body carries verdict, reason codes, $ assessment, free text,
  snooze (30/90 days, `valid_cannot_fix` only), channel (`app` | `email_link`) and a
  per-click UUID stored as `idempotency_key = 'app|<uuid>'`.
* Insert only: `ON CONFLICT (idempotency_key) DO NOTHING`; a changed vote is a new
  row with `supersedes_id` = the voter's previous row on that `finding_key`. "You
  said: …" is the latest row per (`finding_key`, `voter_email`). Votes never hide a
  finding.
* Confirm links (`…?focus=<key>&verdict=<v>&reason=<text>`) open the vote form
  prefilled; nothing is written until Confirm (`channel='email_link'`). An unknown
  verdict is ignored and the reason is capped at 500 characters and shown as text.
* Opt-out: `DELETE /api/email-preference/weekly-email` inserts
  `(email, 'all')` into `ops.opt_outs`; `PUT` removes it. The email footer links to
  `/my-findings#email`.
* Tests need a Postgres: `FINOPS_TEST_PG_DSN=postgresql://postgres@localhost:5432/postgres`
  (each test creates and drops its own database); they skip without it.

## Contract rates + cloud VM cost
Capability-gated (`finops_rules/price_basis.py`): each run probes
`billing.account_prices` (unexpired rows in the currency) and `billing.cloud_infra_cost`
(rows in the window). Absent/empty/ungranted ⇒ the flags are off and every rule's SQL
renders **byte-identically** to the list-only SQL; central mode is always off.

* **List stays the complete, ranking basis.** Rules compute list savings exactly as
  before; NBA order never changes with the basis (D2).
* **Contract figures are derived centrally.** The SQL macros (`contract_cost_cols`,
  `contract_price_join`) emit two scale-invariant ratios per resource —
  `contract_ratio` (contract $ / list $ over doubly-priced usage) and
  `contract_price_coverage` — and the engine scales point/low/high by the ratio
  (`Rule.contract_pricing = "ratio"`). Price-gap rules (`interactive_to_job`) price both
  SKUs at contract rates themselves (`"counterpart"`); $0 rules opt out (`"none"`).
  `enable_serverless` is counterpart but prices from configured tier rates, so it has
  no contract figure yet (shown at list with the marker).
* **Coverage gate:** a contract figure only when coverage ≥ `contract_min_coverage`
  (0.95, `thresholds.yaml`). A total at "Your rates" is therefore BLENDED (contract
  where available, list otherwise) and is always shown with its split and a coverage chip.
* **Cloud VM** (`Rule.cloud_savings`): `proportional` = cloud cost × (list savings /
  list cost); `full` = the whole classic VM (moving to serverless). Separate KPI only (D3).
* The global `pricing_mode: effective` is retired (it would contradict per-finding bases).
* Aggregates: `AccountOverview.priced` / `WorkspaceDetail.priced` (`PricedTotals`),
  `RecommendationGroup.monthly_savings_contract_usd`, `/api/pricing` (`PricingSummary`,
  drives the top-bar switch; `default_basis` = contract only at ≥ 95 % coverage, D1).
* **Not yet validated on real contract data** — no reachable account has rows in either
  table (plan risk R1). Treat contract figures as preview.

## Minimum observation window — "too new to judge"
Every savings figure is a *sample* extrapolated to a month, which is only
meaningful once the sample is representative. A cluster created yesterday
afternoon that idled for six hours is statistically indistinguishable from one
that has idled for a month, so recommending "terminate this zombie" on that
evidence is sampling noise, not a finding.

Each rule's SQL therefore emits **`observed_days`** — distinct calendar days the
resource was seen *active*, measured on that rule's own primary evidence source
(node-timeline samples for clusters, `query.history` for warehouses, run/write
events for jobs) — and every `score()` calls
`finops_rules.history.insufficient_history(row, ctx)` **first**, before any
pricing, suppressing rows below the bar.

- Threshold: **`min_observation_days`** (default **5**) at the *top level* of
  `config/thresholds.yaml`. Engine-wide, not per-rule: "too new to judge" is a
  property of the resource and its data, not of the criterion being applied.
- **Distinct days, not a contiguous streak** — a weekday-only resource observed
  Mon–Fri has five days of solid evidence; requiring an unbroken run would
  suppress exactly the well-understood resources we most want to report on.
- Clamped to `lookback_days` at runtime, since a 3-day window could never yield 5
  observed days. Live mode's window is floored at the minimum for the same reason.
- A **missing** `observed_days` (older snapshot, or a rule predating the guard)
  reads as *unknown → don't block*, so the column can never silently empty the app.
- The sample size is surfaced, not just enforced: `observed_days` /
  `min_observation_days` land in `evidence`, and `data_basis` states them in prose.
- `unused_scheduled_jobs` is deliberately exempt — it fires on the *absence* of
  runs, so its `min_days_since_last_run` (30) already *is* a history requirement.

`tests/test_history.py` pins both halves: each guarded rule must suppress an
otherwise-scoring row with `observed_days=1`, and every rule's rendered SQL must
contain `observed_days` or be listed as exempt (an omission would leave the guard
inert and silent).

## Savings, effort, and NBA
- **Savings $**: computed per-rule in `score()` from `usage_quantity × list_prices`
  attributed to the resource, normalized to a 30-day month (`pricing.to_monthly`).
- **Effort score**: `EffortBand` → numeric via `config/effort.yaml` (trivial 1 …
  high 5), so effort is comparable across rules.
- **NBA score** (`services/nba_ranker.compute_nba`): `savings / effort_score`,
  times a priority multiplier (HIGH 1.25 / MEDIUM 1.0 / LOW 0.8). Stored so live
  and precompute rank identically; multipliers/effort weights are config, so the
  tradeoff is re-tunable without recompute.

## The `evidence` JSON — "show the data"
`evidence` is a free-form JSON blob, so it extends **without a schema migration**.
Beyond the raw trigger metrics, rules populate these standardized keys
(builders in `rules/finops_rules/evidence.py`, TS types in `api/types.ts`):

| Key | Meaning |
|-----|---------|
| `confidence` | `high` \| `medium` \| `low` — how *directly* platform data backs the estimate, driven by which tables were available (not by dollar size). E.g. cluster right-size reads per-minute CPU (`high`); warehouse right-size has no CPU signal and is inferred from query concurrency (`low`). Rendered as a pill on the detail page. |
| `data_basis` | One honest sentence: which system tables backed it, the lookback, and where we rounded down. Shown verbatim under the chart. |
| `data_warning` | *Optional.* The rule's own statement that the evidence may not show what it seems to — e.g. `idle_serving_endpoints` on an endpoint that has **never** logged a request, where zero traffic can't be told apart from usage tracking being off. Rendered as a warning callout ABOVE the action on the detail card plus an "Unverified" tag on list rows. A rule setting it should also lower confidence and not book the saving. |
| `viz` | A compact, self-describing chart payload the frontend switches on via `viz.kind`. Rendered by `components/charts/UsageTimeline.tsx`. |

`viz.kind` values today:
- **`hour_heatmap`** — day×hour grid of resource state (`0` stopped / `1` warm+serving / `2` warm+idle); used for warehouse auto-stop. Carries `reclaimable_hours`.
- **`burst_compare`** — query-load series + `warm_floor`; classic-vs-serverless comparison. Carries `idle_pct`, `cold_start_s`.
- **`cpu_area`** — per-minute CPU series + `p95`; cluster idle / right-size (unused headroom shaded).
- **`cluster_daily`** — per-day active vs idle hours across the lookback; cluster idle / auto-termination.
- **`job_runs`** / **`write_no_read`** / **`wh_rightsize`** — the G1/G2/G3 rule charts.
- **`autostop_tradeoff`** — the serverless auto-stop *decision*: the warehouse's idle-gap histogram, every candidate auto-stop value with what it reclaims vs the extra restarts/day it introduces (and whether it was rejected), and the hourly query rhythm. This is what makes the recommended value auditable instead of asserted.
- **`cluster_resources`** — multi-metric cluster utilization (CPU, memory, swap, I/O wait, network) on one axis, plus `cluster_kind` / `node_type` / `worker_count`. CPU alone cannot distinguish "oversized" from "memory-bound" or "I/O-starved".

A finding may carry **more than one chart**: `viz` is the primary one and the
optional `viz_extra` array holds additional charts rendered after it (the cluster
rules use this to show both "when did it run" and "what was it doing"). `viz_extra`
is additive — every existing consumer of `viz` is unaffected.

The demo source (`data/demo_source.py`) and the live rule `score()` build these
through the **same** builders, so the charts render identically offline and in
production. Keep payloads small — they live inside the `evidence` column.

## The output table
Written by the **SDP pipeline** (`precompute/pipeline.py`), which is the single
precompute backend and owns all three of its output tables. The app reads the
latest `snapshot_date`.

**It is a MATERIALIZED VIEW, not a Delta table** — that is what `@dlt.table`
creates, and it has two consequences worth knowing before you touch this:

* **No day-over-day history.** An MV is fully recomputed on each pipeline update,
  so the table holds *only the current* `snapshot_date`. The old imperative job
  appended a partition per day via `replaceWhere`; that history is gone. Nothing in
  the app relies on it today, but a trend chart over snapshots would need a real
  Delta sink (an `append`-mode `@dlt.table`, or a downstream table fed from the MV).
* **Delta-only writes fail against it.** `precompute/writer.py`'s `replaceWhere`
  overwrite raises `DELTA_NOT_A_DELTA_TABLE`, which is exactly why the legacy job is
  now PAUSED (see `precompute/databricks.yml`). Rolling back to that job means
  dropping the MVs and recreating real Delta tables from the DDL files first.

`snapshot_date` is still the read key and the DDL files still document the contract
(and are the fixture for `precompute/tests/test_contract_schema.py`), but
`deploy.sh` no longer creates these tables — pre-creating them makes the pipeline
fail to materialize.

## Total workspace spend — `finops_workspace_spend`
The recommendation table only knows about resources a rule flagged, so it cannot
answer *"what does this workspace cost?"* — the figure a platform admin anchors on.
A sibling table (DDL: `precompute/ddl/finops_workspace_spend.sql`) carries the
whole billed spend per workspace over the lookback window, plus a `by_sku` JSON
breakdown and the serverless/classic split (which the About Serverless view uses).

| Column | Meaning |
|--------|---------|
| `snapshot_date` / `workspace_id` | partition + scoping key |
| `total_spend_usd` / `monthly_spend_usd` | window spend, and the same normalized to 30 days so it is comparable with the rules' monthly savings |
| `total_dbus` | usage quantity behind that spend |
| `by_sku` | JSON `[{sku_group, spend_usd, dbus}]`, biggest first |
| `serverless_spend_usd` / `classic_spend_usd` | how much of the estate is already serverless |
| `total_spend_contract_usd` | BLENDED spend at contract rates where priced, list otherwise (NULL without contract data) |
| `contract_priced_share` | list-$ share of `total_spend_usd` that had a contract price — always shown with the blended figure |
| `total_cloud_cost_usd` | classic cloud VM cost (`billing.cloud_infra_cost`); never added into the DBU spend |

### The breakdown groups on `billing_origin_product`, not `sku_name`
`by_sku` is named for history; the grouping key is the **product**, and that matters:
**Databricks Apps bill under `PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_<REGION>`** — a
SKU whose name contains no hint of "app". So do Vector Search, Lakebase and Model
Serving variants. Grouping on SKU-name substrings (what this did originally) pooled
all of them into a catch-all `'Serverless (other)'` bucket, which on a real account
was the **single largest line item** — $272k/30d, 39% of spend, unlabelled. A
breakdown whose biggest row is "other" explains nothing.

`_SKU_GROUP_SQL` therefore keys on `billing_origin_product` and falls back to
`initcap(billing_origin_product)` for a product Databricks adds later, so a new
surface appears as itself the first time it bills instead of vanishing into "Other".
`sku_name` is still used for the serverless/classic distinction **within** a product
(a serverless and a classic SQL warehouse share the product `SQL`), and for the
`serverless_spend_usd` / `classic_spend_usd` split, which is about compute type
rather than product.

**Read path** (`data/spend_source.py`): the snapshot table first; a **live
`system.billing.usage` aggregate** as a fallback when the table is missing or empty
(a fresh deployment before its first precompute run, or live/dev mode); and if both
fail, `unavailable: true` so the UI **omits** the figure rather than rendering a
confident `$0`. The SQL is defined once in `data/spend_sql.py` and used by the
pipeline (`pipeline.py::_build_spend`), the fallback and the tests, so all three
agree by construction.

`monthly_waste_usd` on a recommendation is the **resource's own billed spend** — the
UI labels it "This resource's spend / month". The old account-level "wasteful spend"
KPI (a sum of per-rule waste estimates) has been removed: it read like a bill it
never reconciled with. Total spend replaces it as the denominator for savings.

## Hidden rules
`Settings.hidden_rules` (env `FINOPS_HIDDEN_RULES`, default
`unused_scheduled_jobs,enable_photon_dbr`) lists rules that are **computed and
stored but hidden from the entire GUI** — no list, group, chart, savings total or
NBA ranking. The filter is applied in `RecommendationSource.fetch`, the single
boundary every read path crosses; `RecommendationSource.load` bypasses it, and the
About Serverless view deliberately uses `load` because the old-DBR findings are its
evidence. This is a presentation switch, not `enabled: false` in `thresholds.yaml`:
the pipeline keeps collecting the data.

## Genie costs — `finops_genie_usage`

Genie spend is reported in its own tab (`/genie-costs`) and is **deliberately
outside the recommendation contract**: it produces no finding, no savings figure,
no effort/priority and no NBA score, and it contributes to no total anywhere else
in the app. It is analysis only. Attribution is to **people and spaces**, not to
compute resources, so it fits neither the recommendation shape (one row per
finding) nor the spend shape (one row per workspace).

### What the billing data actually looks like
Three facts drive the whole design (all verified live against `system.billing.usage`):

1. **The free tier is a separate SKU, not a discount.** `GENIE_FREE_USAGE` has **no
   row at all** in `billing.list_prices`, so it prices to exactly `$0`. The
   free-vs-paid split is therefore *read from billing*, never inferred from a spend
   threshold — which is why the tab can state "N% never went paid" as a fact.
2. **Paid Genie does not mention "genie" in its SKU name.** It bills as
   `PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_<REGION>` — the inference SKU. A
   `sku_name LIKE '%GENIE%'` filter silently returns *free usage only*, making paid
   spend look like zero. **Always filter on `billing_origin_product = 'GENIE'`.**
3. **`usage_metadata.genie.agent_id` is populated for `GENIE_AGENTS` only.** Genie
   Code and Genie One emit no space id, so per-space cost legitimately covers a
   subset of spend. `genie_space_sql` filters to rows that have one rather than
   inventing an "unknown space" that would own most of the money.

Other columns used: `usage_metadata.genie.surface`
(`GENIE_CODE`/`GENIE_AGENTS`/`GENIE_ONE`), `.channel` (`UI`/`API`), and
`identity_metadata.run_as` for the principal.

### Budgets are not available
`usage_metadata.budget_policy_id` is **NULL on every Genie usage row**, and account
budget policies are not readable from a workspace-scoped app. Set budgets therefore
**cannot be shown from system tables**. The tab renders an explicit "not available"
panel (`GenieCosts.budgets_note`) instead of an empty widget that looks broken.

### Table shape — one table, four aggregates
DDL: `precompute/ddl/finops_genie_usage.sql`. Written by the **SDP pipeline**
(`precompute/pipeline.py::_build_genie`), a sibling sink of `finops_recommendations`
— *not* by the legacy `job.py`. Each row is `(snapshot_date, kind, workspace_id,
payload)` where `kind` ∈ `user | surface | space | daily` and `payload` is the
aggregate row as JSON. One table keeps the analysis-only surface cheap to evolve (a
fifth aggregate needs no migration); `workspace_id` stays a real column because
scoping must never depend on parsing JSON.

The four queries live once in `backend/finops/data/genie_sql.py` and are used by the
pipeline, the live fallback and the tests — the same one-definition rule the rules
follow, enforced by `precompute/tests/test_sdp_parity.py`.

### Read path
`data/genie_source.py`: snapshot → concurrent live queries → honest `unavailable`,
mirroring `spend_source.py`. Two things to know before changing it:

- **The live window is truncated** to `live_lookback_days` (like
  `LiveRecommendationSource`) because the path scans `billing.usage` while a page
  load waits. `GenieCosts.lookback_days` reports the window *actually queried*, and
  the monthly figure divides by it — do not report the configured window for a
  truncated read.
- **The time budget only works because the pool is shut down with `wait=False`.**
  Collecting results inside a `with ThreadPoolExecutor` block joins every worker on
  exit, so a straggler holds the response open no matter what the budget says; that
  turned a 45s budget into a >5-minute request on a real account. The budget is also
  set *above* the connection's 40s socket timeout, since that already bounds each
  concurrent query — a lower budget can only cancel queries that were about to
  succeed. `missing_sections` names any aggregate that did not arrive so the UI can
  explain an empty section instead of implying "no usage".
- **The snapshot read must select the workspace columns explicitly.**
  `workspace_id`/`_name`/`_url` are real columns and the pipeline *removes*
  `workspace_id` from the JSON payload (scoping must never parse JSON). A read of
  just `(kind, payload)` therefore loses every workspace attribution while each
  individual figure still looks right — it shipped that way once and the tab showed
  *"across 0 workspaces"* with unnamed spaces. The row's columns are merged back over
  the parsed payload in `_from_snapshot`; the test fixture mirrors the real column
  layout so this can't regress silently.

### Per-workspace scope
Genie respects workspace scope in both directions:

* **A workspace admin** sees only their own workspaces on `GET /api/genie` — the
  scope is server-derived and the snapshot query filters on the real `workspace_id`
  column.
* **A platform admin can drill in** via `GET /api/genie/{workspace_id}`
  (route `/workspaces/:workspaceId/genie-costs`), mirroring
  `GET /api/spend/{workspace_id}`. All four aggregates are already grouped by
  `workspace_id` in SQL, so this is the same rollup over a narrower scope, not a
  second code path.

The path param is client-supplied, so it goes through `Scope.narrowed_to`, which
applies it as a filter *within* the caller's scope and can only ever remove access:
a workspace admin naming a workspace they don't own gets an empty scope (rendered as
`IN (NULL)`, and short-circuited before any query runs), never that workspace's
data. A non-numeric id raises `ScopeError` → **400**, since ids are inlined into SQL
after a digit check. The source caches per scope, so the platform view and each
drill-in can never serve each other's rows.

## Databricks Apps — `finops_apps_usage`
An **inventory, not a rule set**: what apps exist, what they cost, how they are
configured. Written by the SDP pipeline (`pipeline.py::_build_apps`), read by
`data/apps_source.py`, rendered at `/apps`. DDL:
`precompute/ddl/finops_apps_usage.sql`.

### Why there are deliberately NO app recommendations
`system.access.audit` with `service_name='apps'` contains **lifecycle actions only** —
`createApp`, `deployApp`, `startApp`, `stopApp`, `updateApp`, `deleteApp`,
`changeAppsAcl`, `installTemplateApp` (verified live 2026-08-06). **There is no app
request or page-view log anywhere in system tables.** So the question every
idle-resource rule must answer — *is anyone actually using this?* — is unanswerable
for apps, and an "idle app" or "rightsize this app" finding would be a guess wearing
a dollar figure.

Contrast `idle_serving_endpoints`, which exists **because**
`system.serving.endpoint_usage` is a genuine per-request log. That rule also shows the
shape the future apps rule must take: it requires an `entity_matched` flag so that
absence of traffic data reads as *unknown*, never as *idle* — without it, a LEFT JOIN
made busy endpoints look like zero-traffic ones and would have recommended deleting
them.

So the tab shows facts and states the limitation (`analysis_note`, rendered verbatim
in a panel) rather than omitting the surface or inventing advice. The model carries no
`monthly_savings_usd`, `priority`, `nba_score` or `effort_*` field at all, and a test
asserts their absence — if one ever appears, some UI will render it as advice we
cannot justify.

**Where the rule would go when a usage log lands:** `apps_inventory_sql` already
computes `days_billed`, `compute_size` and `last_deploy_time`, which is most of a
rightsizing/staleness candidate query. Add the traffic join, gate on it like the
serving rule, and put the rule in `rules/finops_rules/catalog/`.

### Two billing facts that shape the SQL
1. **Apps bill under a generic serverless SKU** —
   `PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_<REGION>`, nothing in the name says "app".
   Apps cannot be selected by SKU name; filter on `billing_origin_product = 'APPS'`.
   (Same fact that made apps invisible in the spend breakdown above.)
2. **Apps are always-on while running, and mostly one size.** On a real account 551
   of 1,065 apps billed every day of a 30-day window and all but 17 ran `MEDIUM`.
   There is no scale-to-zero, so `days_billed` is a **lifecycle** signal (was it ever
   stopped?), never an idleness one — the UI labels a full-window count "always on"
   as a neutral fact.

### Table shape and read path
Same `(kind, workspace_id, payload)` shape as `finops_genie_usage`, with
`kind ∈ inventory | size | daily`. Both analysis-only sinks now share one pipeline
helper (`pipeline.py::_build_kinded_sink`) so they cannot drift on the two details
that are easy to get wrong: `workspace_id` is lifted **out** of the payload into a
real column (scoping must never parse JSON — so the read path has to select it back
and merge it), and workspace name/url are resolved from `workspaces_latest`.

Read path mirrors Genie: snapshot → three concurrent live queries under one 45s budget
→ honest `unavailable`. The inventory query joins the audit log and is much the
slowest, so it is the one most likely to miss the budget; `missing_sections` names it
so the UI explains an empty table instead of implying there are no apps.

Per-workspace scope works exactly as for Genie: `GET /api/apps/{workspace_id}`
(route `/workspaces/:workspaceId/apps`) via `Scope.narrowed_to`.

### The window is exactly N days
`date_sub(current_date(), N)` is inclusive at **both** ends, so the naive filter spans
N+1 dates and an always-on app reports `days_billed = 31` for a 30-day window. The
apps SQL also excludes today (itself partial, which would understate the last day), so
"billed 30 of the last 30 days" is literally true.

## Cost anomalies — `finops_cost_anomalies`
Analysis-only tab (`/cost-anomalies`, per-workspace `/workspaces/:workspaceId/cost-anomalies`
via `GET /api/anomalies/{workspace_id}` + `Scope.narrowed_to`). **An anomaly is not a
saving**: a spike can be a backfill or a launch, so `CostAnomaly` carries no
`monthly_savings_usd` / priority / NBA field (a test asserts their absence) and nothing
here feeds a savings total. The method (grain, baseline, robust z, weekday rhythm,
types) is documented in the `backend/finops/data/anomaly_sql.py` module docstring; in short:

- Daily **list-priced** cost at two grains: `sku` (workspace × `billing_origin_product` ×
  `sku_name`, covers every dollar) and `resource` (job before cluster, because job
  clusters get a new id per run). Totals come from the `sku` grain only — the two
  grains overlap.
- Baseline = the 28 days before the last 7, densified with $0 days; flagged when the
  robust z > 4 **and** the excess clears `max($200, 3 % of workspace median daily
  spend)`, against both the overall and the same-weekday median.
- Types: `new_spender` (no baseline), `step_change` (≥ 3 consecutive flagged days),
  `spike` (the rest). Today is excluded (partial).
- "Who" = `identity_metadata.run_as` / `owned_by` of the largest record on the peak day.

Same `(kind, workspace_id, payload)` table shape as Genie/Apps, written by
`pipeline.py::_build_anomalies` through `_build_kinded_sink`. Read path: snapshot →
live fallback → honest `unavailable`. **The live fallback needs 35 days of billing and
takes 1.5–3 min on a large account**, well over the 45 s budget, so in practice the
tab depends on the snapshot; before the first pipeline run it says so rather than
showing "no anomalies". The table name defaults to `finops_cost_anomalies` next to
`finops_table` (override: `FINOPS_ANOMALY_TABLE`).
