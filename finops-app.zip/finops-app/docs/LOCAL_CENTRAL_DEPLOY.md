# Run the FinOps app locally on Central Logfood (internal SA preview)

How to run the app **on your own machine** against Databricks' internal **Central
Logfood** system tables, so you can explore a real customer's cost profile **without
deploying anything into their workspace**. This is the current, mirror-free flow: the
app reads the multi-account central tables directly and gates the UI on a single account.

> **Internal only.** This reads `main.centralized_system_tables.*` and
> `main.certified.*`, which aggregate system-table data across many customer accounts.
> Treat everything you see as customer-confidential. This is a preview/analysis setup,
> not a shipped product feature.

For the background on how central mode works (the table resolver, the account
dimension, known gaps), see [`LOGFOOD_LOCAL_PREVIEW.md`](LOGFOOD_LOCAL_PREVIEW.md). For
deploying the app *into a customer workspace*, see [`DEPLOYMENT.md`](DEPLOYMENT.md).

---

## What you get

- **Account gate** — on open you pick one customer; only that account's data loads, so
  the app stays responsive and two customers' data never mix.
- **Cascading refine filters** — within the account, optional **Cloud** and **Databricks
  account-id** filters (the account-id list narrows to the selected cloud).
- **Correct, consistent numbers** — recommendations (addressable savings) and the Total
  Consumption KPI are both scoped to the account's *workspaces* (so an account that
  shares a Databricks `account_id` with another SFDC account — e.g. Mercedes-Benz and
  Daimler Truck — is not over-counted) and both priced at **list price**, so
  addressable-as-a-share-of-total is apples-to-apples.

---

## Prerequisites

1. **Databricks CLI authed to logfood** as an OAuth profile (no PAT needed):
   ```bash
   databricks auth login \
     --host https://adb-2548836972759138.18.azuredatabricks.net --profile logfood
   ```
2. **Read access** (request via [go/opal/tile](https://go/opal/tile), time-bounded):
   - `datasets.main.centralized_system_tables.read` — the central system tables.
   - the `main.certified` dataset group — `workspaces_latest` (names + the
     Salesforce-account ↔ `account_id` mapping the app scopes by).
3. **A SQL warehouse in logfood** you can use. These are heavily contended — see
   [Operational notes](#operational-notes).
4. **A writable catalog/schema** if you want the performance slice (below). The team
   space `main.team_field_dsa_ce` already holds the central pipeline's outputs and is
   the default; use it or your own.
5. **Python 3.11+** and, only if you change the frontend, **Node 20+**.

---

## 1 — Python environment

```bash
cd accelerators/apps/finops-app
make install          # creates .venv and installs backend + dev deps
```
If PyPI/the internal mirror is unreachable on the corp network, reuse an existing venv
that already has the deps (fastapi, uvicorn, databricks-sql-connector, jinja2, pydantic,
python-dotenv). **`pyarrow` is recommended** — with it the SQL connector returns native
types and fetches faster; without it the app falls back to a slower JSON-decode path.

## 2 — Configure `.env`

Copy the template and fill in the Central Logfood block:
```bash
cp .env.example .env
```
```bash
# .env — Central Logfood preview
FINOPS_COMPUTE_MODE=precompute
FINOPS_AUTH_MODE=obo
DATABRICKS_SERVER_HOSTNAME=adb-2548836972759138.18.azuredatabricks.net
DATABRICKS_WAREHOUSE_ID=/sql/1.0/warehouses/<your_warehouse_id>
DATABRICKS_CONFIG_PROFILE=logfood        # SDK uses this OAuth profile — no PAT
FINOPS_CENTRAL_MODE=true
FINOPS_TABLE=main.team_field_dsa_ce.finops_central_recommendations
FINOPS_DEV_ROLE=platform_admin           # see all workspaces
FINOPS_NO_AUDIT=true                     # central has no access.audit

# Performance: read spend from a pre-filtered slice (see step 3). Omit to read the
# full central tables directly (correct, but slow cold).
FINOPS_CENTRAL_NAMESPACE=main.team_field_dsa_ce
# Keep results warm through a session (central reads are slow cold, instant once cached).
FINOPS_PRECOMPUTE_CACHE_TTL=43200
FINOPS_SPEND_CACHE_TTL=43200
```
The recommendations table (`FINOPS_TABLE`) is produced by the central pipeline
(`precompute/central/`); this preview assumes it has already run for your accounts.

## 3 — (Recommended) Build the billing slice for speed

The Total Consumption KPI reads billing live from the central tables. Scoped to one
account that is still a scan of a huge multi-account fact table (~20–40s cold, with
spikes). Materialize a small slice of just the in-scope accounts once:

```bash
PYTHONPATH=rules:backend .venv/bin/python -m precompute.central.build_billing_slice
```
This writes `billing_usage`, `billing_list_prices`, and `workspaces_latest` slices into
`FINOPS_CENTRAL_NAMESPACE` (default `main.team_field_dsa_ce`), clustered for the scoped
read. With `FINOPS_CENTRAL_NAMESPACE` set, spend reads the slice (~4× faster). Re-run to
refresh as the data ages. (Options: `--namespace`, `--window-days`, `--source`.)

## 4 — (Only if you changed the frontend) Rebuild the SPA

The backend serves the **pre-built** SPA from `backend/finops/static/`, so normally you
skip this. If you edited anything under `frontend/src/`:
```bash
cd frontend && npm install && npm run build   # outputs into backend/finops/static/
```

## 5 — Run

```bash
./start.sh            # http://127.0.0.1:8000   (PORT=8001 ./start.sh to override)
```
`start.sh` exports `.env` into the environment before launching uvicorn (some cache
settings are read at import time) and frees the port if a stale instance is bound.

Open **http://127.0.0.1:8000**, pick a customer at the gate, and explore. The first load
of each surface for a newly-selected account recomputes live (seconds to tens of
seconds); it is cached afterwards, so navigating within the account is instant. Switch
customers with **Change account** in the top bar.

---

## Operational notes

- **Shared logfood warehouses are heavily contended.** Cold reads vary a lot (seconds to
  a minute+). The caches (step 2) mean you pay a cold read once per account per session;
  everything after is instant. For predictable cold latency, precompute is the answer.
- **Numbers are list price**, not the discounted amount a customer pays — consistent with
  how the rules value savings. An enterprise's actual (post-discount) spend can be
  roughly half the list figure; that is expected, not a bug.
- **Home-catalog retention is 30 days**; `main.team_field_dsa_ce` is persistent, so the
  slice does not auto-expire — re-run the slice build to refresh it.
- **No PAT required** — with `DATABRICKS_CONFIG_PROFILE=logfood`, the SQL connector
  authenticates via the CLI OAuth profile.

## Troubleshooting

- **Total Consumption tile missing / `unavailable`** — no account selected (the gate
  guards this), or no read grant on `main.certified.workspaces_latest`. Check the grants
  in the prerequisites.
- **Everything is slow** — confirm `FINOPS_CENTRAL_NAMESPACE` points at a built slice
  (step 3) and the cache TTLs are set; the first read per account is still cold.
- **Amber "1 rule cannot run" banner** — expected: `unused_data_jobs` needs
  `access.table_lineage`, which has no central equivalent.
