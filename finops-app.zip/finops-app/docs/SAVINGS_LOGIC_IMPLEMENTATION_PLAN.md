# Savings logic — detailed implementation plan

Status: **Plan, not yet implemented**
Date: 2026-09-17
Companion to: `docs/SAVINGS_LOGIC_REVIEW_IMPLEMENTATION_BACKLOG.md`

This plan translates the accepted review findings into per-file task lists,
acceptance tests, and an execution order. Every finding in the backlog was
re-verified against the current tree before planning; the verification outcome
and any corrections to the backlog's own claims are recorded per item.

## Verification outcome (what is actually true in the tree today)

All 21 findings are **valid or partially valid**. None were bogus. Corrections
to the backlog's secondary claims — these change priority, so they are called
out up front:

- **FIN-021 (enable_photon_dbr) is NOT hidden.** It is live and books non-zero
  savings from fixed 5%/15% fractions (`thresholds.yaml:152-154`). Treat as an
  active over-booking bug in Phase 0, not a deferred item.
- **unused_scheduled_jobs is NOT $0.** It books `monthly_cost` as savings
  (`rules/finops_rules/catalog/unused_scheduled_jobs.py:84`), contradicting the
  backlog's "hygiene, $0" checklist label. Fix in Phase 0.
- **FIN-019 (continuous_pipeline) active-hours bug is already fixed** — update
  spans are exploded across hours (`continuous_pipeline.sql.j2:119-131`). The
  remaining valid parts are the `ORIGINAL`-only filter and the uniform-rate
  assumption within an hour.
- **FIN-020 (failing_jobs) already separates repair from retirement** in the
  savings math (`savings.py:89-92, 791-792`). The remaining gap is that
  retirement is booked without an obsolescence gate and both paths collapse to
  one figure.
- **FIN-001** is partially done: `_macros.sql.j2` centralizes the price join
  (`price_join`/`price_rate`), but windows, coverage, correction handling, and
  product filters are still per-rule.
- **FIN-011 (idle_apps)** — valid. The `databricksApps` audit stream is
  lifecycle-only; no per-app request/traffic log exists in public system tables,
  so the workspace signal gate cannot manufacture traffic evidence.
- **FIN-012 (warehouse auto-stop)** — valid; confirmed partition omits
  `workspace_id`, overlapping query intervals are not merged, the tail after the
  last query is dropped, and serverless histogram buckets use upper bounds.

The bookable / estimated / advisory framing and the ten accounting invariants
are sound and are adopted as the backbone of this plan.

## Contract / schema mirror chain (touched by every additive field change)

Any new recommendation field must be added to all of these together, in order:

1. `rules/finops_rules/contract.py` — `RuleFinding` producer contract
2. `backend/finops/models/recommendation.py` — Pydantic API model
3. `backend/finops/services/contract_schema.py` — schema definition
4. `precompute/ddl/finops_recommendations.sql`
5. `precompute/ddl/finops_central_recommendations.sql`
6. `precompute/ddl/finops_recommendations_evidence.sql`
7. `backend/finops/services/table_comments.py` — column comments
8. `frontend/src/api/types.ts` — TypeScript type
9. `docs/DATA_MODEL.md` — documentation
10. `backend/finops/services/precompute_transform.py` and
    `backend/finops/data/precompute_source.py` — read/write mapping

---

## Phase 0 — Protect the headline (containment)

Goal: the headline total becomes a trustworthy bookable lower bound, and no rule
over-books, **before** any formula is rebuilt. No new economic modeling here.

### 0.1 Additive contract fields

Add across the full mirror chain above:

| Field | Semantics |
|---|---|
| `savings_status` | `bookable` \| `estimated` \| `advisory` |
| `monthly_savings_low_usd` | conservative lower bound — the only value booked |
| `monthly_savings_usd` | point estimate (kept for compatibility) |
| `monthly_savings_high_usd` | upper scenario, never booked |
| `current_monthly_cost_usd` | corrected cost in the affected scope |
| `counterfactual_monthly_cost_usd` | cost after the action, same scope |
| `cost_basis` | `dbx_list` \| `dbx_effective` \| `cloud` \| `combined` |
| `price_coverage` | completeness signal (per usage unit) |
| `action_family` | `rightsize` \| `terminate` \| `migrate` \| `retire` \| `tune` \| `hygiene` |
| `affected_spend_scope` | stable keys for cross-rule de-dup |
| `assumptions` | machine-readable counterfactual inputs |

Keep `monthly_waste_usd` for compatibility but stop treating it as savings.

Defaults so existing rules keep working: `savings_status` defaults to
`estimated`, low/point/high default to the existing `monthly_savings_usd`.

### 0.2 Headline aggregation change

- `backend/finops/services/aggregation.py` and
  `backend/finops/services/recommendation_service.py`: the headline sums only
  `monthly_savings_low_usd` where `savings_status == 'bookable'`. Estimated and
  advisory contribute exactly zero to the booked total but stay visible/rankable.
- Frontend (`AccountOverview.tsx`, `Recommendations.tsx`, `GroupTable.tsx`,
  `RecommendationCard.tsx`, `breakdown.ts`): show booked total distinctly from
  "estimated" and "addressable spend"; badge each finding by status.

### 0.3 Reclassify / disable over-booking rules (status only, formulas untouched)

| Rule | Phase 0 action | File |
|---|---|---|
| idle_apps | disable from recs + totals | `catalog/idle_apps.py`, registration |
| enable_photon_dbr | advisory, $0 (currently live!) | `catalog/enable_photon_dbr.py` |
| unused_scheduled_jobs | stop projecting stale cost; advisory | `catalog/unused_scheduled_jobs.py:84` |
| spot_fallback | advisory, $0 | `catalog/spot_fallback.py` |
| interactive_to_job | advisory, $0 | `catalog/interactive_to_job.py` |
| enable_serverless | advisory until rebuilt | `catalog/enable_serverless.py` |
| serverless_cost_optimized | advisory until measured | `catalog/serverless_cost_optimized.py` |
| unused_data_jobs | advisory, $0 | `catalog/unused_data_jobs.py` |

Mark as `estimated` (still visible, out of booked headline): warehouse_autostop,
warehouse_autostop_serverless, warehouse_rightsize, rightsize_underutilized,
jobs_compute_rightsize, failing_jobs, continuous_pipeline, idle_zombie_clusters.
Keep bookable: idle_serving_endpoints **zero-traffic tier only**,
cluster_autotermination (with caveat).

### 0.4 Effective pricing fail-fast (FIN-005)

- `rules/finops_rules/pricing.py`: `pricing_mode='effective'` must require a
  configured net-cost source; refuse startup otherwise. Never relabel list price
  as effective.

### Phase 0 acceptance
- A booked total equals the sum of `bookable` low values only; flipping any rule
  to advisory drops it from the headline and changes no other number.
- idle_apps produces zero recommendations and zero dollars.
- enable_photon_dbr and unused_scheduled_jobs contribute zero to the headline.
- Effective mode refuses to start with no effective-rate provider.
- All existing unit/render tests pass with defaulted new fields.

---

## Phase 1 — Shared data correctness (FIN-001–007)

### 1.1 FIN-001 canonical corrected hourly cost layer
- New shared SQL relation / macro at workspace/resource/hour/SKU granularity with
  the columns listed in the backlog (ids, corrected qty, list/promo/effective/
  cloud cost, priced/unpriced, correction diagnostics).
- Extend `_macros.sql.j2`; migrate every rule's `system.billing.usage` join to
  consume it.
- **Acceptance:** ORIGINAL+RETRACTION+RESTATEMENT fixture returns corrected
  amount; N-day window has exactly N dates; sum reconciles to Total Spend for the
  same scope/basis; no resource priced when coverage below threshold.

### 1.2 FIN-002 standard windows
- Render shared `window_start_date/end_date/ts` and use
  `usage_date >= date_sub(as_of, N) AND usage_date < as_of` everywhere.
- Fix the 14d-behavior-on-30d-cost mix in `enable_serverless.sql.j2:26 vs 41-99`.
- `apps_sql.py:99-104` is the reference pattern.

### 1.3 FIN-003 corrections
- Include all `record_type`s in additive cost/usage sums. Remove `ORIGINAL`-only
  filters at `continuous_pipeline.sql.j2:82` and `untagged_spend.sql.j2:62`; keep
  ORIGINAL only for documented non-additive metadata. Fold into 1.1.

### 1.4 FIN-004 coverage fails closed
- `rules/finops_rules/coverage.py:70-76`: missing coverage → suppress booking (not
  fail open). Track coverage per usage unit. Add coverage emission + guard to:
  enable_photon_dbr, failing_jobs, idle_serving_endpoints, idle_zombie_clusters,
  jobs_compute_rightsize, rightsize_underutilized, unused_data_jobs,
  unused_scheduled_jobs. Keep free SKUs explicitly classified.

### 1.5 FIN-006 SCD selection
- Convert "filter `delete_time` in WHERE before QUALIFY" to "rank all versions,
  then `WHERE rn = 1 AND delete_time IS NULL`" in: enable_photon_dbr:22-25,
  failing_jobs:74-77, jobs_compute_rightsize:101-104, unused_scheduled_jobs,
  unused_data_jobs, continuous_pipeline (+ audit the rest listed in FIN-006).
  `idle_zombie_clusters.sql.j2:26-40` is the correct reference.

### 1.6 FIN-007 workspace-safe keys
- Add `workspace_id` to joins/`PARTITION BY` in: warehouse_autostop (warm/active
  joins :47-70, query LEAD :109), warehouse_autostop_serverless (:65,:69),
  enable_serverless joins, warehouse_rightsize (load/concurrency/slot CTEs
  :32-91), warehouse_scale_out, idle_serving_endpoints entity map.

### Phase 1 acceptance
- Invariant tests (same scope/units/window, corrections, no missing→zero).
- Duplicate-ID-in-two-workspaces fixture per corrected template.
- Deletion-SCD fixture: deleted resource's final row is what gets ranked.
- Rule totals reconcile to Total Spend for identical window + basis.

---

## Phase 2 — Strongest counterfactuals (FIN-008, 012, 018)

### 2.1 FIN-012 warehouse auto-stop rebuild
- Use `system.compute.warehouse_events` for running/stopped/scaling intervals.
- Merge overlapping query intervals; include head gap + tail; clip to one window;
  simulate each candidate timeout on exact intervals; price reclaimed seconds
  from corrected hourly cost (no bucket upper bounds).
- Assertions: merged busy ≤ running; counterfactual running ≤ current;
  reclaimed ≤ corrected cost; edge gaps included; concurrency adds no dup warm.

### 2.2 FIN-018 serving zero-traffic tier
- Promote zero-request always-billing tier to bookable (post coverage/window/
  workspace-join fixes). Low-traffic tier stays estimated until recomputed from
  arrival gaps.

### 2.3 FIN-008 action-aware aggregation
- Replace max-per-resource (`aggregation.py:29-40`,
  `recommendation_service.py:268-269`) with: mutually-exclusive → pick one;
  compatible → apply in order to remaining counterfactual; migration →
  supersedes tuning of retired source; cross-resource → de-dup same hourly/SKU
  segment via `affected_spend_scope`. Headline = portfolio bookable lower bound;
  "sum of all options" only as a labeled theoretical figure.

### 2.4 cluster_autotermination hardening
- Keep gap method; apply canonical window/cost/coverage/SCD; retain CPU/activity
  caveat.

### Phase 2 acceptance
- Warehouse assertions above hold on overlapping-interval fixtures.
- Aggregation: rightsize+auto-stop on one warehouse books a combined bounded
  figure; no spend segment counted twice; migration suppresses source tuning.

---

## Phase 3 — Rebuild estimates

- **FIN-010 interactive_to_job:** fix unit mismatch (`:176` wall-clock ÷
  node-minutes); split dedicated job-only vs shared clusters; shared lower bound
  = 0 until source uptime/worker count provably drops; price-gap only as upper
  bound. Keyed by workspace + compute_id via node_timeline overlap.
- **FIN-016 rightsizing:** per-run driver/worker peaks (CPU/mem/swap/IO/net);
  actual node-minutes + autoscale levels; smallest candidate covering a share of
  historical peaks with headroom; explicit current vs candidate DBU cost. For
  warehouses add runtime elasticity (`candidate = current × size_ratio ×
  runtime_ratio`), replacing `2^-steps` at `savings.py:1031-1032`; veto downsize
  on memory/swap/IO/spill pressure. Wire p95 into score() (currently ignored,
  `rightsize_underutilized`).
- **FIN-013 enable_serverless:** one window, real warehouse events, actual SKU
  prices, emit `cloud`. Without cloud export → DBU comparison + separate VM range,
  status estimated. Suppress when compatibility/region/basis unknown.
- **FIN-014 serverless_cost_optimized:** represent pipelines as pipeline
  resources (not `resource_type="job"` at `serverless_cost_optimized.py:113`);
  prefer actual price/SKU deltas; else matched before/after runs; else advisory
  $0. Use Pipeline Events for pipelines.
- **FIN-015 unused_data_jobs:** drop 50/70% haircut; show producer cost as max
  addressable, $0 booked; add lineage-availability sentinel; distinguish "lineage
  observed, no reads" from "no coverage"; search longest lineage interval;
  cross-workspace reads; promote to bookable only on explicit verification.
- **FIN-017 idle_zombie_clusters:** recency/forward-spend guard; if stopped with
  no recurring start pattern → hygiene/$0 (replace whole-lookback annualization
  at `idle_zombie_clusters.py:93`).
- **FIN-019 continuous_pipeline:** corrected hourly cost (drop ORIGINAL filter),
  exact update intervals, Pipeline Events to separate no-input idle from useful
  processing; model trigger startup; latency as non-financial constraint.
- **FIN-020 failing_jobs:** keep repair estimate only with comparable successful
  runs; require obsolescence signal / owner decision before booking retirement;
  show failed cost as max addressable otherwise; separate repair vs retire line
  items.
- **FIN-021 enable_photon_dbr:** matched runs / query fingerprints across
  runtime/Photon change normalized for input, or book zero. Do not reintroduce
  to totals until solved.
- **FIN-009 spot_fallback:** advisory $0 on Databricks-only data; VM savings only
  with CUR/Azure/GCP billing export (node-minutes × real spot/on-demand rates,
  exclude driver, subtract eviction/replay).

### Surfacing: per-object confidence on the detail pages
- **Show the savings-status confidence (Booked / Estimated / Advisory) on every
  object detail page.** Today the `StatusBadge` pill renders in ONE place —
  `RecommendationCard` on the Next Best Actions page — so a user opening a
  warehouse/cluster/job/endpoint detail (`pages/ResourceDetail.tsx`) or a single
  recommendation (`pages/RecommendationDetail.tsx`) sees the savings figure with no
  indication of how much trust the engine places in it. Reuse the existing
  `StatusBadge` (label + hover text already written) so each detail page — and each
  option within a multi-option resource group — shows its `savings_status`
  alongside the dollar amount, with the "booked vs addressable" split mirrored from
  the Overview KPI header. Also worth surfacing on the detail view: the confidence
  driver (the finding's `data_basis` / coverage note) so the reader can see *why* a
  saving is estimated rather than booked. **Belongs in Phase 3** because each rule
  rebuilt here moves between tiers (estimated → bookable, advisory → estimated), so
  the per-object status only becomes decision-relevant — and worth the UI real
  estate — once the rebuilds make it move. Frontend-only; the `savings_status` field
  is already on the contract and populated end-to-end.

### Phase 3 acceptance
- Per rule: pure unit tests (bounds/units/edges/suppression), render tests
  (nested + central), executable SQL integration tests, correction/SCD/dup-ws/
  missing-price/overlap fixtures, pinned `snapshot_date` golden run (live vs
  precompute), and a live sample review against Query History / resource UI.

---

## Phase 4 — New opportunities (A–H)

After the foundation, following AGENTS.md (three files + one thresholds block per
rule; additive contract changes separately). Order: (B) Predictive-Optimization
duplication and (C) Pipeline Events first — both find directly avoidable work —
then (A) SQL efficiency, (D) AI Gateway, (E) networking, (F) Delta Sharing,
(G) instance pools (operational only, no VM $ without cloud bill), (H) storage
lifecycle (no storage $ from DBUs).

### Delivered so far — the "Labs" (Experimental) surface

Phase 4 rules are **net-new and unvalidated**, so they must not clog the main UI or
touch the trusted headline. They are gated behind an experimental relocation
mechanism and shown on their own **Labs** tab:

- **`Rule.experimental` flag** (contract) — a rule self-declares experimental. The
  backend derives the relocated set from the registry
  (`config.Settings.experimental_rule_ids`, override `FINOPS_EXPERIMENTAL_RULES`),
  and the read-time partition in `data/base.py` keeps these findings OUT of
  `fetch()` (the main surfaces, totals, NBA, leaderboard) and `fetch_sidecar()`,
  serving them ONLY via `fetch_experimental()`. Same contract as `sidecar_categories`
  (governance), keyed on the rule.
- **Labs tab** — `/api/experimental` → `ExperimentalOverview`; frontend
  `pages/Labs.tsx` (nav gated on `config.experimental_enabled`). Headline is
  ADDRESSABLE monthly spend, never a booked saving (experimental rules are advisory).
- **Single-account / local-Databricks ONLY.** Experimental rules run in single-account
  precompute + live modes against a workspace's own `system.*` tables. They are
  explicitly EXCLUDED from the Central Logfood (multi-account) pipeline
  (`central_pipeline._central_enabled_rules`), so they never depend on or run against
  logfood data until they graduate — the same "single-workspace only" stance as
  `idle_apps`.

Implemented (both advisory, `$0` booked; each: catalog `.py` + `sql.j2` + test +
`thresholds.yaml` block + a purpose-built Labs chart):

- **A — `sql_repeated_failures`** (SQL workload efficiency): warehouses running the
  same query to failure repeatedly. From `system.query.history`
  (`execution_status='FAILED'`), the failed compute is apportioned by
  `total_task_duration_ms` share of the warehouse's corrected cost = ADDRESSABLE
  spend. Book only nothing (advisory): the reclaim depends on whether the warehouse
  would otherwise idle. Viz: per-day failed-vs-total query bars + top repeated
  failing statement.
- **B — `manual_maintenance_overlap`** (Predictive-Optimization duplication):
  warehouses running manual `OPTIMIZE`/`VACUUM` that PO may already do. From
  `system.query.history` we count + price the manual maintenance; we cannot prove PO
  covers the same tables from system tables alone, so it is advisory ("verify in
  Catalog Explorer"). Viz: per-day OPTIMIZE/VACUUM bars.

Also delivered (same Labs mechanism; each fires against real `system.*` tables,
validated live on the beta estate before commit):

- **C — `pipeline_failed_updates`** (Pipeline Events): DLT / Lakeflow pipelines burning
  compute on updates that end `FAILED` / `TIMED_OUT` / `ERROR`
  (`system.lakeflow.pipeline_update_timeline`). Cost apportioned by the failed updates'
  wall-clock share of the pipeline's corrected DLT cost = ADDRESSABLE spend (advisory
  $0). COMPLEMENTS `continuous_pipeline` (idle always-on compute) rather than
  duplicating it — this is the failed-update waste that rule cannot see. Viz: per-day
  failed-vs-total updates.
- **D — `ai_gateway_wasted_inference`** (AI Gateway) — **operational, $0**: serving
  endpoints fronted by the AI Gateway returning a high error rate (`status_code >= 400`)
  from `system.ai_gateway.usage`. Reports failed requests + the input tokens 5xx failures
  wasted; NOT dollars — gateway / foundation-model traffic bills per token under a model
  SKU that `system.billing.usage` does not split cleanly by `endpoint_id` (measured: a
  gateway endpoint's per-endpoint serving cost comes back ~$0). Viz: per-day
  failed-vs-total requests.
- **G — `instance_pool_idle`** (instance pools) — **operational, $0**: pools keeping warm
  VMs on standby (`min_idle_instances`), from `system.compute.instance_pools` +
  `instance_events`. Warm pool instances are cloud VMs billed OUTSIDE Databricks DBUs, so
  the metric is the warm-instance count, not dollars (same "we see it but cannot price it
  here" stance as `spot_fallback`'s VM savings). Viz: per-day launches/acquisitions vs the
  warm-floor line.
- **F — `delta_sharing_materialization`** (Delta Sharing) — **operational, $0**: shares
  re-materialized repeatedly (`system.sharing.materialization_history`). The event table
  records no cost and egress is a cloud charge, so the metric is the materialization
  count. (Valid rule; the source table is empty on the beta estate, so 0 findings there —
  it fires on provider estates.) Viz: per-day materialization count.
- **H — `storage_optimization_churn`** (storage lifecycle) — **operational, $0**: tables
  drawing heavy Predictive Optimization maintenance
  (`system.storage.predictive_optimization_operations_history`) — usually a fragmenting
  write pattern (small-file churn) worth fixing at the source. Reports PO's own estimated
  DBUs, not booked dollars (PO bills under its own SKU, not split per table here). Chosen
  over `storage.table_metrics_history` because that table lacks a `workspace_id` (breaking
  persona scoping) and is unpopulated on the estate. Viz: per-day PO DBUs.

**E — networking is DEFERRED (not built).** There is no `system.network*` schema;
cross-region transfer / egress dollars live only in the cloud provider's CUR / billing
export, which the app does not ingest — the same wall as `spot_fallback`'s VM savings and
`E` in the original plan note. It cannot be a system-tables-only rule and is left for when
a cloud-cost export is available.

**Operational vs addressable framing:** of the seven Labs rules, A / B / C carry an
ADDRESSABLE dollar figure (a share of measured Databricks compute); D / F / G / H are
OPERATIONAL — the waste is real and measured (failed requests, warm VMs, materializations,
PO DBUs) but is not priceable from Databricks DBUs (it is tokens, cloud VMs, egress, or
storage), so they book and address $0 and surface a count / DBU metric. The Labs UI shows
an "operational · N findings" chip for these instead of a dollar chip.

---

## Verification & sample-data harness track (cross-cutting)

This is **not** a single trailing phase. It is a dedicated track that runs
alongside every phase, because a formula regression can only be caught if the
rule's coverage exists **before** the formula is touched. It has three parts: an
up-front hardening step, a per-rule gate embedded in Phases 2–3, and a
distinct invariant-assertion layer.

Current state (`sample_data/`): the harness runs each rule's **real SQL on a
warehouse** and scores it, but only **2 of 21 rules** have fixtures + goldens
(idle_apps, continuous_pipeline), several needed system tables are not profiled,
and the suite **skips without a warehouse** so it does not gate CI today.

### V0 — harness hardening (do alongside Phase 0/1, before Phase 2)

- **Profile the missing tables** (`profile/profile_system_tables.py`):
  node_timeline, `system.compute.warehouse_events`, query history, jobs +
  job_run_timeline, compute-cluster SCD, table lineage, serving endpoint usage,
  pipeline events. Note the wide-struct cap (`usage_metadata` ~26/53 fields) —
  switch the profiler to `DESCRIBE ... AS JSON` if a rule needs a capped field.
- **Make the suite able to gate changes — decided: hermetic local-Spark
  backend first (option b).** Today the suite skips without
  `FINOPS_SAMPLE_PROFILE`/`FINOPS_SAMPLE_WAREHOUSE`, so it cannot gate CI. Build
  out the local-Spark backend the runner is already structured for, so goldens
  and the invariant layer run **hermetically on every PR** — no secrets, no
  network, deterministic, and works on fork PRs. Concretely:
  - Implement the local-Spark execution path in `harness/runner.py` behind a
    backend switch (`--backend spark|warehouse`, default `spark` in CI), reusing
    the existing `OfflineResolver` (temp views become local-Spark temp views).
  - Add JVM + PySpark to the CI image; wire the suite into the hermetic `pytest`
    run so it no longer skips.
  - The "JVM not guaranteed" caveat was about dev boxes, not CI — the CI image
    is controlled, so this objection does not apply there. Devs without a JVM can
    still use the warehouse backend locally.
  - **Watch the fidelity gap:** open-source Spark is not identical to DBSQL/Photon
    on edge cases (decimal precision, some struct/date functions). Keep rule SQL
    within portable Spark SQL; where a construct is DBSQL-specific, note it and
    lean on the warehouse backstop below.
  - **Backstop (option a), deferred:** keep the warehouse backend and add a
    nightly / pre-release run on the production engine, alongside
    `precompute/golden_diff.py`, to catch Spark-vs-DBSQL divergences the hermetic
    gate cannot. Not required to start.
- **Add the invariant-assertion layer** (`sample_data/tests/`), separate from
  goldens — see V-invariants below.

### Per-rule coverage gate (Phases 2–3)

For **every rule this plan touches**, land this *before* changing its formula:

1. A `_add_<rule>()` scenario in `fixtures/build_fixtures.py` with **at least one
   should-fire (positive) and one should-suppress (negative)** case, values drawn
   from `value_vocab.json` (never invented numbers).
2. A characterization golden in `expected/<rule>.json`, eyeballed before commit.
3. A row in the README "Rules covered" table: tables / scenario / expected /
   **what it proves**.
4. The relevant invariants from the layer below, bound to that rule's fixture.

Then make the change; the diff in goldens + any invariant break is the signal.

### V-invariants — the "worsening fails a test" layer

Goldens detect *any* change (regenerate and they pass again). These assertions
instead **fail when a change makes a rule wrong**, and map 1:1 to the backlog's
accounting invariants. Each is driven by a purpose-built fixture:

| Invariant | Fixture that triggers it | Guards |
|---|---|---|
| savings ≤ corrected current cost | any firing rule | over-booking (bound) |
| `advisory` ⇒ booked $0; `low ≤ point ≤ high` | any rule | headline integrity, FIN-008 |
| missing price ⇒ **suppressed**, not $0-cost booked | row with null price/coverage | FIN-004 fail-closed |
| ORIGINAL+RETRACTION+RESTATEMENT ⇒ corrected amount | correction triple | FIN-003 |
| deleted latest SCD row still selected correctly | delete-then-older-live rows | FIN-006 |
| duplicate id in two workspaces ⇒ no cross-workspace bleed | dup-id fixture | FIN-007 |
| N-day window has exactly N dates, no partial today | rows incl. "today" | FIN-002 |
| scaling cluster size must **not** move a wall-clock fraction | 1-node vs 4-node, same job | FIN-010 unit bug |
| spot toggle with unchanged DBU ⇒ $0 Databricks savings | spot vs on-demand, same DBU | FIN-009 |
| downsize with 2× runtime ⇒ ~$0 (elasticity) | matched slow-at-half-size runs | FIN-016 warehouse |
| stopped-for-weeks cluster ⇒ $0 forward | historical idle, no recent state | FIN-017 |

These are the tests that "trigger if a change worsens something." A unit-bug
fixture (e.g. the 1-node vs 4-node interactive_to_job case) will fail loudly if
someone reintroduces the node-minute division.

### Formula documentation requirement (every touched rule)

Each rule must carry, at the top of its SQL template and/or catalog `score()`
docstring, a short **formula header**: cost basis (`dbx_list`/`effective`/
`cloud`/`combined`), the units used, the counterfactual (what cost disappears and
why), the `savings_status` it emits, and which invariant(s) it satisfies. This is
what makes "issues in the formula easy to spot" — a reviewer compares the header
to the SQL. `docs/DATA_MODEL.md` and the README "Rules covered" table are the
external mirror of these headers.

### Decision — resolved
V0's CI gate uses **(b) a hermetic local-Spark backend as the primary per-PR
gate**, so formula changes are forced to run the suite on every PR (fork PRs
included) with no secrets or warehouse dependency. The warehouse backend (a) is
retained as a deferred nightly / pre-release fidelity backstop, not the gate.
See V0 for the implementation steps.

## Global verification requirements (all phases)

Green fixture suites are necessary but insufficient — they do not execute
Databricks SQL or validate economics. Each formula change needs: pure unit
tests; render tests; executable SQL integration tests against real system-table
schemas; synthetic correction / deletion-SCD / duplicate-workspace-ID /
missing-price / overlapping-interval fixtures; a pinned-`snapshot_date` golden
run comparing live vs precompute; portfolio invariants (low ≤ point ≤ high;
booked ≤ corrected spend in same basis; no double-counted segment; advisory
contributes zero); and a live sample review per changed rule.

## Suggested sequencing

Phase 0 is independently shippable and should land first (restores headline
trust with no economic risk). Phase 1 blocks Phases 2–3. Phase 2 delivers the
first genuinely bookable rebuilt savings. Phase 3 is per-rule and parallelizable
once Phase 1 lands. Phase 4 is net-new and gated on the foundation.

The **Verification & sample-data track** runs alongside all of this: V0 lands
with Phase 0/1, and from Phase 2 on **no rule formula changes until that rule has
its sample-data coverage + invariants first** (the per-rule gate). This is what
guarantees a worsening change trips a test rather than silently passing a
regenerated golden.
