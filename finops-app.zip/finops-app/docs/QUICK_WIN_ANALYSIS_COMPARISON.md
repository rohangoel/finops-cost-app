# FinOps Quick Win analyses — comparison and integration decisions

This documents how five standalone "FinOps Quick Win" SQL analyses were compared
against the app's existing rule engine, and the decision made for each. The
guiding principle is the app's own: **SQL finds candidates cheaply; Python
decides and prices; the estimate must never exceed true avoidable spend.**

The standalone analyses were written for one Azure tenant: they hardcode
`westeurope_ddx_mbcockpit.bronze.mb_workspace_overview` for workspace metadata, a
`0.36` contractual discount, and Azure-only SKUs. The app's rules must be
account-wide, cloud-agnostic, and free of a `workspace_id` filter (scoping is
injected by the data layer). So even where an analysis "wins", it is ported to
the app's contract rather than copied.

## Summary

| Analysis | App rule today | Decision |
|---|---|---|
| `spot_with_fallback.sql` | — (none) | **Add** `spot_fallback` |
| `severless_cost_optimized_mode.sql` | — (none) | **Add** `serverless_cost_optimized` |
| `jobs_on_all_purpose.sql` | `interactive_to_job` (flat 45%) | **Adopt analysis** — rewrote the rule to its methodology |
| `All purpose compute auto shutdown.sql` | `cluster_autotermination` (gap-based, CPU-only) | **Take the better signal** — folded its activity model into the app's rule; kept the app's superior gap/pricing math |
| `Sql warehouse autoshutdown.sql` | `warehouse_autostop` (classic-only) | **Both** — kept the classic rule; **added `warehouse_autostop_serverless`** for the population the classic rule excludes |

## Net-new rules

### `spot_fallback` — move on-demand classic clusters to SPOT_WITH_FALLBACK
No existing rule covers the spot lever. Added as a `compute`/`cluster` rule.

Ported faithfully but made portable:
- **Cloud-agnostic**: coalesces `aws_/azure_/gcp_attributes.availability` instead
  of the analysis's Azure-only path.
- **Size-aware cap** kept: only `workers/(workers+1)` of a cluster can go spot
  (the driver stays on-demand), single-node clusters are excluded.
- **Conservative pricing** in `savings.spot_fallback_savings`: mid (50%) movable
  fraction, a spot price gap, netted for eviction-replay overhead. All knobs are
  in `thresholds.yaml`.
- Only clusters **currently on ON_DEMAND** are candidates (spot-already clusters
  have nothing to reclaim). MEDIUM confidence — the VM price gap varies by
  region/instance and system tables don't expose the true spot discount.

### `serverless_cost_optimized` — switch serverless Jobs/DLT to Standard mode
No existing rule covers the Performance-Optimized → Standard toggle (the app's
`enable_serverless` is a different lever: classic → serverless *warehouses*).
Added as a `jobs`/`job` rule (pipelines are mapped to the `job` resource type to
stay within the contract's `cluster|warehouse|job` enum).

- Attributes real serverless dollars per entity, computes a **median run
  duration**, and applies a **duration-suitability** discount so short workloads
  (whose cold-start overhead is proportionally large) are down-weighted, not
  over-promised — the same idea as the analysis's `migration_score`, moved into
  testable `score()` logic.
- Dropped the analysis's Azure-tenant metadata join and `GROUPING SETS`
  reporting (the app renders its own rollups); kept the pricing model.

## Overlapping analyses

### `interactive_to_job` — **adopted the analysis's methodology** (rule v1→v2)
The analysis is clearly better than what the rule did:

- **Before**: `savings = monthly_cost * 0.45` — a flat fraction of *all*
  all-purpose spend on a cluster, with no per-job attribution.
- **After** (ported from `jobs_on_all_purpose.sql`): the SQL attributes **real
  billed all-purpose DBUs** to each job by its share of the cluster's job
  runtime, then prices the saving as `attributed_dbus × (all_purpose_price −
  jobs_compute_price)` — the **actual SKU price gap** from `list_prices`, not a
  guess. It filters to **recurring jobs** (`>= min_runs`) that ran **alone** on
  their cluster (`concurrency_factor = 1`), because a shared cluster's cost can't
  be cleanly reassigned per job.
- `score()` now consumes that real figure (falling back to the old 45% only if a
  jobs-compute SKU is missing for the cloud), caps savings at the resource's own
  monthly spend, and reports HIGH confidence. Effort stays HIGH (it's a real
  migration).

### `cluster_autotermination` — **kept the app's math, took the better signal**
Split decision. The app's rule is stronger where it counts:

- The app **sessionizes contiguous idle gaps** and reclaims only gaps longer than
  the proposed timeout, nets a **restart penalty** per reclaimed gap, and prices
  via validated `savings.cluster_autoterm_savings` (matched ground truth exactly
  in a prior session). The analysis uses a flatter "all idle windows beyond X"
  model. **App wins here — kept.**

But the analysis has a **better activity definition**, which fixes a real
false-positive: it treats a minute as *active* if a **job task ran** or a
**notebook command ran** (`system.access.audit`), not CPU-only. The app's rule
counted a low-CPU minute as reclaimable idle even while a job task was genuinely
working (blocked on I/O, slow shuffle, driver-bound). That over-counts idle.

- **Folded in**: the SQL now marks a running minute active if `CPU ≥ 10%` **OR** a
  `job_task_run_timeline` task ran (always on) **OR** — behind an opt-in
  `use_audit_activity` flag — a notebook `runCommand` happened. Idle gaps are
  sessionized from that combined signal. The audit signal is opt-in because
  `system.access.audit` isn't guaranteed enabled/granted; when it is, it closes
  the app's documented "medium confidence, interactive activity invisible" gap.
- The gap-pricing math and `score()` are unchanged, so the validated savings
  behaviour is preserved.

### `warehouse_autostop` (classic) + **new** `warehouse_autostop_serverless`
The two files are **not comparing the same population**, and my first pass got
this wrong — it credited the app rule with "explicit cold-start netting" as a
point over the analysis. Two corrections:

1. **The classic app rule does not, in its live path, net restarts.** The
   restart penalty (`savings.RESTART_PENALTY_MIN`, via `reclaimable_minutes()`)
   is used by the **cluster** rule and the **benchmark simulator** — not by the
   live `warehouse_autostop` path, which computes `reclaimable_minutes` as pure
   gap arithmetic in SQL and prices it via `warehouse_autostop_savings_from_gaps`
   (only a 3% residual margin). So "explicit cold-start netting" was not a real
   advantage of the classic rule as shipped.

2. **The analysis was serverless-aware; a restart penalty would be wrong for it.**
   Serverless warehouses start in seconds and bill per-second, so shortening
   auto-stop incurs no meaningful cold-start cost — which is exactly why the
   analysis offers aggressive `savable_hrs_at_1min` / `at_5min` scenarios.
   Penalizing it for omitting a correction it must not apply was a mistake.

What each side is actually good at:
- **Classic / PRO warehouses**: the app rule is the right tool. A shorter auto-stop
  there trades idle warm-pool cost against a real (billed) cold-start restart, and
  a classic-only rule can reason about that. **Kept as-is** (now with an explicit
  scope note in its docstring). Its per-query gap reconstruction + heatmap viz
  stand.
- **Serverless warehouses**: the app rule **excludes them entirely**
  (`warehouse_type <> 'SERVERLESS'`, added to kill a bogus warm-pool rec). But a
  serverless warehouse still runs — billing per-second — through its auto-stop
  idle tail after each query, and the default 10-min auto-stop leaves a real tail
  a shorter setting reclaims. The classic rule captured none of this.

**Added `warehouse_autostop_serverless`** to fill that gap, porting the analysis's
insight to the app's contract:
- Candidates are `warehouse_type = 'SERVERLESS'` with missing/0/`> max_acceptable`
  auto-stop (default threshold 10 min, the serverless default).
- Same per-query gap reconstruction as the classic rule, but priced by a
  dedicated `savings.serverless_autostop_savings_from_gaps` with a **1-minute
  floor and NO restart penalty** — the "restarts are free" assumption is explicit
  and unit-tested, not implied.
- TRIVIAL effort, HIGH confidence (per-query timestamps + billing).

The analysis's SCD2 idea — capping a gap at the auto-stop configured *at the time
of the gap* — remains a possible future refinement for both warehouse rules.

## Validation
- `make test` → 88 passing (was 50; +20 for the three new rules + serverless rule,
  with interactive_to_job and autotermination tests updated).
- `PYTHONPATH=rules pytest benchmark` → 8 passing (savings math still
  conservative).
- All 14 rules discover, enable, and render SQL with the real `thresholds.yaml`
  and no `workspace_id` filter.
- `ruff` error count unchanged vs. baseline (no new lint).

## Follow-ups (need a live warehouse — flagged for the reviewer)
Unit tests cover `score()` and that the SQL *renders*, not that it *executes*.
Before merging to the deployed instance, validate against a real warehouse:
1. `interactive_to_job` v2 SQL — confirm the attribution + concurrency CTEs run
   and return sane per-job DBUs on the target account.
2. `cluster_autotermination` — confirm the new `job_active_minutes` /
   `nb_active_minutes` CTEs run, and that enabling `use_audit_activity` where
   `system.access.audit` is granted meaningfully reduces false idle.
3. `warehouse_autostop_serverless` — confirm the per-query gap SQL runs for
   serverless warehouses and that reclaimed idle looks right at a 1-min auto-stop.
4. `spot_fallback` / `serverless_cost_optimized` — confirm candidate SQL executes
   account-wide across clouds.
