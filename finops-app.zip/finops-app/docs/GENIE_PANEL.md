# Ask Genie panel (optional PoC)

An **"Ask Genie"** panel shown on the Account Overview, Workspace detail, and
Resource detail pages, so users can ask free-form questions over the precomputed
FinOps tables — the questions the fixed dashboard has no widget for ("compare
Genie spend to Apps spend by workspace", "how does this warehouse's spend compare
to others here").

It is a **feature toggle, off by default**. With it off, the app behaves exactly
as before and references Genie nowhere. Nothing in the deploy or the precompute
pipeline depends on it.

The panel has **two transports**, chosen by `FINOPS_GENIE_MODE`:

- **`api`** (recommended) — a native, context-aware chat proxied through the
  FastAPI backend (`POST /api/genie/ask` → the Genie **Conversation API**). The
  backend injects the workspace/resource the page is showing, answers render in
  the app's own UI, and **no dashboard-embedding allowlist is needed**.
- **`iframe`** — the original embedded Genie space. Cross-origin, so it cannot know
  what the page shows; starter questions are click-to-copy. Kept as the
  low-effort/no-code fallback.

## The three original limitations, and where each stands now

The first cut of this panel shipped with three limitations. Current status:

1. **The panel had no idea what the user was looking at.** *(fixed in `api` mode.)*
   The embedded iframe is cross-origin and cannot be pre-seeded (no URL parameter,
   no supported `postMessage`), so "why is this idle?" got a **contextless
   answer**. In **`api` mode** the backend holds the conversation and prepends the
   current `workspace_id` / `resource_id` / `resource_name` to the question
   (`services/genie_conversation._contextualize`), so it resolves to the actual
   resource; answers render in the app's own chat bubbles. `iframe` mode still has
   this limitation by nature — which is exactly why `api` mode exists.

2. **The space only saw the recommendation *output*, not the reasoning or source
   data.** *(fixed — the space can now pull up the logic and the raw data and
   reason with the user.)* Three things together:
   - a **flattened evidence view**, `finops_recommendations_evidence`
     (`precompute/ddl/finops_recommendations_evidence.sql`), exploding each
     finding's `evidence` JSON (CPU, idle, cost, sizing, failure rate, confidence)
     into columns, so *"which clusters had avg CPU under 5%?"* is answerable;
   - the **rule-knowledge catalog**, `finops_rule_catalog`
     (`precompute/ddl/finops_rule_catalog.sql`, built by
     `backend/finops/services/rule_catalog.py`) — one row per enabled rule with its
     **rendered detection SQL**, **thresholds + current values**, and the verbatim
     **scoring/savings source**, so the space can explain *why* a finding fired and
     a user can push back on the estimate with the actual formula in hand;
   - **SELECT on the system tables the rules read** (granted at deploy by
     `grant_genie_sources`, the exact set `finops_rules/sources.py` derives), so the
     space can re-run a rule's detection SQL against the raw data with a parameter
     changed — *"what would `warehouse_autostop` flag if `max_acceptable_minutes`
     were 15 instead of 30?"* — and reconcile the numbers.
   See [Ask Genie space instructions](GENIE_SPACE_INSTRUCTIONS.md) for the prompt
   that ties these together.

3. **The recommendation couldn't say who owns/created the resource.** *(fixed.)*
   `finops_recommendations` now carries `resource_owner` / `resource_creator`,
   resolved at precompute time from `billing.usage.identity_metadata` (see
   `backend/finops/data/owner_sql.py`) — no new source-table grant, since every
   rule already reads `billing.usage`. Nullable (some resource types carry no
   identity on their usage rows), and an unknown owner never suppresses a finding.
   Surfaced on the resource page and carried in the evidence view, so Genie can
   attribute a finding to a person.

## How it works

### `api` mode (context-aware chat)

- **Proxy, not embed.** `POST /api/genie/ask` (`api/genie.py`) opens/continues a
  Genie conversation via the Conversation REST API
  (`services/genie_conversation.py`), polling the async message to completion and
  returning the text answer plus any query + result-table preview.
- **Runs as the user.** The call uses the caller's OBO token
  (`x-forwarded-access-token`, or `DATABRICKS_TOKEN` locally), so Genie honours the
  user's own Unity Catalog grants. Unlike the SQL warehouse (where the forwarded
  token hangs, so the app uses its SP), the REST API accepts the user token; it
  falls back to the app SP if none is forwarded. Injected page context is
  **guidance, not a security boundary** — UC grants are.
- **OBO scope (required, easy to miss).** The forwarded user token is downscoped to
  the app's declared `user_api_scopes`, which is a property of the **app resource**
  — **NOT** `app.yaml` (an unknown key there is silently ignored, leaving the token
  at the two IAM defaults, and the Genie call 403s). The scope string is **`genie`**
  (not `dashboards.genie`), plus `sql` since Genie runs SQL on a warehouse. `deploy.sh`
  sets it after deploy: `apps update <name> --json '{"user_api_scopes":["genie","sql"]}'`
  when `GENIE_MODE=api`. **Changing scopes requires the user to RE-CONSENT** — reopen
  the app URL in a fresh/incognito session so the consent screen re-issues the token.
  The user also needs CAN RUN on the Genie space and CAN USE on the warehouse.
- **Frontend.** `<GenieChat>` renders the bubbles and threads `conversation_id`
  across turns so follow-ups keep context. `<GeniePanel>` picks it over the iframe
  when `genie_mode === "api"`.

### `iframe` mode (embedded space)

- **Embed.** The panel is an `<iframe>` pointed at a Genie space's embed URL — the
  fastest integration and it renders Genie's own charts natively. Cross-origin, so
  the app cannot pre-fill the chat box; the contextual starter questions are
  **click-to-copy** (`allow="clipboard-write"` is granted on the iframe).

### Gate (both modes)

`GET /api/config` returns `genie_enabled`, `genie_mode`, and `genie_embed_url`.
`<GeniePanel>` renders nothing unless enabled. The backend reports enabled only
when the toggle is on **and** a transport resolves (a space id for `api`, an embed
URL for `iframe`), so a half-configured deploy never shows a broken panel.

## Enabling it

1. **Create a Genie space** over the FinOps tables plus the rule catalog and the
   system tables the rules read — see [Ask Genie space
   instructions](GENIE_SPACE_INSTRUCTIONS.md) for the exact table list, the
   space-instruction text, and sample questions. In short: `finops_recommendations`,
   `finops_recommendations_evidence`, `finops_workspace_spend`, `finops_genie_usage`,
   `finops_apps_usage`, **`finops_rule_catalog`** (the calculations), and the
   granted `system.*` tables (for what-if / push-back). The deploy grants these when
   `GENIE_ENABLED=yes` (`grant_genie_sources`, targeting `GENIE_GRANT_TO` or
   `account users`). The `fe-internal-tools:genie-rooms` skill can author the space.
2. **Set the env vars** (deploy: `deploy/config.env`; local: `.env`):
   - `FINOPS_GENIE_ENABLED=true` (deploy config uses `GENIE_ENABLED="yes"`)
   - `FINOPS_GENIE_MODE=api` **(recommended)** or `iframe`.
   - **`api` mode:** set `FINOPS_GENIE_SPACE_ID=<id>` (the only thing it needs).
     No embedding allowlist. Requires a Genie Conversation API available in the
     workspace; the call runs as the signed-in user.
   - **`iframe` mode:** set `FINOPS_GENIE_SPACE_URL=https://<host>/embed/genie/rooms/<id>`
     (or just `FINOPS_GENIE_SPACE_ID=<id>` to build it from the host).
     - **Use the `/embed/genie/rooms/<id>` path**, not `/genie/rooms/<id>`: the
       interactive room URL always refuses framing ("refused to connect"); only
       the `/embed/...` endpoint is embeddable.
     - **Allow embedding:** the app is cross-origin to the Genie host, so its host
       must be on the workspace embedding allowlist (the AI/BI dashboard-embedding
       policy governs Genie too): Settings → Security → External access → **Embed
       dashboards** → Allow (or Allow approved domains + the app host); CLI
       `databricks settings aibi-dashboard-embedding-approved-domains update`.
       (Iframe usage is rate-limited to ~20 questions/min/workspace.)

## Scoping note

The panel inherits the signed-in user's Unity Catalog grants (the app runs in
OBO), which matches how the rest of the app scopes. In `api` mode the Conversation
API call is made **with the user's own token**, so UC grants apply directly; in
`iframe` mode the embedded space runs as the viewer. Genie does **not** enforce the
app's persona scoping via prompt — never rely on injected page context (`api` mode)
or an "only workspace X" instruction as a security boundary. In OBO this is a
non-issue; under SP mode you would need one space per scope or a trusted row filter.

## Files

- `backend/finops/config.py` — `genie_enabled` / `genie_mode` / `genie_space_url` /
  `genie_space_id` + `genie_embed_url` / `genie_space_id_resolved` / `genie_use_api`
  / `genie_panel_enabled`
- `backend/finops/api/meta.py` — exposes `genie_enabled` / `genie_mode` /
  `genie_embed_url` on `/api/config`
- `backend/finops/api/genie.py` — `POST /api/genie/ask` (the `api`-mode chat)
- `backend/finops/services/genie_conversation.py` — Conversation API proxy +
  context injection
- `backend/finops/models/genie.py` — `GenieAskRequest` / `GenieAskResponse`
- `frontend/src/components/GeniePanel.tsx` — mode switch (chat vs iframe)
- `frontend/src/components/GenieChat.tsx` — the native `api`-mode chat
- `frontend/src/hooks/useConfig.ts` — reads `/api/config`
- `precompute/ddl/finops_recommendations_evidence.sql` — flattened-evidence view
- `precompute/ddl/finops_rule_catalog.sql` + `backend/finops/services/rule_catalog.py`
  — the rule-knowledge catalog (detection SQL + thresholds + scoring)
- `docs/GENIE_SPACE_INSTRUCTIONS.md` — space table list + instruction text + samples
- `deploy/app.yaml.tmpl`, `deploy/deploy.sh` (`grant_genie_sources`),
  `deploy/config.env.example` — deploy wiring incl. system-table grants
