# Auth & persona scoping

Two independent switches: **who runs the SQL** (`FINOPS_AUTH_MODE`) and **which
workspaces a user sees** (persona scoping, derived from identity).

## Auth modes (`FINOPS_AUTH_MODE`)
### `obo` — on-behalf-of-user (dev default)
- Token from `DATABRICKS_TOKEN` locally, else the `x-forwarded-access-token`
  header injected by Databricks Apps (the simple_table_editor pattern).
- SQL runs **as the user**, so Unity Catalog grants naturally limit reads.
- Caveat: OBO alone can't reliably tell us the persona, and most workspace admins
  don't have account-wide `system.billing` access — so OBO is best for dev / a
  single power user. Persona in dev is simulated via `FINOPS_DEV_ROLE` /
  `FINOPS_DEV_WORKSPACES`. `backend/finops/identity/obo.py`.

### `sp` — service principal (prod default)
- The app runs as an SP granted account-wide `SELECT` on `system.*` (or read on
  the precomputed table). SQL uses the SP token.
- The **user's** identity still comes from forwarded headers; a user→scope
  mapping decides what they may see. `backend/finops/identity/service_principal.py`.
- PoC mapping source: `FINOPS_USER_SCOPE_JSON` env, e.g.
  ```json
  {"admin@corp.com": {"role": "platform_admin"},
   "ws@corp.com": {"role": "workspace_admin", "workspace_ids": ["123..."]}}
  ```
  Production should replace this with a governed `finops_user_scope` table.
  Unknown users default to workspace_admin with **no** workspaces (least privilege).

## Persona scoping (the security boundary)
`Scope.from_identity()` yields either `all_workspaces=True` (platform admin) or a
validated `workspace_ids` list (workspace admin). All data access funnels through
`backend/finops/data/scoping.py`:
- `where_clause(scope)` / `wrap_live(sql, scope)` inject `WHERE workspace_id IN (…)`.
- Workspace ids come **only from server-side identity**, never from client query
  params, and each is validated as digits (`ScopeError` otherwise). So a workspace
  admin cannot read another workspace by tampering with a request.

Tested by `backend/finops/tests/test_scoping.py` (incl. a forged-id rejection) and
`test_identity.py`.

## Required grants (prod / SP)
Grant the app's service principal `SELECT` on the system schemas it reads
(`system.compute`, `system.billing`, `system.lakeflow`) — or, in precompute mode,
`SELECT` on `main.finops.finops_recommendations` plus the precompute job's SP the
reads on `system.*`.
