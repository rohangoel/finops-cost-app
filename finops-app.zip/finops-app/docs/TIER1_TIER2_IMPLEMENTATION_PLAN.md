# Implementation plan — Tier 1 + Tier 2 detections and contract / cloud pricing

**Audience:** the agent (or person) implementing this. It is self-contained; read it
top to bottom before touching code.
**Source research:** [WASTE_COVERAGE_REVIEW_2026-09.html](WASTE_COVERAGE_REVIEW_2026-09.html)
(open it in a browser) — the 63-pattern waste → signal map, with live probe numbers.
**Written:** 2026-09-23.

---

## 0. Before you start

### Read first (in this order)
1. `AGENTS.md` — golden rule (a rule = 3 new files + 1 config block), boundaries,
   design principles, and the long handoff history. The gotchas there are real.
2. `docs/ADDING_A_RULE.md` — the 4 pieces, verify steps, new `resource_type` checklist.
3. `docs/SAVINGS_CONFIDENCE_MODEL.md` — confidence tier vs $ range; `savings_status`
   (`bookable | estimated | advisory`) and what the headline books.
4. `docs/DATA_MODEL.md` — recommendation schema and sibling tables.
5. `rules/finops_rules/sql/_macros.sql.j2` — **all pricing flows through here**
   (`price_join`, `price_rate`, `unpriced_dbus`, `usage_cost_cte`, `window_lower`,
   `latest_scd_cte`). Workstream A extends it.
6. `rules/finops_rules/pricing.py` — there is already a `list | effective` pricing-mode
   stub (`PRICING_MODE_EFFECTIVE`, `FINOPS_EFFECTIVE_PRICE_SOURCE`) that refuses to run
   without a net-cost source. `system.billing.account_prices` **is** that source.
7. `rules/finops_rules/coverage.py` + `sources.py` — the price-coverage guard and the
   table-dependency preflight. Mirror their patterns; don't invent new ones.

### Branch
**Work on `finops-app/tier1-tier2-pricing`**, branched from `origin/main` @ `d567933`
(2026-09-23). It carries these **uncommitted** changes, brought over deliberately by the
user:
- the `gpu_wrong_runtime` rule (untracked catalog/SQL/test files + `thresholds.yaml`
  block + classification-map entry) and the GPU-aware change to `idle_serving_endpoints`;
- the `precompute/central-beta/` removal (the beta pipeline is decommissioned);
- `.gitignore` (`.databricks/`) and a local `app.yaml` pointing at the `finops_beta` deploy.
  **Don't commit `app.yaml`** unless the user asks. It's deploy-local.

Commit the GPU work + central-beta removal as their own first commit, before the plan's
work, so the PR history stays readable. 919 tests pass in this state.
Note: an Agent worktree branches from `origin/main` and will **not** see these
uncommitted files, so work in the main checkout.

### Validation workspace
| | |
|---|---|
| CLI profile | `fevm-finops-stable-us` |
| Warehouse | `28ee85f85d49811e` (Serverless Starter, auto-starts) |
| Writable catalog | `finops_stable_us_catalog` (`main` is NOT writable) |
| Deployed app | https://finops-app-7474658295346209.aws.databricksapps.com |

Every probe number below came from this account. In it,
`billing.account_prices`, `billing.cloud_infra_cost`, `billing.attributed_usage` and
`storage.table_metrics_history` **exist but are empty**. The Azure (`fe-vm-classic-stable-ij3nfe`)
and `fevm-serverless-stable-dsfinops` profiles were not logged in when checked. Central
logfood (`main.centralized_system_tables`) has **only** `billing_usage` + `billing_list_prices`.
⇒ **No reachable account has contract or cloud-infra data.** See risk R1.

### Conventions that apply to every item
- **New rules ship `experimental = True`** (Labs tab; out of totals, NBA, and the central
  logfood pipeline) and are **promoted** only after a live run looks right. Promotion =
  flip the flag + update the classification map. This is the Phase-4 convention.
- **Every new rule** must add itself to
  `rules/finops_rules/tests/test_savings_status_classification.py` (ADVISORY or
  bookable map). The suite fails otherwise — that is intentional.
- `score()` guards, in order: `insufficient_history(row, ctx)` (needs `observed_days` from
  SQL) → `underpriced(row)` for $-booking rules → rule-specific suppression → price.
- SQL: no `workspace_id` filter (scoping is injected), outer SELECT exposes
  `workspace_id`, use `window_lower()`, `latest_scd_cte()` for SCD tables, and
  `usage_cost_cte()` / `price_join()` for dollars — **never hand-roll a price join**
  (the macro exists because hand-rolled joins fanned out and read the wrong price field).
- **Execute every new SQL template once, live**, before writing `score()`. Column names
  in system tables differ from the obvious guess (see `AGENTS.md` and the memory note
  "system-table column gotchas"). Tests on dict fixtures cannot catch this.
- Tests: `RuleContext` built inline, plain-dict fixtures, no YAML, no warehouse.
  `make test` (or `PYTHONPATH=rules:backend python -m pytest backend/finops/tests rules/finops_rules/tests -q`).
- Frontend: `tsc -b` + `vite build` clean; screenshot-check demo mode in **light and dark**.

---

## 1. Shape of the work and sequencing

```
A. Pricing foundation (contract + cloud)   ← shared schema; ONE agent, do first
     A1 capability detection
     A2 SQL macros (contract price, cloud cost)
     A3 engine: derive contract / cloud figures centrally
     A4 schema mirrors (additive)
     A5 spend snapshot at contract price
     A6 UI: dual price display + basis switch
     A7 demo data for all three states
B. Tier 1 rules (6)                        ← parallelizable after A3 lands
C. Tier 2 (anomaly tab + 6 rules)           ← parallelizable; C1 is independent of A
D. Deploy + live validation
```

**Key architectural decision (why A comes first):** rules keep computing **list-price**
savings exactly as today. The engine derives the contract and cloud figures **centrally**
from per-resource cost columns the shared macro emits. So a rule author never writes
contract-pricing logic, and every existing *and* new rule picks it up for free.
Only a few "counterpart" rules need special handling (A3).

If you must parallelize immediately, B and C rules can be written against list pricing
before A lands; they gain contract figures automatically once A3 merges.

---

## A. Pricing foundation — contract prices + cloud infra cost

### The user's requirement (verbatim intent)
> account_prices is great, cloud_infra_cost if possible — but if not all prices are
> account prices the sum will be strange. Display two prices or otherwise make it clear.

### Design principles for pricing
1. **List price remains the always-complete basis.** Every finding always has a list figure.
   The list headline is unchanged by this work (regression-tested, see A-DoD).
2. **A contract figure exists only where it is fully backed.** Per finding, compute
   `contract_price_coverage` = share of the resource's DBUs that had an `account_prices`
   match. Emit a contract figure only when coverage ≥ `contract_min_coverage` (default
   0.95, in `thresholds.yaml` engine block). Otherwise the finding is `price_basis = 'list'`.
3. **Never blend silently.** Any total shown at contract basis is displayed as
   *Σ contract (covered findings) + Σ list (uncovered findings)* **with an explicit coverage
   chip** ("96 % at contract rates · $12k at list"). The two parts are also available
   separately on hover/expand.
4. **Cloud VM cost is a separate, additive layer, never folded into the Databricks $.**
   It is classic-compute only and often in preview, so it is shown as its own line
   ("+ $Y/mo cloud VM") and its own KPI, with its own coverage.
5. **Capability-gated.** If a table is absent or empty, the UI looks exactly like today
   (plus one quiet "priced at list" note).

### A1. Capability detection
- Add a cheap capability probe (pattern: `backend/finops/services/health_service.py` /
  `rules/finops_rules/sources.py`): does `billing.account_prices` have any row with a
  `price_end_time IS NULL OR > now()` for the configured currency? Does
  `billing.cloud_infra_cost` have rows in the lookback window?
- Result flows to (a) the rule-rendering context as Jinja flags `contract_prices: bool`,
  `cloud_costs: bool`, and (b) `/api/meta` (or existing health/meta endpoint) as
  `pricing: {contract_available, contract_coverage_account, cloud_available, cloud_currency}`
  so the frontend can gate the switch.
- Central logfood mode: both flags are forced **false** (tables not in the central
  namespace). `resolver.py` must not be asked for them.
- Pipeline (`precompute/pipeline.py`): run the probe once per update; pass flags into rule
  rendering. Log them into the run log table.

### A2. SQL macros (`_macros.sql.j2`)
Add, guarded by `{% if contract_prices %}` so rendered SQL is **byte-identical** when the
flag is off (the golden-diff / SDP-parity tests depend on this):
- `contract_price_join(alias='ap', usage='u', sku_expr=None)` — same keys as `price_join`
  (sku, cloud, usage_unit, currency, validity window; `account_id` in central) against
  `billing.account_prices`.
- `contract_rate(alias='ap')` → `CAST(ap.pricing.default AS DOUBLE)`. **Verify the field**:
  in the probe account the struct was `struct<default:decimal(38,18)>` (no
  `effective_list`). Re-check on an account with data (R1).
- In `usage_cost_cte`, when the flag is on, also emit:
  `cost_30d_contract_usd = SUM(u.usage_quantity * contract_rate)` and
  `contract_priced_dbus = SUM(CASE WHEN ap.sku_name IS NOT NULL THEN u.usage_quantity ELSE 0 END)`.
- Templates that price **without** `usage_cost_cte` (hand-written cost CTEs using
  `price_join` directly — see the usage counts: ~26 templates) need the same two columns.
  Do this as one mechanical pass. The rule-agnostic test in A3 catches any you miss.
- `cloud_cost_cte(cte_name, id_col, id_alias)` (flag `cloud_costs`) — 30-day
  `SUM(cost)` from `billing.cloud_infra_cost` keyed by `usage_metadata.cluster_id |
  warehouse_id | instance_pool_id`, restricted to `currency_code = '{{ currency }}'`,
  using `window_lower('usage_date')`. Emits `cloud_cost_30d_usd`, `cloud_observed_days`.
  Joined only by rules on classic resources (clusters, classic/pro warehouses, pools, job
  clusters via `job_run_id → cluster_id`).

### A3. Engine: derive contract + cloud figures centrally
Location: the shared `build_recommendation` path (find it from `contract.py` /
`backend/finops/services/recommendation_service.py`; demo mode uses the same path).

- New `Rule` class attributes (defaults keep existing rules working):
  - `contract_pricing: Literal["ratio", "counterpart", "none"] = "ratio"`
  - `cloud_savings: Literal["proportional", "full", "none"] = "none"`
- **ratio** (default, almost every rule — savings are a fraction of the resource's own spend):
  `r = cost_30d_contract_usd / cost_30d_usd` over the row. Apply `r` to point, low and high
  list savings → `monthly_savings_contract_usd` / `_low_` / `_high_`. Store
  `effective_discount = 1 - r` in evidence.
- **counterpart** — savings are a price *gap* between two SKUs, so a ratio on the source
  SKU is wrong. The rule's SQL prices both sides at contract rates using
  `contract_price_join(..., sku_expr=...)`, and `score()` sets the contract figure
  explicitly. If either side lacks a contract price → contract figure `None` (list only).
  Known counterpart rules: `interactive_to_job` (all-purpose vs jobs SKU), `enable_serverless`
  (classic/pro vs serverless SQL SKU), `serverless_cost_optimized` (check whether the
  performance target changes the SKU/price — if not, it's `ratio`). Audit the rest.
- **none** — $0 / advisory rules (`untagged_spend`, contention, etc.).
- Coverage gate: if `contract_priced_dbus / dbus_30d < contract_min_coverage` → contract
  fields `None`, `price_basis = 'list'`, `contract_price_coverage` still recorded.
- **Cloud savings** (`cloud_cost_30d_usd` present, flag on):
  - `proportional` — the action removes running time or nodes in the same proportion as
    DBUs: `monthly_cloud_savings_usd = to_monthly(cloud_cost_30d) × (list_savings / list_monthly_cost)`.
    Applies to `autotermination`, `idle_zombie_clusters`, `rightsize_underutilized`,
    `jobs_compute_rightsize`, `warehouse_autostop`, `warehouse_rightsize`,
    `instance_pool_idle`, and the new B6 rule.
  - `full` — the action eliminates the classic VM entirely: `enable_serverless`
    (serverless DBU price already includes infra). This materially *improves* the
    serverless case and is the headline reason to wire `cloud_infra_cost`.
  - `spot_fallback` stays advisory, but gains `cloud_cost_at_risk_usd` (the on-demand
    VM spend) in evidence. The spot price isn't in the data, so don't price the saving.
- **Guarantee test (write it first):** a parametrized test over `list_rules()` asserting
  that, for a fixture row with `cost_30d_contract_usd = 0.8 × cost_30d_usd` and full
  coverage, every `ratio` rule's contract savings = 0.8 × list savings, and every rule
  with `contract_pricing='counterpart'` sets its own figure or `None`. This is what catches
  a template you forgot in A2.
- `pricing.py`: `pricing_mode_note()` must become per-finding. Findings with
  `price_basis='contract'` get "priced at your contract rates (system.billing.account_prices)";
  list findings keep the existing list-price disclaimer. Retire or repurpose the global
  `effective` mode so it can't contradict the per-finding basis.

### A4. Schema — additive, all mirrors in one commit
Shared interface: update **all** of `backend/finops/models/recommendation.py`,
`precompute/ddl/finops_recommendations.sql`, `frontend/src/api/types.ts`,
`backend/finops/services/contract_schema.py` (+ `contract_schema_central.py`),
`precompute_source._COLUMNS`, and `docs/DATA_MODEL.md`. All new fields are **nullable**:

| field | type | meaning |
|---|---|---|
| `price_basis` | `'list' \| 'contract'` | which basis the contract figure (if any) used |
| `contract_price_coverage` | float 0–1, null | share of the resource's DBUs with a contract price |
| `monthly_savings_contract_usd` | float, null | point estimate at contract rates |
| `monthly_savings_contract_low_usd` / `_high_usd` | float, null | range at contract rates |
| `cloud_cost_30d_usd` | float, null | classic VM cost of the resource (cloud_infra_cost) |
| `monthly_cloud_savings_usd` | float, null | cloud VM saving, separate from DBU savings |

- Backward compatibility (GitHub issue #108): the app must read an old snapshot that
  lacks these columns (defensive reads → `None`), and an old app must tolerate the new
  columns. Extend `test_contract_schema*.py`.
- **SDP JSON bridge:** new nullable fields cross `to_json(struct(*))` → `json.loads`.
  `_JSON_OPTIONS` already pins `ignoreNullFields=false`. Add these fields to
  `precompute/tests/test_json_bridge.py` so a null vs absent regression is caught.
- `SDP` outputs are materialized views, so there's no `ALTER TABLE` migration: the next
  pipeline update re-materializes with the new columns. Do **not** pre-create tables in
  `deploy.sh`.

### A5. Spend snapshot at contract price
`backend/finops/data/spend_sql.py` + `precompute/pipeline.py::_build_spend` +
`precompute/ddl/finops_workspace_spend.sql`: add `total_spend_contract_usd`,
`contract_priced_share`, `total_cloud_cost_usd` (all nullable). The Total Spend KPI
follows the same display rules as A6. Remember the DECIMAL→DOUBLE cast gotcha in that
file.

### A6. UI — how two prices are shown
Files: `frontend/src/lib/format.ts` (`money`), `KpiHeader.tsx`, `SavingsBadge.tsx`,
`SavingsRange.tsx`, `GroupTable.tsx`, `OptionCard.tsx`, `RecommendationCard.tsx`,
`recDetailParts.tsx`, `ResourceDetail.tsx`, `AccountOverview.tsx`, `WorkspaceDetail.tsx`,
`Layout.tsx`/`WorkspaceSwitcher.tsx` (top bar), `lib/scope.ts` (localStorage pattern).

1. **One money path.** Introduce `lib/price.ts` with `savingsFor(rec, basis)` and
   `totalFor(recs, basis)` returning `{ value, contractPart, listPart, coverage }`. Then
   replace every direct read of `monthly_savings_usd` / `_low_` / `_high_` in components
   with it. Grep for all reads first; that grep is the checklist.
2. **Global "Price basis" switch** in the top bar, next to the workspace switcher:
   `List price | Your rates`. Render it only when `pricing.contract_available`. Persist it
   in localStorage and sync it across windows, as the workspace scope does.
   **Default:** `Your rates` when account-level contract coverage ≥ 95 %, else `List`.
   Confirm this default with the user (decision D1).
3. **Totals at "Your rates"** show the blended value **plus** a coverage chip:
   `$318k/mo · 96 % at your rates` → hover/expand: "$306k at contract rates
   (1,204 findings) + $12k at list (37 findings without a contract price)".
   The secondary basis is always one line below the KPI ("$401k at list price"), so both
   numbers are visible without toggling.
4. **Per finding** (tables, cards): show the selected basis, and put a small `list`
   marker on rows that fell back to list in "Your rates" mode.
   **Detail page:** always both, side by side: `List $1,240/mo · Your rate $967/mo (−22 %)`,
   plus the basis sentence in data_basis.
5. **Cloud VM layer** (only when `cloud_available`): a separate KPI "Cloud VM savings
   (classic compute)" and a `+ $Y cloud VM` sub-line on affected findings. It is never
   added into the Databricks KPI. It carries its own coverage note ("N of M classic
   findings have cloud cost data").
6. **Sorting / NBA:** ranking stays on the **list** basis, so rank order is identical for
   every viewer and toggling doesn't reshuffle the list. Table sort-by-savings uses the
   selected basis. Confirm with the user (decision D2).
7. Rule Catalog / About Serverless: when cloud data is present, the serverless case shows
   TCO (DBU + VM) for classic resources. That's the most persuasive use of this data.

### A7. Demo mode (`backend/finops/data/demo_source.py`)
Add three switchable states so the UI can be built and screenshot-tested offline:
`FINOPS_DEMO_PRICING=list | contract | contract_partial` (+ `FINOPS_DEMO_CLOUD=0|1`).
`contract` = ~22 % discount on all SKUs; `contract_partial` = discount on most SKUs, a few
uncovered (exercises the blended total + chip + fallback marker). Generate the figures
through the real `build_recommendation` path, as demo mode already does.

### A — Definition of done
- With flags **off**: rendered SQL byte-identical to before (golden / SDP-parity pass
  unchanged); list headline unchanged to the cent on a live run.
- The guarantee test from A3 passes for every rule.
- Demo screenshots in all three pricing states × light/dark; the blended total's chip
  math checks out by hand.
- Live run on `fevm-finops-stable-us`: flags detected false; UI shows "priced at list",
  no switch.

---

## B. Tier 1 rules

Each item = `catalog/<id>.py` + `sql/<id>.sql.j2` + `tests/test_<id>.py` + a
`thresholds.yaml` block + a classification-map entry. Ship `experimental = True`.
Rules are independent, so they can be parallelized across agents.

### B1. `warehouse_keepalive_queries` — warehouse kept warm by trivial/metadata queries
- **Why a new rule:** `warehouse_autostop*` see the idle gaps and recommend a shorter
  auto-stop. That doesn't help when a BI tool or poller issues a statement every few
  minutes, because the timer never expires. The fix is on the **client**.
- **Signal** (`query.history`): per warehouse per hour, classify statements as *trivial*
  = `statement_type IN ('SHOW','DESCRIBE','USE','SET','OTHER')` OR
  `COALESCE(total_task_duration_ms,0) = 0` OR text matches `^select\s+1\s*;?$`.
  A **trivial-only hour** = warehouse billed that hour and every statement in it was
  trivial. Attribute by `client_application` / `executed_by` so `how` can name the culprit
  (e.g. "Tableau Server, user svc_bi").
- **Pricing:** Σ billed cost of trivial-only hours (hourly billing per warehouse from
  `billing.usage` × `price_join`) → `to_monthly`. Serverless warehouses bill the same way,
  so include them. Suppress if trivial-only hours < `min_trivial_hours` (e.g. 24 per 30 d)
  or $ < floor.
- **Status:** `estimated` first. Some "trivial" hours are legitimate: a caching layer
  pre-warming, or genuine `SHOW` usage. Medium confidence. Promote after reviewing a
  sample of top offenders' statement texts.
- **Overlap:** the same warehouse may also have an auto-stop finding. Set
  `savings_composition` so the resource detail doesn't double-count. Check how
  `savings_composition` / grouping de-dupes per resource and follow that.
- **Viz:** reuse the hour-heatmap payload, coloured by real vs trivial-only hours.
- **Probe:** 87 / 1,061 warehouses had ≥ 24 trivial-only hours in 14 days; mean 17 % of
  active hours. Starting SQL in Appendix P1.

### B2. `job_runaway_no_timeout` — hung/runaway runs on jobs without a timeout
- **Signal:** job's current SCD row from `lakeflow.jobs` (`timeout_seconds`) + per-task
  `lakeflow.job_tasks.timeout_seconds` + `health_rules`. Runs from `job_run_timeline`
  (aggregate the hourly-sliced rows per `run_id`: `max(period_end) - min(period_start)`;
  `run_duration_seconds` is populated on the final slice).
- **Detection:** job has ≥ N runs (e.g. 8) in window; run is an outlier if duration >
  `outlier_multiple` (5) × job p50 **and** > 1 h. Exclude `trigger_type='CONTINUOUS'`
  and streaming jobs. **Bimodal guard:** require the outlier to exceed the job's p90 as
  well, and suppress jobs whose p90/p50 ratio is already > 3 (normal durations have two
  peaks, e.g. month-end runs).
- **Pricing:** billed cost of outlier runs (`usage_metadata.job_run_id`) × (excess
  duration / run duration) → excess spend → `to_monthly`. Recommend
  `timeout_seconds ≈ 3 × p95` and a `RUN_DURATION_SECONDS` health rule.
- **Suppression:** job already has a timeout **and** outliers stopped at it → no finding,
  since the timeout works. If a timeout exists but is > 10× p95, recommend tightening.
- **Status:** `estimated`. **Probe:** 84 % of 80.6k jobs have no job-level timeout; 82
  jobs had 18.6k outlier runs (~129k excess wall-hours). That concentration (few jobs,
  many runs) looks like frequent jobs with variable durations. **Inspect the top 5 before
  trusting the guard.** Appendix P2.

### B3. `job_task_retry_waste` — retries hidden inside eventually-successful runs
- **Why separate from `failing_jobs`:** that rule prices failed *runs*; a run that ends
  SUCCESS after retries is invisible to it. Keep it a sibling rule (golden rule: don't
  edit shared/other rules).
- **Signal:** `job_task_run_timeline` — multiple task-run rows (distinct `run_id`) for the
  same (`job_run_id`, `task_key`) = attempts. Count the failed attempts before the final
  success.
- **Pricing:** billed cost of the failed attempts. Attribute via `usage_metadata.job_run_id`
  plus the task's compute share. Where only run-level billing exists, apportion by
  attempt duration. Then `to_monthly`.
- **Suppression:** excess retry rate above a baseline (mirror `failing_jobs`' excess-over-
  baseline logic so noise-level retries book ~$0). Check before writing: run 3-4 queries to
  confirm how retries appear in `job_task_run_timeline` (attempt number column? separate
  run_id? `parent_run_id`?). Don't assume.
- **Status:** `estimated` → `bookable` candidate once validated (the failed-attempt cost
  is measured, not modelled).

### B4. `pipeline_full_refresh_churn` — pipelines doing frequent full refreshes
- **Signal:** `lakeflow.pipeline_update_timeline` — `full_refresh_selection` non-empty or
  full-refresh `update_type`. Verify the actual values live. Frequency per pipeline and
  whether they are scheduled (`trigger_type`) or manual.
- **Pricing:** cost per update from `billing.usage.usage_metadata.dlt_update_id`.
  Saving = Σ (full-refresh update cost − median incremental update cost of the same pipeline).
- **Suppression:** ≤ 1 full refresh per window; pipelines with no incremental updates to
  compare against (the saving can't be priced, so advisory).
- **Status:** `estimated`. `how`: reset the flag in the job/scheduler; check why the
  incremental path is failing (schema change, checkpoint issue).

### B5. `serving_provisioned_overcapacity` — provisioned throughput above real traffic
- **Signal:** `serving.served_entities.foundation_model_config.min_provisioned_throughput`
  / `max_...` (current SCD) + `serving.endpoint_usage` tokens per minute (p95/p99) +
  billing with `product_features.model_serving.offering_type = 'PROVISIONED_THROUGHPUT'`.
- **Two findings, one rule** (or two rules if cleaner):
  a) **Floor too high:** p99 observed throughput ≪ `min_provisioned_throughput` → lower the
     floor / enable scale-to-zero. Saving = billed PT cost × (1 − needed/provisioned).
  b) **Wrong pricing mode:** at observed token volume, pay-per-token would cost less than PT
     spend (price the token volume at the pay-per-token SKU via `price_join` with
     `sku_expr`) → switch. The reverse (heavy pay-per-token that should be PT) is
     informative only, since it's a cost increase for reliability.
- Must not overlap with `idle_serving_endpoints` (idle = zero traffic). Suppress here when
  traffic is zero.
- Throughput units: PT is provisioned in model-specific "tokens/sec" bands. Confirm the
  unit of `min_provisioned_throughput` against docs and one real endpoint before the math.
- **Status:** `estimated`. **Probe:** PT foundation-model serving = 2.6M DBU / 30 d.

### B6. `allpurpose_shape_mismatch` — driver-bound or wrong-family all-purpose clusters
- **Why:** `jobs_compute_rightsize` already classifies `driver_bound` / `memory_oversize`,
  but only for job clusters. `rightsize_underutilized` (all-purpose) is CPU-only.
- **Signal:** `node_timeline` with the `driver` flag (driver p95 CPU high, workers ~0 % →
  single-node), and `compute.node_types` (`memory_mb / core_count`) × `mem_used_percent`
  p95 (memory-optimized family at < 35 % memory, or compute-optimized family swapping →
  wrong family).
- Reuse the classification logic: read `jobs_compute_rightsize.py`. If shared helpers are
  worth extracting, put them in a new module. Don't edit that rule's behaviour.
- **Pricing:** driver-bound → worker share of cost. Family mismatch → DBU/hr delta
  between current and suggested family, taken from **observed** DBU/hr per node type in
  `billing.usage` (`usage_metadata.node_type`). System tables carry no DBU rate per
  instance type. If the suggested type was never billed in the account → advisory.
- **Overlap:** the same cluster may have `rightsize_underutilized` / `autotermination`
  options. Follow the resource-group semantics (options sorted by savings; set
  `savings_composition`).
- `cloud_savings = "proportional"` (A3).

---

### B7. `idle_serving_endpoints` — zero LOGGED requests ≠ zero requests (found while building B5)
- **Problem:** `system.serving.endpoint_usage` only records endpoints with **usage
  tracking** enabled, and no system table says whether it is on. The rule treated
  "0 logged requests" as measured idleness (HIGH confidence, **bookable**). Live on
  `fevm-finops-stable-us`: 35 of 40 zero-traffic candidates had **never** logged a
  request in the table's whole retained history (~90 days, from 2026-06-21). That
  includes 11 always-on provisioned-throughput endpoints at up to $13.2k/mo each. For
  those, idle and untracked look identical.
- **Done (2026-09-23):**
  - The SQL counts requests over the whole retained history (`requests_retained`,
    `last_request_retained`).
  - An endpoint that logged calls before and then went quiet proves tracking works. It
    stays HIGH / bookable, and the `why` now names its last logged request.
  - An endpoint that has never logged anything becomes `traffic_tier = zero_unverified`,
    MEDIUM confidence and **estimated** (out of the booked headline). Its `why` leads
    with the doubt, and its `how` starts with "First verify it is really unused".
  - The finding carries `evidence.data_warning`. That is a new generic evidence key: the
    UI renders it as a warning callout above the action on the detail card, plus an
    "Unverified" tag on list rows and option headers.
  - The pre-flight checklist gained a usage-tracking bullet, and demo mode shows both
    tiers.
- **Still open:** read the actual setting where possible. The serving-endpoints REST API
  exposes the AI Gateway `usage_tracking_config` per endpoint. A precompute-side lookup
  could turn "unverified" into a definite yes/no. It's not in system tables, so it would
  need an API call per workspace. `evidence.data_warning` is reusable by any rule with a
  comparable blind spot (e.g. B5's quiet PT hours).

## C. Tier 2

### C1. Cost anomaly / spike detection — a new analysis tab, not a rule
Anomalies are not savings. Follow the **Genie / Apps tab pattern** exactly (new files +
additive wiring): `data/anomaly_sql.py`, `data/anomaly_source.py` (snapshot → live
fallback → honest `unavailable`), `models/anomaly.py`, `api/anomalies.py` (+
`/api/anomalies/{workspace_id}` via `Scope.narrowed_to`), `pages/CostAnomalies.tsx`,
a chart in `components/charts/`, `ddl/finops_cost_anomalies.sql`, and a
`pipeline.py::_build_kinded_sink` sink. Add the route to `SCOPED_PAGES` in
`WorkspaceSwitcher.tsx`.
- **Grain:** daily cost per (workspace, `billing_origin_product`, SKU) and per top
  resource id (cluster / warehouse / job / endpoint / app / pipeline).
- **Method:** baseline = trailing 28 days excluding the last 7, median + MAD. Flag a day when
  `(cost − median) / (1.4826·MAD) > z` (e.g. 4) **and** Δ$ ≥ floor (e.g. $200/day or 3 %
  of the workspace's daily spend). Types: *spike* (1–2 days), *step change* (≥ 3
  consecutive days above), *new spender* (resource or SKU with no baseline and spend ≥ floor).
  Exclude today (partial day; use `window_lower`).
- Each anomaly links to the resource/workspace and shows the "who" (`identity_metadata.run_as
  / owned_by`).
- Model fields carry **no** `monthly_savings_usd` / priority / NBA (like `AppsInventory`).
  Add the test asserting their absence.
- Show $ in the selected price basis (A6) when available.
- Can be built in parallel with A. It only needs list pricing to start.

### C2. Pricing accuracy — covered by workstream A.

### C3. `alert_hygiene`
- **Signal:** `alert.alerts` (current SCD: `subscriptions`, `schedule.quartz_cron_schedule`,
  `pause_status`, `compute.warehouse_id`, `delete_time`) + `alert.alert_evaluation_history`
  (`error_code`, `evaluated_state`) + `query.history.query_source.alert_id`.
- **Findings:** (a) always erroring for ≥ 7 days (fix or delete), (b) no subscribers
  **and** no job wiring (`job_id` null in evaluation history) → nobody is notified,
  (c) evaluated ≥ hourly on a **classic/pro** warehouse where alert queries are the only
  activity in otherwise idle hours → keeping it warm (reuse B1's trivial-hours logic,
  treating alert queries as the "trivial" class).
- **Status:** advisory $0 for (a)/(b); (c) `estimated` with the warm-hours cost.
  **Probe:** 799 live alerts: 511 no subscribers, 34 always erroring, 80 evaluated hourly+.
  Check the no-subscriber ones for job-driven notification before trusting the count.

### C4. `unviewed_scheduled_dashboards`
- **Signal:** `query.history.query_source.dashboard_id` task time vs `access.audit`
  (`service_name='dashboards'`, `action_name IN ('getDashboard','getPublishedDashboard','getDashboardDetails')`,
  `request_params['dashboard_id']`). Verify the key name live; the probe used
  `dashboard_id` with a `dashboardId` fallback.
- **Pricing:** dashboard's share of warehouse `total_task_duration_ms` × warehouse cost.
  Use `billing.attributed_usage` when present.
- **Guards:** depends on audit (respect `FINOPS_NO_AUDIT` / `sources.py` preflight → the
  rule reports "not evaluable", not "no findings"). Require ≥ 14 days with zero views.
  Embedded / API views may not audit, so use medium confidence and `estimated`.
- **Probe:** 65 / 1,621 dashboards, 19 % of dashboard task-hours, zero views in 14 days.

### C5. `warehouse_min_clusters`
- **Signal:** current `compute.warehouses.min_clusters > 1`; `warehouse_events`
  (`SCALED_UP/DOWN`, `cluster_count`) and per-minute concurrent queries from
  `query.history` → how often concurrency needed more than 1 cluster.
- **Pricing:** billed hours where running clusters > needed clusters × per-cluster hourly
  cost. Recommend `min_clusters = 1` (autoscaling still adds clusters on demand).
- Coordinate with `warehouse_scale_out` (it reads `min_clusters` for the opposite
  direction). Make sure the two can't recommend opposite changes for one warehouse.
- **Status:** `estimated` → `bookable` candidate. **Probe:** 24 warehouses with min > 1,
  one pinned at 30.
- **Include serverless explicitly.** A serverless warehouse with `min_clusters > 1` and
  auto-stop already at the 2-min floor slips past every existing rule:
  `warehouse_autostop*` has nothing to shorten, `warehouse_rightsize` holds back once
  queueing is above 2 %, and B1 doesn't fire when the queries do real work. C5 is the only
  rule that can see it.
- **Price restart churn in cluster-minutes, not billed hours.** The costly shape is not a
  warehouse held warm. It is a warehouse woken dozens of times an hour by short queries,
  where every start brings up `min_clusters` clusters that then sit out the idle timer.
  At hourly grain every hour looks busy, and the excess spreads thin enough to vanish.
  Rebuild cluster-minutes from the `warehouse_events` sequence
  (`STARTING`/`RUNNING`/`SCALED_*`/`STOPPING`/`STOPPED` with `cluster_count`), compare
  them with the clusters per-minute concurrency actually needed, and price the gap. Emit
  `starts_per_day` as evidence.
- **Name the second remedy in `how`.** When the wake-ups come from a service querying
  every few minutes around the clock, say so (from `client_application` / `executed_by`).
  Batching those queries, or moving them to a small dedicated warehouse, also stops the
  wake-ups. `min_clusters = 1` fixes the multiplier, not the pattern.
- **Guard the scale-out interaction with a test (R3).** With `min_clusters = 1`, queries
  arriving right as the warehouse wakes may queue until autoscaling adds the second
  cluster. Only recommend it when per-minute concurrency shows 1 cluster suffices for
  most running minutes. Add a fixture that has both `min_clusters > 1` and moderate
  queueing, and assert C5 and `warehouse_scale_out` don't recommend opposite changes.
- **Real validation case, found 2026-09-23 in the central logfood data (Zepz).**
  Warehouse `sanctions` (`a5a8f3dac52e018f`, ws `7886352121246788`): serverless MEDIUM,
  `min_clusters = 2`, `max_clusters = 3`, auto-stop 2 min, ~$13.7k/mo list, ~1,000
  DBU/day (≈ 40 cluster-hours/day). Over 30 days: 10,133 queries (p50 ~1 s), ~40 h of
  total query time, a query running in only 207 distinct hours, and ~5,770 start/stop
  cycles (≈ 190/day, 40–77 per hour, 24/7). 96 % of statements are real SELECTs from a
  service principal (JDBC plus an unnamed client), so B1 correctly doesn't fire. Queueing
  is 4.5 %. The current snapshot has **no savings finding for it** (only
  `untagged_spend`). A rough estimate is several $k/mo from `min_clusters = 1` alone. Use
  it to hand-check C5's pricing before promoting it out of Labs (R4).

### C6. `instance_generation_modernize`
- **Signal:** `billing.usage.usage_metadata.node_type` / `compute.clusters.worker_node_type`
  matched against a **maintained mapping** (new YAML under `config/`, e.g.
  `instance_generations.yaml`) of previous → current generation and x86 → Arm (Graviton /
  Azure Cobalt) per cloud, with the minimum DBR supporting it.
- **Pricing:** DBU/hr delta only where both types were billed in the account (observed
  rate); VM delta only when `cloud_infra_cost` is present, and even then the new type's
  VM price isn't known → **advisory**, with `$ at stake` = spend on old-generation nodes.
- **Probe:** 37 % of classic DBUs run on previous-generation families; Graviton 1 %.

### C7. `job_no_new_input` — scheduled runs whose upstream data didn't change
- **Signal:** `access.table_lineage` — per job (`entity_type='JOB'`/`entity_id`), the set
  of source tables it reads; per source table, the last write event time (lineage
  `target_table_full_name` writes by anyone). A run is **no-new-input** if no source had a
  write since the job's previous successful run.
- **Pricing:** cost of no-new-input runs (`job_run_id` billing). Recommend a table-update
  trigger (`trigger.table_update`) or file-arrival trigger.
- **Guards:** lineage misses path-based reads and external sources. Suppress jobs with any
  non-UC / path read (`source_type` / `source_path`) and jobs with zero lineage.
  Medium confidence, `estimated`. Lineage is large (95M rows / 30 d), so pre-aggregate
  per (table, day) first.

### C8. `unpruned_repeated_queries`
- **Signal:** `query.history` grouped by a normalized statement fingerprint (strip literals;
  `sql_query_id` / `dashboard_id` when present) with ≥ N executions: `read_files` vs
  `pruned_files`, `read_bytes`, `from_result_cache`, `total_task_duration_ms`.
- **Findings:** heavy repeated scans with ~no file pruning → liquid clustering on the filter
  columns or a materialized view; result cache never hit on an identical query → probably
  non-deterministic (`now()`, `current_timestamp`).
- **Pricing:** fingerprint's task-time share × warehouse cost (exact via
  `attributed_usage` when available). **Advisory** first: the improvement factor from
  clustering is unknown, so show "$ spent on this query shape" rather than a saving.

---

## D. Deploy + live validation
1. Rebuild the wheel (**stale-wheel gotcha:** `pipeline.py` imports from the wheel; a
   stale wheel ships old code silently). Deploy the precompute bundle and run one update
   on `fevm-finops-stable-us` (recipes in `AGENTS.md`, `docs/DEPLOYMENT.md`; TF exec-path
   workaround). Then deploy the app (`deploy/deploy.sh --app-only`).
2. Per new rule: finding count, top-5 findings sanity-checked by hand against the probe
   numbers above, and no NaN / negative $.
3. Pricing: confirm flags are false in this account and the UI shows the list-only state.
   If any account with `account_prices` data becomes reachable, run there too (R1).
4. Update the `AGENTS.md` handoff section (new session entry, verified numbers, what was
   **not** verified), `docs/DATA_MODEL.md`, and the Rule Catalog copy.
5. PR per workstream (A, B-rules can be one PR each or grouped, C1). Announce in
   #finops-app (one line + PR link) per `AGENTS.md`.

---

## Decisions (confirmed by the user 2026-09-23)
- **D1 ✅** Default price basis when contract data exists: `Your rates` if account
  coverage ≥ 95 %, else `List`.
- **D2 ✅** NBA ranking stays on the list basis.
- **D3 ✅** Cloud VM savings are a separate KPI/line only, never added into the Databricks
  headline.
- **D4 ✅** Branch `finops-app/tier1-tier2-pricing` from `origin/main`, carrying the
  uncommitted GPU work (see §0).

## Risks
- **R1 — no test data for contract/cloud pricing.** No reachable account has rows in
  `account_prices` or `cloud_infra_cost`, so the column semantics (`pricing.default`,
  `cost` currency, grain of `usage_metadata`) are from docs + observed schema only. Build
  against demo data plus the schema, keep everything capability-gated, and ask the user
  for an account with the previews enabled (the Databricks account team can enrol one).
  Until validated, label contract figures "preview".
- **R2 — Azure.** Azure Databricks is billed through Microsoft; `account_prices` commonly
  isn't populated there. Expect list-only on Azure. That's correct behaviour, not a bug.
- **R3 — overlap / double counting** between new and existing rules on one resource
  (B1 vs auto-stop, B6 vs rightsize, C5 vs scale-out). Resolve via `savings_composition` +
  grouping; add a test per pair.
- **R4 — probe ≠ rule.** Probe numbers prove signal volume, not correctness. Every rule
  needs a hand-review of its top findings before promotion out of Labs.

---

## Appendix — probe SQL (starting points, not final templates)

These ran against `system.*` in `fevm-finops-stable-us`. Rewrite with the macros
(`window_lower`, `latest_scd_cte`, `price_join`) and without literal windows.

**P1 — trivial-only warehouse hours (B1)**
```sql
with q as (select compute.warehouse_id wh, statement_type st, statement_text txt,
                  start_time, total_task_duration_ms
           from system.query.history
           where start_time >= current_date()-14 and compute.warehouse_id is not null),
c as (select wh, count(*) n,
        count(distinct date_trunc('hour',start_time)) hrs,
        count(distinct case when not (st in ('SHOW','DESCRIBE','USE','SET','OTHER')
                                      or coalesce(total_task_duration_ms,0)=0)
                            then date_trunc('hour',start_time) end) real_hrs
      from q group by wh)
select count(*) warehouses,
       sum(case when hrs-real_hrs >= 24 then 1 else 0 end) wh_24plus_trivial_only_hours,
       avg((hrs-real_hrs)/hrs) avg_share_trivial_only
from c where n > 100
```

**P2 — runaway runs (B2)**
```sql
with j as (select workspace_id, job_id, timeout_seconds, trigger_type
           from system.lakeflow.jobs
           qualify row_number() over (partition by workspace_id, job_id order by change_time desc)=1),
r as (select workspace_id, job_id, run_id,
             unix_timestamp(max(period_end_time)) - unix_timestamp(min(period_start_time)) d
      from system.lakeflow.job_run_timeline
      where period_start_time >= current_date()-30 group by all),
st as (select workspace_id, job_id, percentile(d,0.5) p50 from r group by all having count(*) >= 5)
select count(*) outlier_runs, count(distinct r.job_id) outlier_jobs,
       sum(case when coalesce(j.timeout_seconds,0)=0 then 1 else 0 end) outlier_no_timeout
from r join st using (workspace_id, job_id) left join j using (workspace_id, job_id)
where r.d > 5*st.p50 and r.d > 3600 and coalesce(j.trigger_type,'') <> 'CONTINUOUS'
```
(QUALIFY is DBSQL-only. Final templates must use `latest_scd_cte` so the Spark-based
sample-data gate can parse them.)

**P3 — alerts (C3)**
```sql
with a as (select * from system.alert.alerts
           qualify row_number() over (partition by workspace_id, alert_id order by change_time desc)=1),
live as (select * from a where delete_time is null and coalesce(schedule.pause_status,'UNPAUSED')<>'PAUSED'),
ev as (select workspace_id, alert_id, count(*) evals,
              sum(case when error_code is not null then 1 else 0 end) errs,
              sum(case when evaluated_state='TRIGGERED' then 1 else 0 end) trig
       from system.alert.alert_evaluation_history where start_time >= current_date()-30 group by all)
select count(*) live_alerts,
       sum(case when size(coalesce(l.subscriptions,array()))=0 then 1 else 0 end) no_subscribers,
       sum(case when ev.evals>0 and ev.errs=ev.evals then 1 else 0 end) always_erroring
from live l left join ev using (workspace_id, alert_id)
```

**P4 — unviewed dashboards (C4)**
```sql
with q as (select workspace_id, query_source.dashboard_id d, sum(total_task_duration_ms)/3.6e6 task_hrs
           from system.query.history
           where start_time >= current_date()-14 and query_source.dashboard_id is not null group by all),
v as (select workspace_id, coalesce(request_params['dashboard_id'], request_params['dashboardId']) d, count(*) views
      from system.access.audit
      where event_date >= current_date()-14 and service_name='dashboards'
        and action_name in ('getDashboard','getPublishedDashboard','getDashboardDetails') group by all)
select count(*) dashboards, sum(case when v.views is null then 1 else 0 end) no_views,
       sum(case when v.views is null then q.task_hrs end) task_hrs_unviewed
from q left join v using (workspace_id, d)
```

**Schema facts verified live (2026-09-23)**
- `billing.account_prices.pricing` = `struct<default:decimal(38,18)>`
- `billing.cloud_infra_cost`: `cloud, record_id, account_id, cloud_account_id, workspace_id,
  usage_start_time, usage_end_time, usage_date, cost:decimal, currency_code,
  usage_metadata struct<cluster_id, warehouse_id, instance_pool_id>`
- `billing.attributed_usage.usage_metadata` = `struct<dbsql_statement_id, warehouse_id, client_application>`,
  plus `active_usage_quantity`, `granular_tags.query_tags`
- `serving.served_entities.foundation_model_config` =
  `struct<min_provisioned_throughput:bigint, max_provisioned_throughput:bigint>`;
  `custom_model_config` = `struct<min_concurrency, max_concurrency, compute_type>`
- `alert.alerts.compute` = `struct<type, cluster_id, warehouse_id>`;
  `schedule` = `struct<quartz_cron_schedule, timezone_id, pause_status>`
- `query.history.query_source` has `job_info, legacy_dashboard_id, dashboard_id, alert_id,
  notebook_id, sql_query_id, genie_space_id, pipeline_info`
- `compute.instance_events.event_type` ∈ {`STATE_TRANSITION`, `INSTANCE_LAUNCHING`};
  `availability_type` ∈ {`SPOT`, `ON_DEMAND`}; no explicit preemption event type.
- `compute.warehouse_events.event_type` ∈ {`STARTING, RUNNING, STOPPING, STOPPED, SCALED_UP, SCALED_DOWN`}
