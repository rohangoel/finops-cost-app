# Deployment

> **Deploying into a fresh / customer workspace?** Use the turnkey path instead:
> edit `deploy/config.env` and run `./deploy/deploy.sh` — it does everything
> below (tables, grants, job, app) with nothing hardcoded. See
> [../deploy/SETUP.md](../deploy/SETUP.md). This page is the manual reference for
> what that script does and for redeploying into an existing workspace.
>
> **No CLI access to the customer workspace, or need to deploy through the
> workspace UI?** See [GUI_DEPLOYMENT.md](GUI_DEPLOYMENT.md) — an orchestrator
> notebook replaces the shell script, plus the packaging gotchas (prebuild the
> SPA + wheel, wheel-from-Volume, large-fleet scoring OOM) learned from a live
> customer deploy.

Two independently deployable artifacts that share the `rules/` package and the
recommendation schema: the **App** (reads/serves) and the **precompute Job**
(writes the table). Prod runs the app in `precompute` + `sp` mode.

## ⚠️ Multi-region accounts: deploy once PER region

**A single deployment only covers the workspaces in one region.** This is not a
limitation you can configure away — it follows from how the system tables work,
so plan for it up front on any account that spans regions (e.g. an EMEA account
with workspaces in both `westeurope` and `northeurope`).

Why: `system.billing.usage` is **account-global** (every workspace, every
region), but every other system table the rules read —
`compute.clusters`/`warehouses`, `lakeflow.jobs`, `access.workspaces_latest` —
is **scoped to the metastore of the region the app/job runs in**. There is one
metastore per region. So the pipeline can only produce recommendations for
workspaces in its own region; to see another region's workspaces you must run a
second deployment there. See `backend/finops/data/region.py`.

What the app does about it (so nothing is silently wrong):
- Spend/Genie/Apps totals are filtered to **this region's** workspaces (the
  union of ids in the regional tables), so dollar figures and the savings
  leaderboard line up with the recommendations instead of overcounting an
  estate the rules can't act on.
- Workspaces that billed but sit outside this region are **counted and shown**
  as an "N workspaces out of scope" KPI — never dropped without a trace.

**To cover a whole multi-region account:** run `./deploy/deploy.sh` (or the GUI
deploy) **once in each region**, pointing each at that region's workspace +
warehouse. Each deployment is independent (its own tables, job, app) and reports
its own region's estate. There is deliberately no cross-region aggregation — a
workspace-scoped app cannot read another metastore.

## Prerequisites
- Databricks CLI (`databricks`) authenticated to the target workspace/account.
- A SQL warehouse (its id → the app's `sql-warehouse` resource).
- System tables enabled and readable by the app/job service principal.

## 1. Local dev (live + OBO)
```bash
cp .env.example .env      # host, warehouse, token; keep FINOPS_COMPUTE_MODE=live
make install && make test
make dev-backend          # :8000
make dev-frontend         # :5173 (proxies /api)
```

## 2. Create the tables (prod)
Run the DDL, substituting `{catalog}`/`{schema}` (defaults `main`/`finops`):
- `precompute/ddl/finops_recommendations.sql` — the job writes here.

It must exist **before** the first job run and before the app starts: the job's
writer builds its DataFrame from the table's own schema (`spark.table(...).schema`).

## 3. Deploy the precompute job (Databricks Asset Bundle)
```bash
cd precompute
databricks bundle deploy          # dev target by default
databricks bundle run finops_precompute   # run once to populate the table
```
The bundle (`resources/finops_precompute.job.yml`) schedules `job.py` daily on
serverless job compute and ships the `rules/` + `backend/` packages so the job
reuses the exact rule logic. Tune the cron / `pause_status` there.

## 4. Deploy the App
```bash
make build                # Vite -> backend/finops/static
make deploy-app           # sync + databricks apps deploy (app must exist)
```
`app.yaml` sets prod defaults (`precompute` + `sp`), maps `DATABRICKS_WAREHOUSE_ID`
from the `sql-warehouse` resource, and requests the `sql` OBO scope. For SP-side
user scoping set `FINOPS_USER_SCOPE_JSON` (or wire a `finops_user_scope` table) —
see [AUTH_AND_SCOPING.md](AUTH_AND_SCOPING.md).

## 5. Grants
- App SP: `SELECT` on `main.finops.finops_recommendations` (precompute mode).
- Job SP: `SELECT` on `system.compute`, `system.billing`, `system.lakeflow`;
  `MODIFY` on the finops schema/table.

## Health
`GET /health` → `{"status":"healthy"}` is the Apps readiness gate.

## Switching modes
| | dev | prod |
|--|--|--|
| `FINOPS_COMPUTE_MODE` | `live` | `precompute` |
| `FINOPS_AUTH_MODE` | `obo` | `sp` |
The switches are independent; you can run `live`+`sp` or `precompute`+`obo` if a
scenario needs it.
