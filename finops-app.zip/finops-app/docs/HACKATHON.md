# FinOpsApp — Hackathon Brief

*A Databricks App that reads account-wide system tables and tells admins exactly
what to do to cut spend — which cluster, warehouse, or job is wasting money,
**why**, **how much per month**, how much **effort** the fix is, and a ranked
**Next Best Action** list that trades savings against effort.*

> **Proven impact:** by acting on the biggest opportunities it surfaced, we've
> already cut **>$500k / month** of Databricks' own waste — and it keeps finding
> more, because new waste spawns constantly.

---

## 1. Who it's for

**Databricks platform & workspace admins, FinOps teams, and the SAs/DSAs/FDEs/AEs who advise them.**

- **Platform Admin** — owns the whole account (often **100s of workspaces**).
  Lands on an account-wide **savings leaderboard**, sees total addressable waste,
  and drills into any workspace or resource.
- **Workspace Admin** — scoped to only their own workspace(s). Same insight,
  their slice. Scoping is enforced server-side — a workspace admin *cannot* reach
  another workspace's data.
- **The field (SA / DSA / FDE / AE)** — a repeatable, evidence-backed cost review
  they can run on any customer account instead of hand-writing SQL every time.

## 2. Why it's great

- **It doesn't just show cost — it tells you what to *do* about it.** Every finding
  is an action ("shorten this warehouse's auto-stop to 10 min"), not a dashboard tile.
- **Real money, already banked.** Acting on its top findings removed **>$500k/month**
  of Databricks' internal spend.
- **Every dollar is defensible.** Savings are computed from measured usage through a
  shared pricing model, then guarded so an estimate can *never* exceed true
  avoidable spend. Under-observed or under-priced resources are suppressed, not guessed.
- **Ranked by Next Best Action** = `monthly_savings ÷ effort`. A trivial config
  toggle worth $2k beats a risky migration worth $3k. You get the *smartest* fix
  first, not just the biggest number.
- **Talk to your findings.** A **Genie Agent PoC** lets you interrogate the results in
  natural language and set **alerts / triggers** so new waste comes to you (§7).
- **Radically extensible.** Cost criteria are **auto-discovered plugin rules** — no
  central registry to edit — so many people (or agents) add new checks in parallel
  with zero merge conflicts. This is what made it a natural hackathon platform.
- **Scales to 100s of workspaces** via a precompute mode: a scheduled job runs all
  rules account-wide and writes a Delta table the app just reads.
- **Trustworthy by construction** — **548 tests**, a live-vs-precompute parity test,
  an independent savings-simulation harness, and validation against a real
  deliberately-wasteful demo workspace (§6).

## 3. What problem it solves

Databricks spend sprawls silently. In a large account:

- Clusters run 24/7 with no auto-termination; warehouses idle with 60-minute
  auto-stop; jobs run on expensive all-purpose compute instead of job clusters;
  pipelines run *continuous* when *triggered* would do; serving endpoints and Apps
  sit idle; spend goes untagged so no one can do chargeback.
- Admins **can't see across workspaces** — the signal is buried in system tables
  most people never query, and the waste is invisible until the bill arrives.
- Even when someone writes the SQL, the numbers are fragile: a naive pricing join
  inflates dollars by multiples, and a resource seen for two days can't support a
  monthly estimate.

FinOpsApp turns those raw system tables into a **prioritized, quantified, explained
to-do list** — for one workspace or an entire account.

## 4. Why this problem matters

- **Cloud cost is now a board-level metric.** FinOps is one of the fastest-growing
  disciplines in the industry precisely because compute waste compounds quietly.
- **The waste is real and large.** We removed **>$500k/month** of Databricks' own
  spend by acting on the top findings — and the backlog never empties, because new
  workspaces, jobs, and clusters appear every day. (Correctly pricing usage vs. a
  naive join alone was worth **+5.54% ≈ $37k per 30 days** on one account.)
- **Untrustworthy numbers are worse than none.** An admin who's been burned by an
  inflated estimate stops listening. Getting the money *right* — conservative,
  measured, guarded — is what makes the recommendations actionable at all.
- **It's leverage for the field.** A repeatable cost review shortens the path from
  "you're overspending" to a concrete, agreed action plan with a customer.

---

## 5. How it works

### The pipeline, end to end

![FinOps recommendation pipeline: Unity Catalog system tables → rule SQL → Python score() → RuleFinding → Next Best Action ranker, forking into live and precompute modes, served through FastAPI to the React SPA and Genie Agent](finops-pipeline.png)

**The core principle**, applied to every rule:
> **SQL finds candidates cheaply; Python decides and prices; the estimate must
> never exceed true avoidable spend.**

### The plugin rule engine (the heart of it)

A rule is a **self-contained plugin** — four small files, auto-discovered at
startup. There is **no central list to edit**:

1. `catalog/<rule>.py` — the rule class with a `score(row, ctx)` method
2. `sql/<rule>.sql.j2` — SQL that finds *candidate* resources + raw metrics
3. `config/thresholds.yaml` — runtime-tunable thresholds (what counts as wasteful)
4. `tests/test_<rule>.py` — a fixture-based unit test

`score()` returns a `RuleFinding` carrying: `monthly_savings_usd`, an **effort band**
(`trivial | low | medium | high`), a **priority**, a plain-language **why** and
**how**, and an **evidence** bag. The same rule runs identically in live and
precompute mode — you never write anything mode-specific.

### Guardrails that make the dollars trustworthy

- **Shared pricing macro** — every rule prices usage through one join keyed on all
  four `list_prices` columns and reading promotional (`effective_list`) pricing. A
  hand-written join fans out and inflates dollars in any multi-cloud/multi-currency
  account; a test enforces the macro for *every* rule.
- **Minimum observation window** — a resource seen for only a day or two is
  suppressed; you can't extrapolate a month from a sample that small. The sample
  size is stated in the UI.
- **Coverage / confidence guards** — if too little of a resource's spend could be
  priced, the finding is dropped rather than under-counted.
- **Out-of-scope spend is surfaced, never dropped** — multi-region accounts count
  the workspaces a deployment can't reach as an explicit KPI.

### Two modes, two auth models

| Axis | Options |
|---|---|
| **Compute** | `live` (run rule SQL on a warehouse, dev) · `precompute` (scheduled job → Delta table, prod at scale) |
| **Auth** | `obo` (runs as the logged-in user) · `sp` (service principal, account-wide read + app-side user→workspace scoping) |

A parity test proves live and precompute produce identical results.

### Tech stack

React + TypeScript (Vite) SPA · FastAPI backend · a standalone `finops_rules`
Python package (shared by app and job) · Unity Catalog **system tables** ·
Databricks **SQL warehouse** · Databricks **Apps** (OBO OAuth) · **Databricks
Asset Bundles** (the precompute job) · **Genie** (Conversation API agent, §7).

---

## 6. How we evaluated and hardened the rules

Every rule went through a three-layer evaluation — **theory, then independent
simulation, then a real workspace** — so that what the app claims is both
methodologically sound and grounded in authentic telemetry.

### Layer 1 — First-principles / theoretical review

We read each rule's SQL and `score()` against the actual **system-table schema and
semantics**, asking: does this key on the right columns, and what does it
structurally *miss*? This surfaced real blind spots before any data was involved —
e.g. the cluster rules originally filtered `cluster_source = 'UI'`, silently
skipping every cluster created via API / Terraform / Asset Bundles (a huge gap for
IaC-heavy customers). Fixed to `IN ('UI','API')`. Each such finding (lookback
windows, sustained-idle sampling counts, `node_timeline` requiring the cluster to
be *up*) was documented and folded back into the rules.

### Layer 2 — Independent savings-simulation harness (`benchmark/`)

You can't grade a savings estimate against a real bill — nobody knows the *true*
avoidable dollars in it — and grading it with the rule's own formula just proves
the rule agrees with itself. So we **simulate one level below what the rule sees**:

- the **rule** sees only hourly aggregates (billed warm hours, whole idle hours),
  exactly what `billing.usage` / `warehouse_events` expose;
- the **simulator** models the warehouse as a **minute-level state machine** (a
  query keeps it warm; it stays warm for `auto_stop` minutes after the last query,
  then stops; every stopped→warm transition bills a cold start).

Ground truth for a proposed change = re-run the *same* workload under the new
setting and diff the warm minutes — a number that comes from simulation, never the
rule's formula, so agreement is meaningful. Three gates run on every commit:

1. **Known-answer** — a hand-computed scenario validates the simulator itself.
2. **Conservative (hard gate)** — on every workload shape, the rule's estimate
   **≤** the simulator's independent ground truth. *This is the trust guarantee: it
   can never over-estimate.*
3. **Accuracy** — with per-query gaps from `query.history`, the estimate recovers
   **~91–97%** of true savings across shapes (steady, bursty, weekend-only,
   zombie), and **0** where there's nothing to save. Gated on min and median.

### Layer 3 — Real deliberately-wasteful demo workspace (`finops-test-kit/`)

Synthetic system-table rows would only test the app against data shaped to its own
queries. Instead we **provision real, deliberately-wasteful resources** on a fresh
FE vending-machine workspace (near-empty system tables, so every flagged row is
provably ours), let authentic telemetry accrue for **~5 days**, then verify:

- **True positives fire** — an idle 24/7 cluster, an over-provisioned cluster, an
  old-DBR cluster, on-demand workers, perf-mode serverless batch, etc. each produce
  the expected finding with a sane, conservative savings figure.
- **Blind spots are exposed** — categories with *no* rule are recorded as gaps with
  the raw signal a future rule would key on. Every gap we found was then **closed
  and re-verified against the real fixture with a specific measured finding**:
  - **failing jobs** → new `failing_jobs` rule; fires on genuinely-broken jobs
    (73%/100% fail rate) at measured billed cost per failed run;
  - **job produces unread data** → new `unused_data_jobs` rule; the fixture table
    (237 writes, 0 reads, $44.89/30d) is the top candidate;
  - **oversized warehouse** → new `warehouse_rightsize` rule; the fixture (Small,
    0% queued/spilled, $741/30d) fires with a proposed ladder step down (~$370/mo).

This is what "hardened and grounded" means here: a rule isn't trusted until its
math survives an independent simulator **and** it produces the right finding on
real telemetry from a workload we built to trigger it.

---

## 7. Genie Agent PoC — talk to your findings, and get alerted

On top of the dashboards, a **Genie Agent PoC** turns the FinOps data into a
conversational, proactive assistant:

- **Natural-language interrogation of the findings.** Ask free-form questions the
  fixed dashboard has no widget for — *"compare Genie spend to Apps spend by
  workspace"*, *"why is this warehouse flagged idle?"*, *"which clusters had avg CPU
  under 5%?"* — right on the Overview, Workspace, and Resource pages. In `api` mode
  the backend is **context-aware**: it injects the workspace/resource the page is
  showing, and answers render in the app's own chat UI.
- **It can explain and defend the numbers**, not just read the output. The agent
  has access to a flattened **evidence view**, a **rule-knowledge catalog** (each
  rule's rendered detection SQL, thresholds + current values, and the verbatim
  scoring/savings logic), and **SELECT on the underlying system tables** — so it can
  explain *why* a finding fired and let a user push back on an estimate with the
  actual formula in hand.
- **Alerts & triggers on findings.** Set conditions so new or growing waste comes to
  you — no one has to remember to open the app.
- **Scheduled "top opportunities" report (already running).** A scheduled task
  periodically surfaces the best savings opportunities and reports them out — the
  exact mechanism by which we drove the **>$500k/month** reduction: the biggest
  opportunities were pushed to owners on a cadence, acted on, and the next batch
  took their place.

It's a **feature toggle, off by default** — with it off the app behaves exactly as
before and references Genie nowhere; nothing in deploy or precompute depends on it.

**Recommendation:** bake this into the **default FEVM demo-environment setup**, with
the scheduled report enabled, so our own demo fleet keeps its waste low continuously
instead of accumulating the very sprawl the app is built to catch.

---

## 8. Availability — internal today, customer-deployable tomorrow

**Two ways to run the exact same app:**

- **Databricks-internal, via Central Logfood.** Point it at **customers' Logfood
  system-table data** — no per-workspace deploy. SAs, DSAs, FDEs, and AEs get an
  instant, account-wide FinOps view of an account (given the standard Opal grants on
  the centralized system tables). One command (`bootstrap.sh`) brings it up locally.
- **Deployed in the customer's own environment.** The same rules, NBA ranking, and
  Genie Agent capabilities run **on the customer's own Unity Catalog system tables**
  — one config file, one command (`deploy/deploy.sh`) creates the tables + grants,
  the daily precompute job, and the app, all pointed at their workspace with nothing
  hardcoded. This hands the customer the full FinOps + Genie Agent toolkit as a
  first-class part of their platform. *(Multi-region accounts: deploy once per
  region — see `DEPLOYMENT.md`.)*

Same codebase, same rules, same guarantees — whether *we* run it over Logfood to
advise an account, or *the customer* runs it over their own system tables to
self-serve.

---

## 9. What it checks for (the rule catalog — 23 rules today)

| Category | Rules |
|---|---|
| **Compute (clusters)** | Enable/shorten **auto-termination** · terminate **idle/zombie clusters** · **rightsize** underutilized clusters · move scheduled work **off all-purpose** onto job clusters · upgrade DBR / **enable Photon** · move on-demand to **spot with fallback** · isolate **concurrent jobs contending** on a shared cluster |
| **SQL (warehouses)** | Enable/shorten **auto-stop** (classic + serverless) · move eligible warehouses to **Serverless** · **right-size** over-provisioned · **scale out** under-provisioned |
| **Jobs** | Remove/pause **unused scheduled jobs** · fix/retire a **chronically-failing job** · retire a job producing **unread data** · switch serverless jobs/pipelines to **cost-optimized mode** |
| **Pipelines** | Switch idle **continuous pipelines to triggered** |
| **Serving** | Shut down / scale-to-zero an **idle serving endpoint** |
| **Apps** | Stop or delete an **idle Databricks App** |
| **Governance** | **Tag spend** for chargeback (find untagged spend) |

Each finding names the exact resource, quantifies monthly waste and achievable
savings, and links straight into the workspace to fix it.

### How the data is acquired

Everything comes from **Unity Catalog system tables** — no agents, no exports, no
customer data movement:

- `system.billing.usage` + `system.billing.list_prices` — DBUs and priced dollars
- `system.compute.clusters`, `system.compute.node_timeline`,
  `system.compute.warehouses` — compute config + actual utilization
- `system.lakeflow.jobs` / `job_run_timeline`, `pipelines` /
  `pipeline_update_timeline` — job & pipeline runs and outcomes
- `system.access.table_lineage` — writes-with-zero-reads (unused-data rule)
- query history for warehouse activity signals

`system.billing.usage` is account-global; the other tables are per-region
metastore-scoped — hence "deploy once per region." Rules never filter by
`workspace_id`; the data layer injects the caller's scope. The result: an
admin sees measured behaviour (idle time, run gaps, utilization, spill/shuffle,
failure rates), not vendor rules of thumb.

---

## 10. What else to document to make it compelling

For a hackathon audience, layer these on top of the above:

1. **A live demo path / screenshots.** Platform-admin leaderboard → drill into the
   biggest-waste workspace → open a recommendation → show the *why/how/evidence*
   and the deep-link to fix it → **ask Genie a follow-up question about it**. One
   picture of the ranked NBA list sells the whole idea.

2. **The headline number, front and centre.** **>$500k/month removed** from
   Databricks' own spend, plus total addressable savings on the demo account and one
   hero finding ("this one warehouse's auto-stop is worth $Xk/mo").

3. **The trust story, concretely.** The independent simulation harness (estimate ≤
   ground truth, 91–97% recovery), the pricing-macro fix (+5.54% ≈ $37k/30d), the
   observation-window guard, the real demo-workspace validation, and the **548
   tests** + live-vs-precompute parity test. Judges reward correctness that's
   *demonstrated*, not claimed.

4. **Extensibility as the hook.** Live-add a rule in the demo (or show the 4-file
   diff): drop a file, it auto-appears in the Rule Catalog page and `/api/rules`.
   "No central list — humans and agents add rules in parallel" is the platform pitch.

5. **The architecture diagram** (system tables → rules → NBA → dual mode → SPA +
   Genie) and the two mode/auth switches — shows it's production-shaped, not a script.

6. **The two deployment stories** (internal-over-Logfood vs. customer-owned) — same
   codebase serving both the field and the customer.

7. **Roadmap / vision.** Today it's **recommend + explain**, with the Genie Agent
   PoC for conversation and alerting. The obvious next phase — **one-click apply**
   (set auto-termination via the SDK, with approval + audit) and write-back — plus
   rolling the Genie scheduled report into the **default FEVM demo setup**. Frames it
   as a platform, not a finished toy.

8. **Impact framing for the field.** Position it as a repeatable customer cost
   review / QBR artifact — the business case beyond the tech.

---

*Deeper references: [`README.md`](../README.md) · [`ARCHITECTURE.md`](ARCHITECTURE.md) ·
[`ADDING_A_RULE.md`](ADDING_A_RULE.md) · [`DATA_MODEL.md`](DATA_MODEL.md) ·
[`AUTH_AND_SCOPING.md`](AUTH_AND_SCOPING.md) · [`GENIE_PANEL.md`](GENIE_PANEL.md) ·
[`benchmark/README.md`](../benchmark/README.md) ·
[`finops-test-kit/TEST_PLAN.md`](../finops-test-kit/TEST_PLAN.md)*
