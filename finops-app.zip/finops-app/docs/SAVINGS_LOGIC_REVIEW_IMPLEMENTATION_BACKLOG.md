# Savings logic review — accepted findings and implementation backlog

Status: **Accepted for implementation**  
Review date: 2026-09-17  
Scope: all 21 recommendation rules, shared pricing/window logic, recommendation
aggregation, and additional opportunities exposed by Databricks system tables.

This document is the implementation record for the functional review. The
findings below are accepted; they are not open review questions. The order and
formula designs may be refined during implementation, but a change must not
restore a heuristic dollar claim without equivalent evidence.

## Outcome

The app is useful for discovery and prioritization, but its current headline
savings total is **directional, not decision-grade**. Some findings identify a
real configuration or operating concern while pricing the wrong cost component,
using incomplete activity evidence, or assuming that observed spend disappears
under the proposed action.

The target state must separate:

- **Bookable savings**: a conservative lower bound supported by a current-cost
  and counterfactual-cost calculation.
- **Estimated savings**: a range with an explicit assumption or missing cost
  component.
- **Advisory findings**: actionable evidence with no dollar value proven by the
  available data.

Only bookable lower bounds belong in the headline total. Estimated and advisory
findings remain visible and rankable.

## Immediate containment

Before rebuilding the formulas:

1. Add an additive savings-status field to the recommendation contract:
   bookable, estimated, or advisory. Update the Pydantic model, both table-schema
   mirrors, TypeScript type, table comments, and docs/DATA_MODEL.md together.
2. Exclude estimated and advisory amounts from the booked headline total.
3. Keep the affected findings in the UI; show their current spend or maximum
   addressable spend separately from savings.
4. Treat the following rules as advisory until their corresponding backlog item
   is complete:
   - spot_fallback
   - interactive_to_job
   - idle_apps
   - enable_serverless
   - serverless_cost_optimized
   - unused_data_jobs
   - enable_photon_dbr
5. Treat warehouse auto-stop, rightsizing, failing-job, continuous-pipeline, and
   idle-zombie amounts as estimated rather than bookable until the shared
   counterfactual and data-quality work is complete.
6. Keep the zero-dollar hygiene/performance rules as advisory:
   cluster_job_contention, untagged_spend, warehouse_scale_out, and
   unused_scheduled_jobs.

## Accounting invariants

Every implemented savings formula must satisfy all of these:

1. **Same scope:** current and counterfactual cost use the same workspace,
   resource, cost components, currency, and complete observation window.
2. **Same units:** wall-clock minutes are never divided by node-minutes; DBU
   cost is never treated as cloud-VM cost.
3. **Closed-open windows:** use [window_start, window_end), normally the last N
   complete dates, excluding partial today.
4. **Corrections included:** billing retractions and restatements are applied.
5. **No missing-data inference:** absent price, lineage, request, telemetry, or
   entity data is unknown, not zero activity or zero cost.
6. **Counterfactual required:** a proposed action must cause the modeled cost to
   disappear or decrease. Observed “waste” alone is not savings.
7. **Bounded result:** savings for an affected spend segment cannot exceed its
   current corrected cost.
8. **No double booking:** the same hourly/SKU spend segment can contribute to
   the portfolio total only once.
9. **Explicit cost basis:** Databricks list price, customer-effective Databricks
   price, cloud infrastructure, or combined.
10. **Uncertainty survives aggregation:** the headline sums bookable lower
    bounds, not optimistic point estimates.

The preferred rule-level calculation is:

```text
monthly_savings =
  30 / complete_observed_days
  * sum_over_hours(max(0, current_cost_hour - counterfactual_cost_hour))
```

When the counterfactual is uncertain, emit low/point/high values. A low value of
zero is valid and must not be silently replaced with a fixed percentage.

## P0 — shared correctness foundation

### FIN-001: Build a canonical corrected hourly cost layer

**Problem**

Cost attribution is repeated in rule SQL. Windows, correction handling, price
coverage, identifiers, and product filters therefore differ between rules.

**Required implementation**

Create one reusable SQL relation or materialized pipeline output at
workspace/resource/hour/SKU granularity with:

- account_id, workspace_id, cloud, currency_code
- a closed-open window timestamp and usage date
- sku_name, billing_origin_product, usage_unit, usage_type
- job, job-run, cluster, warehouse, pipeline, endpoint, and app identifiers
  available in usage_metadata
- corrected usage quantity
- list/promotional-list cost
- optional customer-effective cost and cloud cost
- priced and unpriced quantities/rows
- record-type/correction diagnostics

All savings rules should consume this layer instead of maintaining their own
billing join.

**Acceptance**

- An ORIGINAL + RETRACTION + RESTATEMENT fixture returns the corrected amount.
- An N-day full-date window contains exactly N dates and no partial current date.
- The sum reconciles to the Total Spend source for the same scope and basis.
- No resource can be priced when its coverage is missing or below the configured
  threshold.

### FIN-002: Standardize observation windows

**Problem**

Most templates use usage_date >= date_sub(current_date(), N). Because the
boundary is inclusive and today is partial, “30 days” can contain 31 dates plus
partial-day data. Some rules also combine a 14-day behavior sample with a 30-day
cost sample.

**Required implementation**

Render shared window_start_date, window_end_date, window_start_ts, and
window_end_ts values. For full-day reporting:

```sql
usage_date >= date_sub(as_of_date, lookback_days)
AND usage_date < as_of_date
```

Use the same interval for cost, utilization, activity, history sufficiency, and
monthly normalization. If a shorter behavior window is intentionally used,
label it and calculate its own cost rather than applying its ratio to another
window.

**Affected broadly**

All rule templates and backend spend/Genie sources. apps_sql.py already excludes
today and is the pattern to preserve.

### FIN-003: Apply billing corrections consistently

**Problem**

Billing usage is an additive log. Filtering to ORIGINAL keeps superseded usage
and drops the RETRACTION that cancels it. continuous_pipeline.sql.j2 and
untagged_spend.sql.j2 currently do this in cost aggregates. Other queries have no
shared guarantee.

**Required implementation**

Include all record types in additive usage/cost sums. Use ORIGINAL-only data only
for a documented non-additive metadata purpose. Put this behavior in the
canonical cost layer and test correction triples.

### FIN-004: Make price coverage fail closed

**Problem**

coverage.py treats a missing unpriced_dbus field as unknown and underpriced()
returns false. Several dollar-booking rules do not emit coverage fields or call
the guard. A schema omission can therefore produce a confident partial-dollar
finding.

**Required implementation**

- Require coverage for every non-zero dollar result.
- Suppress booking when coverage is absent, not just when it is below 80%.
- Track coverage per usage unit; “DBU share” is not meaningful for token,
  storage, or network units.
- Add coverage to enable_photon_dbr, failing_jobs, idle_serving_endpoints,
  idle_zombie_clusters, jobs_compute_rightsize, rightsize_underutilized,
  unused_data_jobs, and unused_scheduled_jobs where cost is retained.
- Keep free SKUs explicitly classified rather than treating every unpriced row
  as an error.

### FIN-005: Make effective pricing real

**Problem**

pricing_mode=effective only removes the list-price disclaimer. It does not
change the rate used by SQL. system.billing.list_prices provides list and
promotional-list pricing, not a customer's negotiated effective price.

**Required implementation**

- List mode continues to use pricing.effective_list.default and says “list.”
- Effective mode must require a real contract-rate mapping, invoice/export
  input, or other authorized net-cost source.
- Refuse to start in effective mode when no effective-price provider is
  configured.
- Never use a config flag only to relabel the same number.

### FIN-006: Fix current-resource SCD selection

**Problem**

Several SCD queries filter delete_time IS NULL before QUALIFY. SQL applies WHERE
before QUALIFY, so a deleted resource's final row can be removed before ranking
and an older live version can be selected. Other “latest” CTEs do not test the
latest row for deletion at all.

**Required implementation**

First rank all versions per workspace/resource, then filter the selected row:

```sql
SELECT *
FROM (
  SELECT ..., ROW_NUMBER() OVER (
    PARTITION BY workspace_id, resource_id ORDER BY change_time DESC
  ) AS rn
  FROM system_table
)
WHERE rn = 1 AND delete_time IS NULL
```

Audit at least enable_photon_dbr, jobs_compute_rightsize, failing_jobs,
unused_scheduled_jobs, unused_data_jobs, continuous_pipeline, all warehouse
rules, spot_fallback, autotermination, cluster_job_contention,
interactive_to_job, and serverless_cost_optimized metadata CTEs.

### FIN-007: Complete multi-workspace join keys

**Problem**

Several joins and window partitions use only warehouse_id, cluster_id, or
served_entity_id. The app runs account-wide; identifiers must not be assumed
globally unique.

**Required implementation**

Use workspace_id plus the resource identifier in joins, groups, and analytic
partitions. Confirm and fix at least:

- warehouse_autostop: warm/active joins and query LEAD partition
- warehouse_autostop_serverless: query LEAD partition
- enable_serverless: warm/active joins, cold-start and observed joins
- warehouse_rightsize: load, concurrency, and slot-utilization joins
- warehouse_scale_out: load/hourly joins and concurrency partition
- idle_serving_endpoints: endpoint-usage to served-entity-version mapping where
  the source exposes workspace_id

Add duplicate-ID fixtures in two workspaces for every corrected template.

### FIN-008: Replace max-per-resource aggregation with action-aware aggregation

**Problem**

aggregation.py and recommendation_service.py use the maximum savings value per
resource. This:

- undercounts compatible actions such as rightsize then auto-stop;
- treats all same-resource actions as mutually exclusive;
- misses overlap between a job finding and the cluster/warehouse spend that ran
  it;
- can collide different workload kinds represented as the same resource type.

**Required implementation**

Add action_family, compatibility/supersession metadata, and an affected-spend
scope to the recommendation contract. Calculate a sequence:

- mutually exclusive actions: choose one;
- compatible actions: apply in order to the remaining counterfactual cost;
- migration actions: supersede tuning of the retired source resource;
- cross-resource actions: de-duplicate the same hourly/SKU cost segments.

The headline must be the portfolio's bookable lower bound. Keep “sum of all
options” only as a clearly labeled theoretical figure, never as booked savings.

## P0 — invalid or incomplete rule formulas

### FIN-009: spot_fallback prices the wrong cost component

**Current logic**

savings.py applies movable worker fraction × spot discount × replay haircut to
cost from system.billing.usage.

**Why it is invalid**

Spot changes the cloud VM bill. It does not discount Databricks DBUs. The
current formula therefore claims savings against spend that remains after the
action.

**Implementation**

- With Databricks system tables only: keep an eligibility/advisory finding and
  book $0.
- With AWS CUR, Azure Cost Management, or GCP Billing export: join cluster
  node-minutes and node type to actual on-demand/spot VM rates; exclude driver
  cost; subtract eviction/replay cost measured from retries and elapsed compute.
- State whether the result covers cloud VM only or combined cost.

**Acceptance**

A spot toggle with unchanged DBU usage produces zero Databricks-platform
savings. No VM dollar is emitted without a VM price source.

### FIN-010: interactive_to_job mixes units and lacks incremental-cost proof

**Current logic**

interactive_to_job.sql.j2 divides distinct job-active wall-clock minutes by
COUNT(*) from node_timeline. COUNT(*) is node-minutes, so the fraction shrinks
with cluster size. It then applies the all-purpose versus jobs-compute price gap
to attributed DBUs.

**Why it is incomplete**

Even after fixing units, moving a job off a shared interactive cluster may add
job-compute cost without reducing the already-running interactive cluster. The
price gap is realizable only when source capacity or uptime actually disappears.

**Implementation**

- Calculate job-overlap node-minutes and total node-minutes in the same units.
- Separate dedicated job-only all-purpose clusters from genuinely shared
  interactive clusters.
- Dedicated case: compare measured current configuration/runtime with the same
  work on jobs compute, using region-correct prices.
- Shared case: lower bound is zero until removal is shown to reduce source
  worker count or uptime; expose the price-gap allocation as an upper-bound
  scenario only.
- Use job/task run timeline compute_ids and node_timeline interval overlap,
  keyed by workspace.

### FIN-011: idle_apps uses lifecycle audit events as traffic

**Why it is invalid**

Public system tables do not expose App HTTP request/page-view traffic. Apps
audit records are lifecycle operations such as deploy/start/stop, not end-user
access. A workspace-level “some app event exists” gate cannot turn lifecycle
data into per-app traffic evidence.

**Implementation**

- Disable/remove idle_apps from recommendations and all totals.
- Preserve the Apps inventory and its explicit analysis boundary.
- Re-enable only when an authoritative request/telemetry source exists and can
  be joined by app_id. Until then, days_billed and lifecycle events are inventory
  facts, not idleness.

This is an intentional product boundary, not a missing threshold adjustment.

### FIN-012: Warehouse auto-stop must use real state and merged intervals

**Current weaknesses**

- Raw queries are passed to LEAD without merging overlapping query intervals.
- Query durations and warm time can be double-counted under concurrency.
- The gap before the first query and tail after the last query are omitted.
- Query window partitions omit workspace_id.
- Serverless histogram buckets substitute upper bounds for exact gaps and can
  overstate reclaim.
- Billing presence per hour is only a proxy for running state.

**Implementation**

Use system.compute.warehouse_events for running/stopped/scaling intervals.
Clip events and queries to one complete window, merge overlapping query
intervals, and simulate each candidate timeout on the exact intervals. Calculate
restarts from exact gaps and retain the usability guard. Price reclaimed seconds
from corrected hourly usage; do not infer exact seconds from bucket upper
bounds.

For each warehouse assert:

- merged busy seconds <= running seconds;
- counterfactual running seconds <= current running seconds;
- reclaimed cost <= corrected current cost;
- edge gaps are included;
- concurrent queries do not add duplicate warm time.

### FIN-013: enable_serverless combines mismatched data and hard-coded rates

**Current weaknesses**

- A 14-day inferred utilization series is applied to 30-day cost.
- classic/pro/serverless and cloud-VM rates are hard-coded.
- score() reads cloud, but enable_serverless.sql.j2 does not emit it.
- hourly billing/query presence is used instead of warehouse events.
- classic/pro cloud infrastructure cost is absent from Databricks billing data.

**Implementation**

Use one complete window, real warehouse events, actual list/effective SKU prices,
and emit cloud explicitly. Without a cloud-billing export, return a Databricks
cost comparison plus a clearly separated VM-cost range and keep status
estimated. With cloud cost, calculate:

```text
current all-in = corrected DBU cost + actual cloud VM cost
serverless counterfactual = modeled active work at actual serverless rate
savings = current all-in - serverless counterfactual
```

Suppress when compatibility, regional availability, or the cost basis is
unknown.

### FIN-014: serverless_cost_optimized assumes a 50% saving

**Why it is invalid**

The formula cost × 0.50 is a configured claim, not a per-workload
counterfactual. A duration threshold does not prove the DBU reduction, and a
pipeline is serialized as resource_type=job, creating ownership/deep-link and
aggregation ambiguity.

**Implementation**

- Represent pipelines as pipeline resources throughout the schema and UI.
- Prefer actual price/SKU differences when the performance target changes
  price.
- Where consumption changes rather than price, estimate from matched runs of the
  same workload before/after a historical mode change, controlling for input
  volume and run duration.
- Use Pipeline Events throughput/input metrics for pipelines.
- Without matched evidence, emit an advisory with current
  PERFORMANCE_OPTIMIZED spend and $0 bookable savings.

### FIN-015: Missing lineage cannot become 50–70% committed savings

**Current logic**

unused_data_jobs treats no observed reads as dead data and books 50% or 70% of
the producer's cost.

**Why it is invalid**

Lineage coverage is incomplete for paths, external readers, unsupported
surfaces, retention boundaries, and some cross-workspace consumption. A haircut
does not convert missing evidence into a measured counterfactual.

**Implementation**

- Keep the finding as “verify unused output” with current producer cost shown as
  maximum addressable spend and $0 booked.
- Add a lineage-availability sentinel and distinguish “lineage observed, no
  reads” from “no lineage coverage.”
- Search the longest supported lineage interval, not only the cost interval.
- Count reads across workspaces/metastores where identity permits.
- Promote to bookable only after explicit verification/approval or an
  authoritative consumer log.

## P1 — improve estimated rules

### FIN-016: Rightsizing must model per-run peaks and actual node-minutes

**Affected**

rightsize_underutilized, jobs_compute_rightsize, and warehouse_rightsize.

**Current weaknesses**

- Cluster candidate gates use averages; rightsize_underutilized calculates p95
  evidence but score() ignores it and books a fixed 30%.
- Job rightsizing aggregates heterogeneous runs and applies the latest cluster
  config plus fixed structural percentages.
- Warehouse downsizing assumes each size step halves cost while runtime remains
  unchanged. A half-size warehouse that runs twice as long saves nothing.

**Implementation**

- Build per-run driver/worker peaks for CPU, memory, swap, I/O wait, and network.
- Use actual node-minutes and actual autoscaling levels, not configured maximums.
- Choose the smallest candidate that covers a configured share of historical
  run peaks with headroom.
- Calculate current and candidate DBU/node-minute cost explicitly.
- For warehouses, include runtime elasticity:
  candidate cost = current cost × size-rate ratio × expected runtime ratio.
- Derive runtime ratio from matched query fingerprints across historical size
  changes when available; otherwise emit a range whose lower bound may be zero.
- Veto a downsize on memory, swap, I/O, or spill pressure even when CPU is low.

### FIN-017: Idle-zombie savings needs a recency/forward-spend guard

An all-purpose cluster that ran briefly and has already been off for weeks can
show historical idle spend even though there is no ongoing monthly spend left to
save. Base forward savings on recent recurring spend/state, not the whole
lookback average. If the cluster is already stopped and no future start pattern
is established, make it hygiene/advisory or book zero.

### FIN-018: Split serving endpoint zero-traffic and low-traffic economics

The zero-request, always-billing tier has strong request evidence and can retain
full avoidable cost after coverage/window fixes. The low-traffic tier currently
uses a fixed 70% reclaim fraction. Recalculate it from request arrival gaps,
endpoint configuration/state, and billed intervals; otherwise keep that tier
estimated. Ensure endpoint-entity joins are workspace-safe and price coverage is
required.

### FIN-019: Continuous pipeline savings needs interval-level pricing

The rule's direction is sound, but distinct billed hours versus active hours
assumes a uniform DBU rate within those hours, and it filters ORIGINAL billing
records. Use corrected hourly cost, exact update intervals, and Pipeline Events
to distinguish no-input idle from useful continuous processing/backlog. Model
trigger startup from observed starts. Keep latency/freshness as an explicit
non-financial constraint.

### FIN-020: Failing-job savings must separate repair from retirement

Failed-run cost is real waste, but fixing a run normally converts it into a
successful run that still costs money. Keep a repair estimate only when the
same job has comparable successful runs and the counterfactual is defensible.
A job that never succeeded is not automatically safe to retire; show its failed
cost as maximum addressable spend and require an obsolescence signal or owner
decision before booking retirement savings. Exclude intentional continuous-job
restart behavior as today.

### FIN-021: Photon/DBR uplift remains advisory without matched performance data

Runtime-name classification improves relevance but fixed 5%/15% savings is not
a measured workload response. Use matched runs/query fingerprints across runtime
or Photon changes, normalized for input, or book zero. The rule is already
hidden; do not reintroduce it into totals until this is solved.

## Rule disposition checklist

| Rule | Current disposition | Required outcome |
|---|---|---|
| cluster_autotermination | Estimated | Keep gap method; add canonical window/cost/coverage/SCD and retain CPU/activity caveat |
| cluster_job_contention | Advisory, $0 | Keep; fix SCD/workspace correctness |
| continuous_pipeline | Estimated | FIN-003, FIN-006, FIN-019 |
| enable_photon_dbr | Advisory, $0 | FIN-021 |
| enable_serverless | Advisory until rebuilt | FIN-012, FIN-013 |
| failing_jobs | Estimated/conditional | FIN-004, FIN-006, FIN-020 |
| idle_apps | Disable | FIN-011 |
| idle_serving_endpoints | Split bookable/estimated tiers | FIN-004, FIN-007, FIN-018 |
| idle_zombie_clusters | Estimated | FIN-004, FIN-006, FIN-017 |
| interactive_to_job | Advisory until rebuilt | FIN-010 |
| jobs_compute_rightsize | Estimated | FIN-004, FIN-006, FIN-016 |
| rightsize_underutilized | Estimated | FIN-004, FIN-016 |
| serverless_cost_optimized | Advisory until measured | FIN-014 |
| spot_fallback | Advisory without cloud bill | FIN-009 |
| untagged_spend | Advisory, $0 | Keep; correction-aware spend attribution |
| unused_data_jobs | Advisory, $0 | FIN-015 |
| unused_scheduled_jobs | Hygiene, $0 | Fix SCD; do not project stale historical cost forward |
| warehouse_autostop | Estimated until rebuilt | FIN-012 |
| warehouse_autostop_serverless | Estimated until rebuilt | FIN-012 |
| warehouse_rightsize | Estimated | FIN-007, FIN-016 |
| warehouse_scale_out | Advisory, $0 | Keep; fix workspace joins |

## New savings opportunities from system tables

These are additions after the correctness foundation. Follow AGENTS.md: each new
criterion is three new files plus one thresholds.yaml block. If a new
resource_type or recommendation field is required, make the additive contract
change separately and update all schema mirrors.

### A. SQL workload efficiency

**Data:** system.query.history plus warehouse events and corrected warehouse
cost.  
**Detect:** repeated failed queries, repeated large scans with tiny outputs,
heavy spill/shuffle, excessive queue/start wait, and identical recurring query
shapes.  
**Savings:** allocate corrected warehouse cost across merged concurrent query
intervals or task-duration shares. Book only eliminated work (for example a
known repeated failure/retry); keep general tuning potential estimated.

### B. Duplicate manual maintenance when Predictive Optimization is active

**Data:** Predictive Optimization operations history, query history
OPTIMIZE/VACUUM statements, table lineage, job timelines, and job cost.  
**Detect:** scheduled maintenance jobs performing work already handled by
Predictive Optimization on the same tables.  
**Savings:** actual cost of the redundant job runs, after proving table/action
overlap and excluding other tasks in the job.

### C. Pipeline throughput and no-input continuous time

**Data:** Pipeline Events, pipeline update timeline, and corrected DLT cost.  
**Detect:** continuous pipelines with no input/backlog for long periods,
repeated retries, maintenance-heavy workloads, and a trigger cadence that
matches actual arrivals.  
**Savings:** simulate triggered updates from measured arrival/update intervals
and startup cost. This should replace, not duplicate, continuous_pipeline.

### D. Model/AI Gateway token and routing efficiency

**Data:** AI Gateway/inference request system tables, serving endpoint usage,
and billing usage.  
**Detect:** expensive model routes for low-complexity traffic, avoidable
fallbacks/retries, missing prompt caching where cache metrics exist, and token
growth by endpoint/client.  
**Savings:** price actual input/output/cached token quantities against a
candidate model/route. Preserve quality and latency as gates; otherwise show a
scenario rather than bookable savings.

### E. Network and cross-region transfer

**Data:** billing usage networking products/usage types, lineage/share activity,
workspace cloud/region metadata, and cloud billing export for components not
present in Databricks billing.  
**Detect:** recurring cross-region/cross-cloud transfers, avoidable egress, and
replication/materialization patterns.  
**Savings:** exact charged network quantity × alternative route/placement rate.
Do not infer a network dollar from DBUs.

### F. Delta Sharing materialization

**Data:** sharing materialization history, recipient/share metadata where
available, lineage, and billing usage.  
**Detect:** repeated large materializations for inactive recipients or avoidable
cross-region patterns.  
**Savings:** use actual materialization/network charges; inactive-share cleanup
without a charge remains hygiene.

### G. Instance-pool opportunities

**Data:** compute cluster SCD, node timeline, job start wait, and cloud billing.  
**Detect:** repeated classic-cluster startup latency that may benefit from a
pool, or costly idle pool capacity.  
**Boundary:** Databricks system tables do not provide a complete cloud-VM price
and idle-pool inventory. Without the cloud bill/API, keep this operational and
do not claim VM savings.

### H. Storage lifecycle and redundant data

**Data:** table metadata/storage metrics where available, table lineage,
Predictive Optimization history, sharing materialization, and cloud object-store
billing/inventory.  
**Detect:** stale unreferenced tables, excessive retention, duplicate
materializations, and manual maintenance duplication.  
**Boundary:** absence of lineage is not deletion evidence, and cloud storage
cost must not be derived from Databricks DBUs.

## Suggested additive recommendation fields

Names may change, but the semantics are required:

| Field | Purpose |
|---|---|
| savings_status | bookable, estimated, advisory |
| monthly_savings_low_usd | Conservative value eligible for booked aggregation |
| monthly_savings_usd | Point estimate/scenario |
| monthly_savings_high_usd | Upper scenario, never booked |
| current_monthly_cost_usd | Corrected cost in the affected scope |
| counterfactual_monthly_cost_usd | Cost after the action in the same scope |
| cost_basis | dbx_list, dbx_effective, cloud, combined |
| window_start/window_end | Exact closed-open observation interval |
| price_coverage | Required completeness signal |
| action_family | rightsize, terminate, migrate, retire, tune, hygiene, etc. |
| affected_spend_scope | Stable keys used for cross-rule de-duplication |
| assumptions | Machine-readable inputs used by the counterfactual |

Keep monthly_waste_usd for compatibility during migration, but stop treating it
as synonymous with current cost or realizable savings.

## Implementation sequence

### Phase 0 — protect the headline

- Add savings status/range fields and aggregate bookable lower bounds only.
- Disable idle_apps recommendations.
- Mark invalid/heuristic rules advisory or estimated per the matrix.
- Make effective mode fail when no effective-rate source exists.

### Phase 1 — shared data correctness

- FIN-001 through FIN-007.
- Add invariant tests and corrected multi-workspace fixtures.
- Reconcile rule totals with Total Spend for identical windows/cost basis.

### Phase 2 — strongest counterfactuals

- Warehouse auto-stop using warehouse events and exact merged intervals.
- Serving zero-traffic tier.
- Cluster auto-termination hardening.
- Action-aware and cross-resource aggregation.

### Phase 3 — rebuild estimates

- interactive-to-job, rightsizing, serverless migration,
  continuous pipelines, failing jobs, and cost-optimized mode.
- Add cloud billing input before restoring spot or all-in classic/serverless
  savings.

### Phase 4 — new opportunities

- Predictive Optimization duplication and Pipeline Events first: both can
  identify directly avoidable work.
- Then SQL efficiency, AI Gateway, networking/sharing, pools, and storage.

## Verification requirements

Unit tests that score plain dictionaries are necessary but insufficient; they do
not execute Databricks SQL or validate economic counterfactuals. Each formula
change needs:

1. Pure unit tests for bounds, units, edge cases, and suppression.
2. Render tests for nested and central table layouts.
3. Executable SQL integration tests against real system-table schemas.
4. Synthetic correction, deletion-SCD, duplicate-workspace-ID, missing-price,
   and overlapping-interval fixtures.
5. A pinned snapshot_date golden run comparing live and precompute modes.
6. Portfolio invariants:
   - booked low <= point <= high;
   - booked savings <= corrected spend in the same basis;
   - no affected spend segment is counted twice;
   - advisory findings contribute exactly zero to booked totals.
7. A live sample review comparing at least several recommendations per changed
   rule with Query History/resource UI and, where relevant, the cloud bill.

At review time the backend/rule suite passed, but those tests did not execute the
Databricks SQL or independently validate the disputed savings economics. A green
fixture suite must not be used as evidence that these formulas are correct.

## Public Databricks references used

- [Billing system table](https://docs.databricks.com/aws/en/admin/system-tables/billing)
- [Pricing system table](https://docs.databricks.com/aws/en/admin/system-tables/pricing)
- [Compute system tables](https://docs.databricks.com/aws/en/admin/system-tables/compute)
- [Warehouse events](https://docs.databricks.com/aws/en/admin/system-tables/warehouse-events)
- [Query history](https://docs.databricks.com/aws/en/admin/system-tables/query-history)
- [Jobs system tables](https://docs.databricks.com/aws/en/admin/system-tables/jobs)
- [Pipeline Events](https://docs.databricks.com/aws/en/admin/system-tables/pipeline-events)
- [System tables overview](https://docs.databricks.com/aws/en/admin/system-tables/)

Public Apps monitoring/telemetry, serving usage, lineage, Predictive
Optimization, sharing, and AI Gateway documentation were also checked during
the review. Availability, regional support, retention, and required privileges
must be validated in the target account before enabling a rule.
