# GUI review — what the app shows, and what changed (2026-09-23)

Audience: **data engineers** (own the clusters/warehouses/jobs), **platform admins**
(own the settings and the estate), **FinOps teams** (own the number and the follow-up).
The review walked every page in demo mode, then in the rule code, since the real
rules' copy differs from the demo's.

## What each audience needs from a finding

| Question | Data engineer | Platform admin | FinOps |
|---|---|---|---|
| What exactly do I change? (setting, before → after) | **must** | **must** | nice |
| Why — the one number that proves it | **must** | **must** | **must** |
| Who owns it? | nice | **must** | **must** |
| What is it worth, and how sure are we? | nice | nice | **must** |
| What could go wrong / what to check first | **must** | **must** | — |
| How the estimate was built (tables, method) | on demand | on demand | on demand |
| NBA score, raw evidence keys, rule id/version | — | — | — |

## Findings (before)

**1. The action was the last thing on the page.** A resource page led with the rule
title ("2 ways to optimize this cluster"), four metric tiles (two of which held one
badge each), a serverless essay, and every chart. "Why" and "How" came after all of
that. The concrete setting (`auto-termination: off → 60 min`) existed only inside
the `how` prose — and the demo's `how` didn't state it at all ("Terminate after N
minutes").

**2. Numbers did not reconcile.** The headline excludes advisory findings; the donut
and the Recommendations total included them ($194k vs $221k on the same page).
Demo spend was drawn independently of findings, so one workspace showed savings at
**5× its whole bill**. On a resource page the facts strip said cost $6,643 while the
"why" said $4,072 (two rules had invented two different resources under one id).

**3. Charts contradicted each other (demo).** The auto-termination page drew "ran on
one day" (daily bars), "up 24×7" (weekly heatmap) and "two weeks of metrics"
(resource lines) for the same cluster — all generated independently.

**4. Chart-level problems (real, not demo):**
- *Resource utilisation*: five lines on one axis; network is normalised to its own
  peak, so it always touches 100% and was the loudest mark while being the least
  diagnostic. CPU and memory — the two that decide "can it shrink?" — were buried.
- *Right-size*: showed CPU today, never the question ("does it still fit on 4?").
- *Auto-stop candidates*: "today" was printed under the **nearest** bar, so a
  warehouse set to 60 min showed "today" under the 10-min bar.
- *Legends* were pooled under the last panel of a multi-chart finding, mixing
  colours from three different charts ("Focused hour", "Active minutes by hour").
- *Spend trend* in alarm red (spend is the bill, not a warning); the category donut
  repeated colours (Compute = Pipelines, Jobs = Serving) and said "Sql".

**5. Bugs found on the way:** serverless-fit link routed to `/resource/…` (no such
route → silently redirected home); `.nba-score` set `display:inline-flex` on a
`<td>`, breaking the table's last column; Rule Catalog printed `[object Object]`;
raw evidence did the same for nested values; header overflowed at phone width.

**6. Wording.**
- *Fluff*: "'x' matches the 'Enable / shorten…' criterion" (demo — restates the
  heading); "Best single option / month"; "Easiest option" (which described a
  *different* option from the savings beside it); "sampled windows" (engineers think
  in hours); ★ 4214 (a unitless score nobody can act on); "ws 6120394857612039".
- *Good, keep*: the real rules' `why` copy (concrete: hours, gaps, $), the "Before
  you act, verify" checklists, "Current auto-stop: OFF — the warehouse never
  stops", the high-churn warning, Booked/Estimated/Advisory as a trust tier.

## What changed (the mock)

**Resource page — action first.** Title is the resource; under it workspace, owner
(or an explicit "unknown"), creator. One summary row: saving (status + range),
resource spend with "saving = N% of it", and for multi-option resources
"Overlapping — pick one / savings don't add up". Each option opens with a
**What to change** box (`Auto-stop 30 min → 5 min` + the steps), then *Why it was
flagged*, the charts, the pre-flight checks, and — collapsed — *How this figure was
estimated* and *Raw evidence*. Options are tagged **Largest saving** / **Quickest
win**. The serverless verdict is a one-line disclosure unless it actually
recommends something.

**"How this figure was estimated"** now opens with 1–2 plain sentences per rule, in
the finding's own numbers (`frontend/src/lib/explain.ts`): e.g. *"The cluster ran 694h
in the last 30 days, and 399h of that was idle in stretches longer than 60 min — exactly
when a 60 min timeout would have shut it down. Those hours are priced at the cluster's
average running cost (about $5.72/hour), minus a few minutes per extra restart."* Then
*Why a range* (the rule's `savings_range_basis`, previously only a tooltip), the trust
line, and the technical *Based on*. Advisory findings explain why $0 is counted. The
trust copy was also out of date — it said Estimated was "NOT counted in the headline",
but the headline is booked + estimated; fixed in the badge tooltip and legend too.
Each sentence mirrors the rule's savings logic, so **a change to how a rule prices a
finding should update its sentence in `explain.ts`**.

**Charts.** Resource utilisation → small multiples, one strip per metric on a
shared time axis, fixed 0–100% so 5% CPU honestly looks empty, gaps where the
cluster was off. Right-size → today's p95 plus the projected p95 on the proposed
worker count. Auto-stop → "today" only on an exact match; legends under each panel;
redundant panels hidden (current→proposed line when the action box already says it,
a single-bar "saving split"). Spend trend neutral; one colour per category.

**Lists.** Recommendations table: "What to do" shows the change
(`Auto-termination 240 min → 60 min`) with the rule title beneath; owner under the
resource; status under the saving; effort/priority of the option shown (not a mix of
two options); NBA column removed (the sort already uses it; score is in the row
tooltip). Next Best Actions: dense rows with change, resource · workspace name ·
owner, and the lead sentence of the evidence.

**Overview.** Every chart and list total uses the headline's basis (advisory
excluded, "N advisory-only, not counted" shown). Leaderboard gained **% of spend**
(flags >100%). "Workspaces with findings" tile → **Quick wins / mo**
(trivial + low effort). Effort/priority bars in natural order.

**Data.** `cluster_autotermination` now also emits `proposed_auto_termination_minutes`
(additive evidence key). Demo: one identity (name, spend, owner) per resource;
workspace spend floored above its flagged resources; auto-termination and idle-cluster
charts drawn from one usage pattern; copy matches the live rules.

## Not done — recommended next

1. **Per-rule description in the Rule Catalog** ("detects / data used / how savings
   are computed"). Needs a `description` on the rule contract — a shared interface,
   so it's a deliberate change, not a drive-by.
2. **Stale open question in AGENTS.md.** The 2026-07-14 handoff says the zombie rule
   projects savings for clusters that are already off. The live rule has since fixed
   that (a stopped cluster is advisory at $0; a running one is priced on its recent
   window), so that note can be removed. The demo still draws some zombie findings on
   clusters that last ran weeks ago, with dollars; demo-only.
3. **Additive stacking in client totals.** The backend composes `additive` options;
   the frontend collapse takes the max. Identical today (every option is
   `exclusive`), but the Recommendations total should come from the API once any
   rule ships additive options.
4. **Demo: multi-rule resources** still carry per-rule metrics (e.g. CPU in the facts
   strip from one rule, a different figure in another option's `why`). Production
   reads one row per resource, so this is demo-only.
5. **Genie tab**: dual-axis chart (DBUs + users) and green for *spend* (green means
   *saving* everywhere else); space IDs instead of names.
