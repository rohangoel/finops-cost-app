# Adding a cost-saving rule

A rule is a self-contained plugin. Adding one never requires editing a shared
list — that's what lets many people/agents work in parallel.

## The 4 pieces
1. `rules/finops_rules/catalog/<rule_id>.py` — the rule class
2. `rules/finops_rules/sql/<rule_id>.sql.j2` — candidate-finding SQL
3. `rules/finops_rules/config/thresholds.yaml` — a `<rule_id>:` config block
4. `rules/finops_rules/tests/test_<rule_id>.py` — a fixture-based unit test

Fastest path: **copy `autotermination.py` + `autotermination.sql.j2`** and adapt.

## Step 1 — write the candidate SQL (`sql/<rule_id>.sql.j2`)
Return the resources that *might* be wasteful, plus the raw metrics `score()`
needs. Rules:
- **Do not filter by `workspace_id`** — scoping is injected later by the data
  layer. Your final `SELECT` **must** expose a `workspace_id` column.
- Use the current SCD2 row when reading config tables:
  `QUALIFY ROW_NUMBER() OVER (PARTITION BY workspace_id, <resource_id> ORDER BY change_time DESC) = 1`.
- Attribute **real dollars** through the SHARED pricing macro — never a
  hand-written join. Start the template with
  `{% import '_macros.sql.j2' as m with context %}` and use:
  ```sql
  SUM(u.usage_quantity * {{ m.price_rate('lp') }}) AS cost_30d_usd,
  SUM({{ m.unpriced_dbus() }})                     AS unpriced_dbus
  FROM {{ catalog }}.billing.usage u
  {{ m.price_join('lp') }}
  ```
  The macro keys the join on all four `list_prices` columns and reads
  `pricing.effective_list.default`. A copy-pasted join gets both wrong: keying on
  `sku_name` alone fans out (and inflates dollars) in any multi-cloud or
  multi-currency account, and `pricing.default` ignores promotional pricing —
  measured at **+5.54% / ~$37k per 30 days** on a real account. See the header of
  `sql/_macros.sql.j2`. `tests/test_pricing_join.py` enforces this for every rule.
- Reference thresholds as Jinja vars: `{{ max_acceptable_minutes }}`, plus
  `{{ catalog }}` and `{{ lookback_days }}` which are always provided.
- **Emit an `observed_days` column** — distinct calendar days the resource was
  seen *active*, on whichever source is your rule's primary evidence
  (`COUNT(DISTINCT CAST(start_time AS DATE))` off `node_timeline` /
  `query.history`, `COUNT(DISTINCT usage_date)` off `billing.usage`, distinct run
  days off the timelines). This feeds the minimum-observation guard in Step 2.
  `tests/test_history.py` fails if a rule's SQL omits it.

## Step 2 — write the rule class (`catalog/<rule_id>.py`)
```python
from finops_rules.contract import EffortBand, Rule, RuleContext, RuleFinding, RulePriority
from finops_rules.coverage import coverage_evidence, coverage_note, underpriced
from finops_rules.history import history_evidence, history_note, insufficient_history
from finops_rules.pricing import to_monthly
from finops_rules.registry import register

@register
class MyRule(Rule):
    id = "my_rule"                 # must match the SQL/test/config file names
    version = "1.0.0"
    title = "Human-readable action"
    resource_type = "cluster"      # cluster|warehouse|job|serving_endpoint|pipeline
    category = "compute"           # compute|sql|jobs|serving|pipelines|governance
    sql_file = "my_rule.sql.j2"    # optional; defaults to "<id>.sql.j2"

    def score(self, row: dict, ctx: RuleContext) -> RuleFinding | None:
        if insufficient_history(row, ctx):
            return None                    # too new to judge -> suppress FIRST
        if underpriced(row):
            return None                    # too little of its spend could be priced
        monthly = to_monthly(row.get("cost_30d_usd") or 0, ctx.lookback_days)
        if monthly <= 0:
            return None                    # nothing to save -> suppress
        if not _actually_applies(row, ctx.thresholds):
            return None                    # investigation-guided guard
        savings = monthly * _fraction(row)
        return RuleFinding(
            workspace_id=str(row["workspace_id"]),
            resource_type=self.resource_type,
            resource_id=str(row["resource_id"]),
            resource_name=row.get("resource_name") or str(row["resource_id"]),
            monthly_waste_usd=round(monthly, 2),
            monthly_savings_usd=round(savings, 2),
            effort=EffortBand.LOW,         # trivial | low | medium | high
            priority=RulePriority.HIGH,    # HIGH | MEDIUM | LOW
            why="Why this wastes money, with the numbers.",
            how="The concrete action to take.",
            evidence={"metric": row.get("metric"), **history_evidence(row, ctx)},
        )
```
`effort` drives the Next-Best-Action score (`monthly_savings_usd / effort_score`),
so be honest: a config toggle is `TRIVIAL`, a migration is `HIGH`.

**`insufficient_history` goes first, before any pricing.** Every savings number is
a sample extrapolated to a month, and a resource observed for a day or two cannot
support one — see the "Minimum observation window" section of `docs/DATA_MODEL.md`.
Append `history_note(row, ctx)` to your `data_basis` so the sample size is stated
in the UI, not just enforced. If your rule genuinely keys on the *absence* of
activity (like `unused_scheduled_jobs`), skip the guard and add the rule id to
`_EXEMPT_FROM_HISTORY_GUARD` in `tests/test_history.py` with the reason.

## Step 3 — add the config block (`config/thresholds.yaml`)
```yaml
my_rule:
  enabled: true
  max_acceptable_minutes: 60   # whatever your SQL/score reference
```
These are runtime-tunable — changing a threshold changes what counts as
wasteful without touching code.

## Step 4 — write the test (`tests/test_<rule_id>.py`)
Tests must **not** read YAML or hit a warehouse. Build `RuleContext` inline and
feed plain-dict rows (see `tests/test_autotermination.py`). Cover:
- a candidate that produces a finding with the expected savings sign — give its
  row an `observed_days` above `min_observation_days` (e.g. 28) so you are testing
  your scoring math and not the history guard,
- a suppressed case (guard triggers / no cost → `None`),
- `render_sql(ctx)` contains the table name and has **no** `workspace_id IN`.

## Verify
```bash
make test
```
Then confirm it shows up: `GET /api/rules` (and the **Rule Catalog** page) list
every registered rule with its current thresholds and enabled state.

Also run the rendered SQL **once** against a real warehouse before trusting it.
Rule unit tests feed plain dicts, so a wrong column name passes every test and
only fails on a live query:
```bash
databricks api post /api/2.0/sql/statements --json '{"warehouse_id":"…",
  "statement":"SELECT COUNT(*) FROM (\n<rendered sql>\n)","wait_timeout":"50s"}'
```
Keep the newline before the closing paren — several templates end in a `--`
comment which would otherwise swallow it.

## Introducing a NEW `resource_type`
The contract does not enforce an enum, but the frontend switches on
`resource_type` in three places, and an unhandled value degrades silently (a
fallback icon and, worse, **no working deep link**). If your rule introduces a
type beyond `cluster|warehouse|job|serving_endpoint`, update all three:
- `frontend/src/components/ResourceChip.tsx` — icon (+ `RESOURCE_LABEL` if the
  slug isn't what an admin would call it) and a `.chip-<type>` rule in
  `index.css`,
- `resourceUrl()` in `frontend/src/components/recDetailParts.tsx` — the workspace
  deep-link path. Note serving endpoints are addressed by *name*, not id, so that
  branch reads `resourceName`; check how your resource is addressed in the UI,
- `resourceFacts()` in the same file — the auditable facts strip.

## It just works in both modes
Because a rule is only SQL + `score()`, live mode and the precompute job both run
it the same way. You don't write anything mode-specific.
