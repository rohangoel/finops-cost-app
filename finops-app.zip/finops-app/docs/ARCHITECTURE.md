# Architecture

## Overview
```
                        ┌──────────────────────────────────────────┐
   React SPA  ──/api──▶  │ FastAPI backend                          │
 (persona-aware)         │  api/ → services/ → data source (factory)│
                         │              │            │              │
                         │       identity/ (OBO|SP)  │              │
                         │       scoping (persona)   │              │
                         └───────────────┼───────────┼──────────────┘
                                         │           │
                            live mode ◀──┘           └──▶ precompute mode
                        run rule SQL on a           read latest snapshot from
                        SQL warehouse, score        Delta finops_recommendations
                                 │                          ▲
                                 └── finops_rules ──────────┘
                                     (same rules, scored the same way)
                                            ▲
                    precompute/job.py runs the rules account-wide on a
                    schedule and writes the Delta table (Asset Bundle)
```

## Key decisions
- **Rule engine is a separate package** (`finops_rules`) so both the web app and
  the scheduled job depend on the same rule logic. Rules are auto-discovered
  plugins (`registry.discover()`), so adding one never edits a shared file.
- **Dual compute mode** behind one interface (`data/base.RecommendationSource`).
  `data/factory.py` returns `LiveRecommendationSource` or
  `PrecomputeRecommendationSource` from `FINOPS_COMPUTE_MODE`. Everything above
  the source is mode-agnostic. `test_sources_parity.py` guards that both agree.
- **Dual auth mode** behind `identity/IdentityProvider` (`obo` | `sp`), chosen by
  `FINOPS_AUTH_MODE`. It yields both the caller's `Identity` and the access token
  for the SQL connection.
- **Persona scoping is one server-side choke point** (`data/scoping.py`). Scope
  comes only from the resolved identity, never client params, and is validated as
  numeric workspace ids. A workspace admin cannot reach another workspace's data.

## Request flow (a recommendations page load)
1. `deps.get_identity(request)` → provider resolves `Identity` (user, role, workspaces).
2. `deps.get_scope(identity)` → `Scope` (all workspaces, or a validated id list).
3. `deps.get_recommendation_service(request)` builds a `connect()` bound to the
   caller's token and a `RecommendationSource` from the compute mode.
4. `RecommendationService.list(scope, …)` fetches (live: run+score rules; precompute:
   SELECT the table), filters, sorts by NBA.
5. FastAPI serializes `list[Recommendation]`; the SPA renders it.

## The recommendation contract
One schema, four mirrors that must stay in sync (additively):
`rules` produce `RuleFinding` → `services/nba_ranker.build_recommendation` →
`models/recommendation.Recommendation` (API) ↔ `precompute/ddl/*.sql` (table) ↔
`frontend/src/api/types.ts` (UI). See [DATA_MODEL.md](DATA_MODEL.md).

## Layers (backend/finops)
| Layer | Responsibility |
|-------|----------------|
| `api/` | thin HTTP routers, one per resource area |
| `services/` | orchestration, aggregation roll-ups, NBA ranking |
| `data/` | source abstraction (live/precompute), SQL client, scoping |
| `identity/` | OBO/SP providers, Scope derivation |
| `models/` | pydantic contract models |
| `config.py` | env-driven `Settings` (the two mode switches) |

## Frontend
Persona from `/api/me` drives routing (`App.tsx`): platform admins land on the
account leaderboard; workspace admins on their workspace. React Query hooks
(`hooks/`) call `/api/*` same-origin; the Databricks Apps platform injects the
user's token, so the browser never handles tokens.

## Scaling to 100s of workspaces
Account-level system tables already contain every workspace (`workspace_id`).
Live mode is fine for a few workspaces in dev; prod uses precompute so the app
only does a scoped SELECT against a partitioned/ clustered Delta table.
