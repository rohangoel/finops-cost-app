# Deploying via the Databricks workspace UI (no CLI, no git)

The turnkey path (`deploy/deploy.sh`, see [../deploy/SETUP.md](../deploy/SETUP.md))
assumes the deployer has the **Databricks CLI authenticated to the target
workspace** from their laptop. That assumption breaks in real customer
engagements: the customer often can't/won't give you CLI credentials, can't clone
this repo into their workspace (no git integration, egress rules), and expects to
click through the workspace UI rather than run a shell script.

This page is the **playbook + lessons learned** for packaging the app so it
deploys entirely from inside the workspace: copy a folder in, open one notebook,
fill in widgets, **Run All**. It was written from a live customer deploy; the
gotchas below are the ones that actually bit, not hypotheticals.

> This is a reference/pattern, not a shipped artifact — the deploy notebook itself
> is built per engagement (it hardcodes nothing). The turnkey CLI path remains the
> default for anyone who *does* have CLI access.

---

## The shape of the solution

An **orchestrator notebook** dropped at the root of the app folder that does, via
`WorkspaceClient()` + `spark.sql`, everything `deploy.sh` does from a laptop:

1. **Tables** — `CREATE SCHEMA` via `spark.sql` (no warehouse needed; the
   notebook's own compute runs it). The `finops_*` tables are materialized by the
   pipeline.
2. **Wheel** — stage the prebuilt wheel into a UC Volume (see gotcha #2).
3. **Pipeline** — create the SDP pipeline (SDK/REST), run it once, wire the daily
   trigger job.
4. **App** — render `app.yaml`, `apps.create` + `apps.deploy` from the workspace
   folder, read back the URL + service principal.
5. **Grants** — SP warehouse `CAN_USE` + UC reads; optional group grants.

Widgets at the top collect `warehouse_id`, `target_catalog`, `target_schema`,
`app_name`, `grant_to`, `run_pipeline_now`. The notebook uses **its own ambient
auth** — no token to paste, everything runs as the person clicking Run All.

---

## Gotchas (the whole point of this page)

### 1. Prebuild the frontend and the wheel — a notebook has no `npm` or `uv`
`deploy.sh` runs `npm run build` (→ `backend/finops/static/`) and
`uv build --wheel` (→ `precompute/dist/*.whl`) on the laptop. A notebook runtime
has neither tool. **Build both locally and bake them into the folder you hand
over.** The built SPA and the wheel must be *present in the copy* before it goes
into the workspace. Verify `backend/finops/static/index.html` and
`precompute/dist/finops_app-*.whl` exist in the package.

### 2. A serverless pipeline installs its wheel from a UC Volume, not `/Workspace`
The bundle declares the wheel under `environment.dependencies` as a repo-relative
path, which the CLI uploads. Doing it by hand, the reliable location for a
**serverless** pipeline's dependency is a **Unity Catalog Volume path**
(`/Volumes/<cat>/<schema>/.../*.whl`), not a `/Workspace` path. The notebook
creates a Volume and copies the prebuilt wheel there, then points
`environment.dependencies` at the Volume path. The pipeline *source*
(`pipeline.py`) is a normal workspace `file` library.

### 3. Copying files in the UI does NOT honor `.gitignore` — which is good here
`databricks sync` (what `deploy.sh` uses) respects `.gitignore`, which lists
`backend/finops/static/` and `precompute/dist/` — so the script has a trap that
temporarily un-ignores the built SPA before syncing. When the customer **copies
the folder in through the UI**, `.gitignore` is irrelevant and the built assets
come along automatically. One less moving part — but only because you prebuilt
them (gotcha #1).

### 4. Resolve the app folder path robustly inside the notebook
`dbutils.notebook...notebookPath()` returns a workspace path **without** the
`/Workspace` prefix (e.g. `/Users/you/finops-app/00_deploy`). Driver-local file
reads, the pipeline `file` library, and the app `source_code_path` all want the
`/Workspace`-prefixed absolute path. Normalize once, assert the directory exists,
and fail loudly if the notebook isn't at the folder root.

### 5. Scrub the previous workspace's values before handing the package over
The repo's checked-in `app.yaml` and `deploy/config.env` carry whatever workspace
they were last deployed to (host, warehouse id, catalog). Reset them to the
template/placeholder form, and `grep` the whole package for the old host /
warehouse id / catalog before packaging. Also drop internal-only files from the
customer copy (`AGENTS.md`, `benchmark/`, local `.env`, `.claude/`).

### 6. Keep the package small
The working tree is ~200 MB+ (`.venv/`, `frontend/node_modules/`, downloaded
Terraform under `.databricks/bundle/`). None of it is needed at runtime — the SPA
is prebuilt into `static/` and the pipeline installs the wheel. Excluding those
takes the customer package to a couple of MB, which imports into the workspace
quickly.

---

## Auth reality (matters when a customer can't grant a service principal)

Despite what the README/`app.yaml` suggest ("reads as the signed-in user"), in
`precompute` mode the app reads its data tables through **its own service
principal** — `backend/finops/deps.py` connects every source with the SP, and the
OBO user token is used only for *scoping* (which workspaces a user may see), not
for the SQL. See [AUTH_AND_SCOPING.md](AUTH_AND_SCOPING.md).

That's usually fine: the app only reads the four `finops_*` tables (which the
deployer owns and can grant to the SP), while the **pipeline** reads `system.*`
and runs as its creator. So the SP never needs system-table access.

**If a customer can't grant the SP even the `finops_*` tables** (e.g. only one
user's identity is allowed to read anything), the app already supports running all
SQL as a specific user with **no code change**: set `DATABRICKS_TOKEN` (+
`DATABRICKS_SERVER_HOSTNAME`) and `sql_client.get_connection` takes the
explicit-token path. Inject the token from a Databricks **secret** via `app.yaml`
`valueFrom`, bound to the app as an `AppResourceSecret` (permission `READ`) — never
plaintext. Consequence: everyone who can open the app reads with that user's
grants, so only do this for single-user / PoC deployments.

---

## Production gotcha: pipeline scoring OOMs on a large fleet

On a big account the pipeline can fail building `finops_recommendations` with:

```
Function exceeded the limit of 1024 megabytes.
Unexpected end of input trying to read batch.
```

Cause: the scoring sink used `groupBy("rule_id").applyInPandas`, which materializes
**one rule's entire candidate set into a single pandas frame** on one executor.
When a rule matches thousands of resources across a large fleet, that frame blows
the serverless 1 GB-per-UDF cap. (A small test workspace never hits it — this only
shows up at customer scale.)

Fix: score with **`mapInPandas`** instead, which streams bounded Arrow batches
(`spark.sql.execution.arrow.maxRecordsPerBatch`, default 10k rows) and groups by
`rule_id` *within* each batch. This is safe because the scoring transform
(`finops.services.precompute_transform.records_for_rule`) is **per-row
independent** — no cross-row aggregation — so batching changes memory, never
results (`tests/test_sdp_parity.py` still holds). If it still OOMs on a pathological
single rule, lower `maxRecordsPerBatch` to ~2000 in the pipeline configuration.

This lives in `precompute/pipeline.py`, which is the pipeline's *source library* —
not in the wheel — so fixing it is a one-file re-sync, no wheel rebuild.

---

## Checklist for the next customer

- [ ] `npm run build` and `uv build --wheel` locally; confirm `static/` + wheel exist
- [ ] Reset `app.yaml` / `deploy/config.env` to placeholders; `grep` for the prior host/warehouse/catalog
- [ ] Strip `.venv/`, `node_modules/`, `.databricks/bundle/`, internal docs, `.env`
- [ ] Build the orchestrator notebook (widgets → tables → volume+wheel → pipeline → app → grants)
- [ ] Verify SDK/REST shapes against the runtime SDK version (they drift — Apps API is recent)
- [ ] Decide auth: SP (default) vs run-as-user token (only-one-identity case)
- [ ] Sanity-check the `mapInPandas` scoring is in `pipeline.py` before a large-fleet run
```
