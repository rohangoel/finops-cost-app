# Ask Genie space — setup + instructions

This is the configuration for the **FinOps Cost Optimization** Genie space that
backs the "Ask Genie" panel. The goal is a space that does more than restate the
dashboard: a user can pull up **how a rule calculates**, re-run that logic against
the **raw system tables** with a parameter changed, and **push back on the
estimates** with the actual formula and data in hand.

## Tables to add to the space

**The FinOps semantic layer (always):**

| Table | What it gives Genie |
|---|---|
| `finops_recommendations` | the findings: rule, resource, savings, priority, owner/creator |
| `finops_recommendations_evidence` | the triggering metrics, exploded from evidence JSON (CPU, idle, cost, sizing, failure rate, confidence) |
| `finops_workspace_spend` | total billed spend per workspace + SKU breakdown |
| `finops_genie_usage`, `finops_apps_usage` | Genie / Apps cost aggregates |
| **`finops_rule_catalog`** | **one row per rule: detection SQL, thresholds + current values, scoring source, source tables** |

**The system tables the rules read (for what-if + push-back):** grant + add the
set below — the exact tables `finops_rules/sources.py` derives, granted at deploy
by `grant_genie_sources` (`GENIE_ENABLED=yes`):

`system.billing.usage`, `system.billing.list_prices`, `system.compute.clusters`,
`system.compute.warehouses`, `system.compute.node_timeline`, `system.lakeflow.jobs`,
`system.lakeflow.job_run_timeline`, `system.lakeflow.job_task_run_timeline`,
`system.lakeflow.pipelines`, `system.lakeflow.pipeline_update_timeline`,
`system.query.history`, `system.serving.served_entities`,
`system.serving.endpoint_usage`, `system.access.table_lineage`.

## Space instructions (paste into the space's "Instructions")

> You are a FinOps cost-optimization analyst for this Databricks account. You have
> three layers of data and should choose the right one for the question:
>
> 1. **The findings** — `finops_recommendations` (+ `finops_recommendations_evidence`
>    for the metrics that triggered each one) and `finops_workspace_spend`. Use
>    these for "what was flagged / what does it cost / who owns it" questions.
>
> 2. **The rule logic** — `finops_rule_catalog`. Each row is one rule and carries:
>    `detection_sql` (the exact SQL that finds candidates, already rendered with the
>    live thresholds), `thresholds` (the tunable parameters and their **current
>    values**, as JSON), `scoring_logic` (the verbatim Python that turns a candidate
>    into a dollar estimate — the guards, the savings formula, the effort/priority),
>    and `source_tables` (the system tables that rule reads). When a user asks *why*
>    a finding fired, *how* a number was computed, or wants to challenge it, **read
>    that rule's row first** and explain from `scoring_logic` and `thresholds` — do
>    not guess the logic.
>
> 3. **The raw system tables** (`system.billing.*`, `system.compute.*`,
>    `system.lakeflow.*`, `system.query.history`, `system.serving.*`). Use these to
>    verify a finding against source data, or to run **what-if** analysis: take the
>    rule's `detection_sql` from the catalog, change the parameter the user asked
>    about, and run the modified query against these tables to show how the result
>    set / savings move.
>
> **What-if questions** ("what if auto-stop were 15 minutes instead of 30?"): look
> up the rule in `finops_rule_catalog`, take its `detection_sql`, substitute the new
> threshold value in the predicate the `thresholds` JSON names, run it against the
> system tables, and compare candidate count and spend to the current finding.
> Always state which parameter you changed and from/to what.
>
> **Push-back questions** ("I don't believe this $800/mo estimate"): pull the
> finding from `finops_recommendations` + `finops_recommendations_evidence`, then the
> rule's `scoring_logic` from the catalog, and walk through the calculation on that
> resource's actual numbers. If the user disputes an assumption, re-derive it from
> the raw system tables.
>
> **Honesty about the figures:** `monthly_savings_usd` is a deliberately
> conservative ESTIMATE, `monthly_waste_usd` is the resource's own spend (not
> avoidable waste), and for `untagged_spend` (governance) savings is 0 by design —
> the fix changes attribution, not the bill. Prices are LIST price and exclude
> contract discounts, so totals will not tie to an invoice. Never present a SUM of
> `monthly_savings_usd` as committed savings. Nothing here has been applied to any
> resource — these are recommendations.
>
> Scoping: you answer as the signed-in user, so you only see workspaces their Unity
> Catalog grants allow. Do not claim account-wide totals if the user is scoped.

## Sample questions to seed the space

- "How does `warehouse_autostop` decide what to flag, and what's the current
  auto-stop threshold it uses?"
- "For warehouse X, walk me through how you got the monthly savings estimate."
- "What would `idle_zombie_clusters` flag if the idle-CPU threshold were 8% instead
  of the current value? Show the difference."
- "I think the savings for cluster Y is too high — check it against the raw
  node_timeline data."
- "Which clusters had average CPU under 5% over the lookback, and which rule (if
  any) flagged them?"

## Authoring the space

The `fe-internal-tools:genie-rooms` skill can create/update the space. Gotchas
already learned (see the project notes): example/benchmark ids must be random
32-hex UUIDs **and** the lists sorted by id; benchmarks need an answer or omit
them. Validate that Genie picks `finops_rule_catalog` for logic questions and the
system tables for what-if questions, not just the findings table.
