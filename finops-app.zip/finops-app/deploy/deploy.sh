#!/usr/bin/env bash
# FinOps App — one-command deploy into a target (customer) workspace.
#
#   cp deploy/config.env.example deploy/config.env   # edit the values
#   ./deploy/deploy.sh                                # full install
#   ./deploy/deploy.sh --app-only                     # just rebuild + redeploy the app
#   ./deploy/deploy.sh --job-only                     # just (re)deploy + run the precompute job
#
# What it does, end to end, nothing pointing at any other workspace:
#   1. preflight  — CLI auth + config sanity
#   2. tables     — create schema (+ optional grants). Every table is an OUTPUT of
#                   the SDP pipeline, which materializes it itself:
#                   finops_recommendations, finops_workspace_spend,
#                   finops_genie_usage, finops_apps_usage, finops_cost_anomalies
#   3. job        — build wheel, deploy the precompute bundle, optionally run it once
#   4. app        — build the SPA, render app.yaml, create the app if missing, sync + deploy
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${FINOPS_CONFIG:-deploy/config.env}"
[[ -f "$CONFIG" ]] || { echo "ERROR: $CONFIG not found. Copy deploy/config.env.example to it and fill it in." >&2; exit 1; }
# shellcheck disable=SC1090
source "$CONFIG"

# --- resolve config / defaults -------------------------------------------
: "${HOST:?set HOST in $CONFIG}"
: "${WAREHOUSE_ID:?set WAREHOUSE_ID in $CONFIG}"
TARGET_CATALOG="${TARGET_CATALOG:-main}"
TARGET_SCHEMA="${TARGET_SCHEMA:-finops}"
SYSTEM_CATALOG="${SYSTEM_CATALOG:-system}"
# COMPUTE_MODE: precompute (default; needs a writable TARGET schema + the job) or
# live (rules run on the warehouse on demand — no tables, no job, no writable schema).
COMPUTE_MODE="${COMPUTE_MODE:-precompute}"
# SCHEMA_PREFIX: for a system-table MIRROR whose schemas are renamed, e.g. a mirror
# exposing system.billing as <SYSTEM_CATALOG>.aapsbilling -> set SCHEMA_PREFIX=aaps.
# Empty (default) = standard system.<schema> layout.
SCHEMA_PREFIX="${SCHEMA_PREFIX:-}"
# HIDDEN_RULES: CSV of rule ids to disable (e.g. rules reading tables a mirror lacks).
HIDDEN_RULES="${HIDDEN_RULES:-}"
APP_NAME="${APP_NAME:-finops-app}"
LOOKBACK_DAYS="${LOOKBACK_DAYS:-30}"
GRANT_TO="${GRANT_TO:-}"
RUN_JOB_NOW="${RUN_JOB_NOW:-yes}"
# Optional Genie panel (PoC). Off unless GENIE_ENABLED=yes. GENIE_MODE picks the
# transport: "api" (native context-aware chat, needs GENIE_SPACE_ID, no embedding
# allowlist) or "iframe" (embedded space, needs GENIE_SPACE_URL + the allowlist).
GENIE_ENABLED="${GENIE_ENABLED:-no}"
GENIE_MODE="${GENIE_MODE:-iframe}"
GENIE_SPACE_URL="${GENIE_SPACE_URL:-}"
GENIE_SPACE_ID="${GENIE_SPACE_ID:-}"
# Who may open the app (StopTheLeak, GH #123). Empty = leave app permissions alone.
# Set (e.g. "account users"): grant it CAN_USE, and reduce the workspace `users`
# group from CAN_MANAGE to CAN_USE if it has that. Additive update-permissions only.
APP_USERS="${APP_USERS:-}"
# Optional StopTheLeak integration (off by default): My findings tab, workspace-owner
# routing and, with FEEDBACK_ENABLED, in-app votes stored in StopTheLeak's Lakebase.
STOPTHELEAK_ENABLED="${STOPTHELEAK_ENABLED:-no}"
# Billing custom tag naming a workspace's owner; SP-owned findings route to them.
# Defaults to "Owner" with StopTheLeak on, else "" (no lookup).
if [[ "$STOPTHELEAK_ENABLED" == "yes" ]]; then
  WORKSPACE_OWNER_TAG="${WORKSPACE_OWNER_TAG-Owner}"
else
  WORKSPACE_OWNER_TAG="${WORKSPACE_OWNER_TAG-}"
fi
FEEDBACK_ENABLED="${FEEDBACK_ENABLED:-no}"
if [[ "$FEEDBACK_ENABLED" == "yes" && "$STOPTHELEAK_ENABLED" != "yes" ]]; then
  echo "WARNING: FEEDBACK_ENABLED=yes has no effect without STOPTHELEAK_ENABLED=yes" >&2
  FEEDBACK_ENABLED="no"
fi
FEEDBACK_DATABASE_INSTANCE="${FEEDBACK_DATABASE_INSTANCE:-}"
FEEDBACK_DATABASE="${FEEDBACK_DATABASE:-}"
HOST="${HOST#https://}"; HOST="${HOST#http://}"; HOST="${HOST%/}"
REC_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_recommendations"
SPEND_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_workspace_spend"
GENIE_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_genie_usage"
APPS_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_apps_usage"
ANOMALY_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_cost_anomalies"
# Flattened-evidence VIEW for the Ask Genie space (reads finops_recommendations
# only — no system-table access). Created after the pipeline populates the table.
EVIDENCE_VIEW="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_recommendations_evidence"
# Rule-knowledge catalog (pipeline-owned) — the calculations behind the findings,
# for the Ask Genie space's what-if / push-back ability.
RULE_CATALOG="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_rule_catalog"
# Which principal the Ask Genie space runs its queries as (for the system-table +
# catalog grants that let it do what-if analysis). Defaults to GRANT_TO, else the
# broad "account users". Set GENIE_GRANT_TO to target a specific space owner/group.
GENIE_GRANT_TO="${GENIE_GRANT_TO:-${GRANT_TO:-account users}}"
# The SDP pipeline's event log (see precompute/databricks.yml `event_log.name`).
# The app reads it for the run-status strip (/api/data-health last_run).
RUNLOG_TABLE="${TARGET_CATALOG}.${TARGET_SCHEMA}.finops_run_log"

# databricks CLI, with the profile flag applied to every call if set
DBX=(databricks)
[[ -n "${DATABRICKS_PROFILE:-}" ]] && DBX+=(-p "$DATABRICKS_PROFILE")

STAGE="${1:-all}"
say() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m!! %s\033[0m\n' "$*" >&2; }

# --- run a single SQL statement on the warehouse via the CLI --------------
# Returns non-zero (and reports why) instead of exiting, so callers can choose
# whether a failure is fatal — see run_sql (fatal) and run_sql_optional (not).
_run_sql_status() {
  local stmt="$1"
  local payload out state
  payload=$(cat <<JSON
{"warehouse_id":"${WAREHOUSE_ID}","statement":$(printf '%s' "$stmt" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),"wait_timeout":"50s","on_wait_timeout":"CANCEL"}
JSON
)
  out=$("${DBX[@]}" api post /api/2.0/sql/statements --json "$payload")
  state=$(printf '%s' "$out" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("status",{}).get("state",""))')
  if [[ "$state" != "SUCCEEDED" ]]; then
    warn "SQL failed (state=$state):"
    printf '%s\n' "$out" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("status",{}).get("error",{}).get("message","(no message)"))' >&2
    printf '   statement: %s\n' "${stmt:0:120}..." >&2
    return 1
  fi
}

run_sql() {
  _run_sql_status "$1" || exit 1
}

# --- like run_sql, but a failure is a warning rather than fatal -----------
# For statements that legitimately fail on a first install, specifically GRANTs on
# the SDP pipeline's output tables: the pipeline creates those on its first run, so
# before that they do not exist. Without this, `--app-only` on a fresh workspace
# would abort the deploy on a grant that will succeed a minute later.
run_sql_optional() {
  _run_sql_status "$1" || warn "  ^ non-fatal (target may not exist yet); continuing"
  return 0
}

# =========================================================================
preflight() {
  say "Preflight: verifying CLI auth to $HOST"
  command -v databricks >/dev/null || { echo "ERROR: databricks CLI not on PATH." >&2; exit 1; }
  command -v python3 >/dev/null || { echo "ERROR: python3 required (used to build JSON)." >&2; exit 1; }
  local me
  me=$("${DBX[@]}" current-user me --output json 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("userName",""))' || true)
  [[ -n "$me" ]] || { echo "ERROR: not authenticated. Run: databricks auth login --host https://$HOST" >&2; exit 1; }
  echo "   authenticated as: $me"
  echo "   target tables:    $REC_TABLE"
  echo "                     $SPEND_TABLE"
  echo "                     $GENIE_TABLE"
  echo "                     $APPS_TABLE"
  echo "                     $ANOMALY_TABLE"
  echo "   warehouse:        $WAREHOUSE_ID"
}

# =========================================================================
tables() {
  say "Creating schema on warehouse $WAREHOUSE_ID"
  run_sql "CREATE SCHEMA IF NOT EXISTS ${TARGET_CATALOG}.${TARGET_SCHEMA}"
  # No tables are created here. Every table (finops_recommendations,
  # finops_workspace_spend, finops_genie_usage, finops_apps_usage) is an OUTPUT of
  # the SDP pipeline, which materializes it itself — pre-creating them makes the
  # pipeline fail with "cannot materialize ... because a MANAGED table already
  # exists with that name". Their DDL files are retained as the documented contract
  # and as the fixture for precompute/tests/test_contract_schema.py.

  # Nothing app-owned to grant here: every table is pipeline-owned and granted in
  # grant_pipeline_tables(), after the pipeline has created it. When GRANT_TO is
  # unset, print the manual-grant guidance so the deployer can run it themselves.
  if [[ -z "$GRANT_TO" ]]; then
    cat <<GRANTS

   GRANT_TO not set — run these yourself (replace the principal), so app users
   (queries run AS the signed-in user in OBO mode) can read:

     GRANT SELECT ON TABLE ${REC_TABLE} TO \`account users\`;
     GRANT SELECT ON TABLE ${SPEND_TABLE} TO \`account users\`;
     GRANT SELECT ON TABLE ${GENIE_TABLE} TO \`account users\`;
     GRANT SELECT ON TABLE ${APPS_TABLE} TO \`account users\`;
     GRANT SELECT ON TABLE ${ANOMALY_TABLE} TO \`account users\`;
     -- Ask Genie extras (optional; only if the Genie space is used):
     GRANT SELECT ON VIEW ${EVIDENCE_VIEW} TO \`account users\`;
     GRANT SELECT ON TABLE ${RULE_CATALOG} TO \`account users\`;
     -- and SELECT on the system tables the rules read, so the space can do
     -- what-if analysis / challenge the numbers (see grant_genie_sources).
     -- plus SELECT on the system tables (system.compute/billing/lakeflow/access)
     GRANT SELECT ON SCHEMA ${SYSTEM_CATALOG}.compute TO \`account users\`;

GRANTS
  fi
}

# =========================================================================
# Grants for the tables the SDP pipeline creates. Must run AFTER the pipeline has
# materialized them — a GRANT on a not-yet-existing table is a hard error.
grant_pipeline_tables() {
  [[ -n "$GRANT_TO" ]] || return 0
  say "Granting access on the pipeline-owned tables to: $GRANT_TO"
  run_sql "GRANT SELECT ON TABLE ${REC_TABLE} TO \`${GRANT_TO}\`"
  run_sql "GRANT SELECT ON TABLE ${SPEND_TABLE} TO \`${GRANT_TO}\`"
  run_sql "GRANT SELECT ON TABLE ${GENIE_TABLE} TO \`${GRANT_TO}\`"
  run_sql "GRANT SELECT ON TABLE ${APPS_TABLE} TO \`${GRANT_TO}\`"
  # Optional: a pipeline deployed before the Cost Anomalies sink existed hasn't
  # created it yet, and that must not block the other grants.
  run_sql_optional "GRANT SELECT ON TABLE ${ANOMALY_TABLE} TO \`${GRANT_TO}\`"
  # The rule-knowledge catalog (may not exist on a --app-only run before the first
  # pipeline run, so don't hard-fail).
  run_sql_optional "GRANT SELECT ON TABLE ${RULE_CATALOG} TO \`${GRANT_TO}\`"
}

# =========================================================================
# System-table access for the Ask Genie space, so it can go beyond restating the
# precomputed findings: with SELECT on the tables the rules read, plus the rule
# catalog (detection SQL + thresholds + scoring), a user can ask Genie to re-run a
# rule's logic with a parameter changed ("what if auto-stop were 15 min?") and
# challenge an estimate against the raw data. Only the tables the rules actually
# read are granted — the exact set finops_rules/sources.py derives. Optional (off
# unless GENIE_ENABLED=yes), and per-table non-fatal so a schema that isn't enabled
# in this workspace just degrades that rule's depth rather than failing the deploy.
grant_genie_sources() {
  [[ "$GENIE_ENABLED" == "yes" ]] || return 0
  say "Granting the Ask Genie space read on the rules' system tables: $GENIE_GRANT_TO"
  # The union of system tables the rules read (see finops_rules/sources.py). Grant
  # per-table (not whole schemas) so the space sees only what the engine uses.
  local sys="${SYSTEM_CATALOG}"
  local tables=(
    "billing.usage" "billing.list_prices"
    "compute.clusters" "compute.warehouses" "compute.node_timeline"
    "lakeflow.jobs" "lakeflow.job_run_timeline" "lakeflow.job_task_run_timeline"
    "lakeflow.pipelines" "lakeflow.pipeline_update_timeline"
    "query.history"
    "serving.served_entities" "serving.endpoint_usage"
    "access.table_lineage"
  )
  # Granting on system.* requires ACCOUNT ADMIN. The deployer often isn't one, so
  # track failures and, if any, print one actionable block instead of burying the
  # requirement in 14 scattered warnings. Non-fatal: the app + evidence view + rule
  # catalog still work; only the space's what-if-against-raw-data depth needs these.
  local t failed=0
  for t in "${tables[@]}"; do
    _run_sql_status "GRANT SELECT ON TABLE ${sys}.${t} TO \`${GENIE_GRANT_TO}\`" \
      || failed=$((failed + 1))
  done
  # The rule catalog itself, so the space can look up the logic to reason with.
  run_sql_optional "GRANT SELECT ON TABLE ${RULE_CATALOG} TO \`${GENIE_GRANT_TO}\`"

  if [[ "$failed" -gt 0 ]]; then
    warn "Could not grant $failed system table(s) to ${GENIE_GRANT_TO} — this needs an"
    warn "ACCOUNT ADMIN (granting on system.* is account-level). The app, the evidence"
    warn "view and the rule catalog still work; only the Ask Genie space's ability to"
    warn "run what-if queries against RAW system tables needs these. Have an account"
    warn "admin run (see docs/GENIE_SPACE_INSTRUCTIONS.md):"
    for t in "${tables[@]}"; do
      echo "     GRANT SELECT ON TABLE ${sys}.${t} TO \`${GENIE_GRANT_TO}\`;"
    done
  fi
}

# =========================================================================
# Flattened-evidence view for the Ask Genie space. Reads finops_recommendations
# ONLY, so it needs no system-table access — it gives the space the triggering
# metrics ("which clusters had avg CPU under 5%?") while staying inside the
# precompute semantic layer. Must run AFTER the pipeline materializes the table.
create_evidence_view() {
  local sql
  sql=$(sed -e "s/{catalog}/${TARGET_CATALOG}/g" -e "s/{schema}/${TARGET_SCHEMA}/g" \
        "precompute/ddl/finops_recommendations_evidence.sql")
  # Keep only the CREATE ... statement (drop the leading comment header).
  sql=$(printf '%s' "$sql" | python3 -c '
import re,sys
txt=sys.stdin.read()
txt="\n".join(l for l in txt.splitlines() if not l.strip().startswith("--"))
m=re.search(r"CREATE OR REPLACE VIEW.*?;", txt, re.S)
print(m.group(0) if m else txt)')
  say "Creating the Ask Genie evidence view: ${EVIDENCE_VIEW}"
  # Optional: on --app-only the base table may not exist yet, so don't hard-fail.
  run_sql_optional "$sql"
  if [[ -n "$GRANT_TO" ]]; then
    run_sql_optional "GRANT SELECT ON VIEW ${EVIDENCE_VIEW} TO \`${GRANT_TO}\`"
  fi
}

# =========================================================================
# Document the output tables in Unity Catalog, so a reader who finds them outside
# the app (Catalog Explorer, a Genie space, an analyst running SELECT *) sees the
# caveats — above all that the dollar figures are advisory estimates, not billed
# amounts or committed savings.
#
# TABLE comments only: the pipeline's outputs are materialized views, and an MV
# silently DISCARDS column comments (verified live — see
# finops.services.table_comments, which is the single source of the text). The
# column-level caveats live in the DDL files.
#
# Runs after the pipeline has materialized its tables. Non-fatal: failing to
# annotate a table must never fail a deploy that otherwise worked.
comment_tables() {
  say "Documenting the output tables in Unity Catalog"
  local stmts
  # One statement per line (the text itself never contains a newline).
  # Loaded by FILE PATH, not as finops.services.table_comments: importing the
  # package would drag in pydantic/fastapi, which this script (running on a
  # deployer machine with only the CLI) has no reason to need. The module itself is
  # dependency-free data.
  stmts=$(python3 -c '
import importlib.util, sys
spec = importlib.util.spec_from_file_location(
    "table_comments", "backend/finops/services/table_comments.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
catalog, schema = sys.argv[1], sys.argv[2]
for table in mod.TABLE_COMMENTS:
    stmt = mod.table_comment_sql(f"{catalog}.{schema}.{table}", table)
    if stmt:
        print(stmt)
' "$TARGET_CATALOG" "$TARGET_SCHEMA")
  while IFS= read -r stmt; do
    [[ -n "$stmt" ]] || continue
    local table="${stmt#COMMENT ON TABLE }"
    table="${table%% *}"
    # Use the non-fatal _run_sql_status, NOT run_sql: run_sql does `|| exit 1`,
    # which fires even inside this `if` condition and kills the whole deploy
    # before the app stage. TABLE_COMMENTS covers central-mode tables too
    # (finops_central_*), which do not exist in a single-account deploy, so a
    # missing-table failure here is expected and must stay non-fatal — exactly
    # what this function's header promises.
    if _run_sql_status "$stmt" >/dev/null 2>&1; then
      echo "   -> ${table##*.}"
    else
      warn "could not comment ${table##*.} (may not exist yet); continuing"
    fi
  done <<<"$stmts"
}

# =========================================================================
# The precompute stage. Deploys the bundle and runs the SDP PIPELINE, which is
# the single precompute backend: it writes finops_recommendations,
# finops_workspace_spend and finops_genie_usage. (The legacy imperative job.py
# remains in the bundle for one release as a rollback path — see AGENTS.md — but
# is no longer what a deploy runs, and no longer writes anything the pipeline
# does not.)
job() {
  say "Building wheel for the precompute pipeline"
  rm -f precompute/dist/finops_app-*.whl
  if ! UV_INDEX_URL="${UV_INDEX_URL:-https://pypi-proxy.cloud.databricks.com/simple/}" \
        uv build --wheel --out-dir precompute/dist 2>/dev/null; then
    warn "uv build via proxy failed; retrying offline (uses cached build deps)"
    UV_OFFLINE=1 uv build --wheel --out-dir precompute/dist
  fi

  # `bundle deploy` downloads its own Terraform and verifies the signature. That
  # check fails on some machines with "openpgp: key expired", which has nothing to
  # do with this bundle. If a local terraform is on PATH, point the CLI at it and
  # skip the download entirely; DATABRICKS_TF_VERSION must match the binary.
  local tf_env=()
  if [[ -z "${DATABRICKS_TF_EXEC_PATH:-}" ]] && command -v terraform >/dev/null; then
    local tf_bin tf_ver
    tf_bin=$(command -v terraform)
    tf_ver=$(terraform version -json 2>/dev/null \
      | python3 -c 'import json,sys; print(json.load(sys.stdin).get("terraform_version",""))' 2>/dev/null || true)
    if [[ -n "$tf_ver" ]]; then
      echo "   using local terraform $tf_ver ($tf_bin)"
      tf_env=(env "DATABRICKS_TF_EXEC_PATH=$tf_bin" "DATABRICKS_TF_VERSION=$tf_ver")
    fi
  fi

  say "Deploying precompute bundle (catalog=$TARGET_CATALOG schema=$TARGET_SCHEMA)"
  ( cd precompute && ${tf_env[@]+"${tf_env[@]}"} "${DBX[@]}" bundle deploy \
      --var="catalog=${TARGET_CATALOG},schema=${TARGET_SCHEMA}" \
      --var="workspace_owner_tag=${WORKSPACE_OWNER_TAG}" )

  if [[ "$RUN_JOB_NOW" == "yes" ]]; then
    say "Running the SDP pipeline once to populate $REC_TABLE"
    ( cd precompute && ${tf_env[@]+"${tf_env[@]}"} "${DBX[@]}" bundle run finops_precompute_sdp \
        --var="catalog=${TARGET_CATALOG},schema=${TARGET_SCHEMA}" \
        --var="workspace_owner_tag=${WORKSPACE_OWNER_TAG}" )
    # The pipeline creates these tables, so the grants, comments and the evidence
    # view (which reads finops_recommendations) can only run now.
    grant_pipeline_tables
    create_evidence_view
    grant_genie_sources
    comment_tables
  else
    echo "   RUN_JOB_NOW=no — the pipeline is scheduled daily; tables do not exist"
    echo "   until its first run (the app falls back to live queries until then)."
    # Only the app-owned table exists yet; the rest are annotated on a later run.
    comment_tables
  fi
}

# =========================================================================
app() {
  say "Building the SPA"
  ( cd frontend && npm install --silent && npm run build )

  say "Rendering app.yaml from deploy/app.yaml.tmpl"
  sed -e "s|__WAREHOUSE_ID__|${WAREHOUSE_ID}|g" \
      -e "s|__TARGET_CATALOG__|${TARGET_CATALOG}|g" \
      -e "s|__TARGET_SCHEMA__|${TARGET_SCHEMA}|g" \
      -e "s|__SYSTEM_CATALOG__|${SYSTEM_CATALOG}|g" \
      -e "s|__COMPUTE_MODE__|${COMPUTE_MODE}|g" \
      -e "s|__SCHEMA_PREFIX__|${SCHEMA_PREFIX}|g" \
      -e "s|__HIDDEN_RULES__|${HIDDEN_RULES}|g" \
      -e "s|__LOOKBACK_DAYS__|${LOOKBACK_DAYS}|g" \
      -e "s|__GENIE_ENABLED__|${GENIE_ENABLED}|g" \
      -e "s|__GENIE_MODE__|${GENIE_MODE}|g" \
      -e "s|__GENIE_SPACE_URL__|${GENIE_SPACE_URL}|g" \
      -e "s|__GENIE_SPACE_ID__|${GENIE_SPACE_ID}|g" \
      -e "s|__STOPTHELEAK_ENABLED__|$([[ "$STOPTHELEAK_ENABLED" == "yes" ]] && echo true || echo false)|g" \
      -e "s|__FEEDBACK_ENABLED__|$([[ "$FEEDBACK_ENABLED" == "yes" ]] && echo true || echo false)|g" \
      -e "s|__FEEDBACK_DATABASE__|${FEEDBACK_DATABASE}|g" \
      deploy/app.yaml.tmpl > app.yaml
  echo "   app.yaml -> $REC_TABLE, warehouse $WAREHOUSE_ID"

  # Create the app if it doesn't exist yet (deploy alone won't create it).
  if "${DBX[@]}" apps get "$APP_NAME" >/dev/null 2>&1; then
    echo "   app '$APP_NAME' exists"
  else
    say "Creating app '$APP_NAME'"
    "${DBX[@]}" apps create "$APP_NAME"
  fi

  # `databricks sync` honors .gitignore, which excludes the built SPA
  # (backend/finops/static) — temporarily un-ignore it so the assets upload,
  # and always restore .gitignore on exit.
  local src="/Workspace/Users/$("${DBX[@]}" current-user me --output json | python3 -c 'import json,sys; print(json.load(sys.stdin)["userName"])')/apps/${APP_NAME}"
  say "Syncing source to $src"
  local restore=0
  if grep -qxF 'backend/finops/static/' .gitignore; then
    sed -i.bak 's|^backend/finops/static/$|# (deploy) backend/finops/static/|' .gitignore
    restore=1
  fi
  # shellcheck disable=SC2064
  trap "[[ $restore == 1 ]] && mv .gitignore.bak .gitignore" EXIT

  # The Postgres driver is needed only for the optional feedback store, so it is not
  # in requirements.txt; add it for this upload when feedback is on (restored below).
  local restore_req=0
  if [[ "$FEEDBACK_ENABLED" == "yes" ]] && ! grep -q '^psycopg' requirements.txt; then
    cp requirements.txt requirements.txt.bak
    echo 'psycopg[binary]==3.2.3' >> requirements.txt
    restore_req=1
  fi
  # shellcheck disable=SC2064
  trap "[[ $restore == 1 ]] && mv .gitignore.bak .gitignore; [[ $restore_req == 1 ]] && mv requirements.txt.bak requirements.txt" EXIT

  "${DBX[@]}" sync --watch=false . "$src"
  say "Deploying app '$APP_NAME'"
  "${DBX[@]}" apps deploy "$APP_NAME" --source-code-path "$src"

  # OBO user scopes live on the APP RESOURCE (NOT app.yaml, which silently ignores
  # them). The app calls the warehouse and — in api mode — the Genie Conversation
  # API AS the signed-in user, so the forwarded token must carry those scopes or
  # the calls 403. "sql" always; add "genie" when the api-mode Ask Genie chat is on.
  # NB the scope is "genie", not "dashboards.genie". Changing scopes requires the
  # user to RE-CONSENT: open the app URL in a fresh/incognito session afterwards.
  local scopes='["sql"]'
  if [[ "$GENIE_ENABLED" == "yes" && "$GENIE_MODE" == "api" ]]; then
    scopes='["genie","sql"]'
  fi
  say "Setting OBO user_api_scopes = $scopes"
  "${DBX[@]}" apps update "$APP_NAME" --json "{\"user_api_scopes\": $scopes}" >/dev/null \
    && echo "   scopes set (users must re-consent: reopen the app in a fresh session)" \
    || warn "could not set user_api_scopes; set manually: apps update $APP_NAME --json '{\"user_api_scopes\": $scopes}'"

  # Grant the app's OWN service principal everything it needs to read the
  # recommendation table. The deployed app authenticates its SQL queries as this
  # SP (see backend/finops/data/sql_client.py — the OBO token is not forwarded to
  # the connection), so WITHOUT these grants every data query hangs and the UI is
  # stuck loading. The SP only exists after `apps create`, which is why this runs
  # here and not in the tables stage. Two independent things are required:
  #   1. CAN_USE on the SQL warehouse — otherwise the SP cannot even OPEN a
  #      session; the connector retries for its full 900s window then fails
  #      (the classic "stuck on Loading…" symptom).
  #   2. UC privileges: USE CATALOG + USE SCHEMA + table SELECT — needed once the
  #      session is open.
  local app_sp
  app_sp=$("${DBX[@]}" apps get "$APP_NAME" --output json \
    | python3 -c 'import json,sys; print(json.load(sys.stdin).get("service_principal_client_id",""))' || true)
  if [[ -n "$app_sp" ]]; then
    say "Granting the app service principal ($app_sp) warehouse + UC access"
    # 1. Warehouse CAN_USE (additive — merges into the existing ACL).
    "${DBX[@]}" warehouses update-permissions "$WAREHOUSE_ID" --json \
      "{\"access_control_list\":[{\"service_principal_name\":\"${app_sp}\",\"permission_level\":\"CAN_USE\"}]}" \
      >/dev/null 2>&1 || warn "Could not set warehouse CAN_USE for $app_sp — grant it in the SQL Warehouse UI."
    # 2. Unity Catalog read grants.
    run_sql "GRANT USE CATALOG ON CATALOG ${TARGET_CATALOG} TO \`${app_sp}\`"
    run_sql "GRANT USE SCHEMA ON SCHEMA ${TARGET_CATALOG}.${TARGET_SCHEMA} TO \`${app_sp}\`"
    # The pipeline-owned tables may not exist yet (the SDP pipeline creates
    # them on its first run), and `--app-only` legitimately runs before that. Use
    # the non-fatal variant so a first deploy is not blocked; the app falls back to
    # live queries until the pipeline has run, and the `job` stage re-grants.
    run_sql_optional "GRANT SELECT ON TABLE ${REC_TABLE} TO \`${app_sp}\`"
    # Without this the Total Spend KPI silently falls back to a live billing query
    # on every page load (and shows nothing if the SP can't read system.billing).
    run_sql_optional "GRANT SELECT ON TABLE ${SPEND_TABLE} TO \`${app_sp}\`"
    # Same rationale for the Genie tab: without this it re-queries billing live.
    run_sql_optional "GRANT SELECT ON TABLE ${GENIE_TABLE} TO \`${app_sp}\`"
    # Same rationale for the Apps tab.
    run_sql_optional "GRANT SELECT ON TABLE ${APPS_TABLE} TO \`${app_sp}\`"
    # Same rationale for the Cost Anomalies tab — and here it matters more: its live
    # fallback needs 35 days of billing and misses the budget on a large account.
    run_sql_optional "GRANT SELECT ON TABLE ${ANOMALY_TABLE} TO \`${app_sp}\`"
    # Without this the run-status strip is stuck on "unavailable": the health
    # service can't read the pipeline event log, so a failed nightly run stays
    # invisible. Optional because the log only exists after the pipeline's first run.
    run_sql_optional "GRANT SELECT ON TABLE ${RUNLOG_TABLE} TO \`${app_sp}\`"
  else
    warn "Could not resolve the app service principal client id — grant it manually:"
    warn "  (SQL Warehouses UI) give the app SP CAN_USE on warehouse ${WAREHOUSE_ID}"
    warn "  GRANT USE CATALOG ON CATALOG ${TARGET_CATALOG} TO \`<app-sp>\`;"
    warn "  GRANT USE SCHEMA ON SCHEMA ${TARGET_CATALOG}.${TARGET_SCHEMA} TO \`<app-sp>\`;"
    warn "  GRANT SELECT ON TABLE ${REC_TABLE} TO \`<app-sp>\`;"
    warn "  GRANT SELECT ON TABLE ${SPEND_TABLE} TO \`<app-sp>\`;"
    warn "  GRANT SELECT ON TABLE ${GENIE_TABLE} TO \`<app-sp>\`;"
  fi

  app_permissions
  feedback_database

  local url
  url=$("${DBX[@]}" apps get "$APP_NAME" --output json | python3 -c 'import json,sys; print(json.load(sys.stdin).get("url",""))' || true)
  say "Done. App URL: ${url:-<check: databricks apps get $APP_NAME>}"
}

# Who may open the app. Recipients of My findings / the StopTheLeak email are mostly
# NOT workspace members, and opening an App needs no workspace membership, so
# `account users` CAN_USE lets them in. Also reduces the workspace `users` group from
# CAN_MANAGE (anyone could redeploy or delete the app) to CAN_USE. Uses the additive
# `update-permissions` (PATCH) only, never `set-permissions`, which would drop every
# other grant on the app.
app_permissions() {
  [[ -n "$APP_USERS" ]] || { echo "   APP_USERS empty — leaving app permissions unchanged"; return 0; }
  say "App permissions: '$APP_USERS' CAN_USE"
  local acl='[{"group_name":"'"$APP_USERS"'","permission_level":"CAN_USE"}]'
  local users_level
  users_level=$("${DBX[@]}" apps get-permissions "$APP_NAME" --output json 2>/dev/null | python3 -c '
import json, sys
acl = json.load(sys.stdin).get("access_control_list", [])
for e in acl:
    if e.get("group_name") == "users":
        print(",".join(p.get("permission_level", "") for p in e.get("all_permissions", []) if not p.get("inherited")))
' || true)
  if [[ "$users_level" == *CAN_MANAGE* && "$APP_USERS" != "users" ]]; then
    echo "   workspace 'users' group has CAN_MANAGE — reducing it to CAN_USE"
    acl='[{"group_name":"'"$APP_USERS"'","permission_level":"CAN_USE"},{"group_name":"users","permission_level":"CAN_USE"}]'
  fi
  "${DBX[@]}" apps update-permissions "$APP_NAME" --json "{\"access_control_list\": $acl}" >/dev/null \
    || { warn "could not update app permissions; set them in the app's Permissions tab"; return 0; }
  users_level=$("${DBX[@]}" apps get-permissions "$APP_NAME" --output json 2>/dev/null | python3 -c '
import json, sys
acl = json.load(sys.stdin).get("access_control_list", [])
print(",".join(p.get("permission_level", "") for e in acl if e.get("group_name") == "users"
               for p in e.get("all_permissions", []) if not p.get("inherited")))
' || true)
  if [[ "$users_level" == *CAN_MANAGE* && "$APP_USERS" != "users" ]]; then
    warn "'users' still has CAN_MANAGE on $APP_NAME (update-permissions does not downgrade it here)."
    warn "Remove it in the app's Permissions tab, keeping '$APP_USERS' CAN_USE."
  fi
}

# Attach StopTheLeak's Lakebase database as an app DATABASE resource, which gives
# the app SP a Postgres role and sets PGHOST/PGUSER/PGDATABASE for it. StopTheLeak
# owns the instance, database and tables (ops.feedback, ops.opt_outs) and grants
# that role USAGE ON SCHEMA ops + SELECT, INSERT on both + DELETE on ops.opt_outs.
# Merges into the app's existing resources (an update replaces the whole list).
feedback_database() {
  [[ "$FEEDBACK_ENABLED" == "yes" ]] || return 0
  if [[ -z "$FEEDBACK_DATABASE_INSTANCE" || -z "$FEEDBACK_DATABASE" ]]; then
    warn "FEEDBACK_ENABLED=yes needs FEEDBACK_DATABASE_INSTANCE and FEEDBACK_DATABASE; skipping the database resource"
    return 0
  fi
  say "Attaching database resource ${FEEDBACK_DATABASE_INSTANCE}/${FEEDBACK_DATABASE}"
  local body
  body=$("${DBX[@]}" apps get "$APP_NAME" --output json | INSTANCE="$FEEDBACK_DATABASE_INSTANCE" DB="$FEEDBACK_DATABASE" python3 -c '
import json, os, sys
res = [r for r in json.load(sys.stdin).get("resources", []) if r.get("name") != "feedback-db"]
res.append({"name": "feedback-db", "description": "StopTheLeak votes + email opt-outs",
            "database": {"instance_name": os.environ["INSTANCE"],
                         "database_name": os.environ["DB"],
                         "permission": "CAN_CONNECT_AND_CREATE"}})
print(json.dumps({"resources": res}))
')
  "${DBX[@]}" apps update "$APP_NAME" --json "$body" >/dev/null \
    && echo "   attached; redeploy picks up the PG* env (deploy.sh --app-only)" \
    || warn "could not attach the database resource; add it in the app's Resources tab (key: feedback-db)"
}

case "$STAGE" in
  all)       preflight; tables; job; app ;;
  --app-only) preflight; app ;;
  --job-only) preflight; job ;;
  --tables-only) preflight; tables ;;
  *) echo "usage: $0 [all|--app-only|--job-only|--tables-only]" >&2; exit 2 ;;
esac
