# Deploying FinOps App in your own workspace

This is the turnkey path: edit **one** config file, run **one** script, and you
get the recommendation tables, the daily precompute job, and the app — all
pointing at *your* workspace, nothing hardcoded to anyone else's.

Time: ~15 min. Everything the script does by hand is listed in
[../docs/DEPLOYMENT.md](../docs/DEPLOYMENT.md) if you'd rather step through it.

---

## Prerequisites

| Need | Why | Check |
|------|-----|-------|
| **Databricks CLI** ≥ 0.220 | deploys the app + bundle, runs the DDL | `databricks -v` |
| **Authenticated** to the target workspace | all API calls | `databricks auth login --host https://<your-host>` |
| **A SQL warehouse** (serverless is fine) | creates tables + serves the app's reads | grab its id from **SQL Warehouses → your warehouse → Connection details** |
| **Unity Catalog + system tables enabled** | the whole product reads `system.*` | you can `SELECT * FROM system.compute.clusters LIMIT 1` |
| **A catalog/schema you can write** | holds the two finops tables | e.g. `main.finops` |
| **`uv`, `node`/`npm`, `python3`** locally | build the wheel + the SPA | `uv --version`, `npm -v` |

**Grants you need in the target workspace:** permission to `CREATE SCHEMA` /
`CREATE TABLE` in the chosen catalog, to create a job + an app, and `SELECT` on
the `system.*` tables (as the deploying user, and later as every app user — see
step 3).

---

## Deploy

```bash
cp deploy/config.env.example deploy/config.env
$EDITOR deploy/config.env        # fill in HOST, WAREHOUSE_ID, TARGET_CATALOG/SCHEMA, ...
./deploy/deploy.sh
```

That single run does, in order:

1. **Preflight** — confirms CLI auth and echoes what it's about to touch.
2. **Tables** — `CREATE SCHEMA` (the `finops_*` tables are materialized by the
   precompute pipeline, not pre-created here).
3. **Job** — builds the wheel, deploys the precompute bundle (scheduled daily at
   05:00 UTC), and runs it once so the table has data immediately.
4. **App** — builds the SPA, renders `app.yaml` for *your* warehouse + table,
   creates the app if it doesn't exist, then syncs + deploys. Prints the URL.

Re-run subsets any time:

```bash
./deploy/deploy.sh --app-only     # rebuilt frontend / changed app.yaml.tmpl
./deploy/deploy.sh --job-only      # changed a rule → redeploy + re-run the job
./deploy/deploy.sh --tables-only   # just (re)create tables / re-apply grants
```

---

## Config reference (`deploy/config.env`)

| Key | What it is |
|-----|-----------|
| `DATABRICKS_PROFILE` | CLI profile for the target workspace (empty = default profile / env) |
| `HOST` | workspace host, no scheme |
| `WAREHOUSE_ID` | bare warehouse id (not the `/sql/1.0/...` path) |
| `TARGET_CATALOG` / `TARGET_SCHEMA` | where the two finops tables live (e.g. `main` / `finops`) |
| `SYSTEM_CATALOG` | where system tables live — almost always `system` |
| `APP_NAME` | Databricks App name (default `finops-app`) |
| `LOOKBACK_DAYS` | analysis window (default 30) |
| `GRANT_TO` | group/user to auto-grant table access, or empty to print the grants |
| `RUN_JOB_NOW` | run the precompute job once at the end (`yes`/`no`) |

---

## 3. Grants — the one thing to get right

The app ships in **precompute + OBO** mode: the app reads the precomputed table
in **one SELECT that runs as the signed-in user**. So *every person who opens the
app* needs, in Unity Catalog:

- `SELECT` on `<catalog>.<schema>.finops_recommendations`
- `SELECT` on the `system.*` tables the rules read (`system.compute`, `system.billing`, `system.lakeflow`, `system.access`)

Set `GRANT_TO` in the config to auto-apply the `finops_*` table grants to a group;
the script prints copy-paste `GRANT` statements for the rest. For a PoC, granting
to `account users` is the quickest way to let colleagues in.

---

## Scaling past a handful of workspaces (OBO → SP)

OBO is simplest and needs no extra identity, but it makes each user's own grants
the access boundary. To run account-wide behind a single **service principal**
(the app reads the table as the SP, and scopes users to workspaces app-side),
switch `FINOPS_AUTH_MODE` to `sp` in `deploy/app.yaml.tmpl` and follow
[../docs/AUTH_AND_SCOPING.md](../docs/AUTH_AND_SCOPING.md). Then the SP — not each
user — needs the grants above.

---

## Verify

```bash
databricks apps get <APP_NAME>                      # status RUNNING, note the URL
# open the URL → the Next Best Actions list should be populated
```

If the app loads but shows **no recommendations**: the job hasn't populated the
table yet (check the job run), or the signed-in user lacks `SELECT` on the table
(step 3). `GET <url>/health` should return `{"status":"healthy"}`.

## Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `Table or view not found` in the job | tables step didn't run — `./deploy/deploy.sh --tables-only` |
| App loads, list is empty | no grant (step 3) or job hasn't run — `./deploy/deploy.sh --job-only` |
| `uv build` proxy timeout | script auto-retries offline; if that fails, run one `uv build --wheel --out-dir precompute/dist` manually once to warm the cache |
| SPA missing / API-docs page instead of the UI | the `backend/finops/static` un-ignore didn't restore — the script uses a trap; check `.gitignore` has the line back |
| Deep links open the wrong workspace | the job couldn't read `system.access.workspaces_latest` — grant `SELECT` on `system.access` and re-run the job |
