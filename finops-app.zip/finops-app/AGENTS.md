# AGENTS.md — how agents & people work on FinOpsApp

Read this before making changes. It exists so many contributors (human or agent)
can extend this app in parallel without stepping on each other.

## The golden rule of extensibility
**A new cost-saving criterion = 3 new files + 1 config block. Never edit a shared list.**
1. `rules/finops_rules/catalog/<rule_id>.py`   — the rule class (`@register`)
2. `rules/finops_rules/sql/<rule_id>.sql.j2`    — its candidate SQL
3. `rules/finops_rules/tests/test_<rule_id>.py` — fixture-based unit test
4. a `<rule_id>:` block in `rules/finops_rules/config/thresholds.yaml`

Rules are discovered by walking the `catalog/` package (`registry.discover()`),
so simply adding the file registers it. There is **no registry list, no
`__all__`, no switch statement** to update → no merge conflicts between rules.

Full walkthrough: [docs/ADDING_A_RULE.md](docs/ADDING_A_RULE.md).
Clone the reference rule: `rules/finops_rules/catalog/autotermination.py` +
`sql/autotermination.sql.j2`.

## Boundaries (what you may edit, and what to leave alone)
- **Adding a rule:** touch only your 3 new files + your `thresholds.yaml` block.
- **The contract** (`rules/finops_rules/contract.py`) and the **recommendation
  schema** (`backend/finops/models/recommendation.py` ↔
  `precompute/ddl/finops_recommendations.sql` ↔ `frontend/src/api/types.ts`) are
  shared interfaces. Change them only deliberately, **additively**, and update
  all three schema mirrors + [docs/DATA_MODEL.md](docs/DATA_MODEL.md) together.
- **Backend layers** (`api/`, `data/`, `identity/`, `services/`) are modular by
  concern; keep new logic in the layer it belongs to.

## Design principles for rules (investigation-guided)
- **SQL finds candidates cheaply; Python decides and prices.** Keep dollar math
  and suppression in `score()` so it is unit-testable and identical in both modes.
- **Return `None` to suppress** anything that doesn't actually apply (e.g. a
  cluster that only *looks* idle but isn't). Don't recommend actions that won't help.
- **Don't judge a resource you've barely seen.** Emit `observed_days` from your SQL
  and call `insufficient_history(row, ctx)` as the FIRST guard in `score()`. A
  resource running for one day looks identical to a chronically wasteful one, and
  every savings figure here is a sample extrapolated to a month — one afternoon
  isn't a sample. Default minimum is 5 days (`min_observation_days`, engine-wide in
  `thresholds.yaml`). See `rules/finops_rules/history.py` and the "Minimum
  observation window" section of [docs/DATA_MODEL.md](docs/DATA_MODEL.md).
- **No `workspace_id` filter in rule SQL** — scoping is injected by the data
  layer. Your outer SELECT must expose `workspace_id`.
- **Attribute real dollars** via `system.billing.usage` × `system.billing.list_prices`
  (see the reference SQL), then `to_monthly(...)`.

## Running the tests
The suite needs `jinja2`, `pyyaml`, `pytest` (see `pyproject.toml [dev]`).
```bash
make test
# or:
PYTHONPATH=rules:backend python -m pytest backend/finops/tests rules/finops_rules/tests -q
```
Rule unit tests must **construct `RuleContext` inline** with a thresholds dict and
use plain-dict fixture rows — they must not read YAML from disk or hit a warehouse.

## Repo contribution workflow (dsa-emea-ce)
- Work on a branch; open a PR; get another DSA to review (repo README convention).
- **Never commit** customer data, credentials, `.env`, or `backend/finops/static/`
  (built artifact).
- **Announce new PRs / features in [#finops-app](https://databricks.enterprise.slack.com/archives/C0BPLDZ2XGB)**
  so everyone stays aware. Keep it super brief — one line on what changed — and
  link to the PR for the detail.

## Where things live
| Area | Path |
|------|------|
| Rule contract | `rules/finops_rules/contract.py` |
| Rule discovery | `rules/finops_rules/registry.py` |
| Reference rule | `rules/finops_rules/catalog/autotermination.py` |
| Live vs precompute switch | `backend/finops/data/factory.py` |
| OBO vs SP + scoping | `backend/finops/identity/`, `backend/finops/data/scoping.py` |
| NBA ranking | `backend/finops/services/nba_ranker.py` |
| Schema contract | `precompute/ddl/finops_recommendations.sql` |
| Precompute backend (SDP) | `precompute/pipeline.py` |
| Contract schema (as code) | `backend/finops/services/contract_schema.py` |
| Legacy job (PAUSED, rollback only) | `precompute/job.py` |
| Product spend breakdown (groups on `billing_origin_product`) | `backend/finops/data/spend_sql.py` |
| Apps inventory (no recommendations — see why in the module docstring) | `backend/finops/data/apps_sql.py` |
| Cost anomalies (analysis only, method in the module docstring) | `backend/finops/data/anomaly_sql.py` |
| Demo (offline) data source | `backend/finops/data/demo_source.py` |
| Frontend design system (light/dark) | `frontend/src/index.css` + `frontend/src/lib/theme.ts` |
| SVG charts (no deps) | `frontend/src/components/charts/` |
| Platform↔Workspace switcher | `frontend/src/components/WorkspaceSwitcher.tsx` |
| finding_key + owner routing (shared with StopTheLeak) | `backend/finops/routing.py`, `backend/finops/data/workspace_owner_sql.py` |
| My findings, votes, email opt-out (API) | `backend/finops/api/my_findings.py` |
| Feedback store (StopTheLeak Lakebase `ops.*`) | `backend/finops/data/feedback_store.py` |

---

# Handoff / current state (read this if you're picking up the app)

## Session (2026-09-29): My findings, stable finding_key, owner routing, votes (GH #123)

**Optional by design.** Only `finding_key` + `?focus=<finding_key>` links are core.
Everything StopTheLeak-specific is behind `FINOPS_STOPTHELEAK_ENABLED` (default
off; `deps.stoptheleak_enabled` / `require_stoptheleak`): off, `/api/my-findings`,
votes and opt-out 404, `get_caller_email` is None (so no recipient access; scope only),
the nav/route are hidden, the pipeline skips the owner-tag lookup
(`workspace_owner_tag` default `""`) and psycopg isn't installed (optional extra
`stoptheleak`; deploy.sh adds it to the upload only with `FEEDBACK_ENABLED=yes`).

For StopTheLeak (separate repo), which emails owners their findings and collects a
vote on each. Where #123 and StopTheLeak `docs/FINOPS_APP_CONTRACT.md` differ, the
contract won (no Slack; the exact `ops.feedback` / `ops.opt_outs` tables; confirm-link
prefill; the email opt-out).

* **Five additive columns** at the end of the contract: `finding_key`,
  `workspace_owner`, `resource_owner_kind`, `notify_recipient`, `recipient_source`.
  Routing: email object owner → workspace owner (billing `Owner` tag) → nobody.
  Defined once in `routing.py`; the pipeline applies `ROUTING_SQL` AFTER the owner
  join (central + central-review too, without a workspace owner). SQLite parity test.
  `finding_key` must keep StopTheLeak's formula.
* **My findings** (`/my-findings`; with the flag on, nav for everyone and users with
  no workspace scope land there). `/api/my-findings` and the recipient path into the resource page use
  `X-Forwarded-Email` ONLY (`deps.get_caller_email`, never the identity fallbacks).
  `test_my_findings.py` has the escalation cases.
* **Votes + opt-out** additionally behind `FINOPS_FEEDBACK_ENABLED` (default off). Store tests
  need a Postgres (`FINOPS_TEST_PG_DSN`), skip otherwise. Verified locally in demo
  mode against Postgres 16 (`FINOPS_DEV_EMAIL=anna.berg@example.com`): prefilled
  confirm link recorded nothing on load, a vote wrote one row, "You said" rendered.
* **Deploy:** `APP_USERS` (e.g. `account users`) → CAN_USE via update-permissions,
  and reduces workspace `users` CAN_MANAGE → CAN_USE (warns if the PATCH doesn't
  downgrade it). `FEEDBACK_*` attaches the Lakebase database resource `feedback-db`.
  `STOPTHELEAK_ENABLED=yes` also sets `WORKSPACE_OWNER_TAG=Owner` → bundle var.

**Not done / open:** not deployed; the Lakebase instance doesn't exist yet, so the
OAuth-token-as-password connection path is untested against real Lakebase.
StopTheLeak's own grants file doesn't yet grant the app role anything on
`ops.opt_outs`. On the beta every user is `platform_admin` (`FINOPS_DEV_ROLE`
default), so everyone still sees everything elsewhere; My findings is per person
regardless. Locally, the header's identity (`/api/me`) and My findings' email can
differ (no forwarded header); deployed both come from `X-Forwarded-Email`.

## Session (2026-09-24): charts, copy and demo data for the promoted rules

**Charts.** Two generic viz kinds, so a rule's picture is a Python builder call:
`daily_stack` (`evidence.viz_daily_stack`, per-day stacked bars + optional marker /
reference line; the SQL emits a sparse `days` array and `densify_days` fills the
closed-open window) and `ranked_bars` (`viz_ranked_bars`). Renderer:
`charts/DailyStack.tsx`. New charts: `warehouse_min_clusters` (needed vs floor-only
cluster-hours), `alert_hygiene` (alert-only warm hours + daily evaluation outcomes as
`viz_extra`), `job_no_new_input` (runs with vs without new input, last-new-input
marker), `job_task_retry_waste` (clean vs retried runs), `unviewed_scheduled_dashboards`
(refreshes vs views, last-viewed marker), `unpruned_repeated_queries` (top shapes, $/mo).
Each template now aggregates **per day first and totals from that**, so the chart costs
no extra scan (tests pin one `minute_class` read / one `access.audit` scan). Executed
live on `fevm-finops-stable-us`: all 7 changed rules reproduce the 2026-09-23 snapshot's
finding counts and dollars exactly, and the per-day arrays sum to the totals.

**Regression fixed:** the Labs chart components lived in `pages/Labs.tsx`, so the three
promoted rules that had charts (`pipeline_failed_updates`, `sql_repeated_failures`,
`instance_pool_idle`) lost them on promotion. They now live in
`charts/LabsCharts.tsx` and `UsageTimeline` dispatches them on the detail page. The
keep-alive heatmap passes `context="keepalive"` (own title + legend, not "warm idle").

**Copy.** `explain.ts` and `action.ts` cases for all 15 promoted/Labs rules. The generic
advisory default ("can't be reliably priced") was wrong for the priced-but-not-a-saving
rules; a vitest case pins that.

**Demo.** The promoted rules used `_DEFAULT_PROFILE` — random savings on ADVISORY
findings, generic copy, no chart. `data/demo_rule_rows.py` now builds a synthetic
candidate row per rule and runs the real `score()`, so demo findings carry production
status/copy/chart (8 rules); the 4 Labs rules got $0-saving profiles. The shared rng
stream is untouched, but new profiles changed `rng.sample` draws, so other demo figures
shifted (synthetic, no test pins them).

**Beta pill.** The 11 promoted rules show a "Beta" pill (with a hover/focus tooltip:
still being validated, figures may change) next to their title on Next Best Actions,
the recommendation table, the resource detail page and the Rule Catalog.
`components/BetaPill.tsx` holds the list; `test_beta_rules.py` pins it to real,
non-experimental rules and to the PROMOTED set. Drop a rule from the list once its
findings have held up.

**Sample-data goldens: 20/20 on FEVM and on local Spark, ~3 min each.** Two engines,
one root cause: each fixture was a temp view over a thousands-row literal `UNION ALL`
the rule SQL references several times, and the engine re-expands it at every reference.
- Warehouse backend (was: one rule 7.5 min, then a dropped connection): with
  `FINOPS_SAMPLE_SCHEMA=finops_stable_us_catalog.finops_sample` each fixture is
  materialized once (empty CTAS + batched `INSERT … VALUES`). See sample_data/README.md.
- Local Spark backend (was: `Java heap space` on `job_no_new_input`, then every later
  rule "connection refused"; a full run took 35 min): each view is re-registered over its
  collected rows (a LocalRelation), PySpark workers are pinned to the driver's
  interpreter (a 3.14 `python3` on PATH vs the 3.13 venv failed with
  PYTHON_VERSION_MISMATCH), and rows come back as `asDict(recursive=True)` — the shape the
  SDP JSON bridge gives `score()`; plain `asDict()` left nested structs as Rows, so every
  rule reading an array<struct> with `.get()` failed.
- **There IS a JDK on the dev Mac** (`/opt/homebrew/opt/openjdk@17`, unlinked; the Spark
  backend finds it). `java -version` failing on PATH does not mean the suite can't run.
- Six new goldens + scenarios (min_clusters, keepalive, retry, no_new_input, dashboards,
  unpruned), every figure hand-checked; scenarios kept small (see README) because the
  shared fixture tables are views on local Spark.
- `idle_serving_endpoints` golden and the zero-traffic value invariant were stale since
  the 2026-09-23 unverified-endpoint change. Golden regenerated (bookable → estimated);
  the invariant's endpoint now has one request 60 days ago, so it tests the VERIFIED
  zero-traffic path (bookable) and the golden the unverified one (estimated).
- Not covered: `alert_hygiene` (needs `alert.*` in the profiler + fixtures). Nothing in CI
  runs these suites (no `.github/workflows`) — issue #114, together with the keep-alive
  rule counting a NULL `statement_type` as a ping (0 of 80,777 untyped statements on
  FEVM did any compute, so it's consistent today).

## Session (2026-09-23d): 11 Labs rules promoted (still advisory) + spend dedup

Reviewed the Labs rules against the live beta snapshot (top findings hand-read, overlaps
with regular rules measured) and **promoted 11 to the main surfaces**:
`warehouse_keepalive_queries`, `alert_hygiene`, `warehouse_min_clusters`,
`unpruned_repeated_queries`, `unviewed_scheduled_dashboards`, `pipeline_failed_updates`,
`job_no_new_input`, `sql_repeated_failures`, `job_task_retry_waste`,
`serving_provisioned_overcapacity`, `instance_pool_idle`. **None is bookable.** Six
now carry their measured counterfactual as an **`estimated` saving** (shown, ranked by
NBA, in the estimate, never in the booked floor): `warehouse_min_clusters`,
`warehouse_keepalive_queries`, `alert_hygiene` (only findings where the alert holds its
warehouse up; hygiene-only ones stay advisory at $0), `serving_provisioned_overcapacity`,
`job_task_retry_waste`, `job_no_new_input` (advisory at $0 when a source is invisible to
lineage). The other five stay **advisory**, because their dollar figure is not what the
bill drops by: `unpruned_repeated_queries` (a fix's effect is unknown),
`unviewed_scheduled_dashboards` (a task-time share — only drops if the warehouse runs
less), `pipeline_failed_updates` / `sql_repeated_failures` (fixing a failure makes the work
succeed, it doesn't remove it), `instance_pool_idle` (unpriceable). All compose
`exclusive`, so a warehouse's pool books its single best option. Live, the estimate
moves $1.62M → $1.81M (+$188k deduped; the raw sum of the six is $481k); the booked
headline is unchanged. The six are list-price only (`contract_pricing="none"`: their
SQL projects no `contract_ratio` yet). `PROMOTED` in
`test_savings_status_classification.py` pins "promoted, never bookable". `instance_pool_idle` now carries an
`evidence.data_warning` ("we can't tell what this pool costs"): the warm floor is certain,
its cloud-VM price isn't in any system table.

**Still in Labs:** `allpurpose_shape_mismatch` + `instance_generation_modernize` contradict
each other on 7 of 9 shared clusters (i3 → m5 vs "m5 is old, use i4i");
`ai_gateway_wasted_inference` (top hits are 429s on Databricks-hosted `system.ai.*`
models — not the customer's to fix); `storage_optimization_churn` (unpriced); and five
rules with zero live findings. **`instance_generation_modernize` now books AND addresses
$0**: public list prices put the like-for-like x86 successor at the same or MORE per hour
(us-east-1 c5d→c6id +5 %, i3→i4i +10 %, m5d→m6id +5 %; only Graviton is cheaper), so the
old-generation spend (now `evidence.old_generation_monthly_usd`) was never the saving —
the saving is a speed-up nothing in system tables predicts.

**Dedup.** Several rules describe one warehouse's spend, so every spend total now counts
each spend POOL once: `aggregation.waste_total` (max `monthly_waste_usd` per
`_scope_key`, summed) replaces per-resource sums in the account / workspace figures and
the Labs headline (which summed every finding). `alert_hygiene` and
`unviewed_scheduled_dashboards` set `affected_spend_scope = "warehouse|<id>"`, because
their dollars ARE their warehouse's compute. Counts stay per resource; Labs adds
`resource_count`. Zero-savings ties in `_collapse_to_resources` (and its TS mirror) now
keep the option with the most spend instead of whichever was read first. Live effect on
the 2026-09-23 snapshot: the promoted rules add 309 findings on 302 resources, but only
206 resources are new to the main list, and only **$143k** of spend once deduped vs
**$646k** if summed (main total $4.05M → $4.19M; the naive sum would be $5.33M).

**Known consequence:** NBA = savings / effort, so the five $0 advisory rules rank last
in the main list (Labs sorted them by addressable spend); the six estimated ones rank on
their saving.

## Session (2026-09-23c): Workstream C — Cost Anomalies tab + six Tier 2 rules (plan §C)

**C1 Cost Anomalies tab** (`/cost-anomalies`) — Genie/Apps pattern, analysis only, no
savings fields (test-enforced). Method + table in docs/DATA_MODEL.md "Cost anomalies".
Live SQL on `fevm-finops-stable-us` (1.5–3 min): by product/SKU 24 step changes ($84k
above baseline), 35 spikes ($35k), 21 new spenders ($37k). Two fixes came from the live
run: an upper-quartile spread term (MAD alone flagged every run of an every-third-day
job) and a same-weekday baseline (weekly jobs). **The live fallback misses the 45 s budget
on a large account** — the tab effectively needs the pipeline snapshot.

**Deployed to `finops-app-beta` (2026-09-23).** The first real pipeline run exposed a
plan blow-up: Spark inlines CTEs, and the anomaly SQL joined its own aggregates back and
filtered name lookups with `IN (SELECT … FROM anomalous)` — **524 scans of
`billing.usage`, a 5.5 MB plan**. The warehouse ground through it (~2 min); the SDP flow
sat in STARTING for 35 min. Rewritten as one linear chain (window aggregates over one
densified set, one GROUP BY per key): 8 scans, same 149 anomalies live (only tie-days
for peak date differed — now broken to the latest day), ~35 s on the warehouse, <2 min
in the pipeline. `test_no_intermediate_step_is_read_more_than_twice` guards it. The tab
now serves from the snapshot in ~5 s. Also fixed: `deploy.sh` died on macOS bash 3.2
(`tf_env[@]: unbound variable`) whenever `DATABRICKS_TF_EXEC_PATH` was preset. Seen
once: after a CANCELLED update, a `refresh_selection` run planned the sink against the
empty temp table the cancelled run left behind (sink had `daily` rows only) — a second
sink-only refresh fixed it.

**Six rules**, all `experimental` + advisory ($0 booked, `monthly_waste_usd` =
addressable, `contract_pricing="none"`), each executed live with pricing flags off and on:

| Rule | Live result | Data facts that shaped it |
|---|---|---|
| `alert_hygiene` | 109 → **97 findings, ~$139k/mo** (mostly alerts holding a warehouse warm) | every evaluation has a `job_id` — an alert's own schedule is a system job with `task_key='evaluate_alert'`, so "job-wired" = `task_key <> 'evaluate_alert'`; erroring alerts still bill; new `resource_type="alert"` |
| `unviewed_scheduled_dashboards` | 30 → **26 findings, ~$36k/mo** | audit key is `request_params['dashboard_id']` (the `dashboardId` fallback never occurs); scheduled refreshes are `executeQuery` with user agent `lakeview-processing_*` — not views; priced per warehouse-hour (query-count share when all cache hits); new `resource_type="dashboard"` |
| `warehouse_min_clusters` | 16 → **9 findings, ~$82k/mo** | cluster-minutes rebuilt from `warehouse_events` reproduce published DBU/h exactly; silent at ≥ 10 % queued so it can never oppose `warehouse_scale_out` (sweep test); plan's Zepz case prices at ≈ $6.8k/mo in a fixture |
| `instance_generation_modernize` | 624 → **45 findings, ~$115k/mo at stake** | mapping in `config/instance_generations.yaml`; `node_timeline.node_type` IS populated (splits cost by core-minutes); job clusters rolled up to job/pipeline; no successor type billed stably here ⇒ no DBU delta, low confidence |
| `job_no_new_input` | 288 → **23 findings, ~$9.7k/mo** | `source_path` is set for normal table reads (path read = `source_type='PATH'`); system and inference tables never show writes in lineage ⇒ suppressed; partial unknown sources carry `evidence.data_warning` |
| `unpruned_repeated_queries` | 286 → **59 findings, ~$115k/mo spent on the shapes** | all statement text is `<REDACTED>` here ⇒ id-based fingerprints only (text path unit-tested); dashboard id pools all datasets, so dashboards are excluded from the never-cached check |

**Before promoting any of these (R4/R3):** overlaps to resolve via `savings_composition` —
alert (c) / dashboards / unpruned vs `warehouse_keepalive_queries` and the auto-stop
rules on the same warehouse; min_clusters vs `warehouse_autostop` on always-on
warehouses; instance generation vs B6 (B6 can suggest i3 → m5d, which C6 calls old);
job_no_new_input vs `unused_data_jobs`. The alert/dashboard deep links
(`sql/alerts-v2/<id>`, `dashboardsv3/<id>/published`) are not verified in a browser. No
Azure/GCP generation mappings are untested. (Demo findings + charts: added 2026-09-24.)

## Session (2026-09-23b): Workstream B — six Tier 1 rules (plan §B), all in Labs

Six new rules, each the golden-rule 3 files + a `thresholds.yaml` block, all
`experimental = True` + advisory ($0 booked, `monthly_waste_usd` = addressable,
`contract_pricing="none"`). The plan said `estimated`, but the enforced Phase-4 test
requires experimental ⇒ advisory; the plan's status (and B6's `cloud_savings="proportional"`)
applies at promotion. Every template executed live on `fevm-finops-stable-us` with
pricing flags off AND on; the existing 29 rules' templates are untouched.

| Rule | Live result (fevm-finops-stable-us) | Data facts that shaped it |
|---|---|---|
| `warehouse_keepalive_queries` | 74 candidates → **58 findings, ~$249k/mo** addressable; top: X-Large wh held warm 297/336 h by dashboard cache hits | `statement_text` mostly `<redacted>` ⇒ classification leans on statement_type + zero task time; `min_mean_run_hours` guard added after the first run flagged post-work cache re-reads |
| `job_runaway_no_timeout` | 40 candidates → **0 findings** at $25 floor | `run_duration_seconds` is 0 everywhere (span of slices instead); long runs mostly WAIT, not compute, so priced on cost above the median run, not duration share; plan's p90/p50 bimodal guard hid real hangs — relaxed when ≥ 50 % of long runs end CANCELLED/ERROR |
| `job_task_retry_waste` | 59 candidates → **5 findings** ($79–$673/mo) | no attempt column: each attempt = own task `run_id` under one `(job_run_id, task_key)`; for_each iterations look identical but have `parent_run_id <> job_run_id`; billing is per JOB run ⇒ apportion by task wall-time |
| `pipeline_full_refresh_churn` | 411 candidates → **0 findings** | `update_type='FULL_REFRESH'` (+ selective via `full_refresh_selection`); Lakebase synced tables (`DATABASE_TABLE_SYNC`) full-refresh by design — excluded |
| `serving_provisioned_overcapacity` | 22 candidates → **1 finding** (~$1.2k/mo) | PT capacity (model units) is NOT in system tables — `min_provisioned_throughput` is NULL on current endpoints — so only the "billed through long no-request stretches" part ships; pay-per-token comparison dropped (per-model token rate not in list_prices) |
| `allpurpose_shape_mismatch` | 109 candidates → **10 findings** (8 memory-family, 2 driver-bound) | `usage_metadata.node_type` mostly NULL ⇒ DBU/hr per node type MEASURED from single-type clusters (reproduces published rates exactly), noisy types filtered by spread |

**Worth a look before promoting any of these (R4):**
- `warehouse_autostop`'s heatmap passes fixed Mon…Sun labels to a 14-day grid that doesn't start on
  Monday, so its rows are mislabelled. The keep-alive rule computes real weekday labels. Pre-existing, left unchanged.
- B6's i3 → m5 suggestion drops local NVMe. The copy says to pick an SSD variant, but the code doesn't prefer one.
- `jpmc-rtm-fraud` (B6's driver-bound top finding) is borderline; `driver_only_share` 0.8 would drop it.
- The keep-alive heatmap reuses `hour_heatmap`, whose legend says "warm idle", not "keep-alive".
- No `savings_composition` handling is set for overlaps. That's safe while the rules book $0, but it needs adding at promotion.
- Demo mode has no synthetic findings for these rules yet.

**Fixed this session: `idle_serving_endpoints` no longer books findings it can't
verify.** `endpoint_usage` only logs endpoints that have usage tracking on, and 35 of
40 zero-traffic candidates had never logged a single request in the ~90 days of
retained history. The SQL now also counts requests over that whole history
(`requests_retained`). Endpoints that have never logged anything become
`zero_unverified`: medium confidence, **estimated** (out of the booked headline), and a
new generic `evidence.data_warning` that the UI shows as a callout above the action,
plus an "Unverified" tag on list rows. Plan §B7 has the open follow-up: read the AI
Gateway `usage_tracking_config` through the API.

## Session (2026-09-23): Workstream A — contract rates + cloud VM cost (plan §A)

Implements §A of [docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md](docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md);
details in the "Contract rates + cloud VM cost" section of docs/DATA_MODEL.md.
`finops_rules/price_basis.py` probes `billing.account_prices` / `cloud_infra_cost` once
per run; with both absent (every reachable account today) **every rule renders
byte-identically** to before — verified by rendering all 29 rules × nested/central
against a HEAD baseline. With flags on, every changed template was **executed live** on
`fevm-finops-stable-us` (tables exist but are empty ⇒ ratios NULL, row counts sane).
Rules keep list math; the engine scales by a per-resource `contract_ratio` (ratio rules),
`interactive_to_job` prices both SKUs (counterpart), $0 rules opt out. UI: top-bar
`List price | Your rates` switch (only when contract data exists), blended totals with a
coverage chip + the other basis one line below, `list` marker on fallback rows, dual
price on detail, separate Cloud VM KPI. Demo: `FINOPS_DEMO_PRICING=list|contract|contract_partial`,
`FINOPS_DEMO_CLOUD=1` (note: the local `.env` is a central preview — pass
`FINOPS_CENTRAL_MODE=false` for demo).

**Not done / known gaps:** no real contract data anywhere (R1) — contract semantics
(`pricing.default`) are from schema only; `enable_serverless` has no contract figure
(prices from configured tier rates, needs a serverless-SKU `account_prices` lookup) and
its point estimate already folds in an ESTIMATED VM, so its separate measured Cloud VM
line overlaps that estimate; server-side sort-by-savings stays on list; live-mode spend
is list-only; About Serverless TCO (A6.7) not built; `instance_pool_idle` books $0 so it
gets no cloud figure. Pre-existing: 2 `test_sdp_parity` failures (also fail at main).

## Session (2026-08-06c): spend breakdown fixed + Apps tab (no recommendations)

**The spend breakdown was hiding the account's largest line item.** `_SKU_GROUP_SQL`
bucketed on `sku_name` substrings, but **Databricks Apps bill under
`PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_<REGION>`** — a SKU whose name says nothing
about apps. So apps (plus Vector Search, Lakebase, Model Serving variants) fell into a
catch-all `'Serverless (other)'` bucket that was **$272k/30d, 39% of total spend, with
no label**. A breakdown whose biggest row is "other" explains nothing. It now groups on
`billing_origin_product` — the authoritative product dimension — and `sku_name` is used
only for the serverless/classic distinction *within* a product (which is the only place
that lives) and for the `serverless_spend_usd`/`classic_spend_usd` split, which is
about compute type, not product. An unknown future product falls back to
`initcap(billing_origin_product)` so it appears as itself rather than vanishing.

**New Apps tab (`/apps`) — inventory, deliberately with NO recommendations.** New files
only (`data/apps_sql.py`, `data/apps_source.py`, `models/apps.py`, `api/apps.py`,
`pages/Apps.tsx`, `charts/AppsTrend.tsx`, `ddl/finops_apps_usage.sql`) plus additive
wiring. Shows what apps run, what they cost, their `compute_size`, and lifecycle
(last deploy / by whom). Paginated, filterable by size, with the per-workspace
drill-in (`/api/apps/{workspace_id}`) via `Scope.narrowed_to`.

**Why no recommendations, and please don't "fix" this:** `system.access.audit`
`service_name='apps'` has **lifecycle actions only** — no request or page-view log
exists for apps anywhere in system tables (re-verified live). So "is anyone using this
app?" is unanswerable and an idle/rightsize finding would be a guess with a dollar
figure on it. The tab states that in `analysis_note`, rendered in a panel, so the
absence reads as a boundary rather than an unfinished feature. `AppInfo`/`AppsInventory`
carry no `monthly_savings_usd`/`priority`/`nba_score`/`effort_*` field and a test
asserts their absence. When a usage log ships, `apps_inventory_sql` already computes
`days_billed`/`compute_size`/`last_deploy_time` — add the traffic join and gate on it
the way `idle_serving_endpoints` gates on `entity_matched`.

**Three data details worth knowing:**
1. **`days_billed` is a lifecycle signal, not idleness.** Apps have no scale-to-zero,
   so a running app bills every day — 551 of 1,065 did. The UI labels a full-window
   count "always on" as a neutral fact.
2. **The audit log uses two different parameter keys.** `deployApp` carries
   `request_params.app_name`; `startApp`/`stopApp` carry `request_params['name']`.
   Reading only `app_name` (the obvious guess) returns nothing for start/stop. The
   join is on NAME because `request_params.app_id` is populated zero times, and it is
   a LEFT join because most apps have no lifecycle event in a window (146 of 1,239).
3. **`date_sub` is inclusive at both ends**, so the naive filter spans N+1 dates and an
   always-on app reported `days_billed = 31` for a 30-day window. The apps SQL also
   excludes today (partial), so "billed 30 of the last 30 days" is literally true.

**Also refactored:** the Genie and Apps sinks were near-identical, so the shared
`(kind, workspace_id, payload)` table shape now lives in
`pipeline.py::_build_kinded_sink`. The SDP text-based tests previously sliced
`pipeline.py` to end-of-file, which would have let an assertion about "the Genie sink"
pass on Apps-sink text; `_sink_src` is now bounded to one function.

**Verified live**: pipeline update `8eb502f0` COMPLETED; `finops_apps_usage` has
1,234 inventory + 304 size + 6,385 daily rows; the spend snapshot now reports
"Databricks Apps $272,336" as its top group. 336 tests pass; `tsc -b` + `vite build`
clean.

## Session (2026-08-06b): leaderboard pagination + Genie per-workspace scope

**Workspace leaderboard is paginated** (`AccountOverview.tsx`) using the existing
`Pager`, same pattern as the recommendation list. It was rendering all 434 rows.
Note the rank badge is the position in the *whole* leaderboard, not on the page.

**Genie now scopes per workspace.** It already respected a workspace admin's scope
(`/api/genie` derives `Scope` server-side and the snapshot filters on the real
`workspace_id` column), but a platform admin had no way to drill in. Added
`GET /api/genie/{workspace_id}` + route `/workspaces/:workspaceId/genie-costs`,
mirroring `GET /api/spend/{workspace_id}`. All four aggregates already group by
`workspace_id`, so it's the same rollup over a narrower scope — no second code path.
The nav link and the workspace switcher now preserve scope instead of bouncing you
back to the platform view (`SCOPED_PAGES` in `WorkspaceSwitcher.tsx` is the list to
extend when another page gains a per-workspace form).

Client-supplied ids go through **`Scope.narrowed_to`**, which can only ever REMOVE
access: a workspace admin naming a workspace they don't own gets an empty scope
(short-circuited before any query), and a non-numeric id raises `ScopeError` → 400
rather than the 500 it produced at first. That method is the security boundary —
`test_genie.py` has the escalation cases; read them before changing it.

**Found and fixed a live bug while verifying:** the Genie snapshot read selected only
`(kind, payload)`, but the pipeline deliberately lifts `workspace_id` OUT of the
payload into its own column. So in precompute mode **every workspace attribution was
lost** — the tab said "across **0** workspaces" and no space or user had a workspace
name, while every dollar figure was individually correct. `workspace_count` went
0 → 263 after the fix. **The test fixture had encoded the same wrong assumption**
(`_SNAPSHOT_COLUMNS = ["kind", "payload"]`), which is why 289 tests passed over a
broken read path; the fixture now mirrors the real column layout.

**Verified live**: platform view 263 workspaces / $1,962.72; drill-ins return
`workspace_count: 1` with correctly narrowed spend ($61.86 and $202.91); unknown
workspace → honest zero; `1;DROP` and `abc` → 400. 294 tests pass, `tsc -b` clean.

## Session (2026-08-06): SDP is now THE precompute backend

The migration the previous session called "the obvious follow-up" is done. **The SDP
pipeline (`precompute/pipeline.py`) is the single precompute backend** and writes all
three output tables: `finops_recommendations`, `finops_workspace_spend` (ported this
session) and `finops_genie_usage`. `job.py` is PAUSED and kept for one release as a
rollback path only.

**The pipeline had never actually run before this session.** It was deployed as a
bundle resource, but `state: IDLE`, `latest_updates: None`, and
`finops_genie_usage` did not exist in the schema — so every table in use was written
by `job.py`, and the Genie tab was silently running on its live-query fallback. Three
bugs were found by *running it*, not by reading it:

1. **It failed at import on any workspace.** `pipeline.py` read the contract schema
   off `finops_recommendations_golden` — a table nothing in the repo creates —
   raising `TABLE_OR_VIEW_NOT_FOUND` before declaring a single table. Borrowing the
   shape of the thing you are about to define is also circular under SDP. The schema
   is now code: `backend/finops/services/contract_schema.py`, pinned against the DDL
   *and* the pydantic model by `precompute/tests/test_contract_schema.py`.
2. **`deploy.sh` pre-created the pipeline's own tables**, so materialization failed
   with *"a MANAGED table already exists with that name"*. `tables()` now creates
   **only the schema** — every `finops_*` table is a pipeline output; their DDL
   files are retained as the documented contract + test fixture.
3. **`@dlt.table` creates a MATERIALIZED VIEW, not a Delta table.** Two live
   consequences: day-over-day snapshot history is gone (an MV is recomputed per
   update, so it holds only the current `snapshot_date`), and the legacy writer's
   `replaceWhere` now fails with `DELTA_NOT_A_DELTA_TABLE`. That second one is why
   `job.py` **must stay paused** — left on its 05:00 schedule it would fail every
   morning. The daily schedule moved to a new one-task trigger job
   (`finops_precompute_sdp_daily`); a pipeline has no `schedule:` block of its own.

**The JSON bridge is the real fidelity risk, and `test_sdp_parity.py` does not cover
it.** To union heterogeneous candidate schemas the pipeline does
`to_json(struct(*))` → `json.loads` inside the UDF; the parity suite injects plain
dicts and skips that seam entirely. Two Spark defaults are actively wrong here and
are now pinned in `_JSON_OPTIONS`: `ignoreNullFields` defaults to **true** (drops
null columns, and the history guard distinguishes null from absent), and the default
timestamp format is not what `_days_since` parses (a job would read as never-run,
999 days stale). `precompute/tests/test_json_bridge.py` covers this.

**Verified live** against `fe-vm-classic-stable-ij3nfe`: pipeline update
`fe9816f6` COMPLETED; 599 recommendations across 13 rules, 434 spend rows, 3,080
Genie rows (all four `kind`s); the scheduled trigger job run end-to-end SUCCESS; app
`ACTIVE` at https://finops-app-7405606814849660.0.azure.databricksapps.com. Row count
and rule count match the legacy job's run from the same morning (599 / 13).

**Not verified, and worth knowing:** there is **no live golden diff** between the two
backends. The old snapshots were dropped without a backup (deliberate call), and a
later attempt to populate a golden table failed because `bundle run --var` does not
override the task parameter baked in at deploy time — the job wrote to
`finops_recommendations` and hit `DELTA_NOT_A_DELTA_TABLE` against the new MV. Total
savings differed by **$20** (~0.05%) between the job's morning run and the SDP run,
which is consistent with the ~7 minutes of extra billing data between them but is
**not proven** to be that. To close it properly: run both backends against a pinned
`snapshot_date` into two real Delta tables and use `golden_diff.py`.

## Session (2026-08-05): Genie Costs tab (analysis-only, SDP-backed)

New **Genie Costs** tab (`/genie-costs`) answering platform-level questions about
AI/BI Genie spend: highest spenders, free-tier share, surface mix, per-space cost,
adoption trend. **Deliberately outside the recommendation flow** — no finding, no
savings figure, no NBA score, contributes to no other total. New files only
(`data/genie_sql.py`, `data/genie_source.py`, `api/genie.py`, `models/genie.py`,
`pages/GenieCosts.tsx`, `charts/GenieTrend.tsx`, `ddl/finops_genie_usage.sql`) plus
additive wiring. Full rationale in [docs/DATA_MODEL.md](docs/DATA_MODEL.md).

**Written by the SDP pipeline, not `job.py`.** `pipeline.py::_build_genie` is a
sibling sink of `finops_recommendations`.

> **Superseded by the 2026-08-06 session above.** The asymmetry described here
> (`job.py` wrote the spend snapshot, `pipeline.py` did not) is resolved — the spend
> step is ported (`pipeline.py::_build_spend`) and the pipeline writes all three
> tables. Also note: as written this session, the Genie sink had **never actually
> run**, so the tab was served by its live-query fallback, not by this snapshot.

**Three facts about Genie billing that shaped everything** (verified live; the
first two are easy to get silently wrong):
1. The free tier is a **separate zero-priced SKU** (`GENIE_FREE_USAGE`, absent from
   `list_prices`), so "still free" is read from billing, not thresholded.
2. **Paid Genie bills as `PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_<REGION>`** —
   `sku_name LIKE '%GENIE%'` returns free usage ONLY and makes paid spend look like
   $0. Filter on `billing_origin_product = 'GENIE'`.
3. `agent_id` exists for `GENIE_AGENTS` only → per-space cost covers Spaces only.

**Budgets cannot be shown.** `budget_policy_id` is NULL on every Genie row and
account budget policies aren't readable from a workspace-scoped app. The tab says
so explicitly rather than rendering an empty panel.

**Four bugs that only live execution / a real browser caught** — worth reading
before touching any fan-out source:
1. **`with ThreadPoolExecutor` defeats a time budget.** Exiting the context manager
   joins every worker, so a straggler held the response open: a 45s budget became a
   **>5 min** request. Needs `shutdown(wait=False, cancel_futures=True)` — which is
   why `fleet_source` does exactly that.
2. **A budget below the 40s `_socket_timeout` is worse than none.** Queries run
   concurrently so the socket timeout already bounds each; 25s (copied from
   `fleet_source`) dropped all four aggregates and reported `unavailable` for an
   account full of Genie usage. Now 45s.
3. **Rounding before classifying broke the headline stat.** `paid_dbus` is rounded
   to 2dp but real Genie records are as small as **0.009 DBU**, so a paying user
   rounded to `0.0` and counted as free-tier. `free_only` is now decided on the
   unrounded value (caught by a unit test, not by inspection).
4. **The live window was truncated but reported as 30 days.** Every figure is
   window-dependent and the monthly figure divides by it. `lookback_days` now
   reports the window actually queried, and `missing_sections` explains any
   aggregate that missed the budget instead of implying "no usage".

**Verified**: 231 backend + 16 SDP + 8 benchmark tests pass; `tsc -b` + `vite build`
clean; page screenshot-checked in **light and dark** in demo mode; and run **live**
against `fe-vm-classic-stable-ij3nfe` — $551 over 7 days (→ $2,362/mo), 79% of 215
users free-tier, 25 spaces, all four aggregates inside budget. Demo data is now
generated from **one synthetic event stream** so the four aggregates reconcile; the
first version built each independently and the KPI contradicted the chart beside it.

**Deploy needs the new table**: `deploy/deploy.sh` creates + grants
`finops_genie_usage` and sets `FINOPS_GENIE_TABLE`. The app falls back to live
queries until the pipeline has run once, so it works before the first run.

## Session (2026-08-04): usability-aware auto-stop, total spend, About Serverless
A feedback round from the app owner. Seven changes, all in this branch:

1. **Serverless auto-stop no longer recommends 1 minute** (`warehouse_autostop_serverless`
   v2.0.0). The old rule proposed the 1-min API floor, which maximizes modelled
   savings and wrecks usability. It now *analyses each warehouse's own inter-query
   gap distribution* and picks the shortest value in **5–10 min** (5 = the
   Databricks **UI** floor for serverless; 1 min is API-only) that adds no more than
   `max_extra_stops_per_day` (3) restarts. If nothing in that window both shortens
   and stays comfortable, it returns `None` rather than nagging. New SQL emits a
   `gap_hist_*` histogram; `savings.choose_serverless_autostop` decides;
   `serverless_autostop_savings_at` prices the NET reclaim (restart cost deducted).
   New viz `autostop_tradeoff` shows all three panels (gap histogram, per-candidate
   reclaim vs restarts/day with the rejected values greyed out, hourly rhythm) so
   the number is auditable. **Beware** when editing: a candidate only causes an
   extra restart for gaps `proposed < gap <= current` — gaps at exactly the bucket
   bound are NOT restarted, which is why the chooser can pick 7 for a warehouse with
   a wall of 7-minute gaps. Two of my own tests initially asserted the opposite.
2. **Cluster detail leads with what the cluster IS** — `cluster_source` →
   `cluster_kind_label()` ("Job cluster" vs "All-purpose cluster (UI/API)"), in the
   `why` copy and the facts strip. All three cluster SQL templates now also emit
   **memory, swap, CPU I/O-wait and network** hourly series → new viz
   `cluster_resources`, attached via the new additive `viz_extra` list so a finding
   can carry several charts. NOTE: `node_timeline` has **no disk read/write rate**
   (only free space per mount point), so I/O wait stands in for storage pressure —
   don't add a "disk throughput" line, the data isn't there.
3. **"Wasteful spend" is gone from the GUI**; **Total Spend** replaces it. New
   sibling table `finops_workspace_spend` + `data/spend_source.py` (snapshot → live
   fallback → honest `unavailable`) + `/api/spend`. See docs/DATA_MODEL.md. The
   precompute job writes it in a non-fatal step, so a spend failure never loses the
   recommendations. **Deploy needs the new table** (`deploy/deploy.sh tables`
   creates it and grants SELECT).
4. **Recommendations are paged** (25/50, `components/Pager.tsx`). The `waste` sort
   option is gone with the KPI.
5. **`unused_scheduled_jobs` + `enable_photon_dbr` hidden from the GUI** and from
   every total, via `Settings.hidden_rules` filtered in `RecommendationSource.fetch`.
   Still computed + stored. `load()` bypasses the filter — About Serverless uses it.
6. **New "About Serverless" tab** (`/about-serverless`, `services/serverless_case.py`).
   Framed as *classes of operational work serverless deletes* (sizing, idle-timeout
   tuning, wrong compute class, runtime upkeep, spot handling, reliability), each
   backed by this account's measured findings, plus fleet facts from the new
   `data/fleet_source.py` (DBR version spread, `waiting_for_compute_ms` start-up
   latency, autoscaling churn — each degrades independently if a schema is
   ungranted). Headline savings are **de-duplicated per resource** across issues.
7. **Resource detail shows ALL applicable recommendations**, savings-descending,
   biggest expanded. Group options are now sorted by savings (not NBA); the group's
   `nba_score` is the max across options so overview ranking is unchanged.
   `/recommendations/:id` now redirects to `/resources/:group_id?focus=<rec_id>`, and
   `Recommendation.group_id` is a computed pydantic field so the UI doesn't re-hash.

**Verified**: 148 tests pass (`make test`); frontend `tsc -b` + `vite build` clean;
all pages screenshot-checked in demo mode via headless Chrome. One real bug was
caught that way — the demo source fabricated an auto-stop finding with an empty
`candidates` list, blanking the middle chart panel; it now redraws a genuinely
recommendable pattern instead of faking the analysis.

**Live-validated** on `fe-vm-classic-stable-ij3nfe` (Azure). NOTE: the old
warehouse `abb840dba1d634bc` from the previous handoff **no longer exists** — the
workspace appears to have been rebuilt. Use `3d9e03ad29981508` ("Serverless Starter
Warehouse"); it auto-starts on query. All four changed rule SQL templates plus
`spend_sql.py` and the three `fleet_source.py` queries execute and return sane data
(67 / 29 / 4 / 41 candidate rows; 428 workspaces of spend; 45 DBR versions).

**Three column-name bugs that only live execution could catch** — worth knowing,
because unit tests on dict fixtures cannot see them:
1. `system.compute.clusters` has **no `node_type_id`**. The real columns are
   `worker_node_type` / `driver_node_type`; we select `worker_node_type AS
   node_type_id` so the Python/TS side is unchanged.
2. `system.query.history` has **no `waiting_for_compute_ms`** — it is
   `waiting_for_compute_duration_ms`. This typo was also in two PRE-EXISTING
   `data_basis` strings (`enable_serverless`, demo source), which are shown verbatim
   in the UI; fixed those too.
3. `node_timeline` metric columns all verified present and correctly named:
   `cpu_wait_percent`, `mem_used_percent`, `mem_swap_percent`,
   `network_sent_bytes`, `network_received_bytes`. Confirmed there is **no** disk
   read/write rate (only `disk_free_bytes_per_mount_point`), so don't try to add a
   disk-throughput line — I/O wait is the honest proxy.

**The high-churn tier came out of that live run.** `dbx-analyzer-warehouse`
($6.1k/mo) has ~723 idle gaps in the 30-60 min band — an hourly poller. The 3
restarts/day guard suppressed it silently, hiding ~$5.4k/mo, the single biggest
serverless auto-stop opportunity in the workspace. So `choose_serverless_autostop`
now has a second tier: above `max_extra_stops_per_day` (3) but within
`churny_stops_per_day` (30) it still recommends, with `high_churn=True`, and the
rule downgrades to LOW effort / MEDIUM priority / medium confidence, states the
restart cost in `why`, tells the user to check Query History first in `how`, and the
chart draws the chosen bar amber with a warning banner. Beyond 30/day it still
suppresses. Live re-run: 5 warehouses, total addressable $5.3k → $10.7k/mo.

### Deployed 2026-08-04 (this session's work is LIVE)
| | |
|---|---|
| Workspace / profile | `classic-stable-ij3nfe` / `fe-vm-classic-stable-ij3nfe` |
| App URL | https://finops-app-7405606814849660.0.azure.databricksapps.com |
| Warehouse | `3d9e03ad29981508` (the old `abb840dba1d634bc` is gone) |
| Tables | `classic_stable_ij3nfe.finops.{finops_recommendations, finops_workspace_spend}` |
| App SP | `2cf1b234-6a2f-4bc7-a872-ffc9a4b0a6ec` — SELECT on both tables |
| Snapshot | `2026-08-04`: **689 recommendations + 428 workspace-spend rows** |

Deploy path used: `./deploy/deploy.sh --tables-only`, then wheel rebuild + `bundle
deploy`/`run` from `precompute/`, then `./deploy/deploy.sh --app-only`. The script
now also creates/grants the spend table and sets `FINOPS_SPEND_TABLE` in `app.yaml`.

**Two more bugs found only by deploying** (unit tests and single-query validation
both passed first):
1. **Spend write failed silently.** `usage_quantity` is DECIMAL in `billing.usage`,
   so `SUM()` produced a Decimal that Arrow refused to write into the table's DOUBLE
   `total_dbus` column. The job logged `spend table ... unwritable ...; skipping` and
   carried on (the non-fatal design worked as intended, but the table stayed empty).
   Fixed by `CAST(u.usage_quantity AS DOUBLE)` once in the `priced` CTE of
   `spend_sql.py`, so every downstream SUM is a double. **If you add a column to
   that table, check its type against the DDL** — this failure mode is quiet.
2. **About Serverless hung forever** on "Analysing your estate…". The three
   `fleet_source` queries are ~10s each on a real account and ran SERIALLY, which
   with the recommendation + spend reads exceeded the connector's 40s
   `_socket_timeout`. Now they run concurrently under a 25s `_FLEET_BUDGET_S`; a
   query that misses the budget drops its card instead of blocking the page
   (`test_fleet_source.py` covers concurrency, the budget, and per-metric failure).

Verified live in-browser after deploy: Total Spend $698,311/mo, 94% already
serverless, pagination over 160 resources, all three upkeep cards populated, and
`dbx-analyzer-warehouse` showing the 5-min recommendation with the amber high-churn
banner (~25 restarts/day) rather than the old 1-minute advice.

## Session (2026-07-14): honest cluster idle — gap-based savings + real-time chart
Feedback: an auto-termination rec showed ~4h idle on the graph but "24,676 of
35,209 windows idle" in text. Investigation (see this cluster: ran 186h/9 days,
70% of node-minutes idle, a 33h continuous low-CPU run that the 120-min
auto-termination never terminated):
- **Off-time was NOT counted** (node_timeline only logs running minutes) — the
  user's guess was wrong, but the numbers were genuinely inconsistent.
- **Graph** classified an hour active if its *peak* ≥ 10% → a bursty cluster
  looked ~all-active. **Fixed**: `cluster_daily_evidence` now splits each day's
  bar by REAL idle time (`sum(idle_frac)`), so amber = actual idle hours.
- **"N of M windows"** were node-minutes (× node count). Copy now uses wall-clock
  hours (running/idle/reclaimable).
- **Savings re-baselined, gap-based**: auto-termination reclaims only CONTIGUOUS
  idle gaps longer than the timeout, not scattered idle between bursts. New SQL
  CTEs in `autotermination.sql.j2` sessionize per-cluster-minute idle →
  `reclaimable_gross_min`, `num_reclaim_gaps`, `running_minutes`, `idle_minutes`,
  `longest_idle_gap_min`; priced by `savings.cluster_autoterm_savings` (nets a
  restart penalty + residual margin). Validated against the warehouse: matches
  ground truth exactly (idle 8245, reclaimable 7315, 10 gaps, running 11162).
- **Confidence dropped HIGH→MEDIUM** for both cluster idle rules, with a caveat:
  CPU idle is a proxy for the command/session activity auto-termination actually
  keys on, and **that signal is not in system tables for interactive clusters**
  (query.history = DBSQL only; verified 0 rows for this cluster). Job activity IS
  used where present (`job_run_timeline.compute_ids`).
- idle_zombie kept its idle-fraction savings (fine for a true zombie) but now
  medium-confidence + same caveat + the real-time chart.
- KNOWN GAP: idle_zombie SQL doesn't have the gap CTEs (only autotermination
  does); job-run minute-level idle exclusion is coarse (metric only). Fine for now.

## Session (2026-07-14): cluster activity chart over the real 30-day window
Feedback: the cluster idle/zombie chart looked "always idle", was labelled 30
days but only showed ~24h of data, and hid real work. Root cause: it plotted the
sparse hourly-average CPU line (only the hours a cluster ran, ≤ a day for an
abandoned cluster) and hourly averaging crushed real bursts (one cluster peaked
88% but showed ~6%).
- New viz kind **`cluster_daily`** (evidence.py `cluster_daily_evidence` /
  `viz_cluster_daily`; renderer `UsageTimeline.ClusterDaily`): one stacked bar
  per day across the FULL lookback — active hours (that hour's PEAK CPU ≥
  idle_threshold) vs idle hours — with a dashed "last active" marker and a
  "peak N% CPU when used" caption. Honestly shows mostly-off + idle-when-on +
  real bursts.
- Applied to **idle_zombie_clusters** + **cluster_autotermination**.
  **rightsize_underutilized** keeps `cpu_area` (headroom is a different question).
- SQL: all 3 cluster `cpu_series` CTEs now also emit per-hour `cpu_peak`
  (`MAX(cpu)/100`). `cluster_activity_stats()` powers honest copy: "ran on N of
  30 days, last ran X days ago, peaked at Y% when used" — so the `why` no longer
  implies always-idle.
- Verified both archetypes (abandoned / frequent) with headless-Chrome
  screenshots in demo mode before deploy.
- OPEN CORRECTNESS QUESTION (flagged, not yet fixed): idle_zombie projects the
  idle share of `cost_30d` as ongoing monthly savings, but a cluster that ran 2
  days and has been OFF ~19 days has no ongoing spend to save — the projection
  overstates. Consider gating savings/confidence on recency (days_since_active).

## Session (2026-07-13): dismiss / hide findings — REMOVED
This feature (dismiss/hide a finding, shared across users, with a `finops_dismissals`
table, store, resurface logic, dismiss/restore API, and a Dismissed nav page) was
later deleted on branch `finops-app/remove-dismissals`. No dismiss endpoints, table,
store, model, or UI remain.

## Session (2026-07-13): correct cross-workspace deep links (PR #24, merged)
The "Open in Databricks" link was built from the app's OWN host for every rec.
The account spans ~3,500 workspaces, each on its own host — so the link was wrong
for any resource outside the app's workspace (and `?o=<workspace_id>` does not fix
a wrong host). Fix: a `workspace_url` column now travels on each recommendation,
sourced from `system.access.workspaces_latest` (`workspace_id → workspace_name,
workspace_url`); the UI links to that host.
- Contract: `workspace_url` added to the `Recommendation` model, precompute DDL,
  `precompute_source._COLUMNS`, and `api/types.ts`. Precompute self-heals the
  existing table via `_ensure_columns()` (idempotent `ALTER TABLE ADD COLUMN`).
- Precompute + live sources load a `workspace_id → (name, url)` map once (from
  `{system}.access.workspaces_latest`) and pass it through `build_recommendation`.
  This also finally populates `workspace_name` (was null in precompute).
- Frontend `resourceUrl()` links to `rec.workspace_url`; legacy fallback to app
  host + `?o=` only when the field is absent.
- Deployed + re-run: snapshot `2026-07-13`, 784 recs, 495 carry a resolved host
  across 87 workspaces. The unresolved ~290 are workspace_ids not in
  `workspaces_latest` (deleted/decommissioned but still in billing) — expected.
- NOTE: `workspaces_latest` needs the `system.access` schema enabled + SELECT for
  the reader (job SP has it). Not every billing workspace_id is present.

## Latest session (2026-07-10): "show the data" + accurate savings + real deploy
Branch `finops_app`, 4 commits on top of the initial app:
1. **"Show the data" charts** — each recommendation carries a chart of its usage
   pattern. `evidence` (a free-form JSON blob → no schema migration) now holds
   three additive keys: `confidence` (high/medium/low, by *what data* backed it),
   `data_basis` (which system tables + where we rounded down — shown verbatim),
   and `viz` (a compact chart payload). Builders in
   `rules/finops_rules/evidence.py`; TS types in `api/types.ts`; rendered by
   `frontend/src/components/charts/UsageTimeline.tsx` on the detail page. Three
   kinds: `hour_heatmap` (warehouse auto-stop — day×hour warm/idle/stopped),
   `burst_compare` (serverless — classic warm-pool vs scale-to-zero), `cpu_area`
   (cluster right-size — CPU vs paid-for headroom).
2. **Data-driven savings + validation** — `rules/finops_rules/savings.py` replaces
   the old flat fractions (`0.15`, `0.20`) with math computed from the real usage
   series. `benchmark/` is a local harness: a minute-level state-machine simulator
   gives *independent* ground truth; tests assert the estimate is **conservative
   first** (never over-estimates, on every workload shape) and accurate second.
   Run: `PYTHONPATH=rules python -m pytest benchmark -q`.
3. **Accuracy ~50%→~95%** — auto-stop savings now reconstruct the true idle gaps
   from `system.query.history` (per-query timestamps) instead of hourly buckets,
   and net out cold-start restarts explicitly. The rule prefers the gap path when
   SQL supplies `reclaimable_minutes`/`warm_minutes`, else falls back to the
   hourly rollup. Accuracy is bounded by *data resolution*, not cleverness.
4. **Precompute made deployable** — the batch bundle had never actually run; see
   the recipe + gotchas below.

Only the two **warehouse** rules (`warehouse_autostop`, `enable_serverless`) emit
`viz` + gap-based savings in live/precompute. Cluster rules emit `cpu_area` in
**demo only** — wiring the live cluster rules (read `node_timeline`) is a
follow-up. All 63 unit+benchmark tests pass (`make test`).

## What the frontend is now
A polished React (Vite + TS) dashboard with a **light/dark theme toggle**
(`data-theme` on `<html>`, persisted in localStorage), **dependency-free SVG
charts** (donut / bar-list / stacked mix), richer KPI cards, tables with inline
savings bars, and a top-bar **Platform ↔ Workspace switcher**. All colors are CSS
custom properties in `index.css` so both themes stay in lockstep. Charts live in
`frontend/src/components/charts/` and read rollups from `frontend/src/lib/breakdown.ts`.

## Three compute modes (not two)
`FINOPS_COMPUTE_MODE` = `live` | `precompute` | **`demo`**.
- **`demo`** (`backend/finops/data/demo_source.py`) — deterministic, realistic
  sample data with **no warehouse/auth needed**. Use it for offline UI work and
  self-contained demos: `FINOPS_COMPUTE_MODE=demo FINOPS_AUTH_MODE=obo`. It
  synthesizes findings through the real `build_recommendation` path, so NBA
  scores/effort/ids match production.
- `live` — runs rules on a warehouse per request (slow on large accounts).
- `precompute` — reads the latest snapshot from the Delta table (fast). **This is
  what the deployed app uses.**

## Local dev, build & run
```bash
# offline UI dev (no Databricks needed):
printf 'FINOPS_COMPUTE_MODE=demo\nFINOPS_AUTH_MODE=obo\n' > .env
make install                     # backend venv (.venv)
make install-frontend            # npm (see registry note below)
make build                       # tsc -b && vite build -> backend/finops/static/
PYTHONPATH=rules:backend .venv/bin/python -m uvicorn finops.main:app --port 8000
# open http://localhost:8000
```
**npm registry note:** public `registry.npmjs.org` is blocked on the corporate
network (503). `frontend/.npmrc` points npm at Databricks' internal proxy
`https://npm-proxy.cloud.databricks.com/`, which works. (JFrog `databricks.jfrog.io`
also works but needs auth.)

## Deployed instance (as of this handoff)
| | |
|---|---|
| Workspace (CLI profile) | `fevm-serverless-stable-ni2hkg` |
| App name | `finops-app` |
| URL | https://finops-app-7474650767037843.aws.databricksapps.com |
| Mode | `precompute` + `obo` (see `app.yaml`) |
| Warehouse | `b2f69d07f77b7fcb` ("Serverless Starter Warehouse") |
| Recommendation table | `serverless_stable_ni2hkg_catalog.finops.finops_recommendations` |
| App service principal | `eb8e0f4f-7aee-4dac-af95-6d87cb808285` ("app-56epe1 finops-app") — has `SELECT` on the table |
| Access | `users` group = `CAN_USE` (everyone in the workspace) |

**Live as of 2026-07-10** with the 4 commits above and the table repopulated by a
real precompute run (snapshot `2026-07-10`, 741 recs; 11 `warehouse_autostop` + 1
`enable_serverless` carry `viz` at `high` confidence). A **demo-mode** copy also
exists on the `fe-vm-classic-stable-g1cg4s` workspace (app `finops-app`, URL
`https://finops-app-7474645508925047.aws.databricksapps.com`) for offline showcase.
Note: `ni2hkg` has an **IP access list** that intermittently blocks the CLI from
*polling* job runs (statements API still works) — verify job results via
`databricks jobs get-run <id>` or by querying the table, not the `bundle run` stream.

### Redeploy recipe
```bash
P=fevm-serverless-stable-ni2hkg
WS=/Workspace/Users/<you>@databricks.com/finops-app
make build
# static/ is gitignored — temporarily un-ignore it so `sync` uploads the SPA:
sed -i '' 's|^backend/finops/static/$|# backend/finops/static/|' .gitignore
databricks sync --full --watch=false . "$WS" -p "$P"
databricks apps deploy finops-app --source-code-path "$WS" -p "$P"
sed -i '' 's|^# backend/finops/static/$|backend/finops/static/|' .gitignore   # restore
```

## Hard-won gotchas (don't re-learn these)
1. **The SQL connection must run as the app service principal, NOT the forwarded
   OBO user token.** Connecting the `databricks-sql-connector` to a SQL warehouse
   with the forwarded `x-forwarded-access-token` **hangs indefinitely**. The app
   SP connection works in ~1.5s. So: identity/scoping comes from the user (headers),
   but the SQL connection uses the SP (`deps.py` passes `settings.databricks_token
   or None`; deployed → SP via `cfg.authenticate` in `sql_client.get_connection`).
   Do **not** wire the caller token into `connect()`.
2. **The app SP needs UC grants** on whatever it reads: `USE CATALOG`, `USE SCHEMA`,
   `SELECT` on the precompute table (in precompute mode) — or on `system.*` (in live/SP mode).
3. **`backend/finops/static/` is gitignored** (build artifact) but `databricks sync`
   respects `.gitignore`, so you must temporarily un-ignore it for deploys (see recipe),
   or the deployed app serves `/docs` instead of the GUI.
4. **`_socket_timeout=40`** is set on the SQL connection so a bad endpoint fails
   fast instead of hanging forever.

## Precompute bundle — now deployable (recipe)
The batch job (`precompute/`) reruns all rules account-wide and writes the Delta
table the app reads. It ships a **wheel** (both packages + rule SQL/config data);
build it first, then deploy/run pointing at the app's catalog:
```bash
# from repo root — build the wheel the bundle installs:
UV_INDEX_URL=https://pypi-proxy.cloud.databricks.com/simple/ \
  uv build --wheel --out-dir precompute/dist        # ships finops + finops_rules + data files
cd precompute
export DATABRICKS_TF_EXEC_PATH=/opt/homebrew/bin/terraform DATABRICKS_TF_VERSION=1.13.4  # see gotcha 5
P=fevm-serverless-stable-ni2hkg
V="catalog=serverless_stable_ni2hkg_catalog,schema=finops"   # target = the app's table
databricks bundle deploy -p "$P" --var="$V"
databricks bundle run finops_precompute -p "$P" --var="$V"   # ~2-4 min account-wide
```
Then redeploy the app (recipe above) so the SPA/backend match, and it serves the
new snapshot. The wheel (`precompute/dist/`) is gitignored — rebuild after code
changes.

## Hard-won gotchas (precompute) — don't re-learn these
5. **`bundle deploy` fails "unable to verify checksums signature: openpgp: key
   expired"** — the CLI's Terraform provider download has an expired key. Fix:
   point at a local terraform via `DATABRICKS_TF_EXEC_PATH` **and** set
   `DATABRICKS_TF_VERSION` to match its version (e.g. `1.13.4`).
6. **The bundle installs local code as a wheel, not directory deps** — plain
   `../rules`/`../backend` dir deps fail ("is a directory"). `pyproject.toml` uses
   `packages.find` (both roots) + `package-data` (sql/*.sql.j2, config/*.yaml) so
   the wheel is self-contained.
7. **`job.py` must receive the target table as its task parameter** — the
   `spark_python_task` passes the FQN as `sys.argv[1]`; without threading it into
   `run()` it falls back to the inaccessible `main.finops` catalog.
8. **Write via the table's own schema** (`writer.py`) — Spark Connect can't infer
   a schema from dicts with all-null columns / DECIMALs.

## Detail-page feedback round (2026-07-13) — done
- **Cluster CPU charts now live** — all three cluster rules emit `cpu_area` from
  `system.compute.node_timeline` (shared `evidence.cpu_area_evidence`). Note: the
  series is bucketed **hourly**, so a cluster that only ran a few hours yields a
  sparse (few-point) chart — accurate but thin; consider adaptive bucketing.
- **Serverless excluded from `warehouse_autostop`** — candidate SQL filters
  `warehouse_type <> 'SERVERLESS'` (they scale to zero → no warm-pool to reclaim).
  This removed a bogus $24k rec on a serverless "Starter" warehouse.
- **Warehouse detail shows a cost basis** — size + DBUs(30d) + effective $/DBU +
  cost (facts strip), so the dollar figures are auditable (DBUs × $/DBU = cost).
- **"Open in Databricks" deep link** on every detail page — built client-side from
  `identity.workspace_host` (exposed by `/api/me`) + resource type/id + `?o=`.
  Limitation: uses the app's own workspace host, so links to resources in *other*
  workspaces of the account may not resolve — store per-rec workspace URL to fix.
- **Serverless viz is now the 14-day heatmap** (was a cramped 3-day burst compare).

## Known follow-ups
- **Graphs for the remaining rule types** — jobs (`unused_scheduled_jobs`),
  `enable_photon_dbr`, `interactive_to_job` still have no chart (no natural
  per-resource time-series). Add runs-over-time / cost bars if wanted.
- **Behavioural validation of the live gap SQL** — the `query.history` LEAD-window
  reconstruction is verified to *execute* and return sane shapes, not yet checked
  against a controlled warehouse (see `benchmark/README.md` limitations).
- **`workspace_name = NULL`** — join `system.access.workspaces_latest` in the
  precompute job so the UI shows names, not IDs.
- Earlier rule fixes still in place: `autotermination.sql.j2` column drift;
  `unused_scheduled_jobs` `require_activity_or_cost` guard.
