"""Guarantee tests for contract and cloud pricing features.

These tests verify that rules correctly emit contract and cloud cost columns
required by the central price_basis engine. Every rule with contract_pricing !=
"none" or cloud_savings != "none" must satisfy these contracts:

1. SQL templates project contract_ratio and contract_price_coverage through to
   the final SELECT when contract_prices=True
2. SQL templates project cloud_cost_30d_usd to the final SELECT when cloud_costs=True
3. price_basis.apply_price_basis correctly scales ratio-based rules by the
   contract discount
4. Counterpart rules set contract figures explicitly from contract columns
"""

from __future__ import annotations

import re

import pytest

from finops_rules import load_thresholds
from finops_rules.contract import RuleContext, RuleFinding, RulePriority, EffortBand
from finops_rules.price_basis import apply_price_basis, DEFAULT_CONTRACT_MIN_COVERAGE
from finops_rules.registry import list_rules


class TestSQLColumnsEmitted:
    """Verify that templates emit required columns through to the final SELECT."""

    def _get_final_select(self, sql: str) -> str:
        """Extract the final SELECT statement (the one that actually returns rows)."""
        # Find the LAST occurrence of "SELECT" at the top level (parenthesis depth 0).
        depth = 0
        last_select_pos = -1
        i = 0
        while i < len(sql):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            elif depth == 0 and i <= len(sql) - 6 and sql[i:i+6].upper() == 'SELECT':
                last_select_pos = i
            i += 1

        if last_select_pos >= 0:
            return sql[last_select_pos:]
        return sql

    @pytest.mark.parametrize("rule", list_rules())
    def test_contract_columns_when_contract_pricing_enabled(self, rule):
        """When contract_pricing != 'none' and the rule prices usage,
        the final SELECT must project contract_ratio and contract_price_coverage
        when contract_prices=True."""
        if getattr(rule, "contract_pricing", "ratio") == "none":
            pytest.skip(f"{rule.id} has contract_pricing=none")

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(thresholds=thresholds, contract_prices=True, lookback_days=30)

        sql = rule.render_sql(ctx)

        # If the template never uses pricing (e.g., untagged_spend which is $0),
        # skip the column check.
        if "billing" not in sql.lower() or "usage" not in sql.lower():
            pytest.skip(f"{rule.id} does not price usage")

        final_select = self._get_final_select(sql)
        if getattr(rule, "contract_pricing", "ratio") == "counterpart":
            # A counterpart rule sets its own contract figure; the engine still needs
            # the coverage figure to apply the gate (and mark a list fallback).
            assert re.search(r'\bcontract_price_coverage\b', final_select), rule.id
            return

        # The final SELECT must include contract_ratio and contract_price_coverage.
        # They may be prefixed with an alias like "cost.contract_ratio".
        has_contract_ratio = bool(re.search(r'\bcontract_ratio\b', final_select, re.IGNORECASE))
        has_contract_coverage = bool(re.search(r'\bcontract_price_coverage\b', final_select, re.IGNORECASE))

        assert has_contract_ratio, (
            f"{rule.id} final SELECT must project contract_ratio when contract_pricing=True. "
            f"Final SELECT:\n{final_select[:500]}"
        )
        assert has_contract_coverage, (
            f"{rule.id} final SELECT must project contract_price_coverage when contract_pricing=True. "
            f"Final SELECT:\n{final_select[:500]}"
        )

    @pytest.mark.parametrize("rule", list_rules())
    def test_cloud_columns_when_cloud_savings_enabled(self, rule):
        """When cloud_savings != 'none', the final SELECT must project
        cloud_cost_30d_usd when cloud_costs=True."""
        if getattr(rule, "cloud_savings", "none") == "none":
            pytest.skip(f"{rule.id} has cloud_savings=none")

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(thresholds=thresholds, cloud_costs=True, lookback_days=30)

        sql = rule.render_sql(ctx)

        final_select = self._get_final_select(sql)
        has_cloud_cost = bool(re.search(r'\bcloud_cost_30d_usd\b', final_select, re.IGNORECASE))

        assert has_cloud_cost, (
            f"{rule.id} final SELECT must project cloud_cost_30d_usd when cloud_savings != none. "
            f"Final SELECT:\n{final_select[:500]}"
        )


class TestRatioPricingEngine:
    """Verify that ratio-mode contract pricing scales correctly."""

    def _find_ratio_rules(self):
        """Return all rules with contract_pricing='ratio' that emit findings."""
        return [r for r in list_rules()
                if getattr(r, "contract_pricing", "ratio") == "ratio"]

    @pytest.mark.parametrize("rule", _find_ratio_rules(None))
    def test_ratio_applied_to_point_and_bounds(self, rule):
        """For ratio-mode rules, apply_price_basis should scale the point estimate
        and (if set) the low/high bounds by the contract ratio."""
        # Create a synthetic row with full contract coverage and a 20% discount.
        row = {
            "contract_ratio": 0.8,           # 20% discount
            "contract_price_coverage": 1.0,  # 100% coverage
            "cost_30d_usd": 1000.0,
        }

        # Create a synthetic finding with point + bounds.
        finding = RuleFinding(
            workspace_id="test",
            resource_type="warehouse",
            resource_id="wh-1",
            resource_name="test_wh",
            monthly_waste_usd=0,
            monthly_savings_usd=100.0,
            effort=EffortBand.LOW,
            priority=RulePriority.MEDIUM,
            why="test",
            how="test",
            monthly_savings_low_usd=80.0,
            monthly_savings_high_usd=120.0,
        )

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(
            thresholds=thresholds,
            contract_prices=True,
            contract_min_coverage=DEFAULT_CONTRACT_MIN_COVERAGE,
        )

        apply_price_basis(rule, row, finding, ctx)

        # Contract figures should be 0.8× the list figures.
        assert finding.price_basis == "contract"
        assert finding.monthly_savings_contract_usd == pytest.approx(80.0, abs=0.01)
        assert finding.monthly_savings_contract_low_usd == pytest.approx(64.0, abs=0.01)
        assert finding.monthly_savings_contract_high_usd == pytest.approx(96.0, abs=0.01)
        assert finding.contract_price_coverage == pytest.approx(1.0, abs=0.001)

    @pytest.mark.parametrize("rule", _find_ratio_rules(None))
    def test_ratio_falls_back_to_list_below_coverage_gate(self, rule):
        """When contract_price_coverage falls below the gate, the finding
        should fall back to list-only (contract figures None)."""
        row = {
            "contract_ratio": 0.8,
            "contract_price_coverage": 0.90,  # Below the 0.95 default gate
            "cost_30d_usd": 1000.0,
        }

        finding = RuleFinding(
            workspace_id="test",
            resource_type="warehouse",
            resource_id="wh-1",
            resource_name="test_wh",
            monthly_waste_usd=0,
            monthly_savings_usd=100.0,
            effort=EffortBand.LOW,
            priority=RulePriority.MEDIUM,
            why="test",
            how="test",
        )

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(
            thresholds=thresholds,
            contract_prices=True,
            contract_min_coverage=DEFAULT_CONTRACT_MIN_COVERAGE,
        )

        apply_price_basis(rule, row, finding, ctx)

        # Should fall back to list.
        assert finding.price_basis == "list"
        assert finding.monthly_savings_contract_usd is None
        assert finding.monthly_savings_contract_low_usd is None
        assert finding.monthly_savings_contract_high_usd is None
        assert finding.contract_price_coverage == pytest.approx(0.90, abs=0.001)

    def test_ratio_with_no_contract_price(self):
        """When contract_ratio is None (unpriced), fall back to list."""
        rule = next((r for r in list_rules() if getattr(r, "contract_pricing", "ratio") == "ratio"), None)
        if rule is None:
            pytest.skip("No ratio-pricing rules found")

        row = {
            "contract_ratio": None,  # No contract price
            "contract_price_coverage": 0.0,
            "cost_30d_usd": 1000.0,
        }

        finding = RuleFinding(
            workspace_id="test",
            resource_type="warehouse",
            resource_id="wh-1",
            resource_name="test_wh",
            monthly_waste_usd=0,
            monthly_savings_usd=100.0,
            effort=EffortBand.LOW,
            priority=RulePriority.MEDIUM,
            why="test",
            how="test",
        )

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(
            thresholds=thresholds,
            contract_prices=True,
            contract_min_coverage=0.0,  # Accept any coverage
        )

        apply_price_basis(rule, row, finding, ctx)

        # Should fall back to list.
        assert finding.price_basis == "list"
        assert finding.monthly_savings_contract_usd is None


class TestCounterpartPricing:
    """Verify that counterpart rules handle both SKUs correctly."""

    def _find_counterpart_rules(self):
        """Return all rules with contract_pricing='counterpart'."""
        return [r for r in list_rules()
                if getattr(r, "contract_pricing", "ratio") == "counterpart"]

    def _itj(self, **row_over):
        from finops_rules.catalog.interactive_to_job import InteractiveToJobRule

        rule = InteractiveToJobRule()
        ctx = RuleContext(
            thresholds={"enabled": True, "min_monthly_cost_usd": 200, "min_runs": 3,
                        "recency_days": 30},
            lookback_days=30, contract_prices=True,
        )
        row = {
            "workspace_id": "111", "cluster_id": "c-int", "cluster_name": "x",
            "job_count": 2, "recurring_job_count": 2, "run_count": 7,
            "runtime_hours": 12.0, "observed_days": 30, "running_minutes": 10_000,
            "job_active_minutes": 9_000, "job_active_frac": 0.9, "is_dedicated": True,
            "attributed_dbus": 1000.0, "dbus_30d": 1111.0, "unpriced_dbus": 0.0,
            "price_all_purpose": 0.55, "price_jobs_compute": 0.30,
            "cost_30d_usd": 550.0, "savings_30d_usd": 250.0, "job_breakdown": [],
            "savings_30d_contract_usd": 180.0, "contract_price_coverage": 1.0,
            **row_over,
        }
        finding = rule.score(row, ctx)
        apply_price_basis(rule, row, finding, ctx)
        return finding

    def test_interactive_to_job_prices_the_contract_gap(self):
        f = self._itj()
        assert f.price_basis == "contract"
        assert f.monthly_savings_contract_usd == 180.0  # the contract gap, not 0.x * list
        assert f.monthly_savings_contract_low_usd == 180.0  # dedicated => bookable shape

    def test_interactive_to_job_shared_cluster_contract_low_is_zero(self):
        f = self._itj(is_dedicated=False)
        assert f.monthly_savings_contract_low_usd == 0.0
        assert f.monthly_savings_contract_high_usd == 180.0

    def test_interactive_to_job_unpriced_side_or_low_coverage_is_list(self):
        assert self._itj(savings_30d_contract_usd=None).price_basis == "list"
        f = self._itj(contract_price_coverage=0.5)
        assert f.price_basis == "list" and f.monthly_savings_contract_usd is None


class TestCloudSavingsEngine:
    """Verify that cloud savings scale correctly."""

    def test_proportional_cloud_savings(self):
        """For 'proportional' mode, cloud savings should be list_savings *
        (cloud_cost / list_cost)."""
        rule = next((r for r in list_rules() if getattr(r, "cloud_savings", "none") == "proportional"), None)
        if rule is None:
            pytest.skip("No proportional cloud-savings rules found")

        # Row: $1000 cloud cost, list savings is 10% of $10k = $1k
        row = {
            "cost_30d_usd": 10000.0,
            "cloud_cost_30d_usd": 1000.0,
        }

        finding = RuleFinding(
            workspace_id="test",
            resource_type="cluster",
            resource_id="c-1",
            resource_name="test_cluster",
            monthly_waste_usd=0,
            monthly_savings_usd=1000.0,  # 10% of $10k DBU cost
            effort=EffortBand.LOW,
            priority=RulePriority.MEDIUM,
            why="test",
            how="test",
        )

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(thresholds=thresholds, cloud_costs=True, lookback_days=30)

        apply_price_basis(rule, row, finding, ctx)

        # Cloud savings should be ~$1000 * (1000 / 10000) = $100 monthly
        # (to_monthly scales 30d to 30d = no change)
        assert finding.cloud_cost_30d_usd == pytest.approx(1000.0, abs=0.01)
        assert finding.monthly_cloud_savings_usd == pytest.approx(100.0, abs=0.01)

    def test_full_cloud_savings(self):
        """For 'full' mode, cloud savings should be the full monthly cloud cost."""
        rule = next((r for r in list_rules() if getattr(r, "cloud_savings", "none") == "full"), None)
        if rule is None:
            pytest.skip("No full cloud-savings rules found")

        row = {
            "cost_30d_usd": 5000.0,
            "cloud_cost_30d_usd": 1000.0,
        }

        finding = RuleFinding(
            workspace_id="test",
            resource_type="warehouse",
            resource_id="wh-1",
            resource_name="test_wh",
            monthly_waste_usd=0,
            monthly_savings_usd=100.0,  # DBU savings
            effort=EffortBand.MEDIUM,
            priority=RulePriority.MEDIUM,
            why="test",
            how="test",
        )

        thresholds = load_thresholds().get(rule.id, {})
        ctx = RuleContext(thresholds=thresholds, cloud_costs=True, lookback_days=30)

        apply_price_basis(rule, row, finding, ctx)

        # Cloud savings should be the full 30-day cloud cost (no scaling by DBU savings)
        assert finding.cloud_cost_30d_usd == pytest.approx(1000.0, abs=0.01)
        assert finding.monthly_cloud_savings_usd == pytest.approx(1000.0, abs=0.01)


class TestFlagsOffByteIdentity:
    """Verify that SQL is byte-identical when flags are off."""

    @pytest.mark.parametrize("rule", list_rules())
    def test_flags_off_identical_to_default(self, rule):
        """When both contract_prices and cloud_costs are False (the default),
        the rendered SQL must be identical whether flags are explicitly set or omitted."""
        thresholds = load_thresholds().get(rule.id, {})

        # Render with default context (flags off by default).
        ctx_default = RuleContext(thresholds=thresholds, lookback_days=30)
        sql_default = rule.render_sql(ctx_default)

        # Render with explicit flags=False.
        ctx_explicit_off = RuleContext(
            thresholds=thresholds,
            contract_prices=False,
            cloud_costs=False,
            lookback_days=30,
        )
        sql_explicit_off = rule.render_sql(ctx_explicit_off)

        assert sql_default == sql_explicit_off, (
            f"{rule.id} SQL differs with explicit flags=False vs implicit default. "
            "Byte-identity is required so the golden / SDP-parity tests remain unchanged."
        )
