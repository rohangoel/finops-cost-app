"""Shared fixtures: sample system-table rows shaped like the rule SQL output."""

from __future__ import annotations

import pytest

from finops_rules.contract import RuleContext


@pytest.fixture
def autotermination_ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "max_acceptable_minutes": 60,
            "min_idle_events": 3,
            "use_audit_activity": False,
        },
        lookback_days=30,
        catalog="system",
    )


@pytest.fixture
def idle_no_autoterm_row() -> dict:
    """A costly cluster with no auto-termination that sits idle most of the time.

    Gap-based fields (from the sessionization CTE): it ran 10000 min, of which
    8000 were idle, and 7000 of those sat in gaps longer than 60 min (across 20
    gaps, longest 500 min) — i.e. genuinely reclaimable by a tighter timeout.
    ``observed_days`` clears the minimum-observation guard, so this fixture tests
    the scoring math rather than the guard (see tests/test_history.py)."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-abc",
        "cluster_name": "adhoc-analytics",
        "auto_termination_minutes": None,
        "dbr_version": "13.3.x",
        "worker_count": 4,
        "cost_30d_usd": 3000.0,
        "dbus_30d": 5000.0,
        "running_minutes": 10000.0,
        "idle_minutes": 8000.0,
        "reclaimable_gross_min": 7000.0,
        "num_reclaim_gaps": 20,
        "longest_idle_gap_min": 500,
        "job_runs_30d": 0,
        "observed_days": 28,
    }


@pytest.fixture
def busy_row() -> dict:
    """A genuinely busy cluster: almost no idle, and no long reclaimable gaps."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-busy",
        "cluster_name": "streaming-prod",
        "auto_termination_minutes": 0,
        "dbr_version": "14.3.x",
        "worker_count": 8,
        "cost_30d_usd": 9000.0,
        "dbus_30d": 15000.0,
        "running_minutes": 10000.0,
        "idle_minutes": 200.0,
        "reclaimable_gross_min": 0.0,
        "num_reclaim_gaps": 0,
        "longest_idle_gap_min": 30,
        "job_runs_30d": 0,
        "observed_days": 30,
    }
