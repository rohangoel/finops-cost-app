"""Phase 1 shared-correctness invariants, asserted on the RENDERED SQL of every rule.

These are the hermetic half of the plan's "a worsening change trips a test" layer
(docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md, V-invariants). The fixture-driven half
executes real SQL and needs a warehouse (sample_data/tests, skipped in credential-free
CI); these run on every PR with no warehouse, because they inspect the SQL string a
rule renders rather than its results. They fail the moment a rule reintroduces one of
the defects Phase 1 removed:

* FIN-002 — an observation window that is not closed-open (includes partial today).
* FIN-003 — a cost aggregate filtered to record_type='ORIGINAL' (drops corrections).
* FIN-006 — an SCD "current row" selection that filters delete_time BEFORE ranking
  (resurrects an older live version of a since-deleted resource).
* FIN-007 — a warehouse analytic/join keyed on warehouse_id alone (cross-workspace
  bleed when the same id exists in two workspaces).

The shared macros live in sql/_macros.sql.j2; migrating a rule to them is what keeps
it on the right side of these assertions.
"""

from __future__ import annotations

import re

import pytest

from finops_rules import list_rules, load_thresholds
from finops_rules.contract import RuleContext
from finops_rules.resolver import TableResolver

THRESHOLDS = load_thresholds()
_RULES = list_rules()


def _ctx(rule_id: str, resolver: TableResolver | None = None) -> RuleContext:
    return RuleContext(
        thresholds=THRESHOLDS.get(rule_id, {}),
        lookback_days=30,
        catalog="system",
        currency="USD",
        resolver=resolver,
    )


def _rendered():
    return [(r.id, r.render_sql(_ctx(r.id))) for r in _RULES]


# --- FIN-002: closed-open observation windows -------------------------------

@pytest.mark.parametrize("rule_id,sql", _rendered(), ids=lambda v: v if isinstance(v, str) else "")
def test_every_date_sub_window_is_closed_open(rule_id, sql):
    """`col >= date_sub(current_date(), N)` is an inclusive lower bound with no
    upper bound, so it spans N+1 dates and lets today's partial data in. Every such
    predicate must carry the matching `< current_date()` upper bound — the shared
    window_lower() macro renders both on one line, so an offending predicate is a
    line with date_sub(current_date() and no `< current_date()`."""
    offenders = [
        line.strip()
        for line in sql.splitlines()
        if "date_sub(current_date()" in line and "< current_date()" not in line
    ]
    assert not offenders, f"{rule_id} has non-closed-open window(s): {offenders}"


# --- FIN-003: corrections are never filtered out of cost sums ---------------

@pytest.mark.parametrize("rule_id,sql", _rendered(), ids=lambda v: v if isinstance(v, str) else "")
def test_no_rule_filters_record_type_to_original(rule_id, sql):
    """billing.usage is additive; filtering to record_type='ORIGINAL' keeps stale
    spend and drops the RETRACTION that cancels it. No rule may do it (the only
    legitimate ORIGINAL-only use is non-additive owner metadata, which lives in the
    backend, not in a rule's cost sum)."""
    assert "record_type = 'ORIGINAL'" not in sql, f"{rule_id} filters to ORIGINAL"
    assert "record_type='ORIGINAL'" not in sql, f"{rule_id} filters to ORIGINAL"


# --- FIN-006: SCD selection ranks first, filters delete_time after ----------

_QUALIFY_RANK = re.compile(r"QUALIFY\s+ROW_NUMBER", re.IGNORECASE)
_DELETE_FILTER = re.compile(r"delete_time\s+IS\s+NULL", re.IGNORECASE)


@pytest.mark.parametrize("rule_id,sql", _rendered(), ids=lambda v: v if isinstance(v, str) else "")
def test_scd_never_filters_delete_time_before_ranking(rule_id, sql):
    """The WHERE clause runs before QUALIFY, so filtering `delete_time IS NULL`
    before a QUALIFY ROW_NUMBER ranking removes a deleted resource's final row and
    lets an older live version rank #1. Correct rules either rank with the shared
    latest_scd_cte macro (delete filtered in the OUTER `rn = 1 AND delete_time IS
    NULL`) or rank in one CTE and filter delete_time in a LATER one — so no
    `delete_time IS NULL` may appear in the text immediately preceding a QUALIFY."""
    for m in _QUALIFY_RANK.finditer(sql):
        preceding = sql[max(0, m.start() - 600):m.start()]
        assert not _DELETE_FILTER.search(preceding), (
            f"{rule_id} filters delete_time in a WHERE before a QUALIFY ROW_NUMBER "
            f"ranking — rank first, then keep `rn = 1 AND delete_time IS NULL`"
        )


# Rules whose SCD selection was the broken shape (or a non-portable QUALIFY with no
# delete handling) and is now the shared latest_scd_cte macro. Assert the corrected
# shape is actually present so a regression cannot silently pass the anti-pattern
# check above by dropping the delete filter entirely.
_FORMERLY_BROKEN_SCD = [
    "enable_photon_dbr",
    "failing_jobs",
    "continuous_pipeline",
    "jobs_compute_rightsize",
    "unused_data_jobs",
    "unused_scheduled_jobs",
    # FIN Phase 2 §2.4: migrated off a DBSQL-only QUALIFY that also never filtered
    # deleted clusters — now rank-then-filter with delete_time IS NULL via the macro.
    "cluster_autotermination",
]


@pytest.mark.parametrize("rule_id", _FORMERLY_BROKEN_SCD)
def test_formerly_broken_scd_rules_rank_then_filter(rule_id):
    rule = next(r for r in _RULES if r.id == rule_id)
    sql = rule.render_sql(_ctx(rule_id))
    assert "rn = 1 AND delete_time IS NULL" in sql, (
        f"{rule_id} must select the current SCD row via rank-then-filter "
        f"(latest_scd_cte macro)"
    )


# --- FIN-007: warehouse identifiers are workspace-scoped --------------------

@pytest.mark.parametrize("rule_id,sql", _rendered(), ids=lambda v: v if isinstance(v, str) else "")
def test_no_bare_warehouse_id_analytic_partition(rule_id, sql):
    """warehouse_id is unique only within a workspace. A LEAD/window PARTITION BY
    warehouse_id alone (no workspace_id) interleaves two workspaces' query streams;
    the fix partitions by (workspace_id, warehouse_id)."""
    bare = re.findall(r"PARTITION BY\s+(?:c\.)?warehouse_id\s+ORDER", sql)
    assert not bare, f"{rule_id} partitions an analytic by warehouse_id alone"


@pytest.mark.parametrize("rule_id,sql", _rendered(), ids=lambda v: v if isinstance(v, str) else "")
def test_no_single_key_warehouse_join(rule_id, sql):
    """A `USING (warehouse_id)` join (single key) merges rows across workspaces that
    share a warehouse_id. Warehouse joins must be `USING (workspace_id, warehouse_id)`."""
    assert "USING (warehouse_id)" not in sql, (
        f"{rule_id} joins on warehouse_id alone — add workspace_id"
    )


# --- the macros render in BOTH execution modes ------------------------------

@pytest.mark.parametrize("rule_id", [r.id for r in _RULES])
def test_rule_renders_in_nested_and_central_modes(rule_id):
    """The shared macros (window_lower / usage_cost_cte / latest_scd_cte) must render
    byte-valid SQL through both the nested resolver and the central Logfood resolver
    — the central path rewrites tbl() and scopes by account_id.

    Rules that read a table with no Central Logfood equivalent (access.audit,
    access.table_lineage) are deliberately excluded from central mode: the resolver
    raises for them, and the central pipeline drops them from the enabled set. That
    is the documented contract, not a rendering failure, so it is accepted here."""
    rule = next(r for r in _RULES if r.id == rule_id)
    assert rule.render_sql(_ctx(rule_id)).strip()
    central = _ctx(rule_id, resolver=TableResolver.central_for(["acc-1", "acc-2"]))
    try:
        assert rule.render_sql(central).strip()
    except ValueError as e:
        assert "no Central Logfood equivalent" in str(e)
