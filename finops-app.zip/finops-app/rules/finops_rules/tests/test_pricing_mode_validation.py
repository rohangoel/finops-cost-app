"""Phase 0.4: effective-pricing fail-fast (docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md).

'effective' mode must have a configured net-cost source; otherwise the rules would
price off list_prices while dropping the list-price disclaimer — relabelling list as
effective. The guard refuses instead.
"""

from __future__ import annotations

import pytest

from finops_rules.pricing import (
    EFFECTIVE_PRICE_SOURCE_ENV,
    PRICING_MODE_EFFECTIVE,
    PRICING_MODE_LIST,
    pricing_mode_note,
    validate_pricing_mode,
)


def test_list_mode_is_always_valid_and_normalized():
    assert validate_pricing_mode("list") == PRICING_MODE_LIST
    assert validate_pricing_mode(None) == PRICING_MODE_LIST
    assert validate_pricing_mode("  LIST ") == PRICING_MODE_LIST


def test_effective_is_retired_with_or_without_a_source(monkeypatch):
    # The global 'effective' mode is retired in favour of per-finding contract pricing
    # (finops_rules.price_basis): dropping the list disclaimer from EVERY finding would
    # contradict findings that are still priced at list.
    monkeypatch.delenv(EFFECTIVE_PRICE_SOURCE_ENV, raising=False)
    with pytest.raises(ValueError, match="retired"):
        validate_pricing_mode(PRICING_MODE_EFFECTIVE)
    with pytest.raises(ValueError, match="retired"):
        validate_pricing_mode(PRICING_MODE_EFFECTIVE, effective_source="cat.sch.net_rates")
    monkeypatch.setenv(EFFECTIVE_PRICE_SOURCE_ENV, "cat.sch.net_rates")
    with pytest.raises(ValueError, match="retired"):
        validate_pricing_mode(PRICING_MODE_EFFECTIVE)


def test_unknown_mode_refuses():
    with pytest.raises(ValueError, match="Unknown pricing_mode"):
        validate_pricing_mode("contract")


def test_list_note_is_always_present():
    # The disclaimer is applied to every list-priced finding; contract-priced findings
    # skip it at the call site (precompute_transform), not via a global mode.
    assert pricing_mode_note(PRICING_MODE_LIST)
