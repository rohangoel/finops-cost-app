from __future__ import annotations

from finops_rules.catalog.idle_zombie_clusters import IdleZombieClustersRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "idle_cpu_pct_threshold": 5,
            "min_idle_windows": 8,
            "max_job_runs": 0,
            "defer_to_autostop_when_reclaimable": True,
            "max_acceptable_autostop_minutes": 60,
            "recency_days": 7,
        },
        lookback_days=30,
        catalog="system",
    )


def _zombie_row() -> dict:
    """A genuine zombie: costly UI cluster, essentially idle almost all the time,
    STILL running now (recent spend > 0), and it ALREADY has a tight auto-stop
    (20 min) yet is still up around the clock — so auto-termination can't fix it
    and terminate is the honest call. (A cluster with no / loose auto-stop defers
    to cluster_autotermination instead.)

    recent_cost_usd=700 over a 7-day recency window annualizes to ~$3000/mo
    (700 x 30/7), matching the whole-lookback rate — this is a cluster still idle
    now, not one that ran hot early then stopped."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-zombie",
        "cluster_name": "leftover-adhoc",
        "cluster_source": "UI",
        "avg_cpu": 2.0,
        "idle_windows": 95,
        "total_windows": 100,
        "auto_termination_minutes": 20,
        "cost_30d_usd": 3000.0,
        # FIN-017 forward-spend guard: still running idle in the recent window.
        "recent_windows": 100,
        "recent_idle_windows": 95,
        "recent_active_days": 7,
        "recent_cost_usd": 700.0,
    }


def _busy_row() -> dict:
    """A genuinely busy cluster: high CPU, few idle windows."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-busy",
        "cluster_name": "streaming-prod",
        "avg_cpu": 55.0,
        "idle_windows": 2,
        "total_windows": 100,
        "cost_30d_usd": 9000.0,
    }


def test_flags_zombie_cluster_with_savings():
    finding = IdleZombieClustersRule().score(_zombie_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-zombie"
    assert finding.resource_name == "leftover-adhoc"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.HIGH
    # 95% idle of ~$3000/mo => ~$2850/mo waste.
    assert 2700 < finding.monthly_savings_usd <= 3000
    assert "terminate" in finding.how.lower()
    assert finding.evidence["idle_windows"] == 95


def test_cluster_daily_viz_spans_full_lookback_and_shows_bursts():
    import time

    # A sparse series: ran ~2 days ~19 days ago, with one real burst (88% peak).
    base = int(time.time()) // 3600 * 3600 - 19 * 86400
    row = _zombie_row()
    row["cpu_hourly"] = [0.02] * 10
    row["cpu_ts"] = [base + h * 3600 for h in range(6)] + [base + 86400 + h * 3600 for h in range(4)]
    row["idle_frac"] = [0.95] * 10
    row["cpu_peak"] = [0.88] + [0.05] * 9  # one active hour, rest idle
    finding = IdleZombieClustersRule().score(row, _ctx())
    viz = finding.evidence["viz"]
    assert viz["kind"] == "cluster_daily"
    assert len(viz["days"]) == 30  # full lookback window, not just the days it ran
    assert viz["peak_overall"] == 0.88  # the real burst is preserved, not averaged away
    assert viz["last_active"] is not None
    assert finding.evidence["confidence"] == "medium"  # CPU idle is a proxy, not high-confidence
    active = [d for d in viz["days"] if d["a"] or d["i"]]
    assert len(active) == 2
    # active/idle split by REAL idle time (idle_frac=0.95 => ~0.5 active hr of 10)
    total_idle = sum(d["i"] for d in active)
    total_active = sum(d["a"] for d in active)
    assert 9.0 < total_idle < 9.9 and 0.1 < total_active < 1.0
    # The copy acknowledges real (bursty) work + recency, not "always idle".
    assert "peaking at 88% CPU" in finding.why and "last ran" in finding.why


def test_suppresses_busy_cluster():
    # High avg CPU and few idle windows => not a zombie.
    assert IdleZombieClustersRule().score(_busy_row(), _ctx()) is None


def test_suppresses_when_no_cost():
    row = _zombie_row()
    row["cost_30d_usd"] = 0
    assert IdleZombieClustersRule().score(row, _ctx()) is None


def test_suppresses_cluster_kept_warm_by_a_job():
    # Low CPU but a schedule runs on it => NOT an abandoned zombie. Terminating
    # would break the job; interactive_to_job / cluster_autotermination handle it.
    row = _zombie_row()
    row["job_runs_30d"] = 500
    assert IdleZombieClustersRule().score(row, _ctx()) is None
    # A truly abandoned cluster (no job runs) still fires.
    row["job_runs_30d"] = 0
    assert IdleZombieClustersRule().score(row, _ctx()) is not None


def test_defers_to_autostop_when_no_timeout():
    # The common case (measured: 10 of 12 zombie findings): an idle interactive
    # cluster with NO auto-stop is what cluster_autotermination reclaims — "add
    # auto-stop" beats "terminate" on a shared box, so the zombie rule defers.
    row = _zombie_row()
    row["auto_termination_minutes"] = None
    assert IdleZombieClustersRule().score(row, _ctx()) is None


def test_defers_to_autostop_when_timeout_is_loose():
    # A loose timeout (> max_acceptable) is still auto-termination's job to tighten.
    row = _zombie_row()
    row["auto_termination_minutes"] = 240
    assert IdleZombieClustersRule().score(row, _ctx()) is None


def test_survives_as_zombie_with_tight_timeout_still_idle():
    # ALREADY on a tight timeout yet still idle around the clock => a timeout can't
    # fix it (something keeps resetting the timer) => genuine terminate candidate.
    row = _zombie_row()
    row["auto_termination_minutes"] = 30
    finding = IdleZombieClustersRule().score(row, _ctx())
    assert finding is not None
    assert "30-minute auto-stop" in finding.why  # copy names the paradox honestly


def test_defer_guard_can_be_disabled():
    # With the guard off, a no-timeout idle cluster fires as before (back-compat).
    row = _zombie_row()
    row["auto_termination_minutes"] = None
    ctx = _ctx()
    ctx.thresholds["defer_to_autostop_when_reclaimable"] = False
    assert IdleZombieClustersRule().score(row, ctx) is not None


def test_sql_renders_without_workspace_filter():
    sql = IdleZombieClustersRule().render_sql(_ctx())
    assert "system.compute.clusters" in sql
    assert "system.compute.node_timeline" in sql
    assert "workspace_id IN" not in sql  # scoping is injected later, not here
    # cpu_peak must be projected by the FINAL select (not just built in the CTE),
    # or score() falls back to hourly averages and the daily chart shows 0 bursts.
    assert "cpu_series.cpu_peak" in sql
    # Job-activity signal so a schedule-kept cluster isn't mislabeled a zombie.
    # Must use the TASK-level table — only it populates compute_ids.
    assert "job_task_run_timeline" in sql
    assert "job_runs_30d" in sql
    # The auto-stop timeout drives the defer-to-autotermination guard in score().
    assert "auto_termination_minutes" in sql


# --- FIN-017 forward-spend guard / tiering ------------------------------------


def test_still_running_zombie_is_estimated_low_zero():
    # A cluster STILL running idle now: reclaimable, but CPU idle is only a proxy,
    # so the finding is ESTIMATED with a $0 lower bound (never booked).
    finding = IdleZombieClustersRule().score(_zombie_row(), _ctx())
    assert finding is not None
    assert finding.savings_status == "estimated"
    assert finding.monthly_savings_low_usd == 0.0
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd
    assert finding.monthly_savings_usd > 0
    assert finding.evidence["still_running"] is True


def test_stopped_cluster_books_zero_hygiene():
    # FIN-017: a cluster that wasted money earlier in the lookback but has NOT run
    # in the recency window is stopped — terminating it saves nothing forward. It
    # surfaces as advisory hygiene with $0 savings; the historical waste is context.
    row = _zombie_row()
    row["recent_windows"] = 0
    row["recent_idle_windows"] = 0
    row["recent_active_days"] = 0
    row["recent_cost_usd"] = 0.0
    finding = IdleZombieClustersRule().score(row, _ctx())
    assert finding is not None
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_usd == 0.0
    assert finding.monthly_savings_low_usd == 0.0
    # historical idle waste is still surfaced as the max-addressable upper bound
    assert finding.monthly_savings_high_usd > 0
    assert finding.evidence["still_running"] is False
    # copy is explicit that terminating saves nothing forward
    assert "saves nothing going forward" in finding.why
    assert "hygiene" in finding.why.lower()
    assert "delete" in finding.how.lower()


def test_still_running_but_recently_busy_is_suppressed():
    # Idle across the whole lookback (so it clears the candidate gates) but BUSY
    # again in the recent window: recent_idle_fraction -> 0, so there is no forward
    # idle to reclaim. It must NOT emit a $0 "Estimated" finding — the running path
    # returns None (unlike the stopped path, whose $0 is intentional advisory hygiene).
    row = _zombie_row()
    row["recent_idle_windows"] = 0   # ran, but not idle, in the recent window
    assert IdleZombieClustersRule().score(row, _ctx()) is None


def test_no_whole_lookback_annualization_when_stopped():
    # The OLD bug: a cluster that ran hot for a few days then stopped got its whole
    # spend annualized as ongoing monthly savings. Now a stopped cluster books $0.
    row = _zombie_row()
    row["recent_windows"] = 0
    row["recent_cost_usd"] = 0.0
    stopped = IdleZombieClustersRule().score(row, _ctx())
    running = IdleZombieClustersRule().score(_zombie_row(), _ctx())
    assert stopped.monthly_savings_usd == 0.0
    assert running.monthly_savings_usd > 0.0  # same cluster, still running => real


def test_band_is_ordered_and_bounded():
    finding = IdleZombieClustersRule().score(_zombie_row(), _ctx())
    lo = finding.monthly_savings_low_usd
    pt = finding.monthly_savings_usd
    hi = finding.monthly_savings_high_usd
    assert lo <= pt <= hi
    # savings never exceeds the (forward) reclaimable spend
    assert pt <= finding.monthly_waste_usd + 0.01
