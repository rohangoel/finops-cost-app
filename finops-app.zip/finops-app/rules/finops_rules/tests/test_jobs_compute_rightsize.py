from __future__ import annotations

from finops_rules.catalog.jobs_compute_rightsize import JobsComputeRightsizeRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import jobs_compute_rightsize_savings


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_runs": 5,
            "worker_idle_cpu_pct": 5,
            "driver_active_cpu_pct": 10,
            "cpu_headroom_pct": 40,
            "cpu_peak_pct": 60,
            "mem_oversize_pct": 30,
            "mem_bound_pct": 85,
            "savings_fraction": 0.30,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "job_id": "job-1",
        "job_name": "nightly-etl",
        "cluster_name": "job-cluster",
        "worker_count": 4,
        "driver_node_type": "m5.xlarge",
        "worker_node_type": "m5.xlarge",
        "driver_cores": None,     # exercise the node-count fallback (4/(4+1)=0.8)
        "worker_cores": None,
        "driver_memory_mb": None,
        "worker_memory_mb": None,
        "driver_cpu": 40.0,
        "worker_cpu": 2.0,
        "driver_mem": 55.0,
        "worker_mem": 30.0,
        # p95 peaks (FIN-016): low enough not to veto the default driver_bound row.
        "worker_p95_cpu": 8.0,
        "driver_p95_cpu": 55.0,
        "worker_p95_mem": 40.0,
        "driver_p95_mem": 60.0,
        "has_workers": 1,
        "run_clusters": 20,
        "observed_days": 30,
        "cost_30d_usd": 1000.0,
    }
    row.update(over)
    return row


def test_driver_bound_flags_single_node():
    finding = JobsComputeRightsizeRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "job"
    assert finding.effort == EffortBand.MEDIUM
    assert finding.priority == RulePriority.MEDIUM
    assert finding.evidence["symptom"] == "driver_bound"
    # worker_cost_fraction = 4/(4+1) = 0.8; savings = 1000 * 0.8 * 0.30 = 240.
    assert finding.monthly_savings_usd == 240.0
    assert finding.monthly_waste_usd == 1000.0
    assert "single-node" in finding.how.lower()
    # The finding carries the driver-vs-worker chart.
    viz = finding.evidence["viz"]
    assert viz["kind"] == "driver_worker_split"
    assert viz["symptom"] == "driver_bound"
    assert viz["driver_cpu"] > viz["worker_cpu"]


def test_idle_workers_flags_worker_cut():
    # Workers not idle-enough for driver-bound (>=5% CPU) but below headroom, and the
    # p95 peak (35%) is also below cpu_peak, so the burst doesn't need them either.
    finding = JobsComputeRightsizeRule().score(
        _row(worker_cpu=20.0, driver_cpu=25.0, worker_p95_cpu=35.0), _ctx()
    )
    assert finding is not None
    assert finding.evidence["symptom"] == "idle_workers"
    # base = 0.5 * 0.8 = 0.4; savings = 1000 * 0.4 * 0.30 = 120.
    assert finding.monthly_savings_usd == 120.0
    assert "worker" in finding.how.lower()


def test_memory_oversize_flags_smaller_node():
    # Single-node job (no workers) using little of its memory.
    finding = JobsComputeRightsizeRule().score(
        _row(
            has_workers=0, worker_count=0, worker_cpu=None, worker_mem=None,
            worker_p95_cpu=None, worker_p95_mem=None,
            driver_cpu=20.0, driver_mem=12.0, driver_p95_mem=25.0,
        ),
        _ctx(),
    )
    assert finding is not None
    assert finding.evidence["symptom"] == "memory_oversize"
    # memory base = 0.5 of total; savings = 1000 * 0.5 * 0.30 = 150.
    assert finding.monthly_savings_usd == 150.0
    assert "node type" in finding.how.lower()


def test_healthy_job_suppressed():
    # Workers busy, memory used: nothing to rightsize.
    row = _row(worker_cpu=60.0, driver_cpu=55.0, worker_mem=70.0, driver_mem=70.0)
    assert JobsComputeRightsizeRule().score(row, _ctx()) is None


# --- FIN-016 peak vetoes ------------------------------------------------------

def test_bursty_workers_veto_driver_bound():
    # Same driver-bound row (workers idle ON AVERAGE at 2% CPU) but the p95 peak is
    # 75% — the workers exist to serve a burst, so going single-node would starve it.
    # The average-only rule booked idle worker compute here; the peak veto drops it.
    row = _row(worker_p95_cpu=75.0)
    assert JobsComputeRightsizeRule().score(row, _ctx()) is None


def test_bursty_workers_veto_idle_workers():
    # An idle-workers row (avg 20% CPU) whose workers spike to 80% at p95: cutting the
    # worker count would leave the burst under-provisioned, so we don't recommend it.
    row = _row(worker_cpu=20.0, driver_cpu=25.0, worker_p95_cpu=80.0)
    assert JobsComputeRightsizeRule().score(row, _ctx()) is None


def test_high_p95_memory_vetoes_memory_oversize():
    # A single-node job that looks memory-oversized on AVERAGE (12%) but whose p95
    # memory hits 90% (>= mem_bound): a smaller-memory node would OOM/spill at the
    # peak, so the memory-oversize downsize is vetoed.
    row = _row(
        has_workers=0, worker_count=0, worker_cpu=None, worker_mem=None,
        worker_p95_cpu=None, worker_p95_mem=None,
        driver_cpu=20.0, driver_mem=12.0, driver_p95_mem=90.0,
    )
    assert JobsComputeRightsizeRule().score(row, _ctx()) is None


def test_too_new_suppressed():
    # Below the observation minimum -> no recommendation on a thin sample.
    assert JobsComputeRightsizeRule().score(_row(observed_days=1), _ctx()) is None


def test_zero_cost_suppressed():
    assert JobsComputeRightsizeRule().score(_row(cost_30d_usd=0.0), _ctx()) is None


def test_uses_core_counts_when_present():
    # driver 4 cores, 4 workers x 16 cores = 64 -> worker share 64/68 = 0.941.
    finding = JobsComputeRightsizeRule().score(
        _row(driver_cores=4, worker_cores=16), _ctx()
    )
    assert finding.evidence["worker_cost_fraction"] == round(64 / 68, 3)
    assert finding.monthly_savings_usd == round(1000 * (64 / 68) * 0.30, 2)


# --- SQL shape ----------------------------------------------------------------

def test_sql_renders_and_maps_clusters_to_jobs():
    sql = JobsComputeRightsizeRule().render_sql(_ctx())
    assert "node_timeline" in sql
    assert "node_types" in sql                 # memory-oversize node specs
    assert "usage_metadata.cluster_id" in sql  # ephemeral cluster -> job mapping
    assert "usage_metadata.job_id" in sql
    assert "workspace_id IN" not in sql        # scoping injected by the data layer


def test_sql_splits_driver_from_workers():
    sql = JobsComputeRightsizeRule().render_sql(_ctx())
    assert "driver" in sql
    assert "has_workers" in sql


# --- savings helper -----------------------------------------------------------

def test_savings_helper_by_symptom():
    db = jobs_compute_rightsize_savings(
        symptom="driver_bound", monthly_cost=1000, worker_cost_fraction=0.8,
        savings_fraction=0.30,
    )
    iw = jobs_compute_rightsize_savings(
        symptom="idle_workers", monthly_cost=1000, worker_cost_fraction=0.8,
        savings_fraction=0.30,
    )
    mem = jobs_compute_rightsize_savings(
        symptom="memory_oversize", monthly_cost=1000, worker_cost_fraction=0.0,
        savings_fraction=0.30,
    )
    assert db == 240.0
    assert iw == 120.0        # half the driver-bound base
    assert mem == 150.0       # independent of worker share


def test_savings_helper_guards():
    assert jobs_compute_rightsize_savings(
        symptom="driver_bound", monthly_cost=0, worker_cost_fraction=0.8,
        savings_fraction=0.30,
    ) == 0.0
    assert jobs_compute_rightsize_savings(
        symptom="unknown", monthly_cost=1000, worker_cost_fraction=0.8,
        savings_fraction=0.30,
    ) == 0.0
    # Never exceeds monthly cost even with degenerate inputs.
    assert jobs_compute_rightsize_savings(
        symptom="driver_bound", monthly_cost=100, worker_cost_fraction=1.0,
        savings_fraction=5.0,
    ) == 100.0
