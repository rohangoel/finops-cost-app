from __future__ import annotations

from finops_rules.catalog.unused_data_jobs import UnusedDataJobsRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import unused_data_job_savings


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "max_output_tables": 5,
            "min_writes": 10,
            "recoverable_fraction": 0.5,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "job_id": "job-unused-1",
        "job_name": "nightly-dead-table",
        "n_tables": 1,
        "total_writes": 237,
        "sample_table": "cat.schema.finops_test_unused",
        "last_write": "2026-07-29 15:30:00",
        "cost_30d_usd": 45.0,
        # FIN-015 sentinel: the output schema HAS captured reads (of other tables),
        # so this table's zero reads is a real signal, not "no coverage".
        "min_schema_reads": 12,
        "days": [
            {"d": "2026-07-27", "w": 48, "r": 0},
            {"d": "2026-07-28", "w": 48, "r": 0},
        ],
    }
    row.update(over)
    return row


def test_flags_unused_data_producer():
    finding = UnusedDataJobsRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "job"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.LOW
    # FIN-015: no haircut — the FULL producing cost is the max-addressable amount,
    # booked $0 (advisory). point == high == cost, low == 0.
    assert finding.monthly_savings_usd == 45.0
    assert finding.monthly_waste_usd == 45.0
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_low_usd == 0.0
    assert finding.monthly_savings_high_usd == 45.0
    assert finding.evidence["confidence"] == "low"
    assert finding.evidence["viz"]["kind"] == "write_no_read"
    assert finding.evidence["viz"]["total_reads"] == 0
    assert "never read" in finding.why


def test_suppresses_zero_cost():
    assert UnusedDataJobsRule().score(_row(cost_30d_usd=0.0), _ctx()) is None


def test_sentinel_suppresses_when_schema_has_no_read_coverage():
    """FIN-015: if the output table's schema shows NO captured reads of any table,
    'zero reads on this table' is 'no coverage', not 'dead data' — suppress."""
    assert UnusedDataJobsRule().score(_row(min_schema_reads=0), _ctx()) is None
    # and a schema WITH read coverage still fires
    assert UnusedDataJobsRule().score(_row(min_schema_reads=1), _ctx()) is not None


def test_advisory_books_zero_but_shows_addressable():
    """The producing cost is surfaced as addressable, but advisory books nothing."""
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    f = UnusedDataJobsRule().score(_row(), _ctx())
    assert f.monthly_savings_high_usd > 0
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1), rule_id="unused_data_jobs",
        rule_version="2.0.0", rule_title="t", category="jobs", workspace_id="111",
        resource_type="job", resource_id="job-unused-1", resource_name="n", why="", how="",
        monthly_waste_usd=f.monthly_waste_usd, monthly_savings_usd=f.monthly_savings_usd,
        savings_status="advisory", monthly_savings_low_usd=0.0,
        monthly_savings_high_usd=f.monthly_savings_high_usd, effort_band="low",
        effort_score=2, priority="LOW", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_savings_helper_conservative():
    # never exceeds the producing cost, scales with the recoverable fraction
    assert unused_data_job_savings(production_cost=100, recoverable_fraction=0.5) == 50.0
    assert unused_data_job_savings(production_cost=100, recoverable_fraction=1.0) == 100.0
    assert unused_data_job_savings(production_cost=0, recoverable_fraction=0.5) == 0.0


def test_sql_renders_without_workspace_filter():
    sql = UnusedDataJobsRule().render_sql(_ctx())
    assert "system.access.table_lineage" in sql
    assert "source_table_full_name" in sql  # the read signal
    assert "workspace_id IN" not in sql
    # FIN-015 sentinel: schema-level read coverage projected for score() to gate on.
    assert "read_schema" in sql
    assert "min_schema_reads" in sql
