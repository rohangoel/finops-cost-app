from __future__ import annotations

from finops_rules.catalog.idle_apps import IdleAppsRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "max_access_events": 0,
        "min_days_billed": 7,
        "min_monthly_cost_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "app_id": "app-abc",
        "app_name": "cost-explorer",
        "cost_window_usd": 300.0,
        "dbus_window": 400.0,
        "unpriced_dbus": 0,
        "observed_days": 30,
        "days_billed": 30,
        "access_events": 0,
        "distinct_users": 0,
        "last_access_time": None,
        # This app had 0 opens, but its workspace logged app access for OTHER apps,
        # so the audit signal is present and a 0 here genuinely means "idle".
        "app_access_events_total": 50,
    }
    row.update(over)
    return row


def test_flags_idle_always_on_app():
    finding = IdleAppsRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "app"
    assert finding.resource_id == "app-abc"
    # Zero access => full always-on cost reclaimable.
    assert finding.monthly_savings_usd == finding.monthly_waste_usd
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    # Best-effort access signal => medium confidence, verify-then-act.
    assert finding.evidence["confidence"] == "medium"
    assert "verify" in finding.how.lower()


def test_any_access_suppresses():
    """One recorded open means someone uses it."""
    assert IdleAppsRule().score(_row(access_events=1), _ctx()) is None


def test_no_workspace_access_signal_suppressed():
    """When the workspace logs ZERO app-access events, access_events==0 means "we
    can't see access", not "idle". The rule must emit nothing rather than flag the
    whole estate as waste (the live false positive this gate exists to prevent)."""
    assert IdleAppsRule().score(_row(app_access_events_total=0), _ctx()) is None


def test_max_access_events_configurable():
    assert IdleAppsRule().score(_row(access_events=3), _ctx()) is None
    assert IdleAppsRule().score(_row(access_events=3), _ctx(max_access_events=5)) is not None


def test_short_history_suppressed():
    assert IdleAppsRule().score(_row(observed_days=2, days_billed=2), _ctx()) is None


def test_below_cost_floor_suppressed():
    assert IdleAppsRule().score(_row(cost_window_usd=10.0), _ctx()) is None


def test_excluded_in_central_mode():
    """access.audit has no Central Logfood equivalent, so a central render raises —
    the pipeline drops the rule rather than failing (same mechanism as
    unused_data_jobs)."""
    from finops_rules.resolver import TableResolver

    ctx = RuleContext(
        thresholds={},
        lookback_days=30,
        catalog="system",
        resolver=TableResolver.central_for(["acc-1"]),
    )
    import pytest

    with pytest.raises(ValueError):
        IdleAppsRule().render_sql(ctx)
