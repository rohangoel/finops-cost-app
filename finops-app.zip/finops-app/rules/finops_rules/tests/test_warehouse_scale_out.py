from __future__ import annotations

from finops_rules.catalog.warehouse_scale_out import WarehouseScaleOutRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import warehouse_scale_out_target


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_queries": 100,
            "min_queued_pct": 0.10,
            "min_p95_queue_wait_s": 2.0,
            "scale_out_step": 2,
            "max_clusters_ceiling": 10,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "finops-test-warehouse-queueing",
        "warehouse_type": "PRO",
        "warehouse_size": "SMALL",
        "min_clusters": 1,
        "max_clusters": 1,
        "auto_stop_minutes": 10,
        "queries": 1101,
        "observed_days": 10,
        "queued_queries": 614,
        "queued_pct": 0.558,
        "spilled_pct": 0.0,
        "total_queue_wait_s": 6671.0,
        "p95_queue_wait_s": 21.3,
        "avg_queue_wait_s": 6.23,
        "p95_runtime_s": 4.32,
        "p95_read_gb": 8.4,
        "p95_shuffle_gb": 1.2,
        "max_spill_gb": 0.0,
        "queries_by_hour": [0] * 24,
        "queued_by_hour": [0] * 24,
        "cost_30d_usd": 741.0,
        "dbus_30d": 1347.0,
    }
    row.update(over)
    return row


def test_flags_queueing_warehouse():
    f = WarehouseScaleOutRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse"
    # Not a savings rule — the whole point.
    assert f.monthly_savings_usd == 0.0
    # Ranks on the spend exposed to the queueing.
    assert f.monthly_waste_usd == 741.0
    assert f.effort == EffortBand.TRIVIAL
    # 56% queued -> HIGH priority and a two-cluster step.
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "wh_scale_out"
    assert f.evidence["proposed_max_clusters"] == 3  # 1 + 2 (severe queueing)
    assert f.evidence["confidence"] == "high"
    assert "max clusters" in f.how.lower() or "maximum clusters" in f.how.lower()


def test_surfaces_measured_query_shape():
    # The measured spill / shuffle / scan volumes back the "add a cluster, don't
    # size up" fork — they must reach the evidence block, not be dropped.
    f = WarehouseScaleOutRule().score(_row(), _ctx())
    assert f is not None
    assert f.evidence["p95_read_gb"] == 8.4
    assert f.evidence["p95_shuffle_gb"] == 1.2
    assert f.evidence["max_spill_gb"] == 0.0
    assert f.evidence["p95_runtime_s"] == 4.32
    # No spill -> the copy says the shortage is concurrency, not memory.
    assert "not spilling to disk" in f.why


def test_spill_clause_cites_measured_volume():
    # When queries DO spill, the why-copy names the worst measured spill volume so
    # the reader can judge whether a size-up should accompany the extra cluster.
    f = WarehouseScaleOutRule().score(_row(spilled_pct=0.08, max_spill_gb=3.7), _ctx())
    assert f is not None
    assert "spilled to disk" in f.why
    assert "3.7 GB" in f.why


def test_single_step_for_moderate_queueing():
    f = WarehouseScaleOutRule().score(
        _row(queued_pct=0.15, queued_queries=165, p95_queue_wait_s=5.0), _ctx()
    )
    assert f is not None
    assert f.priority == RulePriority.MEDIUM
    assert f.evidence["proposed_max_clusters"] == 2  # 1 + 1 (moderate)


def test_concurrency_heuristic_raises_target():
    """SME (Simon Tarzi): measured peak concurrency, divided by ~10 queries/cluster,
    can call for more clusters than the queue-share step alone. A moderately-queueing
    warehouse (1-step) with 25 concurrent queries at peak => ~3 clusters of capacity,
    so the target is raised (still within the single-recommendation step cap)."""
    f = WarehouseScaleOutRule().score(
        _row(queued_pct=0.15, queued_queries=165, p95_queue_wait_s=5.0,
             peak_concurrent_queries=25),
        _ctx(),
    )
    assert f is not None
    assert f.evidence["peak_concurrent_queries"] == 25
    assert f.evidence["concurrency_implied_clusters"] == 3  # ceil(25/10)
    # Queue share alone gave 2 (1+1); concurrency raises it to 3 (still <= 1+step_cap).
    assert f.evidence["proposed_max_clusters"] == 3
    assert "concurrently" in f.why


def test_concurrency_heuristic_absent_signal_is_noop():
    """No concurrency column (older rows) => behaviour is unchanged."""
    f = WarehouseScaleOutRule().score(
        _row(queued_pct=0.15, queued_queries=165, p95_queue_wait_s=5.0), _ctx()
    )
    assert f is not None and f.evidence["proposed_max_clusters"] == 2


def test_suppresses_subsecond_queue_wait():
    # Real false-positive class: queries "queue" but for sub-second times that
    # round to zero real wait — not worth adding (and paying for) a cluster.
    assert WarehouseScaleOutRule().score(
        _row(queued_pct=0.20, p95_queue_wait_s=0.1), _ctx()
    ) is None


def test_suppresses_low_queue_share():
    assert WarehouseScaleOutRule().score(_row(queued_pct=0.03), _ctx()) is None


def test_suppresses_at_cluster_ceiling():
    # Already at the platform ceiling -> nothing to add.
    assert WarehouseScaleOutRule().score(
        _row(max_clusters=10), _ctx()
    ) is None


def test_suppresses_insufficient_history():
    assert WarehouseScaleOutRule().score(_row(observed_days=2), _ctx()) is None


def test_scale_out_target_math():
    # Moderate queueing -> one step; severe -> two; capped by ceiling.
    assert warehouse_scale_out_target(current_max_clusters=1, queued_pct=0.15) == 2
    assert warehouse_scale_out_target(current_max_clusters=1, queued_pct=0.30) == 3
    assert warehouse_scale_out_target(current_max_clusters=2, queued_pct=0.05) == 3
    # No queueing -> no target.
    assert warehouse_scale_out_target(current_max_clusters=1, queued_pct=0.0) is None
    # Ceiling clamps the step.
    assert warehouse_scale_out_target(current_max_clusters=1, queued_pct=0.30, ceiling=1) == 2


def test_sql_renders_without_workspace_filter():
    sql = WarehouseScaleOutRule().render_sql(_ctx())
    assert "system.query.history" in sql
    assert "waiting_at_capacity_duration_ms" in sql
    assert "max_clusters" in sql
    # Measured query-shape signals behind the cluster-vs-size fork.
    assert "shuffle_read_bytes" in sql
    assert "spilled_local_bytes" in sql
    assert "read_bytes" in sql
    assert "workspace_id IN" not in sql
