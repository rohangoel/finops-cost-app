from __future__ import annotations

import pytest

from finops_rules.catalog.alert_hygiene import (
    ISSUE_ERRORING,
    ISSUE_UNNOTIFIED,
    ISSUE_WARM,
    AlertHygieneRule,
)
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "history_days": 14,
        "min_error_streak_days": 7,
        "min_warm_hours": 24,
        "min_warm_days": 3,
        "min_warm_addressable_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # A healthy, subscribed alert every 5 minutes on a warehouse that is busy anyway:
    # no issue by default. Tests switch one signal on at a time.
    row = {
        "workspace_id": "111",
        "alert_id": "a-1",
        "display_name": "Orders null-rate",
        "owned_by": "owner@example.com",
        "run_as": "owner@example.com",
        "compute_type": "WAREHOUSE",
        "warehouse_id": "wh-1",
        "warehouse_name": "bi-serverless",
        "warehouse_type": "SERVERLESS",
        "warehouse_size": "Small",
        "auto_stop_minutes": 10,
        "cron": "0 0/5 * * * ?",
        "subscription_count": 1,
        "evaluations": 4032,
        "errored_evaluations": 0,
        "triggered_evaluations": 12,
        "notifying_evaluations": 12,
        "user_job_evaluations": 0,
        "observed_days": 14,
        "error_streak_days": 0,
        "last_error_code": None,
        "last_error_message": None,
        "last_evaluation_errored": False,
        "alert_statements": 4032,
        "alert_statement_hours": 336,
        "warm_hours": 0,
        "warm_days": 0,
        "warm_cost_usd": 0.0,
        "wh_alert_only_hours": 0,
        "wh_alert_only_cost_usd": 0.0,
        "wh_alert_only_islands": 0,
        "wh_cost_window_usd": 5000.0,
        "wh_billed_hours": 336,
        "dbus_30d": 7000.0,
        "unpriced_dbus": 0.0,
    }
    row.update(over)
    return row


def _warm(**over) -> dict:
    # 300 alert-only hours, $2,800 in the window, all this alert's; 6 islands with a
    # 10-minute auto-stop => 1 tail-hour deducted at ~$9.33/h => $2,790.67 over 14
    # days => x 30/14 = $5,980/mo.
    base = dict(
        warm_hours=300, warm_days=14, warm_cost_usd=2800.0,
        wh_alert_only_hours=300, wh_alert_only_cost_usd=2800.0, wh_alert_only_islands=6,
    )
    base.update(over)
    return _row(**base)


def test_healthy_alert_on_busy_warehouse_is_not_a_finding():
    assert AlertHygieneRule().score(_row(), _ctx()) is None


def test_insufficient_history_guard_runs_first():
    row = _warm(observed_days=2)
    assert AlertHygieneRule().score(row, _ctx()) is None


def test_always_erroring_alert():
    f = AlertHygieneRule().score(
        _row(error_streak_days=9, last_evaluation_errored=True, errored_evaluations=2600,
             last_error_code="INVALID_PARAMETER_VALUE", last_error_message="table not found"),
        _ctx(),
    )
    assert f is not None
    assert f.evidence["issues"] == [ISSUE_ERRORING]
    assert f.resource_type == "alert"
    assert f.resource_id == "a-1"
    assert f.monthly_waste_usd == 0.0 and f.monthly_savings_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.priority == RulePriority.MEDIUM
    assert f.evidence["confidence"] == "high"
    assert "INVALID_PARAMETER_VALUE" in f.why and "table not found" in f.why


def test_error_streak_too_short_or_recovered_is_not_flagged():
    assert AlertHygieneRule().score(
        _row(error_streak_days=5, last_evaluation_errored=True), _ctx()) is None
    # Last evaluation succeeded: it recovered, whatever the streak count says.
    assert AlertHygieneRule().score(
        _row(error_streak_days=9, last_evaluation_errored=False), _ctx()) is None


def test_nobody_notified():
    f = AlertHygieneRule().score(
        _row(subscription_count=0, notifying_evaluations=0, triggered_evaluations=40), _ctx())
    assert f is not None
    assert f.evidence["issues"] == [ISSUE_UNNOTIFIED]
    assert "triggered 40 times" in f.why
    assert f.evidence["confidence"] == "medium"
    assert f.priority == RulePriority.LOW


def test_job_wired_alert_is_not_unnotified():
    # A user job evaluates it: the job may notify on the result itself.
    assert AlertHygieneRule().score(
        _row(subscription_count=0, notifying_evaluations=0, user_job_evaluations=20),
        _ctx()) is None


def test_alert_that_notified_someone_is_not_unnotified():
    # Subscriptions were removed recently, but evaluations in the window still notified.
    assert AlertHygieneRule().score(
        _row(subscription_count=0, notifying_evaluations=3), _ctx()) is None


def test_keeps_warehouse_warm_prices_share_less_tail():
    f = AlertHygieneRule().score(_warm(), _ctx())
    assert f is not None
    assert f.evidence["issues"] == [ISSUE_WARM]
    expected = (2800.0 - 1.0 * 2800.0 / 300) * 30 / 14
    assert f.monthly_waste_usd == pytest.approx(expected, rel=1e-3)
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(expected, rel=1e-3)
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.savings_status == "estimated"
    assert f.monthly_savings_usd == pytest.approx(expected, rel=1e-3)
    assert f.priority == RulePriority.HIGH
    assert "only thing running" in f.why


def test_warm_cost_is_split_between_alerts_sharing_a_warehouse():
    # Three alerts share the warehouse's alert-only hours equally.
    whole = AlertHygieneRule().score(_warm(), _ctx())
    third = AlertHygieneRule().score(_warm(warm_cost_usd=2800.0 / 3), _ctx())
    assert third.monthly_waste_usd == pytest.approx(whole.monthly_waste_usd / 3, rel=1e-3)


def test_warm_hours_below_thresholds_are_not_flagged():
    assert AlertHygieneRule().score(_warm(warm_hours=10), _ctx()) is None
    assert AlertHygieneRule().score(_warm(warm_days=2), _ctx()) is None
    tiny = _warm(warm_cost_usd=5.0, wh_alert_only_cost_usd=5.0)
    assert AlertHygieneRule().score(tiny, _ctx()) is None


def test_underpriced_warehouse_drops_the_warm_figure():
    row = _warm(unpriced_dbus=6000.0)
    assert AlertHygieneRule().score(row, _ctx()) is None
    # ...but a hygiene issue still surfaces, at $0.
    f = AlertHygieneRule().score(
        _warm(unpriced_dbus=6000.0, subscription_count=0, notifying_evaluations=0), _ctx())
    assert f is not None and f.monthly_waste_usd == 0.0
    assert f.evidence["issues"] == [ISSUE_UNNOTIFIED]


def test_erroring_and_warm_combined_copy():
    f = AlertHygieneRule().score(
        _warm(error_streak_days=14, last_evaluation_errored=True, errored_evaluations=4032,
              last_error_code="INVALID_PARAMETER_VALUE"),
        _ctx())
    assert f.evidence["issues"] == [ISSUE_ERRORING, ISSUE_WARM]
    assert f.why.startswith("Alert 'Orders null-rate' has failed")
    assert "Its evaluations" in f.why
    assert f.evidence["confidence"] == "medium"
    assert f.monthly_waste_usd > 0


def test_rule_is_promoted_estimated():
    r = AlertHygieneRule()
    assert r.experimental is False  # promoted out of Labs 2026-09-23
    assert r.default_savings_status == "estimated"
    assert r.contract_pricing == "none" and r.cloud_savings == "none"


def test_finding_shares_its_warehouse_spend_pool():
    # Its dollars are the warehouse's compute, so the totals dedupe it with the
    # warehouse's own findings instead of counting that spend twice.
    f = AlertHygieneRule().score(_warm(), _ctx())
    assert f.evidence["warehouse_id"]
    assert f.affected_spend_scope == f"warehouse|{f.evidence['warehouse_id']}"


def _recent(n: int) -> str:
    from datetime import date, timedelta
    return (date.today() - timedelta(days=n)).isoformat()


def test_warm_alert_charts_its_warm_hours_then_its_evaluations():
    f = AlertHygieneRule().score(
        _warm(warm_by_day=[{"d": _recent(2), "h": 22}],
              eval_by_day=[{"d": _recent(2), "ok": 280, "t": 8, "e": 0}]), _ctx())
    assert f.evidence["viz"]["kind"] == "daily_stack"
    assert f.evidence["viz"]["series"][0]["color"] == "warn"
    assert len(f.evidence["viz"]["days"]) == 14  # history_days, not the lookback
    assert f.evidence["viz_extra"][0]["title"] == "Evaluations per day"


def test_erroring_alert_charts_its_evaluations_only():
    f = AlertHygieneRule().score(
        _row(error_streak_days=9, last_evaluation_errored=True, errored_evaluations=2600,
             eval_by_day=[{"d": _recent(1), "ok": 0, "t": 0, "e": 288}]), _ctx())
    assert f.evidence["viz"]["title"] == "Evaluations per day"
    assert "viz_extra" not in f.evidence
