from __future__ import annotations

import pytest

from finops_rules.catalog.warehouse_min_clusters import WarehouseMinClustersRule
from finops_rules.catalog.warehouse_scale_out import WarehouseScaleOutRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "max_queries_per_cluster": 10,
        "carry_in_days": 30,
        "min_one_cluster_share": 0.90,
        "max_queued_pct": 0.10,
        "max_rate_ratio": 1.25,
        "min_addressable_usd": 50,
        "churn_starts_per_day": 24,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # An always-on serverless LARGE warehouse at min_clusters = 2 whose load fits on one
    # cluster: 720 h up, 2 clusters the whole time, $40,320 over 30 days.
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "bi-warehouse",
        "warehouse_type": "SERVERLESS",
        "warehouse_size": "LARGE",
        "min_clusters": 2,
        "max_clusters": 4,
        "auto_stop_minutes": 60,
        "actual_cluster_min": 86_400.0,
        "floor_cluster_min": 86_400.0,
        "excess_cluster_min": 43_000.0,
        "running_min": 43_200.0,
        "one_cluster_min": 43_000.0,
        "no_query_min": 20_000.0,
        "peak_needed": 3,
        "starts": 0,
        "queries": 11_000,
        "queued_pct": 0.0001,
        "p95_queue_wait_s": 0.0,
        "p50_duration_s": 1.2,
        "query_hours": 700,
        "hours_of_day_active": 24,
        "top_clients": [
            {"client": "Databricks SQL Dashboard", "user": "ana@example.com", "n": 3000},
            {"client": "unknown", "user": "e474ba23-svc", "n": 8000},
        ],
        "cost_window_usd": 40_320.0,
        "dbus_30d": 57_600.0,  # 1,440 cluster-hours x 40 DBU/h = LARGE's published rate
        "unpriced_dbus": 0.0,
        "observed_days": 30,
    }
    row.update(over)
    return row


def test_flags_floor_held_clusters():
    f = WarehouseMinClustersRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse" and f.resource_id == "wh-1"
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.savings_status == "estimated"
    # 43,000 excess cluster-min x ($40,320 / 86,400 cluster-min) = $20,066.67 / 30 d.
    assert f.monthly_waste_usd == pytest.approx(43_000 * 40_320 / 86_400, abs=0.01)
    assert f.evidence["addressable_monthly_usd"] == f.monthly_waste_usd
    assert f.monthly_savings_usd == f.monthly_savings_low_usd == f.monthly_waste_usd
    assert f.evidence["proposed_min_clusters"] == 1
    assert f.evidence["dbu_per_cluster_hour"] == 40.0
    assert f.evidence["starts_per_day"] == 0.0
    assert f.evidence["confidence"] == "medium"
    assert f.priority == RulePriority.HIGH
    assert f.effort == EffortBand.TRIVIAL
    assert "Minimum clusters to 1" in f.how and "Maximum at 4" in f.how
    # No churn, so no second remedy.
    assert "wake-ups" not in f.how
    # A 0.01% queued share is noise, not worth a sentence.
    assert "wait for capacity" not in f.why


def test_zepz_sanctions_validation_case():
    """Plan §C5 hand check (Zepz `sanctions`, central logfood, 2026-09-23).

    Serverless MEDIUM, min 2 / max 3, auto-stop 2 min, ~$13.7k/mo list, ~1,000 DBU/day
    (≈ 41.7 cluster-hours/day), ~5,770 starts in 30 days (≈ 192/day, 24/7), 10,133
    queries (p50 ~1 s) almost all from one service principal, 4.5% queued.

    Reconstructed: up ~20.8 h/day at 2 clusters (a few minutes at 3), so
      running  = 20.8 h x 60 x 30              = 37,440 min
      actual   = 41.7 h x 60 x 30              = 75,060 cluster-min
      floor    = 2 x 37,440                    = 74,880 cluster-min
      needed   = 1 in all but ~140 minutes     -> sum max(1, needed) ~ 37,580
      excess   = 74,880 - 37,580               = 37,300 cluster-min
      rate     = $13,700 / 75,060              = $0.1825 / cluster-min ($10.95/h)
      => addressable ≈ 37,300 x 0.1825         ≈ $6,808 / mo
    i.e. ~half the bill, consistent with the plan's "several $k/mo from min_clusters = 1".
    """
    row = _row(
        warehouse_name="sanctions", warehouse_size="MEDIUM",
        min_clusters=2, max_clusters=3, auto_stop_minutes=2,
        running_min=37_440.0, actual_cluster_min=75_060.0, floor_cluster_min=74_880.0,
        excess_cluster_min=37_300.0, one_cluster_min=37_300.0,
        starts=5_770, queries=10_133, queued_pct=0.045, p95_queue_wait_s=1.0,
        hours_of_day_active=24,
        top_clients=[{"client": "unknown", "user": "7f3c-sp-uuid", "n": 9_700}],
        cost_window_usd=13_700.0, dbus_30d=30_000.0,  # 1,000 DBU/day; 24.0 DBU/cluster-h
    )
    f = WarehouseMinClustersRule().score(row, _ctx())
    assert f is not None
    assert f.monthly_waste_usd == pytest.approx(6_807.83, abs=1.0)
    assert f.evidence["starts_per_day"] == pytest.approx(192.3, abs=0.1)
    assert f.evidence["dbu_per_cluster_hour"] == pytest.approx(24.0, abs=0.1)
    # Churn: the why names the start count, the how names the second remedy.
    assert "5,770 times" in f.why and "2-minute idle timer" in f.why
    assert "4.5% of queries already wait for capacity" in f.why
    assert "around the clock" in f.how and "(a service identity)" in f.how
    assert "small dedicated warehouse" in f.how


def test_suppresses_when_one_cluster_does_not_suffice():
    row = _row(one_cluster_min=35_000.0)  # 81% of running minutes
    assert WarehouseMinClustersRule().score(row, _ctx()) is None


def test_suppresses_when_queueing_already():
    # Even with a sub-2s p95 (below scale_out's wait gate), half the queries queueing
    # is not a warehouse to take capacity from.
    row = _row(queued_pct=0.47, p95_queue_wait_s=1.5)
    assert WarehouseMinClustersRule().score(row, _ctx()) is None


def test_suppresses_when_rebuilt_minutes_do_not_explain_bill():
    # 57,600 DBUs over only 43,200 rebuilt cluster-min = 80 DBU/h on a LARGE (40):
    # events are missing, the $/cluster-minute would be inflated.
    row = _row(actual_cluster_min=43_200.0, floor_cluster_min=43_200.0,
               excess_cluster_min=20_000.0)
    assert WarehouseMinClustersRule().score(row, _ctx()) is None


def test_rebuilt_minutes_above_bill_are_kept_conservatively():
    # More rebuilt minutes than billed lowers the rate -> smaller figure, still reported.
    row = _row(dbus_30d=40_000.0)
    f = WarehouseMinClustersRule().score(row, _ctx())
    assert f is not None and f.evidence["dbu_per_cluster_hour"] < 40.0


def test_min_one_is_not_a_candidate():
    assert WarehouseMinClustersRule().score(_row(min_clusters=1), _ctx()) is None


def test_insufficient_history_first():
    assert WarehouseMinClustersRule().score(_row(observed_days=2), _ctx()) is None


def test_floor_on_addressable():
    row = _row(cost_window_usd=60.0, dbus_30d=57_600.0)
    assert WarehouseMinClustersRule().score(row, _ctx()) is None


def test_priority_by_dollars_not_share():
    # Small warehouse: ~50% excess (as every min=2 warehouse has) but only ~$65/mo.
    row = _row(cost_window_usd=130.0)
    f = WarehouseMinClustersRule().score(row, _ctx())
    assert f is not None and f.priority == RulePriority.LOW


def test_starts_per_day_uses_observed_days():
    f = WarehouseMinClustersRule().score(_row(starts=300, observed_days=10), _ctx())
    assert f is not None and f.evidence["starts_per_day"] == 30.0


# --- R3: warehouse_min_clusters vs warehouse_scale_out -----------------------------

_SCALE_OUT_CTX = RuleContext(
    thresholds={
        "enabled": True,
        "min_queries": 100,
        "min_queued_pct": 0.10,
        "min_p95_queue_wait_s": 2.0,
        "scale_out_step": 2,
        "max_clusters_ceiling": 10,
        "max_queries_per_cluster": 10,
    },
    lookback_days=30,
    catalog="system",
)


def _both_rows(queued_pct: float, p95: float) -> dict:
    """One warehouse, min_clusters > 1, the columns both rules read."""
    queries = 11_000
    return _row(
        queued_pct=queued_pct,
        p95_queue_wait_s=p95,
        queued_queries=int(queries * queued_pct),
        spilled_pct=0.0,
        total_queue_wait_s=queries * queued_pct * p95,
        avg_queue_wait_s=p95 / 2,
        p95_runtime_s=4.0,
        peak_concurrent_queries=12,
        cost_30d_usd=40_320.0,
    )


@pytest.mark.parametrize(
    "queued_pct,p95",
    [(0.0, 0.0), (0.045, 1.0), (0.045, 30.0), (0.09, 5.0), (0.10, 1.0),
     (0.10, 2.0), (0.15, 3.0), (0.30, 20.0), (0.60, 0.5)],
)
def test_never_opposite_to_scale_out(queued_pct, p95):
    row = _both_rows(queued_pct, p95)
    down = WarehouseMinClustersRule().score(row, _ctx())
    up = WarehouseScaleOutRule().score(row, _SCALE_OUT_CTX)
    assert not (down and up), f"both fired at queued={queued_pct} p95={p95}"


def test_moderate_queueing_goes_to_min_clusters_only():
    # min_clusters = 2 with 4.5% queued (the Zepz shape): this rule fires, scale_out
    # does not — the floor is the problem, not the ceiling.
    row = _both_rows(0.045, 3.0)
    assert WarehouseMinClustersRule().score(row, _ctx()) is not None
    assert WarehouseScaleOutRule().score(row, _SCALE_OUT_CTX) is None


def test_heavy_queueing_goes_to_scale_out_only():
    row = _both_rows(0.20, 10.0)
    assert WarehouseMinClustersRule().score(row, _ctx()) is None
    assert WarehouseScaleOutRule().score(row, _SCALE_OUT_CTX) is not None


def test_daily_chart_splits_needed_from_floor_only_hours():
    from datetime import date, timedelta
    d = (date.today() - timedelta(days=2)).isoformat()
    f = WarehouseMinClustersRule().score(_row(days=[{"d": d, "w": 20.0, "x": 18.5}]), _ctx())
    v = f.evidence["viz"]
    assert v["kind"] == "daily_stack"
    assert [s["color"] for s in v["series"]] == ["info", "warn"]
    assert {"d": d, "v": [20.0, 18.5]} in v["days"]


def test_sql_emits_the_per_day_array_in_one_pass():
    sql = WarehouseMinClustersRule().render_sql(_ctx())
    assert "AS days" in sql
    assert sql.count("FROM minute_class") == 1  # the minute explode is not re-read
