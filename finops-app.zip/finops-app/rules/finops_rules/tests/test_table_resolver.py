"""The table resolver — nested output must be byte-identical to the historical
``{catalog}.schema.table`` form, and central output must be a correctly scoped,
correctly namespaced inline view. This is the seam the whole central mode rests on.
"""

from __future__ import annotations

import pytest

from finops_rules.resolver import (
    CENTRAL_NAMESPACE,
    CERTIFIED_WORKSPACES,
    NO_CENTRAL_EQUIVALENT,
    TableResolver,
)


# --- nested (default) mode: unchanged behavior --------------------------------
def test_nested_is_byte_identical_to_the_historical_form():
    r = TableResolver.nested("system")
    assert r("billing", "usage") == "system.billing.usage"
    assert r("compute", "node_timeline") == "system.compute.node_timeline"
    assert r("access", "workspaces_latest") == "system.access.workspaces_latest"


def test_nested_honors_a_mirror_catalog():
    r = TableResolver.nested("home_me")
    assert r("billing", "usage") == "home_me.billing.usage"


def test_default_resolver_is_nested():
    assert TableResolver()("billing", "usage") == "system.billing.usage"


# --- central mode -------------------------------------------------------------
def test_central_fact_table_is_a_scoped_flat_inline_view():
    r = TableResolver.central_for(["acc-1", "acc-2"])
    out = r("compute", "clusters")
    assert out == (
        f"(SELECT * FROM {CENTRAL_NAMESPACE}.compute_clusters "
        "WHERE account_id IN ('acc-1', 'acc-2'))"
    )


def test_central_scopes_by_account_id_only_no_cloud_predicate():
    # account_id is globally unique, so no cloud predicate is needed on the facts.
    out = TableResolver.central_for(["a"])("billing", "usage")
    assert "cloud" not in out
    assert "account_id IN ('a')" in out


def test_central_list_prices_dedup_keeps_the_columns_the_price_macro_needs():
    out = TableResolver.central_for(["a"])("billing", "list_prices")
    assert out.startswith("(SELECT DISTINCT account_id, cloud, sku_name, usage_unit, "
                          "currency_code, price_start_time, price_end_time, pricing")
    assert f"FROM {CENTRAL_NAMESPACE}.billing_list_prices" in out
    assert "WHERE account_id IN ('a')" in out


def test_central_workspaces_latest_redirects_to_certified_with_sfdc_and_null_url():
    out = TableResolver.central_for(["a"])("access", "workspaces_latest")
    assert CERTIFIED_WORKSPACES in out
    assert "salesforce_account_name" in out
    assert "cloud_type" in out
    assert "CAST(NULL AS STRING) AS workspace_url" in out
    assert "workspace_status" in out  # so callers can restrict to RUNNING


@pytest.mark.parametrize("schema,table", sorted(NO_CENTRAL_EQUIVALENT))
def test_central_raises_for_tables_with_no_central_equivalent(schema, table):
    with pytest.raises(ValueError, match="no Central Logfood equivalent"):
        TableResolver.central_for(["a"])(schema, table)


def test_known_central_absent_tables_stay_excluded():
    """Pin the specific tables verified absent from main.centralized_system_tables. If a
    future change removes one, the rule reading it (e.g. alert_hygiene, instance_pool_idle)
    would silently break the central update instead of being auto-excluded."""
    for key in (("access", "table_lineage"),
                ("alert", "alerts"), ("alert", "alert_evaluation_history"),
                ("compute", "instance_events"), ("compute", "instance_pools")):
        assert key in NO_CENTRAL_EQUIVALENT


def test_central_requires_at_least_one_account_and_drops_empties():
    with pytest.raises(ValueError):
        TableResolver.central_for([])
    with pytest.raises(ValueError):
        TableResolver.central_for([None, "", None])
    # dedup + order preserved
    r = TableResolver.central_for(["a", "a", "b"])
    assert r.account_ids == ("a", "b")


def test_central_rejects_injection_in_account_ids():
    r = TableResolver.central_for(["ok", "bad'; DROP"])
    with pytest.raises(ValueError, match="illegal character"):
        r("billing", "usage")


def test_render_context_exposes_tbl_and_central_flag():
    nested = TableResolver.nested().render_context()
    assert nested["central"] is False and callable(nested["tbl"])
    central = TableResolver.central_for(["a"]).render_context()
    assert central["central"] is True and callable(central["tbl"])
