from __future__ import annotations

import pytest

from finops_rules.catalog.warehouse_keepalive_queries import WarehouseKeepaliveQueriesRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "history_days": 14,
        "min_keepalive_hours": 24,
        "min_keepalive_days": 3,
        "min_keepalive_share": 0.10,
        "min_mean_run_hours": 2,
        "min_addressable_usd": 50,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # A dashboard auto-refresh holding a warehouse up: 200 of 336 billed hours are
    # keep-alive hours in 20 contiguous runs, $10/hour, 30-minute auto-stop.
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "bi-warehouse",
        "warehouse_type": "PRO",
        "warehouse_size": "MEDIUM",
        "auto_stop_minutes": 30,
        "billed_hours": 336,
        "real_hours": 100,
        "keepalive_hours": 200,
        "keepalive_days": 14,
        "keepalive_islands": 20,
        "keepalive_statements": 12_000,
        "keepalive_cache_hits": 11_000,
        "cost_window_usd": 3360.0,
        "keepalive_cost_usd": 2000.0,
        "dbus_30d": 4800.0,
        "unpriced_dbus": 0.0,
        "observed_days": 14,
        "top_clients": [
            {"client": "unknown", "user": "svc", "n": 1000},
            {"client": "Databricks SQL Dashboard", "user": "ana@example.com", "n": 11_000},
        ],
        "hourly_states": [2] * 200 + [1] * 100 + [0] * 36,
    }
    row.update(over)
    return row


def test_flags_warehouse_kept_warm_by_pings():
    f = WarehouseKeepaliveQueriesRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse"
    assert f.resource_id == "wh-1"
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.savings_status == "estimated"
    assert f.monthly_savings_usd == f.monthly_waste_usd == f.monthly_savings_low_usd
    # $2000 keep-alive cost - 20 runs x 0.5h tail x $10/h = $1900 over 14 days
    # -> x 30/14 = $4071.43/mo.
    assert f.monthly_waste_usd == pytest.approx(1900 * 30 / 14, abs=0.01)
    assert f.evidence["addressable_monthly_usd"] == f.monthly_waste_usd
    assert f.priority == RulePriority.HIGH
    assert f.effort == EffortBand.LOW
    assert f.evidence["confidence"] == "medium"
    # The culprit is the client that sent the most statements, whatever the SQL order.
    assert f.evidence["top_clients"][0]["client"] == "Databricks SQL Dashboard"
    assert "Databricks SQL Dashboard" in f.why and "ana@example.com" in f.why
    assert "result-cache hits" in f.why
    assert "auto-refresh" in f.how
    assert f.evidence["viz"]["kind"] == "hour_heatmap"
    assert len(f.evidence["viz"]["grid"]) == 14
    assert f.evidence["viz"]["reclaimable_hours"] == 200


def test_tail_deduction_is_capped_at_one_hour_per_run():
    # A 120-minute auto-stop still deducts at most one billed hour per run.
    f = WarehouseKeepaliveQueriesRule().score(_row(auto_stop_minutes=120), _ctx())
    assert f.monthly_waste_usd == pytest.approx((2000 - 20 * 10) * 30 / 14, abs=0.01)


def test_keepalive_cost_never_exceeds_window_cost():
    f = WarehouseKeepaliveQueriesRule().score(
        _row(keepalive_cost_usd=5000.0, cost_window_usd=3000.0), _ctx())
    assert f.monthly_waste_usd <= 3000.0 * 30 / 14


def test_rule_is_promoted_estimated():
    rule = WarehouseKeepaliveQueriesRule()
    assert rule.experimental is False  # promoted out of Labs 2026-09-23
    assert rule.default_savings_status == "estimated"
    assert rule.contract_pricing == "none"


def test_insufficient_history_suppresses():
    assert WarehouseKeepaliveQueriesRule().score(_row(observed_days=2), _ctx()) is None


def test_underpriced_suppresses():
    assert WarehouseKeepaliveQueriesRule().score(_row(unpriced_dbus=4000.0), _ctx()) is None


@pytest.mark.parametrize(
    "over",
    [
        {"keepalive_hours": 20, "keepalive_islands": 2},   # below min_keepalive_hours
        {"keepalive_days": 2},                             # not a rhythm
        {"billed_hours": 3000},                            # share < 10%
        {"keepalive_islands": 150},                        # mean run 1.3h: auto-stop tails
        {"billed_hours": 0},                               # nothing billed
    ],
)
def test_suppressions(over):
    assert WarehouseKeepaliveQueriesRule().score(_row(**over), _ctx()) is None


def test_below_dollar_floor_suppresses():
    assert WarehouseKeepaliveQueriesRule().score(
        _row(keepalive_cost_usd=20.0, cost_window_usd=40.0), _ctx()) is None


def test_low_share_small_dollars_is_low_priority_and_no_cache_clause():
    f = WarehouseKeepaliveQueriesRule().score(
        _row(billed_hours=1000, keepalive_cost_usd=80.0, cost_window_usd=1000.0,
             keepalive_cache_hits=0, top_clients=[{"client": "Tableau", "user": None, "n": 5000}]),
        _ctx())
    assert f is not None
    assert f.priority == RulePriority.LOW
    assert "result-cache" not in f.why
    # A minority culprit is not called "most".
    assert "The largest share" in f.why
    assert "BI tool" in f.how


def test_no_series_means_no_viz():
    f = WarehouseKeepaliveQueriesRule().score(_row(hourly_states=None, top_clients=None), _ctx())
    assert f is not None
    assert "viz" not in f.evidence
    assert f.evidence["top_clients"] == []
