"""Unit tests for serving_provisioned_overcapacity (B5, experimental)."""

from __future__ import annotations

from finops_rules.catalog.serving_provisioned_overcapacity import (
    ServingProvisionedOvercapacityRule,
)
from finops_rules.contract import RuleContext

T = {
    "min_idle_run_hours": 3,
    "min_idle_cost_share": 0.3,
    "min_days_billed": 7,
    "min_addressable_usd": 50,
    "max_requests_defer_to_idle": 0,
}


def _ctx(**over):
    return RuleContext(thresholds={**T, **over}, lookback_days=30)


def _row(**over):
    # Shaped on the live candidate (ss-aigw-demo): 322 billed PT hours, requests in 6.
    row = {
        "workspace_id": "123",
        "endpoint_id": "ep1",
        "endpoint_name": "demo-pt",
        "entity_type": "FOUNDATION_MODEL",
        "entity_name": "system.ai.gpt-oss-20b",
        "created_by": "someone@example.com",
        "billed_hours": 322,
        "active_hours": 6,
        "idle_hours": 316,
        "days_billed": 14,
        "observed_days": 14,
        "cost_30d_usd": 1205.0,
        "dbus_30d": 17200.0,
        "unpriced_dbus": 0.0,
        "reclaimable_idle_hours": 315,
        "reclaimable_cost_usd": 1181.0,
        "longest_idle_run_hours": 171,
        "requests_window": 182,
        "last_request_hour": "2026-09-20T10:00:00",
        "tokens_window": 20637,
        "peak_hour_tokens": 11042,
        "entity_matched": 1,
        "days_series": [{"d": "2026-09-02", "w": 1, "r": 0}, {"d": "2026-09-01", "w": 1, "r": 12}],
    }
    row.update(over)
    return row


RULE = ServingProvisionedOvercapacityRule()


def test_fires_on_mostly_idle_pt_endpoint():
    f = RULE.score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "serving_endpoint"
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.savings_status == "estimated"
    assert f.monthly_savings_usd == f.monthly_savings_low_usd == 1181.0
    # $1181 over a 30-day window -> $1181/mo addressable.
    assert f.monthly_waste_usd == 1181.0
    assert f.evidence["addressable_monthly_usd"] == 1181.0
    assert f.evidence["idle_cost_share"] == round(1181 / 1205, 4)
    assert f.evidence["viz"]["kind"] == "serving_traffic"
    # Series is sorted by day for the chart.
    assert [d["d"] for d in f.evidence["viz"]["days"]] == ["2026-09-01", "2026-09-02"]


def test_monthly_scaling_uses_lookback():
    ctx = RuleContext(thresholds=T, lookback_days=15)
    f = RULE.score(_row(), ctx)
    assert f is not None
    # to_monthly scales a 15-day window to 30 days (x2), capped at the monthly cost.
    assert f.monthly_waste_usd == 2362.0


def test_zero_traffic_is_left_to_idle_serving_endpoints():
    assert RULE.score(_row(requests_window=0, active_hours=0), _ctx()) is None


def test_unmatched_entity_suppressed():
    assert RULE.score(_row(entity_matched=0), _ctx()) is None


def test_insufficient_history_suppressed():
    assert RULE.score(_row(observed_days=2, days_billed=2), _ctx()) is None


def test_short_lived_reservation_suppressed():
    # Passes the 5-day history guard but not the standing-reservation bar.
    assert RULE.score(_row(observed_days=6, days_billed=6), _ctx()) is None


def test_busy_endpoint_below_idle_share_suppressed():
    assert RULE.score(_row(reclaimable_cost_usd=200.0), _ctx()) is None


def test_below_dollar_floor_suppressed():
    row = _row(cost_30d_usd=60.0, reclaimable_cost_usd=40.0)
    assert RULE.score(row, _ctx()) is None


def test_underpriced_suppressed():
    assert RULE.score(_row(unpriced_dbus=16000.0), _ctx()) is None


def test_addressable_never_exceeds_cost():
    f = RULE.score(_row(reclaimable_cost_usd=5000.0), _ctx())
    assert f is not None
    assert f.monthly_waste_usd <= 1205.0
    assert f.evidence["idle_cost_share"] == 1.0


def test_rule_is_promoted_estimated_no_contract():
    assert RULE.experimental is False  # promoted out of Labs 2026-09-23
    assert RULE.default_savings_status == "estimated"
    assert RULE.contract_pricing == "none"
    assert RULE.cloud_savings == "none"
