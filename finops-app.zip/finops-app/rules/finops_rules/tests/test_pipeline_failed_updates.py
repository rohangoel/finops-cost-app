from __future__ import annotations

from finops_rules.catalog.pipeline_failed_updates import PipelineFailedUpdatesRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_failed_updates": 10,
            "min_fail_rate": 0.05,
            "min_addressable_usd": 25,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    # A pipeline where 30% of updates fail and failed updates are 40% of wall-time, on a
    # $1,000/mo pipeline => ~$400/mo addressable.
    row = {
        "workspace_id": "111",
        "pipeline_id": "pl-1",
        "pipeline_name": "bronze-ingest",
        "updates": 200,
        "observed_days": 14,
        "failed_updates": 60,
        "failed_requests": 40,
        "fail_rate": 0.30,
        "total_dur_s": 100_000.0,
        "failed_dur_s": 40_000.0,
        "cost_30d_usd": 1000.0,
        "dbus_30d": 1500.0,
        "unpriced_dbus": 0.0,
        "days": [{"d": "2026-09-01", "t": 14, "f": 4}, {"d": "2026-09-02", "t": 15, "f": 5}],
    }
    row.update(over)
    return row


def test_flags_failing_pipeline():
    f = PipelineFailedUpdatesRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "pipeline"
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    # Addressable = 40% of $1000/mo.
    assert f.monthly_waste_usd == 400.0
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "pipeline_failures"


def test_rule_is_promoted_advisory():
    rule = PipelineFailedUpdatesRule()
    assert rule.experimental is False  # promoted out of Labs 2026-09-23 (still advisory)
    assert rule.default_savings_status == "advisory"


def test_duration_share_falls_back_to_count_when_no_duration():
    f = PipelineFailedUpdatesRule().score(_row(total_dur_s=0.0, failed_dur_s=0.0), _ctx())
    assert f is not None
    # 60/200 = 0.30 count share on a $1000/mo pipeline => $300.
    assert f.monthly_waste_usd == 300.0


def test_suppresses_noise_level_failures():
    assert PipelineFailedUpdatesRule().score(_row(failed_updates=60, fail_rate=0.02), _ctx()) is None


def test_suppresses_too_few_failures():
    assert PipelineFailedUpdatesRule().score(_row(failed_updates=3), _ctx()) is None


def test_suppresses_below_addressable_floor():
    assert PipelineFailedUpdatesRule().score(
        _row(cost_30d_usd=30.0, total_dur_s=1000.0, failed_dur_s=400.0), _ctx()
    ) is None


def test_suppresses_insufficient_history():
    assert PipelineFailedUpdatesRule().score(_row(observed_days=2), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = PipelineFailedUpdatesRule().render_sql(_ctx())
    assert "system.lakeflow.pipeline_update_timeline" in sql
    assert "result_state" in sql
    assert "workspace_id IN" not in sql
