from __future__ import annotations

from finops_rules.catalog.warehouse_autostop_serverless import (
    WarehouseAutoStopServerlessRule,
)
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import choose_serverless_autostop


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "max_acceptable_minutes": 10,
        "min_autostop_minutes": 5,
        "max_autostop_minutes": 10,
        "max_extra_stops_per_day": 3,
        "churny_stops_per_day": 30,
        "startup_penalty_minutes": 1,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(cost=2000.0, warm=5000.0, auto_stop=30, **hist) -> dict:
    """A candidate row. ``hist`` overrides individual gap-histogram buckets.

    Default shape = a genuinely sporadic warehouse: a handful of short gaps and
    many long ones, so a shorter auto-stop reclaims a lot without churning.
    """
    row = {
        "workspace_id": "111",
        "warehouse_id": "w-sless",
        "warehouse_name": "serverless-adhoc",
        "warehouse_size": "Small",
        "auto_stop_minutes": auto_stop,
        "cost_30d_usd": cost,
        "dbus_30d": 1200.0,
        "warm_minutes": warm,
        "gap_count": 100,
        "median_gap_min": 25.0,
        "p90_gap_min": 90.0,
        "queries_by_hour": [0] * 8 + [12] * 9 + [0] * 7,
        # 1440 per-minute buckets (index = hour*60 + minute), consistent with the
        # hourly array above: each active hour's 12 queries all land on minute :00.
        "queries_by_hour_minute": [
            12 if (8 <= (k // 60) < 17 and k % 60 == 0) else 0 for k in range(1440)
        ],
        # 168 day-of-week x hour buckets (index = dow*24 + hour, dow 0=Mon..6=Sun):
        # weekdays busy 08-17, weekends empty — the pattern the heatmap must show.
        "queries_by_dow_hour": [
            12 if ((k // 24) < 5 and 8 <= (k % 24) < 17) else 0 for k in range(168)
        ],
        # buckets: few tight gaps, lots of long idle
        "gap_hist_1": 2, "gap_hist_2": 1, "gap_hist_3": 1, "gap_hist_4": 1,
        "gap_hist_5": 1, "gap_hist_6": 1, "gap_hist_7": 1, "gap_hist_8": 1,
        "gap_hist_9": 1, "gap_hist_10": 1, "gap_hist_15": 4, "gap_hist_20": 5,
        "gap_hist_30": 20, "gap_hist_60": 30, "gap_hist_over": 30,
        # Measured minutes in the >60 bucket: 30 gaps averaging ~120 min. Keeps the
        # over-bucket keyed at its true length instead of the flat 1440 placeholder.
        "gap_over_minutes": 30 * 120,
    }
    row.update(hist)
    return row


def test_flags_serverless_and_recommends_within_usability_window():
    finding = WarehouseAutoStopServerlessRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "warehouse"
    assert finding.effort == EffortBand.TRIVIAL
    assert finding.priority == RulePriority.HIGH
    proposed = finding.evidence["proposed_autostop_minutes"]
    # The whole point of the rework: never 1 minute, never above the default.
    assert 5 <= proposed <= 10


def test_never_recommends_below_the_ui_floor_even_when_shorter_saves_more():
    # A warehouse idle for hours between queries: the model would happily go to
    # 1 min, but the floor must hold.
    row = _row(
        gap_hist_1=0, gap_hist_2=0, gap_hist_3=0, gap_hist_4=0, gap_hist_5=0,
        gap_hist_6=0, gap_hist_7=0, gap_hist_8=0, gap_hist_9=0, gap_hist_10=0,
        gap_hist_15=0, gap_hist_20=0, gap_hist_30=0, gap_hist_60=0,
        gap_hist_over=200,
    )
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    assert finding.evidence["proposed_autostop_minutes"] == 5


def test_suppresses_when_shortening_would_thrash_the_warehouse():
    # Queried relentlessly every 6-10 minutes, all gaps inside the decision window.
    # Every candidate either reclaims nothing (the gaps are already shorter than
    # today's setting) or buys minutes at the price of 100+ restarts/day — past even
    # the high-churn tier, so we say nothing rather than flag it.
    row = _row(
        auto_stop=12,
        gap_hist_1=0, gap_hist_2=0, gap_hist_3=0, gap_hist_4=0, gap_hist_5=0,
        gap_hist_6=2000, gap_hist_7=2000, gap_hist_8=2000, gap_hist_9=2000,
        gap_hist_10=2000, gap_hist_15=0, gap_hist_20=0, gap_hist_30=0,
        gap_hist_60=0, gap_hist_over=0,
    )
    assert WarehouseAutoStopServerlessRule().score(row, _ctx()) is None


def test_moderate_churn_is_flagged_rather_than_suppressed():
    # Between the two thresholds: ~27 restarts/day. Above "unobtrusive", below
    # "hopeless" — the tier that exists so real money isn't silently hidden.
    row = _row(
        auto_stop=15,
        gap_hist_1=0, gap_hist_2=0, gap_hist_3=0, gap_hist_4=0, gap_hist_5=0,
        gap_hist_6=400, gap_hist_7=400, gap_hist_8=400, gap_hist_9=400,
        gap_hist_10=400, gap_hist_15=0, gap_hist_20=0, gap_hist_30=0,
        gap_hist_60=0, gap_hist_over=0,
    )
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    assert finding.evidence["high_churn"] is True
    chosen = finding.evidence["viz"]["candidates"]
    picked = next(
        c for c in chosen
        if c["minutes"] == finding.evidence["proposed_autostop_minutes"]
    )
    assert 3 < picked["extra_stops_per_day"] <= 30


def test_high_churn_is_surfaced_with_a_warning_not_silently_dropped():
    # The real case that motivated this tier (dbx-analyzer-warehouse, verified
    # against live system tables): ~720 idle gaps in the 30-60 min band, i.e. an
    # hourly poller. Nothing stays under 3 restarts/day, but the idle spend is
    # most of the bill — so recommend it AND state the restart cost.
    row = _row(
        auto_stop=60, cost=6135.0, warm=43960.0,
        gap_hist_1=766, gap_hist_2=11, gap_hist_3=8, gap_hist_4=8, gap_hist_5=2,
        gap_hist_6=4, gap_hist_7=2, gap_hist_8=5, gap_hist_9=4, gap_hist_10=1,
        gap_hist_15=4, gap_hist_20=8, gap_hist_30=5, gap_hist_60=723,
        gap_hist_over=6,
    )
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None, "material idle spend must not be hidden"
    ev = finding.evidence
    assert ev["high_churn"] is True
    assert ev["viz"]["high_churn"] is True
    assert 5 <= ev["proposed_autostop_minutes"] <= 10
    # The copy must state the trade-off and tell the user what to check first.
    assert "TRADE-OFF" in finding.why
    assert "latency-sensitive" in finding.why
    assert "Query History" in finding.how or "querying it" in finding.how
    # And it must not masquerade as a safe, trivial toggle.
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    assert ev["confidence"] == "medium"


def test_comfortable_finding_stays_trivial_and_high_confidence():
    finding = WarehouseAutoStopServerlessRule().score(_row(), _ctx())
    assert finding.evidence["high_churn"] is False
    assert finding.effort == EffortBand.TRIVIAL
    assert finding.priority == RulePriority.HIGH
    assert finding.evidence["confidence"] == "high"
    assert "TRADE-OFF" not in finding.why


def test_prefers_longer_setting_when_shorter_adds_restarts_for_little_gain():
    # Gaps cluster tightly in the 5-7 min band: dropping to 5 would restart on
    # every one of them, so a longer value inside the window must win.
    row = _row(
        auto_stop=20,
        gap_hist_1=0, gap_hist_2=0, gap_hist_3=0, gap_hist_4=0, gap_hist_5=0,
        gap_hist_6=60, gap_hist_7=60, gap_hist_8=2, gap_hist_9=1,
        gap_hist_10=1, gap_hist_15=2, gap_hist_20=2, gap_hist_30=40,
        gap_hist_60=40, gap_hist_over=40,
    )
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    assert finding.evidence["proposed_autostop_minutes"] > 5


def test_does_not_recommend_a_value_at_or_above_current_setting():
    # Already at the bottom of the window => nothing to propose.
    assert WarehouseAutoStopServerlessRule().score(_row(auto_stop=5), _ctx()) is None


def test_never_exceeds_billed_cost():
    finding = WarehouseAutoStopServerlessRule().score(
        _row(cost=1000.0, warm=100.0), _ctx())
    assert finding is not None
    assert finding.monthly_savings_usd <= 1000.0


def test_suppresses_when_no_cost():
    assert WarehouseAutoStopServerlessRule().score(_row(cost=0), _ctx()) is None


def test_suppresses_without_gap_distribution():
    row = _row()
    for suffix in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                   "15", "20", "30", "60", "over"):
        row[f"gap_hist_{suffix}"] = 0
    assert WarehouseAutoStopServerlessRule().score(row, _ctx()) is None


def test_why_explains_the_usability_tradeoff():
    finding = WarehouseAutoStopServerlessRule().score(_row(), _ctx())
    assert "restart" in finding.why.lower()
    # The copy must justify the value, not just assert a number.
    assert "tolerates" in finding.why or "shortest" in finding.why


def test_evidence_carries_the_full_decision_for_the_chart():
    finding = WarehouseAutoStopServerlessRule().score(_row(), _ctx())
    viz = finding.evidence["viz"]
    assert viz["kind"] == "autostop_tradeoff"
    assert viz["gap_buckets"] and viz["candidates"]
    # Every candidate in the window is shown, so the choice is auditable.
    assert {c["minutes"] for c in viz["candidates"]} <= set(range(5, 11))
    assert viz["chosen_minutes"] == finding.evidence["proposed_autostop_minutes"]
    assert len(viz["queries_by_hour"]) == 24
    # The per-minute drilldown data rides along, full-length, and stays consistent
    # with the hourly array (each hour == sum of its 60 minute buckets).
    assert len(viz["queries_by_hour_minute"]) == 1440
    for h in range(24):
        hour_slice = viz["queries_by_hour_minute"][h * 60 : h * 60 + 60]
        assert sum(hour_slice) == viz["queries_by_hour"][h]


def test_per_minute_drilldown_absent_when_row_lacks_it():
    # Older/precomputed rows without queries_by_hour_minute must not carry an empty
    # key — the frontend uses its absence to fall back to the hourly-only view.
    row = _row()
    del row["queries_by_hour_minute"]
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    assert "queries_by_hour_minute" not in finding.evidence["viz"]


def test_over_bucket_keyed_by_measured_length_not_flat_placeholder():
    # A warehouse with no auto-stop and long (multi-hour) idle gaps: the >60 bucket
    # must be keyed by its MEASURED average, not a flat 1440. With the true average
    # the modelled saving cannot exceed the warehouse's real warm time.
    from finops_rules.evidence import gap_histogram_from_row
    row = _row()
    hist = gap_histogram_from_row(row)
    # 30 gaps averaging 120 min => the over bucket lands near 120, well below 1440.
    over_keys = [k for k in hist if k > 60]
    assert over_keys and all(100 <= k <= 140 for k in over_keys), hist
    # And the reported saving stays within billed cost (never over-claims).
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    assert finding.monthly_savings_usd <= finding.evidence["cost_30d_usd"]


def test_over_bucket_falls_back_when_measured_total_absent():
    # Older rows without gap_over_minutes must still work, using the placeholder.
    from finops_rules.evidence import gap_histogram_from_row
    row = _row()
    del row["gap_over_minutes"]
    hist = gap_histogram_from_row(row)
    assert 1440 in hist  # fell back to the one-day placeholder


def test_savings_split_into_enable_and_tighten_tiers():
    # The real motivating case (mirrors the live 4X_LARGE "genie space" warehouse):
    # no auto-stop, and the idle is dominated by a handful of MULTI-HOUR gaps
    # (weekends/overnights). A long baseline stop already reclaims those, so the
    # enable tier must hold the bulk of the saving and the tighten tier the small
    # remainder — the whole point of the split.
    row = _row(
        auto_stop=0, cost=200000.0, warm=30000.0,
        gap_hist_1=15000, gap_hist_2=1200, gap_hist_3=560, gap_hist_4=240,
        gap_hist_5=130, gap_hist_6=60, gap_hist_7=20, gap_hist_8=20,
        gap_hist_9=10, gap_hist_10=10, gap_hist_15=10, gap_hist_20=3,
        gap_hist_30=13, gap_hist_60=13, gap_hist_over=28,
        # 28 long gaps averaging ~13.5h each (weekends + overnights) => the money.
        gap_over_minutes=int(28 * 13.5 * 60),
    )
    finding = WarehouseAutoStopServerlessRule().score(row, _ctx())
    assert finding is not None
    tiers = finding.evidence["viz"]["tiers"]
    assert tiers["enable"] is not None
    assert tiers["enable"]["from_minutes"] is None  # was OFF
    assert tiers["enable"]["to_minutes"] == 60
    enable_usd = tiers["enable"]["monthly_savings_usd"]
    tighten_usd = tiers["tighten"]["monthly_savings_usd"]
    assert enable_usd > tighten_usd, (enable_usd, tighten_usd)
    # The copy must lead with turning auto-stop ON, not with the short setting.
    assert "turning auto-stop ON" in finding.why or "never stops" in finding.why
    assert "Turn on auto-stop" in finding.how
    # And the total must still never exceed billed cost.
    assert finding.monthly_savings_usd <= finding.evidence["cost_30d_usd"]


def test_no_enable_tier_when_autostop_already_short():
    # Already at 30 min (below the 60-min baseline): nothing to "enable", the whole
    # saving is the tighten tier, and the copy uses the plain single-lever wording.
    finding = WarehouseAutoStopServerlessRule().score(_row(auto_stop=30), _ctx())
    assert finding is not None
    tiers = finding.evidence["viz"]["tiers"]
    assert tiers["enable"] is None
    assert "Turn on auto-stop" not in finding.how


def test_dow_hour_matrix_carried_for_the_heatmap():
    finding = WarehouseAutoStopServerlessRule().score(_row(), _ctx())
    viz = finding.evidence["viz"]
    assert len(viz["queries_by_dow_hour"]) == 168
    # Weekends (dow 5,6) must be empty in the fixture; weekdays populated.
    m = viz["queries_by_dow_hour"]
    assert sum(m[5 * 24:7 * 24]) == 0
    assert sum(m[0:5 * 24]) > 0


def test_choose_respects_the_extra_stop_budget():
    # 500 gaps of ~7 min plus a few long ones. Settings BELOW 7 would restart on
    # all 500 of those gaps — far past the budget — so they must be rejected, and
    # the chosen value must sit at or above the gap cluster it has to tolerate.
    hist = {7: 500, 1440: 5}
    chosen, analysis = choose_serverless_autostop(
        gap_histogram=hist, current_autostop_min=10, lookback_days=30,
        max_extra_stops_per_day=1,
    )
    by_min = {c["minutes"]: c for c in analysis["candidates"]}
    for m in (5, 6):
        assert by_min[m]["extra_stops"] == 500
        assert by_min[m]["extra_stops_per_day"] > 1
        assert by_min[m]["acceptable"] is False
    # It still finds the value that reclaims the long-gap idle without churning.
    assert chosen is not None and chosen >= 7
    assert by_min[chosen]["extra_stops"] == 0


def test_choose_credits_reclaim_only_beyond_the_new_setting():
    # One 60-min gap, current setting 30 min: dropping to 10 reclaims the 20 min
    # the 30-min setting held open beyond it, and adds no restart (the gap already
    # exceeded today's setting, so the warehouse already stopped in it).
    chosen, analysis = choose_serverless_autostop(
        gap_histogram={60: 1}, current_autostop_min=30, lookback_days=30,
        min_minutes=10, max_minutes=10,
    )
    assert chosen == 10
    c = analysis["chosen"]
    assert c["reclaimed_min"] == 20.0
    assert c["extra_stops"] == 0


def test_band_floors_at_the_enable_tier_when_warehouse_never_stops():
    # A warehouse with NO auto-stop: the conservative floor is the near-zero-churn
    # reclaim from simply enabling it at the safe baseline; the point/high is the
    # full proposed short setting (docs/SAVINGS_CONFIDENCE_MODEL.md).
    finding = WarehouseAutoStopServerlessRule().score(_row(auto_stop=None), _ctx())
    assert finding is not None
    assert finding.monthly_savings_low_usd < finding.monthly_savings_usd
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd
    assert "turning auto-stop on" in finding.evidence["savings_range_basis"]


def test_band_collapses_for_a_comfortable_already_stopping_warehouse():
    # Already stops at 30 min and tightening is low-churn: the figure is measured
    # with little dollar uncertainty, so the band stays collapsed (no range shown).
    finding = WarehouseAutoStopServerlessRule().score(_row(auto_stop=30), _ctx())
    assert finding is not None
    assert finding.monthly_savings_low_usd == finding.monthly_savings_usd
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd
    assert "savings_range_basis" not in finding.evidence


def test_sql_targets_serverless_only_and_no_workspace_filter():
    sql = WarehouseAutoStopServerlessRule().render_sql(_ctx())
    assert "system.compute.warehouses" in sql
    assert "query.history" in sql
    assert "warehouse_type = 'SERVERLESS'" in sql
    assert "workspace_id IN" not in sql
    # The gap histogram is what makes the per-warehouse choice possible.
    assert "gap_hist_5" in sql and "gap_hist_10" in sql
