from __future__ import annotations

from finops_rules.catalog.unpruned_repeated_queries import (
    UnprunedRepeatedQueriesRule,
    classify_shape,
)
from finops_rules.contract import EffortBand, RuleContext, RulePriority

_T = {
    "enabled": True,
    "min_executions": 20,
    "min_shape_days": 3,
    "max_prune_ratio": 0.1,
    "min_avg_read_files": 20,
    "min_avg_read_gb": 1.0,
    "min_uncached_runs_per_day": 4,
    "max_shapes": 25,
    "top_shapes_shown": 5,
    "min_shape_usd": 10,
    "min_addressable_usd": 25,
}


def _ctx(**over) -> RuleContext:
    return RuleContext(thresholds={**_T, **over}, lookback_days=30, catalog="system")


def _unpruned_shape(**over) -> dict:
    # A dashboard refreshing ~100x/day, reading ~500 files / 2 GB per run, 1% pruned.
    s = {
        "kind": "dashboard",
        "key": "dash-1",
        "executions": 3000,
        "shape_days": 30,
        "cache_hits": 0,
        "scans": 3000,
        "read_files": 1_500_000,
        "pruned_files": 15_000,
        "read_bytes": 6_000e9,
        "task_ms": 600_000.0,
        "distinct_texts": 0,
        "sample_text": None,
        "nondeterministic_text": 0,
    }
    s.update(over)
    return s


def _uncached_shape(**over) -> dict:
    # The identical query 50x/day, small scan, never a cache hit.
    s = {
        "kind": "text",
        "key": "abc123",
        "executions": 1500,
        "shape_days": 30,
        "cache_hits": 0,
        "scans": 1500,
        "read_files": 3000,
        "pruned_files": 3000,
        "read_bytes": 15e9,
        "task_ms": 200_000.0,
        "distinct_texts": 1,
        "sample_text": "select count(*) from sales.orders where ts > now() - interval ? hours",
        "nondeterministic_text": 1,
    }
    s.update(over)
    return s


def _row(shapes=None, **over) -> dict:
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "bi-warehouse",
        "warehouse_type": "PRO",
        "warehouse_size": "MEDIUM",
        "queries": 10_000,
        "observed_days": 30,
        "total_task_ms": 1_000_000.0,
        "candidate_shapes": 2,
        "shapes": [_unpruned_shape(), _uncached_shape()] if shapes is None else shapes,
        "cost_30d_usd": 2000.0,
        "dbus_30d": 2857.0,
        "unpriced_dbus": 0.0,
    }
    row.update(over)
    return row


def test_flags_both_patterns_as_advisory():
    f = UnprunedRepeatedQueriesRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse" and f.resource_id == "wh-1"
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    # 60% + 20% of task time on a $2,000/mo warehouse.
    assert f.monthly_waste_usd == 1600.0
    ev = f.evidence
    assert ev["addressable_monthly_usd"] == 1600.0
    assert ev["unpruned_shapes"] == 1 and ev["uncached_shapes"] == 1
    assert ev["primary_pattern"] == "unpruned"
    assert ev["confidence"] == "medium"
    assert ev["top_shapes"][0]["key"] == "dash-1"  # ranked by $
    assert f.priority == RulePriority.HIGH
    assert f.effort == EffortBand.MEDIUM
    assert "CLUSTER BY" in f.how
    assert "now()" in f.how
    assert "not a saving" in f.why


def test_rule_flags():
    r = UnprunedRepeatedQueriesRule()
    assert r.experimental is False  # promoted out of Labs 2026-09-23 (still advisory)
    assert r.default_savings_status == "advisory"
    assert r.contract_pricing == "none"
    assert r.cloud_savings == "none"


def test_insufficient_history_suppresses():
    assert UnprunedRepeatedQueriesRule().score(_row(observed_days=2), _ctx()) is None


def test_underpriced_suppresses():
    assert UnprunedRepeatedQueriesRule().score(_row(unpriced_dbus=2000.0), _ctx()) is None


def test_well_pruned_shape_is_not_flagged():
    shape = _unpruned_shape(pruned_files=1_500_000)  # 50% pruned
    assert classify_shape(shape, _T) is None


def test_small_table_or_small_scan_is_not_flagged():
    # 5 files per run: a tiny table cannot prune.
    assert classify_shape(_unpruned_shape(read_files=15_000, pruned_files=0), _T) is None
    # 0.1 GB per run: not worth a layout change.
    assert classify_shape(_unpruned_shape(read_bytes=300e9), _T) is None


def test_no_file_scan_is_never_unpruned():
    s = _unpruned_shape(read_files=0, pruned_files=0, read_bytes=0)
    assert classify_shape(s, _T) is None


def test_cache_check_needs_identical_query():
    # Several different texts behind one normalized shape: not identical.
    assert classify_shape(_uncached_shape(distinct_texts=3), _T) is None
    # A dashboard pools several datasets, so "never cached" says nothing.
    assert classify_shape(_uncached_shape(kind="dashboard", distinct_texts=0), _T) is None
    # A saved query or alert is one query.
    assert classify_shape(_uncached_shape(kind="alert", distinct_texts=0), _T)["pattern"] == "uncached"


def test_cache_hits_or_rare_runs_are_not_uncached():
    assert classify_shape(_uncached_shape(cache_hits=5), _T) is None
    # 60 runs over 30 days = 2/day: tables likely change between runs.
    assert classify_shape(_uncached_shape(executions=60, scans=60), _T) is None


def test_repeat_and_day_thresholds():
    assert classify_shape(_unpruned_shape(executions=10), _T) is None
    assert classify_shape(_unpruned_shape(shape_days=2), _T) is None


def test_unpruned_wins_and_keeps_cache_flag():
    c = classify_shape(_unpruned_shape(kind="alert"), _T)
    assert c["pattern"] == "unpruned" and c["also_uncached"] is True


def test_uncached_only_is_low_confidence_and_names_alert_schedule():
    shapes = [_uncached_shape(kind="alert", key="al-9", distinct_texts=0, nondeterministic_text=0)]
    f = UnprunedRepeatedQueriesRule().score(_row(shapes=shapes), _ctx())
    assert f is not None
    assert f.evidence["primary_pattern"] == "uncached"
    assert f.evidence["confidence"] == "low"
    assert "al-9" in f.how and "less" in f.how
    assert f.monthly_waste_usd == 400.0
    assert f.priority == RulePriority.MEDIUM


def test_floors_suppress_small_spend():
    # $2,000/mo x 0.4% = $8 < the $10 per-shape floor.
    shapes = [_unpruned_shape(task_ms=4_000.0)]
    assert UnprunedRepeatedQueriesRule().score(_row(shapes=shapes), _ctx()) is None
    # Per-warehouse floor.
    shapes = [_unpruned_shape(task_ms=10_000.0)]  # $20
    assert UnprunedRepeatedQueriesRule().score(_row(shapes=shapes), _ctx()) is None
    assert UnprunedRepeatedQueriesRule().score(
        _row(shapes=shapes), _ctx(min_addressable_usd=15)
    ) is not None


def test_no_qualifying_shapes_or_zero_cost():
    assert UnprunedRepeatedQueriesRule().score(_row(shapes=[]), _ctx()) is None
    assert UnprunedRepeatedQueriesRule().score(_row(cost_30d_usd=0.0), _ctx()) is None
    assert UnprunedRepeatedQueriesRule().score(_row(total_task_ms=0.0), _ctx()) is None


def test_addressable_bounded_by_warehouse_cost():
    # Shapes summing to more than the warehouse's task time (data skew) never exceed cost.
    shapes = [_unpruned_shape(task_ms=900_000.0), _unpruned_shape(key="dash-2", task_ms=900_000.0)]
    f = UnprunedRepeatedQueriesRule().score(_row(shapes=shapes), _ctx())
    assert f.monthly_waste_usd <= 2000.0


def test_text_label_uses_normalized_sample():
    f = UnprunedRepeatedQueriesRule().score(_row(shapes=[_uncached_shape()]), _ctx())
    assert "select count(*) from sales.orders" in f.why


def test_sql_renders_without_workspace_filter_or_qualify():
    sql = UnprunedRepeatedQueriesRule().render_sql(_ctx())
    assert "QUALIFY" not in sql.upper()
    assert "workspace_id =" not in sql
    assert "<REDACTED>" in sql  # redacted text is detected, not fingerprinted


def test_shapes_are_charted_as_ranked_bars():
    f = UnprunedRepeatedQueriesRule().score(_row(), _ctx())
    v = f.evidence["viz"]
    assert v["kind"] == "ranked_bars" and v["unit"] == "$/mo"
    assert [r["value"] for r in v["rows"]] == sorted((r["value"] for r in v["rows"]), reverse=True)
    assert all(r["color"] in ("warn", "violet") for r in v["rows"])
