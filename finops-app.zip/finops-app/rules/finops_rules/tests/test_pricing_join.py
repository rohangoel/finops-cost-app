"""The list_prices join is a correctness invariant, enforced across ALL rules.

Two defects lived in 14 copy-pasted joins (see sql/_macros.sql.j2):

* joining on ``sku_name`` alone, which fans out — and so inflates dollars — as
  soon as an account bills more than one cloud or currency;
* reading ``pricing.default`` instead of ``pricing.effective_list.default``,
  measured on a real account as a **5.54% (~$37k/30d) overstatement** because
  promotional pricing was ignored.

These tests assert the property for every registered rule rather than for the
handful that existed when the fix landed, so a new rule that hand-rolls its own
join (or a future copy-paste of the old shape) fails here instead of shipping
inflated savings. That matters more than usual for this engine: an overstated
cost baseline overstates savings, breaking the invariant that an estimate must
never exceed true avoidable spend.
"""

from __future__ import annotations

import pytest

from finops_rules import get_enabled_rules, list_rules, load_thresholds
from finops_rules.contract import RuleContext
from finops_rules.coverage import (
    MIN_PRICED_FRACTION,
    coverage_evidence,
    coverage_note,
    coverage_supports_booking,
    priced_fraction,
    underpriced,
)

THRESHOLDS = load_thresholds()


def _ctx(rule_id: str, currency: str = "USD") -> RuleContext:
    return RuleContext(
        thresholds=THRESHOLDS.get(rule_id, {}),
        lookback_days=30,
        catalog="system",
        currency=currency,
    )


def _priced_rules():
    """Rules whose SQL actually joins list_prices (all of them today, but the
    filter keeps a future non-priced rule from failing these assertions)."""
    out = []
    for rule in list_rules():
        sql = rule.render_sql(_ctx(rule.id))
        if "billing.list_prices" in sql:
            out.append((rule, sql))
    return out


@pytest.mark.parametrize("rule_id", [r.id for r in list_rules()])
def test_every_rule_sql_renders(rule_id: str):
    """Rendering is what the macro import could plausibly break, so assert it
    separately from the join-shape checks below."""
    rule = next(r for r in list_rules() if r.id == rule_id)
    assert rule.render_sql(_ctx(rule_id)).strip()


def test_no_rule_uses_the_unresolved_price_field():
    """``pricing.default`` ignores promotional pricing and overstates cost."""
    for rule, sql in _priced_rules():
        # effective_list.default legitimately contains the substring "default",
        # so look for the *bare* field access that skips promotional resolution.
        assert "pricing.default" not in sql, f"{rule.id} reads the unresolved list price"
        assert "pricing.effective_list.default" in sql, f"{rule.id} must use effective_list"


def test_every_price_join_is_fully_keyed():
    """list_prices is keyed on (sku_name, cloud, currency_code, usage_unit) plus
    a validity window. Anything less multiplies usage rows in a multi-cloud or
    multi-currency account."""
    for rule, sql in _priced_rules():
        # One join per price-table alias; every one needs all four keys.
        aliases = set()
        for line in sql.splitlines():
            if "billing.list_prices" in line and "LEFT JOIN" in line:
                aliases.add(line.strip().split()[-1])
        assert aliases, f"{rule.id} joins list_prices but no alias was parsed"
        for alias in aliases:
            assert f"{alias}.sku_name" in sql, f"{rule.id}/{alias}: no sku key"
            assert f"{alias}.cloud" in sql, f"{rule.id}/{alias}: no cloud key"
            assert f"{alias}.usage_unit" in sql, f"{rule.id}/{alias}: no usage_unit key"
            assert f"{alias}.currency_code = " in sql, f"{rule.id}/{alias}: no currency key"
            assert f"{alias}.price_start_time" in sql, f"{rule.id}/{alias}: no window"
            assert f"{alias}.price_end_time" in sql, f"{rule.id}/{alias}: no window end"


def test_no_rule_coalesces_a_missed_price_to_zero():
    """``COALESCE(rate, 0)`` turns a pricing gap into a confident $0, shrinking
    reported cost with nothing recording that it happened."""
    for rule, sql in _priced_rules():
        for alias in ("lp", "ap_lp"):
            assert f"COALESCE(CAST({alias}.pricing" not in sql, (
                f"{rule.id} coalesces an unmatched price to 0"
            )


def test_currency_is_configurable_not_hardcoded():
    """A non-USD account must price against its own currency rows, else every
    join misses and every cost silently reads 0. Checked on a rule that actually
    joins list_prices (operational Labs rules — AI gateway, instance pools, Delta
    Sharing, storage — carry no price join, so they are not subject to this)."""
    rule = next(r for r in list_rules() if "billing.list_prices" in r.render_sql(_ctx(r.id)))
    sql = rule.render_sql(_ctx(rule.id, currency="EUR"))
    assert "currency_code = 'EUR'" in sql
    assert "currency_code = 'USD'" not in sql


# --- the coverage guard ----------------------------------------------------

def test_priced_fraction_math():
    assert priced_fraction({"dbus_30d": 100.0, "unpriced_dbus": 0.0}) == 1.0
    assert priced_fraction({"dbus_30d": 100.0, "unpriced_dbus": 25.0}) == 0.75
    assert priced_fraction({"dbus_30d": 100.0, "unpriced_dbus": 100.0}) == 0.0


def test_unknown_coverage_never_blocks_a_finding():
    """A row from an older snapshot has no coverage columns. Unknown coverage is
    not evidence of bad coverage — treating it as such would empty the app the
    moment the schema lagged the code."""
    assert priced_fraction({"dbus_30d": 100.0}) is None
    assert underpriced({"dbus_30d": 100.0}) is False
    assert coverage_note({"dbus_30d": 100.0}) == ""
    assert coverage_evidence({"dbus_30d": 100.0}) == {}


def test_underpriced_suppresses_below_the_floor():
    below = {"dbus_30d": 100.0, "unpriced_dbus": 100.0 * (1 - MIN_PRICED_FRACTION) + 1}
    at = {"dbus_30d": 100.0, "unpriced_dbus": 100.0 * (1 - MIN_PRICED_FRACTION)}
    assert underpriced(below) is True
    assert underpriced(at) is False


def test_fully_priced_rows_add_no_evidence_noise():
    """The common case (everything priced) must not add keys or prose."""
    row = {"dbus_30d": 100.0, "unpriced_dbus": 0.0}
    assert coverage_evidence(row) == {}
    assert coverage_note(row) == ""


def test_partial_coverage_is_reported_as_a_lower_bound():
    row = {"dbus_30d": 100.0, "unpriced_dbus": 10.0}
    note = coverage_note(row)
    assert "10%" in note and "lower bound" in note
    assert coverage_evidence(row) == {"unpriced_dbus": 10.0, "priced_fraction": 0.9}


def test_zero_dbu_row_is_not_reported_as_zero_percent_priced():
    """No usage means the ratio is undefined, not 0% — otherwise a resource with
    no billed DBUs would be suppressed as 'underpriced' rather than simply
    having nothing to save."""
    assert priced_fraction({"dbus_30d": 0.0, "unpriced_dbus": 0.0}) == 1.0
    assert underpriced({"dbus_30d": 0.0, "unpriced_dbus": 0.0}) is False


# --- FIN-004: booking coverage fails CLOSED ---------------------------------

def test_booking_requires_known_adequate_coverage():
    """coverage_supports_booking gates the BOOKED headline and must fail closed:
    only known, adequate coverage may book. This is the mirror image of
    underpriced() (which fails open, governing visibility only)."""
    fully = {"dbus_30d": 100.0, "unpriced_dbus": 0.0}
    partial = {"dbus_30d": 100.0, "unpriced_dbus": 30.0}          # 70% < 80% floor
    assert coverage_supports_booking(fully) is True
    assert coverage_supports_booking(partial) is False


def test_unknown_coverage_never_books_even_though_it_stays_visible():
    """The key FIN-004 property: an old snapshot with no coverage columns is still
    SHOWN (underpriced is False) but must NOT be booked (coverage_supports_booking
    is False) — absent price data is unknown, not a proven full price."""
    unknown = {"dbus_30d": 100.0}  # no unpriced_dbus column at all
    assert underpriced(unknown) is False           # visible
    assert coverage_supports_booking(unknown) is False  # but never booked


def test_booking_coverage_reads_custom_unit_keys():
    """A rule that aggregates over its own window (idle_serving_endpoints emits
    dbus_window / unpriced_window) can be measured with the same guard."""
    row = {"dbus_window": 200.0, "unpriced_window": 0.0}
    assert coverage_supports_booking(
        row, dbu_key="dbus_window", unpriced_key="unpriced_window"
    ) is True
    row_bad = {"dbus_window": 200.0, "unpriced_window": 150.0}
    assert coverage_supports_booking(
        row_bad, dbu_key="dbus_window", unpriced_key="unpriced_window"
    ) is False
