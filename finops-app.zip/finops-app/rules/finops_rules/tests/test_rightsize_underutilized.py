from __future__ import annotations

from finops_rules.catalog.rightsize_underutilized import RightsizeUnderutilizedRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"cpu_headroom_pct": 40, "mem_bound_pct": 85, "mem_headroom_pct": 40},
        lookback_days=30,
        catalog="system",
    )


def _oversized_row() -> dict:
    """A costly multi-worker cluster running well below CPU headroom, whose p95
    peak (30%) is still low enough to shrink into with headroom."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-big",
        "cluster_name": "analytics-xl",
        "worker_count": 8,
        "avg_cpu": 15.0,
        "avg_mem": 22.0,
        "p95_cpu": 0.30,
        "cost_30d_usd": 4000.0,
    }


def _busy_row() -> dict:
    """A cluster using plenty of CPU/mem => not a right-size candidate."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-hot",
        "cluster_name": "ml-training",
        "worker_count": 8,
        "avg_cpu": 70.0,
        "avg_mem": 65.0,
        "p95_cpu": 0.85,
        "cost_30d_usd": 9000.0,
    }


def test_flags_oversized_cluster_with_savings():
    finding = RightsizeUnderutilizedRule().score(_oversized_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-big"
    assert finding.resource_name == "analytics-xl"
    assert finding.effort == EffortBand.MEDIUM
    assert finding.priority == RulePriority.MEDIUM
    # Peak-based (FIN-016): keep_fraction = 0.30*1.15/0.6 = 0.575, so the saving is
    # (1 - 0.575) = 0.425 of ~$4000/mo => ~$1700/mo, and 8 workers -> ceil(8*0.575)=5.
    assert abs(finding.monthly_savings_usd - 1700.0) < 1.0
    assert "15.0" in finding.why  # cites avg cpu
    assert "30%" in finding.why  # cites the p95 peak that sets the target
    assert "8" in finding.why and "5" in finding.why  # current -> candidate workers
    assert finding.evidence["worker_count"] == 8
    assert finding.evidence["target_workers"] == 5
    assert finding.evidence["confidence"] == "medium"
    assert "proxy" in finding.evidence["data_basis"]
    assert "memory" in finding.why.lower()


def test_suppresses_bursty_cluster_whose_peak_needs_the_size():
    # Low AVERAGE CPU (15%, so it clears the entry gate) but a high p95 peak (55%):
    # shrinking would starve the peak the cluster exists to serve. keep_fraction =
    # 0.55*1.15/0.6 = 1.05 -> clamped to 1.0 -> target == current -> no finding.
    # This is the central bug the old flat-30% haircut had: it would have booked
    # ~$1200/mo here regardless of the peak.
    row = _oversized_row()
    row["p95_cpu"] = 0.55
    assert RightsizeUnderutilizedRule().score(row, _ctx()) is None


def test_cpu_area_viz_carries_time_axis_and_idle():
    row = _oversized_row()
    row["cpu_hourly"] = [0.08, 0.05, 0.2, 0.06]
    row["cpu_ts"] = [1_700_000_000, 1_700_003_600, 1_700_007_200, 1_700_010_800]
    row["idle_frac"] = [0.9, 1.0, 0.1, 0.95]
    row["p95_cpu"] = 0.2
    viz = RightsizeUnderutilizedRule().score(row, _ctx()).evidence["viz"]
    assert viz["kind"] == "cpu_area"
    assert viz["ts"] == row["cpu_ts"]  # real dated x-axis
    assert viz["idle_frac"] == [0.9, 1.0, 0.1, 0.95]  # idle shading per hour
    assert viz["idle_threshold"] == 0.1
    # timestamps/idle only survive when they align 1:1 with the cpu samples
    bad = _oversized_row()
    bad["cpu_hourly"] = [0.1, 0.2]
    bad["cpu_ts"] = [1_700_000_000]
    viz2 = RightsizeUnderutilizedRule().score(bad, _ctx()).evidence["viz"]
    assert "ts" not in viz2


def test_suppresses_busy_cluster():
    # High CPU and memory => not oversized.
    assert RightsizeUnderutilizedRule().score(_busy_row(), _ctx()) is None


def test_flags_cpu_idle_cluster_with_resident_heap():
    # A CPU-idle JVM cluster holds heap resident: 5% CPU but 60% memory. This is
    # the real single-node/idle case the old `AND avg_mem < 40` gate hid — memory
    # is now a one-way veto (only >= mem_bound_pct), so it must still fire.
    row = _oversized_row()
    row["avg_cpu"] = 5.0
    row["avg_mem"] = 60.0
    finding = RightsizeUnderutilizedRule().score(row, _ctx())
    assert finding is not None
    assert finding.resource_id == "c-big"


def test_suppresses_memory_bound_cluster():
    # CPU idle but memory genuinely high (>= mem_bound_pct): shrinking risks
    # OOM/spill, so do NOT recommend a downsize.
    row = _oversized_row()
    row["avg_cpu"] = 5.0
    row["avg_mem"] = 90.0
    assert RightsizeUnderutilizedRule().score(row, _ctx()) is None


def test_suppresses_on_high_p95_memory_even_when_average_is_low():
    # Average memory is comfortable (22%) but the p95 PEAK is 90% (0.90 fraction):
    # fewer workers would concentrate that peak onto fewer nodes, so the peak-aware
    # veto must fire even though avg_mem alone would not.
    row = _oversized_row()
    row["avg_cpu"] = 5.0
    row["p95_mem"] = 0.90
    assert RightsizeUnderutilizedRule().score(row, _ctx()) is None


def test_suppresses_when_no_cost():
    row = _oversized_row()
    row["cost_30d_usd"] = 0
    assert RightsizeUnderutilizedRule().score(row, _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = RightsizeUnderutilizedRule().render_sql(_ctx())
    assert "system.compute.clusters" in sql
    assert "system.compute.node_timeline" in sql
    assert "workspace_id IN" not in sql  # scoping is injected later, not here
