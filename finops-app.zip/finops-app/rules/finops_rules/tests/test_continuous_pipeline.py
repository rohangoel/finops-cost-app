"""Continuous DLT pipelines: price the idle hours, and only the idle hours.

Pipelines were the largest completely-unruled slice of spend (verified live: 359
DLT pipelines, ~$16.4k/mo; 3 continuous ones carried 72% of it). The rule's claim
is unusually strong for this catalog because both sides are COUNTED rather than
inferred — billed hours from billing.usage, active hours from the update timeline —
and it was checked that idle hours really do cost full rate (5.82 DBU/h idle vs
5.69 DBU/h active on the top live candidate).

What must hold: never claim the active-hours cost, never fire on a genuinely
streaming pipeline, and never fire on a development pipeline (whose warm compute is
the point).
"""

from __future__ import annotations

import pytest

from finops_rules import load_thresholds
from finops_rules.catalog.continuous_pipeline import ContinuousPipelineRule
from finops_rules.contract import RuleContext
from finops_rules.savings import continuous_pipeline_savings

THRESHOLDS = load_thresholds()["continuous_pipeline"]


def _ctx(**over) -> RuleContext:
    return RuleContext(
        thresholds={**THRESHOLDS, **over.pop("thresholds", {})},
        lookback_days=over.pop("lookback_days", 30),
        catalog="system",
        currency="USD",
        min_observation_days=over.pop("min_observation_days", 5),
    )


def _row(**over) -> dict:
    """Shaped on the real top candidate: 729 billed hours, 99 active."""
    row = {
        "workspace_id": "111",
        "pipeline_id": "p-abc",
        "pipeline_name": "cdp-streaming-gtm",
        "is_continuous": True,
        "is_development": False,
        "is_serverless": True,
        "is_photon": True,
        "edition": "ADVANCED",
        "run_as": "svc@example.com",
        "cost_30d_usd": 1905.07,
        "dbus_30d": 4200.0,
        "unpriced_dbus": 0.0,
        "billed_hours": 729,
        "observed_days": 31,
        "active_hours": 99,
        "idle_hours": 630,
        "updates_30d": 108,
        "requests_30d": 108,
        "failed_updates": 0,
        "active_days": 27,
        "avg_update_minutes": 12.5,
        "last_update_end": None,
    }
    row.update(over)
    return row


# --- the savings model -----------------------------------------------------

def test_savings_are_bounded_to_the_idle_share():
    """The active-hours cost is work that still runs after the change, so it can
    never appear in the estimate."""
    savings, idle = continuous_pipeline_savings(
        billed_hours=100, active_hours=20, monthly_cost=1000.0,
        startup_overhead_frac=0.0,
    )
    assert idle == 80.0
    assert savings == 800.0  # exactly the idle 80%, never more


def test_startup_overhead_is_subtracted():
    """A triggered pipeline pays to start compute per run, so some of the reclaimed
    idle cost is given back."""
    full, _ = continuous_pipeline_savings(
        billed_hours=100, active_hours=0, monthly_cost=1000.0,
        startup_overhead_frac=0.0,
    )
    discounted, _ = continuous_pipeline_savings(
        billed_hours=100, active_hours=0, monthly_cost=1000.0,
        startup_overhead_frac=0.15,
    )
    assert discounted < full
    assert discounted == pytest.approx(850.0)


def test_a_fully_busy_pipeline_saves_nothing():
    assert continuous_pipeline_savings(
        billed_hours=100, active_hours=100, monthly_cost=1000.0
    ) == (0.0, 0.0)


def test_savings_never_exceed_the_monthly_cost():
    """The engine's core invariant: an estimate must never exceed true avoidable
    spend, and total spend is the hard ceiling."""
    savings, _ = continuous_pipeline_savings(
        billed_hours=729, active_hours=0, monthly_cost=1905.07,
        startup_overhead_frac=0.0,
    )
    assert savings <= 1905.07


def test_active_hours_exceeding_billed_hours_does_not_go_negative():
    """An update straddling an hour boundary can be counted in an hour carrying no
    usage row, which would otherwise produce negative idle time."""
    savings, idle = continuous_pipeline_savings(
        billed_hours=10, active_hours=15, monthly_cost=100.0
    )
    assert idle == 0.0
    assert savings == 0.0


def test_zero_cost_or_zero_hours_is_safe():
    assert continuous_pipeline_savings(
        billed_hours=0, active_hours=0, monthly_cost=100.0
    ) == (0.0, 0.0)
    assert continuous_pipeline_savings(
        billed_hours=100, active_hours=0, monthly_cost=0.0
    ) == (0.0, 0.0)


# --- suppression guards ----------------------------------------------------

def test_a_genuinely_streaming_pipeline_is_not_flagged():
    """If updates cover most of the billed window, continuous is CORRECT and
    switching would break the latency requirement the pipeline exists to meet."""
    row = _row(billed_hours=729, active_hours=700, idle_hours=29)
    assert ContinuousPipelineRule().score(row, _ctx()) is None


def test_cheap_pipeline_is_suppressed():
    """Below the floor the switch is not worth the conversation with its owner."""
    row = _row(cost_30d_usd=40.0)
    assert ContinuousPipelineRule().score(row, _ctx()) is None


def test_new_pipeline_is_suppressed():
    """One day's idle share says nothing about the month."""
    assert ContinuousPipelineRule().score(_row(observed_days=2), _ctx()) is None


def test_mostly_unpriced_pipeline_is_suppressed():
    row = _row(dbus_30d=4200.0, unpriced_dbus=4000.0)
    assert ContinuousPipelineRule().score(row, _ctx()) is None


def test_idle_threshold_is_configurable():
    row = _row(billed_hours=100, active_hours=40, idle_hours=60)  # 60% idle
    assert ContinuousPipelineRule().score(row, _ctx()) is not None
    strict = _ctx(thresholds={"min_idle_hours_frac": 0.8})
    assert ContinuousPipelineRule().score(row, strict) is None


# --- the finding -----------------------------------------------------------

def test_finding_reports_measured_hours_and_conservative_savings():
    finding = ContinuousPipelineRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "pipeline"
    # 630/729 idle = 86%, times cost, less the startup overhead. The fixture is
    # serverless, so it uses the 5% serverless overhead (SME review), not 15%.
    assert finding.monthly_savings_usd == pytest.approx(1564.0, abs=1.0)
    assert finding.monthly_savings_usd < finding.monthly_waste_usd
    assert finding.evidence["idle_hours"] == 630.0
    assert finding.evidence["active_hours"] == 99.0
    assert finding.evidence["idle_pct"] == pytest.approx(86.4, abs=0.2)
    assert finding.evidence["startup_overhead_frac"] == 0.05


def test_startup_overhead_by_compute_type():
    """SME review: serverless DLT starts in seconds, so it is charged a smaller
    startup overhead (5%) than classic compute (15%), yielding a larger saving for
    the same idle share."""
    serverless = ContinuousPipelineRule().score(_row(is_serverless=True), _ctx())
    classic = ContinuousPipelineRule().score(_row(is_serverless=False), _ctx())
    assert serverless is not None and classic is not None
    assert serverless.evidence["startup_overhead_frac"] == 0.05
    assert classic.evidence["startup_overhead_frac"] == 0.15
    # Less overhead given back => serverless keeps more of the reclaimed idle cost.
    assert serverless.monthly_savings_usd > classic.monthly_savings_usd


def test_cadence_aware_overhead_raises_for_a_frequently_triggered_classic_pipeline():
    """SME review round 2, finding #9: a large, frequently-triggered CLASSIC pipeline
    pays more per-run start-up than the flat 15% floor, so the effective overhead rises
    (savings fall). Overhead can only ever RISE above the floor, never drop below it."""
    # Classic, many updates over a modest idle window => cadence overhead > 15% floor.
    row = _row(
        is_serverless=False,
        billed_hours=700, active_hours=100, idle_hours=600,
        updates_30d=4000,   # very churny: 4000 x 7 min = 28000 startup-min
    )
    finding = ContinuousPipelineRule().score(row, _ctx())
    assert finding is not None
    # 4000*7 / (600*60) = 0.778 >> 0.15 floor.
    assert finding.evidence["startup_overhead_frac"] > 0.15
    assert finding.evidence["startup_overhead_floor"] == 0.15
    # A gently-triggered classic pipeline keeps the floor (cadence overhead is tiny).
    calm = ContinuousPipelineRule().score(
        _row(is_serverless=False, billed_hours=700, active_hours=100,
             idle_hours=600, updates_30d=50),
        _ctx(),
    )
    assert calm.evidence["startup_overhead_frac"] == 0.15
    # And the churny pipeline's saving is strictly lower for the same spend/idle share.
    assert finding.monthly_savings_usd < calm.monthly_savings_usd


def test_why_states_the_latency_trade_off_and_the_cadence():
    """Switching to triggered changes data freshness, so the reader needs the
    measured cadence to judge it — not just a dollar figure."""
    finding = ContinuousPipelineRule().score(_row(), _ctx())
    assert "CONTINUOUS" in finding.why
    assert "update" in finding.why.lower()
    assert "latency" in finding.how.lower()
    # And it must name who to ask rather than telling an admin to just flip it.
    assert "owner" in finding.how.lower()


def test_priority_tracks_recoverable_spend():
    big = ContinuousPipelineRule().score(_row(), _ctx())
    small = ContinuousPipelineRule().score(
        _row(cost_30d_usd=150.0, billed_hours=729, active_hours=99), _ctx()
    )
    assert big.priority.value == "HIGH"
    assert small.priority.value in ("LOW", "MEDIUM")


def test_confidence_is_high_because_both_sides_are_counted():
    finding = ContinuousPipelineRule().score(_row(), _ctx())
    assert finding.evidence["confidence"] == "high"
    assert "COUNTED" in finding.evidence["data_basis"]


def test_heatmap_carries_pipeline_context():
    row = _row(hourly_states=([1] * 4 + [2] * 16 + [0] * 4) * 7)
    finding = ContinuousPipelineRule().score(row, _ctx())
    assert finding is not None
    assert finding.evidence["viz"]["kind"] == "hour_heatmap"
    assert finding.evidence["viz"]["context"] == "pipeline"


# --- SQL shape -------------------------------------------------------------

def test_sql_only_considers_continuous_non_development_pipelines():
    sql = ContinuousPipelineRule().render_sql(_ctx())
    # NULL is not "true": treating it so would flag triggered pipelines, whose
    # compute already stops between updates, for a $0 change.
    assert "COALESCE(p.is_continuous, FALSE) = TRUE" in sql
    assert "COALESCE(p.is_development, FALSE) = FALSE" in sql


def test_sql_excludes_deleted_pipelines_and_applies_corrections():
    """FIN-006: the current pipeline row is selected by ranking ALL versions and
    then keeping ``rn = 1 AND delete_time IS NULL`` — never by filtering
    ``delete_time`` before the ranking (which would resurrect an older live
    version of a since-deleted pipeline).
    FIN-003: billing.usage is an additive ledger, so cost sums must include every
    ``record_type`` (a RETRACTION cancels the superseded ORIGINAL). The old
    ``record_type = 'ORIGINAL'`` filter kept stale spend and dropped its
    correction, so it must be gone."""
    sql = ContinuousPipelineRule().render_sql(_ctx())
    assert "rn = 1 AND delete_time IS NULL" in sql
    assert "record_type = 'ORIGINAL'" not in sql
    assert "record_type = \"ORIGINAL\"" not in sql


def test_sql_counts_both_billed_and_active_hours():
    """The whole rule rests on comparing these two, from two different tables."""
    sql = ContinuousPipelineRule().render_sql(_ctx())
    assert "billed_hours" in sql and "active_hours" in sql
    assert "billing.usage" in sql
    assert "lakeflow.pipeline_update_timeline" in sql


def test_sql_floors_idle_hours_at_zero():
    sql = ContinuousPipelineRule().render_sql(_ctx())
    assert "GREATEST(c.billed_hours - COALESCE(asp.active_hours, 0), 0)" in sql


def test_sql_active_hours_explodes_the_update_span_not_start_hours():
    """Regression: a 100-hour update occupies 100 hourly cells, not 1.

    The original SQL derived active_hours as
    ``COUNT(DISTINCT date_trunc('HOUR', period_start_time))`` — the hours in which
    an update STARTED. For a continuous pipeline that runs long, back-to-back
    updates around the clock (measured live: 721 of 732 billed hours active off
    only ~9 update starts) that undercounts active hours ~15x, so a genuinely busy
    pipeline reads as ~94% idle and gets flagged for a bogus five-figure 'saving'.
    active_hours must be counted by EXPLODING each update across every hour it
    spans, so it is directly comparable to billed_hours."""
    sql = ContinuousPipelineRule().render_sql(_ctx())
    # The active-hours count must explode the update span over its start..end range.
    assert "active_span" in sql
    assert "explode(sequence(" in sql
    assert "date_trunc('HOUR', t.period_end_time)" in sql
    # And it must NOT be derived from start hours alone (the original bug).
    assert "COUNT(DISTINCT date_trunc('HOUR', t.period_start_time)) AS active_hours" not in sql


def test_sql_has_no_workspace_filter():
    assert "workspace_id IN" not in ContinuousPipelineRule().render_sql(_ctx())
