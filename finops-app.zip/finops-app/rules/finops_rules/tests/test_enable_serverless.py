from __future__ import annotations

from finops_rules.catalog.enable_serverless import EnableServerlessRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import serverless_migration_savings, summarize_hourly_states


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"min_monthly_cost_usd": 300},
        lookback_days=30,
        catalog="system",
    )


def _series(active_h: int, idle_h: int, days: int = 14) -> list[int]:
    """Classic warm pool: warm all day (active hours + idle-warm hours)."""
    return ([1] * active_h + [2] * idle_h) * days


def _row(states, cost=1000.0, warehouse_type="CLASSIC") -> dict:
    return {
        "workspace_id": "111",
        "warehouse_id": "w-abc",
        "warehouse_name": "classic-sql",
        "warehouse_type": warehouse_type,
        "cost_30d_usd": cost,
        "hourly_states": states,
        "avg_cold_start_s": 12.0,
    }


def test_flags_costly_bursty_warehouse():
    states = _series(active_h=4, idle_h=20)  # mostly idle warm pool
    finding = EnableServerlessRule().score(_row(states), _ctx())
    assert finding is not None
    assert finding.resource_type == "warehouse"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    assert "serverless" in finding.how.lower()
    # Savings must equal the shared migration math exactly (classic tier rate).
    agg = summarize_hourly_states(states)
    expected = serverless_migration_savings(
        warm_hours=agg["warm_hours"], idle_warm_hours=agg["idle_warm_hours"],
        monthly_cost=1000.0, tier_dbu_rate=0.22)
    assert finding.monthly_savings_usd == expected.net_monthly_savings
    # FIN-013: estimated, not booked — the headline credits an ESTIMATED cloud VM cost.
    assert finding.savings_status == "estimated"
    # The band: low = the MEASURABLE DBU-only net (VM zeroed), high = net incl. the VM.
    dbu_only = serverless_migration_savings(
        warm_hours=agg["warm_hours"], idle_warm_hours=agg["idle_warm_hours"],
        monthly_cost=1000.0, tier_dbu_rate=0.22, est_vm_cost_per_dbu=0.0)
    assert finding.monthly_savings_low_usd == max(0.0, dbu_only.net_monthly_savings)
    assert finding.monthly_savings_high_usd == expected.net_monthly_savings
    assert finding.monthly_savings_low_usd <= finding.monthly_savings_usd <= finding.monthly_savings_high_usd
    # The DBU-only floor is carried in evidence, distinct from the VM-included estimate.
    assert finding.evidence["net_dbu_only_usd"] == dbu_only.net_monthly_savings
    # The estimate is flagged medium (VM cost is estimated, not measured).
    assert finding.evidence["confidence"] == "medium"
    # The estimated all-in cost and the VM estimate are surfaced for the SME.
    assert finding.evidence["all_in_monthly_est_usd"] == expected.all_in_monthly_est
    assert finding.evidence["est_vm_cost_per_dbu"] == 0.22
    # 14-day heatmap over the full window (not a cramped 3-day view).
    assert finding.evidence["viz"]["kind"] == "hour_heatmap"
    assert len(finding.evidence["viz"]["grid"]) == 14


def test_estimated_books_zero_but_keeps_measurable_floor():
    """FIN-013: enable_serverless is estimated (the headline credits an estimated cloud
    VM cost), so it books $0 in the account headline — but the DBU-only floor (low) is
    what the billing data can prove."""
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    f = EnableServerlessRule().score(_row(_series(active_h=4, idle_h=20), warehouse_type="PRO"), _ctx())
    assert f is not None and f.savings_status == "estimated"
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1), rule_id="enable_serverless",
        rule_version="2.0.0", rule_title="t", category="sql", workspace_id="111",
        resource_type="warehouse", resource_id="w-abc", resource_name="n", why="", how="",
        monthly_waste_usd=f.monthly_waste_usd, monthly_savings_usd=f.monthly_savings_usd,
        savings_status="estimated", monthly_savings_low_usd=f.monthly_savings_low_usd,
        monthly_savings_high_usd=f.monthly_savings_high_usd, effort_band="low",
        effort_score=2, priority="MEDIUM", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    # Estimated books $0 in the headline (only bookable lows are booked).
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_active_premium_differs_by_tier():
    # The tier distinction the old flat model missed: moving CLASSIC (0.22/DBU) to
    # serverless (0.70) is a real premium on active hours, while PRO (0.55/DBU) is
    # close enough to serverless that active hours are ~break-even or cheaper. The
    # model must reflect that, not treat both tiers alike.
    states = _series(active_h=4, idle_h=20)
    classic = EnableServerlessRule().score(_row(states, warehouse_type="CLASSIC"), _ctx())
    pro = EnableServerlessRule().score(_row(states, warehouse_type="PRO"), _ctx())
    assert classic is not None and pro is not None
    assert classic.evidence["active_premium_est_usd"] > 0   # serverless costs more on active
    assert pro.evidence["active_premium_est_usd"] < 0       # serverless cheaper on active


def test_suppresses_active_heavy_warehouse():
    # Mostly active: the higher serverless rate on active work outweighs the small
    # idle saving, so the honest model nets out non-positive and we suppress.
    assert EnableServerlessRule().score(_row(_series(20, 4)), _ctx()) is None


def test_pro_gated_lower_than_classic_on_idle():
    # A warehouse ~20% idle clears the pro gate (0.15) but not the classic gate
    # (0.30), so the SAME usage surfaces as pro and is suppressed as classic.
    # This is the tiered idle gate from the SME review: pro migrations are still
    # net-positive at low idle because serverless is ~break-even on pro active hours.
    states = _series(active_h=19, idle_h=5)  # idle fraction ~0.21
    classic = EnableServerlessRule().score(_row(states, warehouse_type="CLASSIC"), _ctx())
    pro = EnableServerlessRule().score(_row(states, warehouse_type="PRO"), _ctx())
    assert classic is None      # below the 0.30 classic gate
    assert pro is not None       # above the 0.15 pro gate
    assert pro.evidence["idle_hours_pct"] < 30.0


def test_vm_cost_varies_by_cloud():
    # Per-cloud VM estimate (SME review): Azure's higher VM add makes the all-in
    # cost — and therefore the reclaimed idle saving — larger than AWS for the same
    # measured DBU bill and usage. The estimate is surfaced so the UI can label it.
    states = _series(active_h=4, idle_h=20)
    ctx = RuleContext(
        thresholds={
            "min_monthly_cost_usd": 300,
            "est_vm_cost_per_dbu": 0.22,
            "est_vm_cost_per_dbu_by_cloud": {"aws": 0.22, "azure": 0.26, "gcp": 0.24},
        },
        lookback_days=30,
        catalog="system",
    )
    aws = EnableServerlessRule().score({**_row(states), "cloud": "aws"}, ctx)
    azure = EnableServerlessRule().score({**_row(states), "cloud": "azure"}, ctx)
    assert aws is not None and azure is not None
    assert aws.evidence["est_vm_cost_per_dbu"] == 0.22
    assert azure.evidence["est_vm_cost_per_dbu"] == 0.26
    # Higher VM estimate => larger all-in idle cost removed => larger saving.
    assert azure.monthly_savings_usd > aws.monthly_savings_usd


def test_suppresses_below_cost_threshold():
    row = _row(_series(4, 20))
    row["cost_30d_usd"] = 100.0  # monthly ~$100 < $300 threshold
    assert EnableServerlessRule().score(row, _ctx()) is None


def test_suppresses_when_no_cost():
    assert EnableServerlessRule().score(_row(_series(4, 20), cost=0), _ctx()) is None


def test_suppresses_when_never_idle():
    # Warm and busy every hour => no idle pool to reclaim, and active-rate premium.
    assert EnableServerlessRule().score(_row(_series(24, 0)), _ctx()) is None


def test_sql_renders_without_workspace_filter_and_is_portable():
    sql = EnableServerlessRule().render_sql(_ctx())
    assert "system.billing.usage" in sql
    assert "workspace_id IN" not in sql
    # FIN-006/portability: the DBSQL-only QUALIFY latest-warehouse select was migrated
    # to the shared rank-then-filter macro (with a delete_time guard) so the hermetic
    # local-Spark gate can parse it.
    code = "\n".join(ln for ln in sql.splitlines() if not ln.strip().startswith("--"))
    assert "QUALIFY" not in code
    assert "delete_time IS NULL" in code
