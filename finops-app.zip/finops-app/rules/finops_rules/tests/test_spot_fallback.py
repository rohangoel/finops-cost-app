from __future__ import annotations

from finops_rules.catalog.spot_fallback import SpotFallbackRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_monthly_cost_usd": 200,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(cost=2000.0, workers=4, availability="ON_DEMAND", **over) -> dict:
    row = {
        "workspace_id": "111",
        "cluster_id": "c-spot",
        "cluster_name": "on-demand-etl",
        "worker_node_type": "Standard_DS3_v2",
        "workers": workers,
        "availability": availability,
        "cost_30d_usd": cost,
        "dbus_30d": 1234.0,
    }
    row.update(over)
    return row


def test_surfaces_on_demand_cluster_as_advisory_zero():
    """FIN-009: an on-demand cluster is a spot candidate, but the saving lives in the
    cloud VM bill (not DBUs), so it is surfaced as advisory $0 — opportunity only."""
    finding = SpotFallbackRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-spot"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_usd == 0.0
    assert finding.monthly_savings_low_usd == 0.0
    assert finding.monthly_savings_high_usd == 0.0
    # DBU spend is carried as context, not as the spot-addressable amount.
    assert finding.monthly_waste_usd == 2000.0
    assert "cloud" in finding.why.lower() and "$0" in finding.why


def test_spot_toggle_with_unchanged_dbu_books_zero():
    """The FIN-009 invariant: toggling spot leaves the metered DBUs unchanged, so the
    Databricks-measured saving is $0 regardless of cluster size or DBU spend."""
    for workers in (1, 4, 64):
        for cost in (500.0, 5000.0):
            f = SpotFallbackRule().score(_row(cost=cost, workers=workers), _ctx())
            assert f is not None
            assert f.monthly_savings_usd == 0.0
            assert f.monthly_savings_low_usd == 0.0


def test_advisory_books_zero_in_aggregation():
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    f = SpotFallbackRule().score(_row(), _ctx())
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1), rule_id="spot_fallback",
        rule_version="2.0.0", rule_title="t", category="compute", workspace_id="111",
        resource_type="cluster", resource_id="c-spot", resource_name="n", why="", how="",
        monthly_waste_usd=f.monthly_waste_usd, monthly_savings_usd=f.monthly_savings_usd,
        savings_status="advisory", monthly_savings_low_usd=0.0,
        monthly_savings_high_usd=0.0, effort_band="low",
        effort_score=2, priority="MEDIUM", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_suppresses_single_node():
    # No worker to move to spot (driver always stays on-demand).
    assert SpotFallbackRule().score(_row(workers=0), _ctx()) is None


def test_suppresses_below_min_cost():
    # Too small to be worth surfacing as an opportunity.
    assert SpotFallbackRule().score(_row(cost=100.0), _ctx()) is None


def test_sql_renders_without_workspace_filter_and_is_portable():
    sql = SpotFallbackRule().render_sql(_ctx())
    assert "system.compute.clusters" in sql
    assert "system.billing.usage" in sql
    assert "ON_DEMAND" in sql
    assert "workspace_id IN" not in sql
    # FIN-006/portability: the DBSQL-only QUALIFY latest-version select was migrated to
    # the shared rank-then-filter macro (with a delete_time guard) so the hermetic
    # local-Spark gate can parse it.
    code = "\n".join(ln for ln in sql.splitlines() if not ln.strip().startswith("--"))
    assert "QUALIFY" not in code
    assert "delete_time IS NULL" in code
