"""The frontend's Beta list (frontend/src/components/BetaPill.tsx) must name real,
promoted rules. It is a hand-kept TS set, so a rename or typo would silently drop the
pill; this reads the file and checks every id against the registry."""

from __future__ import annotations

import re
from pathlib import Path

from finops_rules.registry import get_rule, list_rules

_TS = Path(__file__).resolve().parents[3] / "frontend" / "src" / "components" / "BetaPill.tsx"


def _beta_ids() -> set[str]:
    src = _TS.read_text()
    body = src[src.index("BETA_RULES"):src.index("]);")]
    return set(re.findall(r'"([a-z0-9_]+)"', body))


def test_beta_list_names_registered_non_experimental_rules():
    ids = _beta_ids()
    assert ids, "no ids parsed from BetaPill.tsx"
    known = {r.id for r in list_rules()}
    for rid in ids:
        assert rid in known, f"{rid} is not a registered rule"
        # Labs rules carry their own "Experimental" label; Beta is for the main list.
        assert get_rule(rid).experimental is False, rid


def test_every_rule_promoted_out_of_labs_is_marked_beta():
    from finops_rules.tests.test_savings_status_classification import PROMOTED

    assert PROMOTED <= _beta_ids()
