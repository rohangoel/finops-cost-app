from __future__ import annotations

import pytest

from finops_rules.catalog.allpurpose_shape_mismatch import (
    AllPurposeShapeMismatchRule,
    choose_target,
    worker_cost_fraction,
)
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    t = {
        "enabled": True,
        "active_cpu_pct": 20,
        "worker_idle_cpu_pct": 5,
        "min_active_minutes": 120,
        "driver_only_share": 0.6,
        "cpu_peak_pct": 60,
        "memory_family_gb_per_core": 7,
        "mem_oversize_p95_pct": 35,
        "target_fill_pct": 70,
        "general_max_gb_per_core": 4.5,
        "general_min_gb_per_core": 3.5,
        "compute_family_gb_per_core": 2.5,
        "swap_p95_pct": 5,
        "mem_pressure_p95_pct": 90,
        "min_addressable_usd": 25,
    }
    t.update(over)
    return RuleContext(thresholds=t, lookback_days=30, catalog="system")


def _alts() -> list[dict]:
    return [
        {"node_type": "m5.2xlarge", "memory_mb": 32768, "rate_std": 1.37, "rate_photon": None},
        {"node_type": "m5d.2xlarge", "memory_mb": 32768, "rate_std": 1.37, "rate_photon": 2.74},
        # compute-optimized: cheaper still, but must never be picked for a memory move
        {"node_type": "c5.2xlarge", "memory_mb": 16384, "rate_std": 1.21, "rate_photon": None},
    ]


def _row(**over) -> dict:
    """An i3.2xlarge (8 cores, 61 GB) all-purpose cluster, 2 workers, shape OK."""
    row = {
        "workspace_id": "111",
        "cluster_id": "0101-abc",
        "cluster_name": "shared-analytics",
        "cluster_source": "UI",
        "driver_node_type": "i3.2xlarge",
        "worker_node_type": "i3.2xlarge",
        "driver_cores": 8,
        "worker_cores": 8,
        "driver_memory_mb": 62464,
        "worker_memory_mb": 62464,
        "worker_gpu_count": 0,
        "observed_days": 20,
        "driver_node_minutes": 10000,
        "worker_node_minutes": 20000,   # => worker cost fraction 2/3
        "worker_mem": 40.0,
        "driver_mem": 50.0,
        "worker_p95_mem": 60.0,         # not oversized by default
        "driver_p95_mem": 70.0,
        "worker_p95_swap": 0.0,
        "worker_cpu": 20.0,
        "driver_cpu": 25.0,
        "running_minutes": 10000,
        "active_minutes": 3000,
        "driver_only_minutes": 300,     # 10% driver-only: not driver-bound
        "active_driver_cpu": 40.0,
        "active_worker_cpu": 35.0,
        "active_worker_p95_cpu": 70.0,
        "avg_workers": 2.0,
        "cost_30d_usd": 3000.0,
        "dbus_30d": 1500.0,
        "unpriced_dbus": 0.0,
        "photon": 0,
        "current_rate_std": 2.0,
        "current_rate_photon": 4.0,
        "alt_node_types": _alts(),
    }
    row.update(over)
    return row


RULE = AllPurposeShapeMismatchRule()

_DRIVER_BOUND = dict(
    active_minutes=1000,
    driver_only_minutes=900,   # 90% of busy time only the driver worked
    active_driver_cpu=45.0,
    active_worker_cpu=2.0,
    active_worker_p95_cpu=4.0,
)


def test_right_shape_is_suppressed():
    assert RULE.score(_row(), _ctx()) is None


def test_driver_bound_fires_and_prices_worker_share_for_driver_only_time():
    f = RULE.score(_row(**_DRIVER_BOUND), _ctx())
    assert f is not None
    assert f.evidence["symptom"] == "driver_bound"
    # 3000/mo x worker share 2/3 x driver-only share 0.9
    assert f.monthly_waste_usd == pytest.approx(3000 * (2 / 3) * 0.9, abs=0.01)
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(f.monthly_waste_usd)
    assert f.evidence["viz"]["kind"] == "driver_worker_split"
    assert f.evidence["viz"]["symptom"] == "driver_bound"
    assert f.priority == RulePriority.HIGH
    assert "single-node" in f.how.lower()


def test_driver_bound_vetoed_by_worker_p95_burst():
    # Workers peak at 75% CPU while active: they are needed at the burst.
    assert RULE.score(_row(**{**_DRIVER_BOUND, "active_worker_p95_cpu": 75.0}), _ctx()) is None


def test_driver_bound_needs_enough_active_time():
    row = _row(**{**_DRIVER_BOUND, "active_minutes": 100, "driver_only_minutes": 95})
    assert RULE.score(row, _ctx()) is None


def test_memory_family_fires_with_observed_rate_delta():
    f = RULE.score(_row(worker_p95_mem=20.0), _ctx())
    assert f is not None
    ev = f.evidence
    assert ev["symptom"] == "memory_family"
    # Same cores, general-purpose density: m5.2xlarge (not the cheaper c5, which is
    # compute-optimized and would squeeze memory).
    assert ev["target_node_type"] in ("m5.2xlarge", "m5d.2xlarge")
    assert ev["target_rate_measured"] is True
    # 3000 x 2/3 x (1 - 1.37/2.0)
    assert f.monthly_waste_usd == pytest.approx(3000 * (2 / 3) * (1 - 1.37 / 2.0), abs=0.01)
    assert ev["viz"]["symptom"] == "memory_oversize"
    assert f.monthly_savings_usd == 0.0


def test_memory_family_p95_veto():
    # Average memory is low but the p95 peak is not: no family change.
    assert RULE.score(_row(worker_mem=15.0, worker_p95_mem=50.0), _ctx()) is None


def test_memory_family_target_never_billed_is_suggested_without_dollars():
    unbilled = [{"node_type": "m6i.2xlarge", "memory_mb": 32768,
                 "rate_std": None, "rate_photon": None}]
    f = RULE.score(_row(worker_p95_mem=20.0, alt_node_types=unbilled), _ctx())
    assert f is not None
    assert f.evidence["target_node_type"] == "m6i.2xlarge"
    assert f.evidence["target_rate_measured"] is False
    assert f.monthly_waste_usd == 0.0
    assert f.evidence["confidence"] == "low"
    assert "never been billed" in f.why


def test_memory_family_no_fitting_target_is_suppressed():
    # p95 of 34% of 61 GB at 70% fill needs ~29.7 GB: a 16 GB target can't hold it.
    small = [{"node_type": "m5.xlarge-ish", "memory_mb": 16384, "rate_std": 0.5,
              "rate_photon": None}]
    assert RULE.score(_row(worker_p95_mem=34.0, alt_node_types=small), _ctx()) is None


def test_photon_cluster_prices_at_photon_rates_when_both_measured():
    alts = [
        {"node_type": "m5d.2xlarge", "memory_mb": 32768, "rate_std": 1.37, "rate_photon": 2.74},
    ]
    f = RULE.score(_row(worker_p95_mem=20.0, photon=1, alt_node_types=alts), _ctx())
    assert f.evidence["target_node_type"] == "m5d.2xlarge"
    assert f.evidence["current_dbu_per_node_hour"] == 4.0
    assert f.evidence["target_dbu_per_node_hour"] == 2.74


def test_photon_cluster_falls_back_to_standard_rates_ratio():
    # The target was only measured without Photon: the ratio is photon-invariant.
    alts = [{"node_type": "m5.2xlarge", "memory_mb": 32768, "rate_std": 1.37, "rate_photon": None}]
    f = RULE.score(_row(worker_p95_mem=20.0, photon=1, alt_node_types=alts), _ctx())
    assert f.evidence["current_dbu_per_node_hour"] == 2.0
    assert f.monthly_waste_usd == pytest.approx(3000 * (2 / 3) * (1 - 1.37 / 2.0), abs=0.01)


def test_compute_family_pressure_is_zero_dollar_advisory():
    row = _row(
        worker_node_type="c5.2xlarge", worker_memory_mb=16384, worker_p95_swap=8.0,
        worker_p95_mem=80.0,
    )
    f = RULE.score(row, _ctx())
    assert f is not None
    assert f.evidence["symptom"] == "compute_family_pressure"
    assert f.monthly_waste_usd == 0.0
    assert f.priority == RulePriority.LOW
    assert "viz" not in f.evidence


def test_gpu_workers_are_left_to_gpu_rule():
    assert RULE.score(_row(worker_gpu_count=1, **_DRIVER_BOUND), _ctx()) is None


def test_history_guard_suppresses_short_observation():
    assert RULE.score(_row(observed_days=2, **_DRIVER_BOUND), _ctx()) is None


def test_underpriced_cluster_is_suppressed():
    assert RULE.score(_row(unpriced_dbus=1400.0, **_DRIVER_BOUND), _ctx()) is None


def test_floor_suppresses_small_addressable():
    assert RULE.score(_row(cost_30d_usd=30.0, **_DRIVER_BOUND), _ctx()) is None


def test_worker_cost_fraction_core_weighted_and_fallback():
    assert worker_cost_fraction(_row()) == pytest.approx(2 / 3)
    # Big workers, small driver: core-weighted.
    r = _row(driver_cores=4, worker_cores=16, driver_node_minutes=1000,
             worker_node_minutes=2000)
    assert worker_cost_fraction(r) == pytest.approx(32000 / (32000 + 4000))
    # Missing specs fall back to node-minutes.
    r = _row(driver_cores=None, worker_cores=None)
    assert worker_cost_fraction(r) == pytest.approx(2 / 3)
    assert worker_cost_fraction(_row(worker_node_minutes=0)) == 0.0


def test_choose_target_prefers_cheapest_measured_general_purpose():
    alt, pair = choose_target(_row(), needed_mb=20000, min_gb_per_core=3.5)
    assert alt["node_type"] in ("m5.2xlarge", "m5d.2xlarge")
    assert pair == (2.0, 1.37)


def test_rule_is_experimental_advisory_cluster_rule():
    assert RULE.experimental is True
    assert RULE.default_savings_status == "advisory"
    assert RULE.resource_type == "cluster"
    assert RULE.contract_pricing == "none"
