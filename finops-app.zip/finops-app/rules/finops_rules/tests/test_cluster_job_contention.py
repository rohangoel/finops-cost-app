from __future__ import annotations

import pytest

from finops_rules.catalog.cluster_job_contention import ClusterJobContentionRule
from finops_rules.contract import RuleContext


@pytest.fixture
def contention_ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "min_monthly_cost_usd": 100,
            "min_concurrent_runs": 2,
            "min_contended_minutes": 15,
            "min_measured_frac": 0.5,
            "cpu_saturated_pct": 75,
            "mem_saturated_pct": 85,
            "min_saturation_delta_pct": 15,
        },
        lookback_days=30,
        catalog="system",
    )


@pytest.fixture
def contended_row() -> dict:
    """Textbook contention: CPU idles solo (35%) and pegs (p95 97%) when >=2 jobs
    overlap — saturation both high during overlap AND well above the solo level."""
    return {
        "workspace_id": "111",
        "cluster_id": "c-shared",
        "cluster_name": "shared-etl",
        "peak_concurrent_runs": 4,
        "avg_concurrent_runs": 2.6,
        "contended_minutes": 420,
        "contended_minutes_measured": 400,
        "contended_measured_frac": 0.95,
        "cpu_pct_concurrent": 88.0,
        "cpu_pct_solo": 35.0,
        "cpu_pct_concurrent_p95": 97.0,
        "mem_pct_concurrent": 70.0,
        "mem_pct_solo": 60.0,
        "mem_pct_concurrent_p95": 78.0,
        "contended_job_count": 5,
        "job_active_minutes": 900,
        "running_minutes": 1000,
        "observed_days": 20,
        "cost_30d_usd": 2000.0,
        "contended_cost_30d_usd": 840.0,
        "unpriced_dbus": 0.0,
    }


def test_flags_contended_cluster_as_advisory(contention_ctx, contended_row):
    f = ClusterJobContentionRule().score(contended_row, contention_ctx)
    assert f is not None
    assert f.resource_type == "cluster"
    assert f.resource_id == "c-shared"
    # Advisory: no dollars claimed (interactive_to_job owns the price gap), ranked
    # on the contended spend at risk.
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_waste_usd == pytest.approx(840.0, abs=1.0)
    assert f.evidence["confidence"] == "high"
    assert f.evidence["viz"]["kind"] == "cluster_contention"
    assert "job clusters" in f.how.lower() or "job cluster" in f.how.lower()


def test_rejects_undersized_cluster_saturated_equally_solo(contention_ctx, contended_row):
    # A cluster pegged at ~83% whether one job or several run is UNDERSIZED, not
    # contended — the rise over solo is tiny. This is the anti-pattern the live
    # 'Merca' cluster showed; it must NOT fire (rightsize's problem, not this one).
    contended_row["cpu_pct_solo"] = 83.4
    contended_row["cpu_pct_concurrent"] = 76.3  # not even higher than solo
    contended_row["cpu_pct_concurrent_p95"] = 89.4
    contended_row["mem_pct_solo"] = 87.5
    contended_row["mem_pct_concurrent"] = 88.7
    contended_row["mem_pct_concurrent_p95"] = 91.6
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_rejects_low_saturation_during_overlap(contention_ctx, contended_row):
    # Overlap exists, and rises over solo, but the box simply isn't saturated
    # (p95 24% CPU). No contention — there is spare capacity.
    contended_row["cpu_pct_solo"] = 6.8
    contended_row["cpu_pct_concurrent"] = 14.5
    contended_row["cpu_pct_concurrent_p95"] = 24.3
    contended_row["mem_pct_solo"] = 51.9
    contended_row["mem_pct_concurrent"] = 56.6
    contended_row["mem_pct_concurrent_p95"] = 64.5
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_coverage_gate_rejects_unmeasured_overlap(contention_ctx, contended_row):
    # Job timeline shows overlap, but almost none of it had node telemetry to prove
    # saturation. Must not flag contention we could not measure.
    contended_row["contended_minutes"] = 420
    contended_row["contended_minutes_measured"] = 20
    contended_row["contended_measured_frac"] = 0.048
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_rejects_rare_overlap(contention_ctx, contended_row):
    # Only a couple of contended minutes — a one-off collision, not a habit.
    contended_row["contended_minutes"] = 3
    contended_row["contended_minutes_measured"] = 3
    contended_row["contended_measured_frac"] = 1.0
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_rejects_no_real_concurrency(contention_ctx, contended_row):
    # Peak concurrency of 1 means jobs never actually overlapped.
    contended_row["peak_concurrent_runs"] = 1
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_suppresses_below_min_contended_spend(contention_ctx, contended_row):
    contended_row["contended_cost_30d_usd"] = 5.0  # ~$5/mo at risk
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_suppresses_when_too_new(contention_ctx, contended_row):
    contended_row["observed_days"] = 2  # below the 5-day observation minimum
    assert ClusterJobContentionRule().score(contended_row, contention_ctx) is None


def test_memory_bound_contention_fires(contention_ctx, contended_row):
    # CPU is fine, but memory pegs under concurrency (p95 92% vs 60% solo) — a
    # memory-bound contention still fires, on the memory signal alone.
    contended_row["cpu_pct_solo"] = 20.0
    contended_row["cpu_pct_concurrent"] = 25.0
    contended_row["cpu_pct_concurrent_p95"] = 30.0
    contended_row["mem_pct_solo"] = 60.0
    contended_row["mem_pct_concurrent"] = 88.0
    contended_row["mem_pct_concurrent_p95"] = 92.0
    f = ClusterJobContentionRule().score(contended_row, contention_ctx)
    assert f is not None
    assert "memory" in f.why.lower()


def test_sql_renders_with_expected_signals(contention_ctx):
    sql = ClusterJobContentionRule().render_sql(contention_ctx)
    assert "job_task_run_timeline" in sql
    assert "node_timeline" in sql
    # Concurrency + solo/concurrent saturation split.
    assert "concurrent_runs" in sql
    assert "cpu_pct_concurrent" in sql
    assert "cpu_pct_solo" in sql
    assert "contended_measured_frac" in sql  # coverage gate signal
    assert "contended_cost_30d_usd" in sql   # spend at risk, ranked on
    assert "workspace_id IN" not in sql       # scoping injected later, not here


def test_registered_and_advisory_metadata():
    from finops_rules.registry import discover, get_rule

    discover()
    r = get_rule("cluster_job_contention")
    assert r is not None
    assert r.resource_type == "cluster"
    assert r.category == "compute"
