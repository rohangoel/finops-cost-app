from __future__ import annotations

from finops_rules import get_enabled_rules, list_rules
from finops_rules.registry import get_rule


def test_autotermination_is_discovered():
    ids = {r.id for r in list_rules()}
    assert "cluster_autotermination" in ids


def test_rules_have_required_metadata():
    for rule in list_rules():
        assert rule.id and rule.version and rule.title
        assert rule.resource_type and rule.category


def test_disabled_rule_is_excluded():
    thresholds = {"cluster_autotermination": {"enabled": False}}
    enabled_ids = {r.id for r in get_enabled_rules(thresholds)}
    assert "cluster_autotermination" not in enabled_ids


def test_get_rule_roundtrip():
    rule = get_rule("cluster_autotermination")
    assert rule is not None and rule.id == "cluster_autotermination"
