from __future__ import annotations

import pytest

from finops_rules.catalog.pipeline_full_refresh_churn import PipelineFullRefreshChurnRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx(lookback_days: int = 30) -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_full_refreshes": 2,
            "min_incremental_updates": 3,
            "min_addressable_usd": 25,
        },
        lookback_days=lookback_days,
        catalog="system",
    )


def _row(**over) -> dict:
    # A daily-scheduled pipeline that full-refreshed 8 times from a job: each full
    # refresh ~$50 against a ~$2 incremental update => excess $384 over 30 days.
    row = {
        "workspace_id": "111",
        "pipeline_id": "pl-1",
        "pipeline_name": "silver-orders",
        "pipeline_type": "ETL_PIPELINE",
        "is_continuous": False,
        "is_development": False,
        "updates": 60,
        "observed_days": 20,
        "full_refreshes": 8,
        "selective_full_refreshes": 0,
        "fr_job_task": 8,
        "fr_api_call": 0,
        "fr_user_action": 0,
        "fr_retry": 0,
        "fr_days": 8,
        "fr_job_id": "987",
        "fr_priced": 8,
        "full_refresh_cost_usd": 400.0,
        "median_full_refresh_cost_usd": 50.0,
        "excess_cost_usd": 384.0,
        "incremental_updates": 52,
        "incremental_priced": 52,
        "median_incremental_cost_usd": 2.0,
        "cost_30d_usd": 504.0,
        "dbus_30d": 700.0,
        "unpriced_dbus": 0.0,
    }
    row.update(over)
    return row


def test_fires_on_repeated_scheduled_full_refreshes():
    f = PipelineFullRefreshChurnRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "pipeline" and f.resource_id == "pl-1"
    # Advisory: nothing booked, the excess is the addressable figure.
    assert f.savings_status == "advisory"
    assert f.monthly_savings_usd == 0.0 and f.monthly_savings_low_usd == 0.0
    assert f.monthly_waste_usd == pytest.approx(384.0)
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(384.0)
    assert f.evidence["full_refresh_triggers"]["job_task"] == 8
    assert f.priority == RulePriority.MEDIUM
    assert f.effort == EffortBand.LOW  # automated: flip the flag in the job
    assert "job 987" in f.why and "25x" in f.why


def test_monthly_scaling_uses_lookback():
    # 14-day window: $140 excess => $300/mo.
    f = PipelineFullRefreshChurnRule().score(
        _row(excess_cost_usd=140.0, full_refresh_cost_usd=200.0), _ctx(lookback_days=14)
    )
    assert f.monthly_waste_usd == pytest.approx(300.0)


def test_excess_never_exceeds_full_refresh_cost():
    f = PipelineFullRefreshChurnRule().score(
        _row(excess_cost_usd=900.0, full_refresh_cost_usd=400.0), _ctx()
    )
    assert f.monthly_waste_usd == pytest.approx(400.0)


def test_single_full_refresh_is_not_churn():
    assert PipelineFullRefreshChurnRule().score(_row(full_refreshes=1), _ctx()) is None


def test_no_incremental_baseline_is_suppressed():
    rule = PipelineFullRefreshChurnRule()
    assert rule.score(_row(median_incremental_cost_usd=None, incremental_priced=0), _ctx()) is None
    assert rule.score(_row(incremental_priced=2), _ctx()) is None


def test_synced_table_and_continuous_pipelines_are_skipped():
    rule = PipelineFullRefreshChurnRule()
    assert rule.score(_row(pipeline_type="DATABASE_TABLE_SYNC"), _ctx()) is None
    assert rule.score(_row(is_continuous=True), _ctx()) is None


def test_below_floor_is_suppressed():
    assert PipelineFullRefreshChurnRule().score(_row(excess_cost_usd=10.0), _ctx()) is None


def test_history_guard_runs_first():
    assert PipelineFullRefreshChurnRule().score(_row(observed_days=2), _ctx()) is None


def test_underpriced_pipeline_is_suppressed():
    assert PipelineFullRefreshChurnRule().score(_row(unpriced_dbus=400.0), _ctx()) is None


def test_manual_full_refreshes_read_as_manual():
    f = PipelineFullRefreshChurnRule().score(
        _row(fr_job_task=0, fr_user_action=8, fr_job_id=None, is_development=True), _ctx()
    )
    assert f is not None
    assert "by hand" in f.why
    assert "development mode" in f.how
    assert f.effort == EffortBand.MEDIUM


def test_render_sql_carries_threshold():
    sql = PipelineFullRefreshChurnRule().render_sql(_ctx())
    assert "HAVING SUM(p.is_fr) >= 2" in sql
    assert "QUALIFY" not in sql
