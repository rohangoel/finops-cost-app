from __future__ import annotations

from datetime import date, timedelta

import pytest

from finops_rules.catalog.unviewed_scheduled_dashboards import (
    UnviewedScheduledDashboardsRule,
)
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "unviewed_days": 14,
        "min_queries": 20,
        "min_active_days": 5,
        "min_addressable_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _ago(days: int) -> str:
    return (date.today() - timedelta(days=days)).isoformat() + "T09:00:00.000Z"


def _row(**over) -> dict:
    # Hourly refresh on 14 of 14 days (336 queries in 336 warehouse-hours), last opened
    # 25 days ago. Its per-hour share of the warehouse cost sums to $140 over the
    # 14-day window => $140 * 30/14 = $300/mo addressable.
    row = {
        "workspace_id": "111",
        "dashboard_id": "01f0dash",
        "warehouse_id": "wh1",
        "warehouses": 1,
        "executed_by": "owner@example.com",
        "queries": 336,
        "task_hours": 2.5,
        "observed_days": 14,
        "active_hours": 336,
        "first_query": _ago(14),
        "last_query": _ago(1),
        "unviewed_cost_window": 140.0,
        "active_hours_cost_window": 200.0,
        "sole_user_hours": 300,
        "dbus_30d": 50.0,
        "unpriced_dbus": 0.0,
        "unviewed_window_days": 14,
        "audit_events": 700,
        "view_events": 3,
        "last_view_time": _ago(25),
        "automated_events": 690,
        "was_deleted": 0,
    }
    row.update(over)
    return row


def test_flags_scheduled_dashboard_nobody_opens():
    f = UnviewedScheduledDashboardsRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "dashboard"
    assert f.resource_id == "01f0dash"
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.monthly_waste_usd == pytest.approx(300.0)
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(300.0)
    assert f.evidence["confidence"] == "medium"
    assert f.evidence["last_view_days_ago"] == 25
    assert f.evidence["active_hours_share_pct"] == 70.0
    assert f.priority == RulePriority.MEDIUM
    assert "last opened 25 days ago" in f.why
    assert "only thing running in 300" in f.why
    assert "No saving is booked" in f.how


def test_rule_metadata_is_labs_advisory():
    r = UnviewedScheduledDashboardsRule()
    assert r.experimental is False  # promoted out of Labs 2026-09-23 (still advisory)
    assert r.default_savings_status == "advisory"
    assert r.contract_pricing == "none"
    assert r.cloud_savings == "none"


def test_never_viewed_in_lookback_says_so():
    f = UnviewedScheduledDashboardsRule().score(
        _row(last_view_time=None, view_events=0), _ctx()
    )
    assert f is not None
    assert f.evidence["last_view_days_ago"] is None
    assert "Nobody has opened it in the last 30 days" in f.why


def test_viewed_inside_window_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(
        _row(last_view_time=_ago(3)), _ctx()
    ) is None


def test_no_audit_signal_is_suppressed():
    # Query activity but the audit log never saw the dashboard: "no views" would be
    # "can't see views".
    assert UnviewedScheduledDashboardsRule().score(
        _row(audit_events=0, view_events=0, last_view_time=None, automated_events=0),
        _ctx(),
    ) is None


def test_trashed_dashboard_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(_row(was_deleted=1), _ctx()) is None


def test_too_few_queries_or_days_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(_row(queries=10), _ctx()) is None
    assert UnviewedScheduledDashboardsRule().score(
        _row(observed_days=5, active_hours=5), _ctx(min_active_days=6)
    ) is None


def test_insufficient_history_is_first_guard():
    assert UnviewedScheduledDashboardsRule().score(
        _row(observed_days=2, active_hours=2), _ctx()
    ) is None


def test_below_floor_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(
        _row(unviewed_cost_window=5.0), _ctx()
    ) is None


def test_underpriced_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(
        _row(dbus_30d=50.0, unpriced_dbus=40.0), _ctx()
    ) is None


def test_high_frequency_refresh_is_called_out():
    # 230k queries in 336 hours => one every ~5 s, around the clock.
    f = UnviewedScheduledDashboardsRule().score(
        _row(queries=230_000, task_hours=0.01, unviewed_cost_window=5_000.0,
             active_hours_cost_window=5_200.0),
        _ctx(),
    )
    assert f is not None
    assert f.priority == RulePriority.HIGH
    assert "a query every ~5 s" in f.why
    assert "result cache" in f.why
    assert "keeps the warehouse from auto-stopping" in f.why


def test_sql_renders_with_thresholds():
    sql = UnviewedScheduledDashboardsRule().render_sql(_ctx())
    assert "access.audit" in sql
    assert "lakeview-processing" in sql
    assert "date_sub(current_date(), 14)" in sql
    assert "QUALIFY" not in sql.upper()


def test_recent_view_count_is_suppressed():
    assert UnviewedScheduledDashboardsRule().score(
        _row(recent_view_events=1), _ctx()
    ) is None


def test_finding_shares_its_warehouse_spend_pool():
    f = UnviewedScheduledDashboardsRule().score(_row(), _ctx())
    assert f.affected_spend_scope == "warehouse|wh1"


def test_daily_chart_shows_refreshes_views_and_the_last_view():
    f = UnviewedScheduledDashboardsRule().score(
        _row(days=[{"d": _ago(25)[:10], "r": 24, "v": 3}, {"d": _ago(2)[:10], "r": 24, "v": 0}]),
        _ctx())
    v = f.evidence["viz"]
    assert v["kind"] == "daily_stack" and len(v["days"]) == 30
    assert v["marker"]["d"] == _ago(25)[:10]


def test_audit_is_scanned_once():
    sql = UnviewedScheduledDashboardsRule().render_sql(_ctx())
    assert sql.count("FROM system.access.audit") == 1
