from __future__ import annotations

from finops_rules.catalog.job_runaway_no_timeout import JobRunawayNoTimeoutRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "min_runs": 8,
        "outlier_multiple": 5,
        "min_outlier_seconds": 3600,
        "min_outlier_runs": 2,
        "timeout_p95_multiple": 3,
        "min_timeout_seconds": 600,
        "tighten_multiple": 10,
        "max_p90_p50_ratio": 3,
        "min_unsuccessful_outlier_share": 0.5,
        "max_continuous_run_share": 0.5,
        "min_addressable_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # A daily-ish job: p50 20 min, p90 30 min (spread 1.5), 6 of 120 runs hung for hours.
    # $600 of excess over the 30-day window => $600/mo addressable.
    row = {
        "workspace_id": "111",
        "job_id": "42",
        "job_name": "nightly-ingest",
        "total_runs": 120,
        "observed_days": 30,
        "continuous_runs": 0,
        "p50_s": 1200,
        "p90_s": 1800,
        "normal_p95_s": 2000,
        "rec_timeout_s": 6000,
        "median_run_usd": 5.0,
        "outlier_runs": 6,
        "outlier_unsuccessful_runs": 2,
        "outlier_billed_runs": 6,
        "max_outlier_s": 40_000,
        "excess_wall_s": 150_000,
        "outlier_cost_30d": 700.0,
        "excess_cost_30d": 600.0,
        "excess_cost_unsuccessful_30d": 250.0,
        "cost_30d_usd": 1300.0,
        "dbus_30d": 2000.0,
        "unpriced_dbus": 0.0,
        "top_outlier_runs": [{"run_id": "9", "dur_s": 40_000, "state": "CANCELLED", "usd": 180.0}],
        "job_timeout_s": 0,
        "job_trigger_type": "CRON",
        "task_count": 2,
        "tasks_with_timeout": 0,
        "task_timeout_sum_s": 0,
        "has_duration_health_rule": False,
        "has_streaming_health_rule": False,
    }
    row.update(over)
    return row


def _score(row=None, **ctx_over):
    return JobRunawayNoTimeoutRule().score(row if row is not None else _row(), _ctx(**ctx_over))


def test_flags_job_without_timeout():
    f = _score()
    assert f is not None
    assert f.resource_type == "job"
    assert f.resource_id == "42"
    assert f.savings_status == "advisory"
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.monthly_waste_usd == 600.0
    assert f.evidence["addressable_monthly_usd"] == 600.0
    assert f.evidence["timeout_mode"] == "missing"
    assert f.evidence["hang_exemption"] is False
    assert f.evidence["recommended_timeout_seconds"] == 6000
    assert f.effort == EffortBand.LOW
    assert f.priority == RulePriority.HIGH
    assert "no run timeout" in f.why
    assert "100 min" in f.how


def test_rule_is_experimental_advisory_and_unpriced_for_contract():
    rule = JobRunawayNoTimeoutRule()
    assert rule.experimental is True
    assert rule.default_savings_status == "advisory"
    assert rule.contract_pricing == "none"


def test_addressable_scales_to_month_and_caps_at_job_cost():
    # 14-day window: $300 excess -> $300 * 30/14 ~= $642.86/mo.
    ctx = _ctx()
    ctx.lookback_days = 14
    f = JobRunawayNoTimeoutRule().score(
        _row(excess_cost_30d=300.0, observed_days=14, cost_30d_usd=1000.0), ctx
    )
    assert f is not None
    assert abs(f.monthly_waste_usd - 642.86) < 0.01
    # Excess can never exceed the job's own cost.
    f = _score(_row(excess_cost_30d=900.0, cost_30d_usd=400.0))
    assert f.monthly_waste_usd == 400.0


def test_history_guard_suppresses_new_job():
    assert _score(_row(observed_days=2)) is None


def test_underpriced_job_is_suppressed():
    assert _score(_row(unpriced_dbus=1000.0)) is None


def test_streaming_jobs_are_excluded():
    assert _score(_row(job_trigger_type="CONTINUOUS")) is None
    assert _score(_row(continuous_runs=100)) is None
    assert _score(_row(has_streaming_health_rule=True)) is None


def test_working_timeout_suppresses():
    # 3h timeout vs ~33 min normal p95 (< 10x): the timeout already bounds the runs.
    assert _score(_row(job_timeout_s=10_800)) is None


def test_every_task_timed_out_counts_as_a_bound():
    assert _score(_row(tasks_with_timeout=2, task_timeout_sum_s=7200)) is None
    # Only some tasks bounded => the run is still unbounded.
    f = _score(_row(tasks_with_timeout=1, task_timeout_sum_s=3600))
    assert f is not None and f.evidence["timeout_mode"] == "missing"


def test_loose_timeout_recommends_tightening():
    # 2-day timeout vs ~33 min normal p95 (> 10x) -> tighten to the recommended value.
    f = _score(_row(job_timeout_s=172_800))
    assert f is not None
    assert f.evidence["timeout_mode"] == "tighten"
    assert f.evidence["current_run_bound_seconds"] == 172_800
    assert "tighten the run timeout" in f.how


def test_health_rule_alone_is_not_a_bound():
    f = _score(_row(has_duration_health_rule=True))
    assert f is not None
    assert f.evidence["has_duration_health_rule"] is True


def test_bimodal_job_with_successful_long_runs_is_suppressed():
    # p90/p50 = 10: a second normal duration mode, and most outliers SUCCEEDED.
    assert _score(_row(p90_s=12_000, outlier_unsuccessful_runs=1)) is None


def test_bimodal_job_whose_long_runs_hang_is_kept_and_prices_only_those():
    # Same spread, but 5 of 6 outliers ended CANCELLED/ERROR: a hang, not a mode.
    f = _score(_row(p90_s=12_000, outlier_unsuccessful_runs=5))
    assert f is not None
    assert f.evidence["hang_exemption"] is True
    assert f.monthly_waste_usd == 250.0  # only the unsuccessful outliers' excess
    assert "stuck runs" in f.why


def test_zero_p50_is_treated_as_infinite_spread():
    # A p50 of 0 must not divide by zero; it falls to the bimodal branch.
    assert _score(_row(p50_s=0, outlier_unsuccessful_runs=0)) is None
    f = _score(_row(p50_s=0, outlier_unsuccessful_runs=6, excess_cost_unsuccessful_30d=100.0))
    assert f is not None and f.evidence["p90_p50_ratio"] is None


def test_single_outlier_is_not_a_pattern():
    assert _score(_row(outlier_runs=1, outlier_unsuccessful_runs=0)) is None


def test_long_runs_that_bill_like_normal_runs_are_below_the_floor():
    # Live finding: hours-long serverless runs that billed about the same as a normal
    # run leave ~no measured excess, so nothing is surfaced.
    assert _score(_row(excess_cost_30d=11.5)) is None


def test_priority_tiers():
    assert _score(_row(excess_cost_30d=150.0)).priority == RulePriority.MEDIUM
    assert _score(_row(excess_cost_30d=40.0)).priority == RulePriority.LOW


def test_render_sql_projects_required_columns():
    sql = JobRunawayNoTimeoutRule().render_sql(_ctx())
    for col in ("workspace_id", "observed_days", "unpriced_dbus", "excess_cost_30d",
                "rec_timeout_s", "job_timeout_s", "has_streaming_health_rule"):
        assert col in sql, col
    assert "QUALIFY" not in sql.upper()
