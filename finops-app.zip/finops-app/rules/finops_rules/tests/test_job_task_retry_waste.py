from __future__ import annotations

import pytest

from finops_rules.catalog.job_task_retry_waste import JobTaskRetryWasteRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "min_runs": 10,
        "min_retried_runs": 5,
        "min_retry_days": 3,
        "min_retry_rate": 0.10,
        "baseline_retry_rate": 0.05,
        "max_continuous_run_share": 0.5,
        "min_addressable_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # 200 successful runs, 50 of them (25%) needed a retry; the failed attempts billed
    # $400 over the 30-day window. Excess over the 5% baseline = (0.25-0.05)/0.25 = 0.8
    # => $320/mo addressable.
    row = {
        "workspace_id": "111",
        "job_id": "42",
        "job_name": "nightly-ingest",
        "succeeded_runs": 200,
        "observed_days": 30,
        "retried_runs": 50,
        "retry_days": 20,
        "failed_attempts": 60,
        "retry_rate": 0.25,
        "retry_cost_30d": 400.0,
        "cost_30d_usd": 4000.0,
        "dbus_30d": 8000.0,
        "unpriced_dbus": 0.0,
        "continuous_runs": 0,
        "top_task_key": "load_orders",
        "top_failure_code": "RUN_EXECUTION_ERROR",
    }
    row.update(over)
    return row


def test_flags_job_with_hidden_retries():
    f = JobTaskRetryWasteRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "job"
    assert f.resource_id == "42"
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.monthly_savings_usd == pytest.approx(320.0)
    assert f.monthly_savings_low_usd == pytest.approx(320.0)
    assert f.savings_status == "estimated"
    assert f.monthly_waste_usd == pytest.approx(320.0)
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(320.0)
    assert f.evidence["retry_rate_pct"] == 25.0
    assert f.priority == RulePriority.MEDIUM
    assert "load_orders" in f.why and "load_orders" in f.how
    assert "RUN_EXECUTION_ERROR" in f.why


def test_addressable_scales_to_month_and_never_exceeds_retry_cost():
    # 15-day window: $400 over 15 days => $800/mo retry cost; excess 0.8 => $640/mo.
    ctx = RuleContext(thresholds=_ctx().thresholds, lookback_days=15, catalog="system")
    f = JobTaskRetryWasteRule().score(_row(), ctx)
    assert f is not None
    assert f.monthly_waste_usd == pytest.approx(640.0)
    assert f.monthly_waste_usd <= f.evidence["retry_cost_monthly_usd"]


def test_high_priority_on_large_or_very_frequent_retries():
    f = JobTaskRetryWasteRule().score(_row(retried_runs=120, retry_cost_30d=2000.0), _ctx())
    assert f is not None and f.priority == RulePriority.HIGH


def test_insufficient_history_suppresses():
    assert JobTaskRetryWasteRule().score(_row(observed_days=2), _ctx()) is None


def test_underpriced_suppresses():
    assert JobTaskRetryWasteRule().score(_row(unpriced_dbus=6000.0), _ctx()) is None


def test_too_few_retried_runs_suppresses():
    assert JobTaskRetryWasteRule().score(_row(retried_runs=4), _ctx()) is None


def test_retry_burst_in_one_incident_suppresses():
    assert JobTaskRetryWasteRule().score(_row(retry_days=2), _ctx()) is None


def test_noise_level_retry_rate_suppresses():
    # 16 of 200 = 8%: above baseline but under min_retry_rate.
    assert JobTaskRetryWasteRule().score(_row(retried_runs=16), _ctx()) is None
    # min_retry_rate below baseline: at/under baseline credits nothing.
    ctx = _ctx(min_retry_rate=0.01, baseline_retry_rate=0.10)
    assert JobTaskRetryWasteRule().score(_row(retried_runs=20), ctx) is None


def test_small_dollar_floor_suppresses():
    assert JobTaskRetryWasteRule().score(_row(retry_cost_30d=20.0), _ctx()) is None


def test_zero_successful_runs_suppresses():
    assert JobTaskRetryWasteRule().score(_row(succeeded_runs=0), _ctx()) is None


def test_rule_is_promoted_estimated():
    rule = JobTaskRetryWasteRule()
    assert rule.experimental is False  # promoted out of Labs 2026-09-23
    assert rule.default_savings_status == "estimated"
    assert rule.contract_pricing == "none"
    assert rule.cloud_savings == "none"


def test_sql_excludes_for_each_iterations_and_failed_runs():
    sql = JobTaskRetryWasteRule().render_sql(_ctx())
    # for_each iterations share (job_run_id, task_key) but not the parent run
    assert "parent_run_id = job_run_id" in sql
    # failed runs belong to failing_jobs; only SUCCEEDED runs are counted here
    assert "jr.result_state = 'SUCCEEDED'" in sql
    assert "workspace_id =" not in sql.split("FROM per_job pj")[-1]


def test_daily_chart_splits_clean_and_retried_runs():
    from datetime import date, timedelta
    d = (date.today() - timedelta(days=1)).isoformat()
    f = JobTaskRetryWasteRule().score(_row(days=[{"d": d, "c": 3, "r": 2}]), _ctx())
    assert {"d": d, "v": [3.0, 2.0]} in f.evidence["viz"]["days"]
    assert "AS days" in JobTaskRetryWasteRule().render_sql(_ctx())
