from __future__ import annotations

from finops_rules.catalog.serverless_cost_optimized import ServerlessCostOptimizedRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import serverless_cost_optimized_savings


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_monthly_cost_usd": 100,
            "dbu_reduction": 0.50,
            "short_run_minutes": 10,
            "suitability_short": 0.25,
            "suitability_unknown": 0.40,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(cost=2000.0, median_min=30.0, product="JOBS") -> dict:
    return {
        "workspace_id": "111",
        "entity_id": "j-777",
        "billing_origin_product": product,
        "workload_type": "Job" if product == "JOBS" else "SDP pipeline",
        "entity_name": "nightly-etl",
        "median_run_min": median_min,
        "cost_30d_usd": cost,
        "dbus_30d": 900.0,
    }


def test_flags_long_job_as_advisory_zero():
    """FIN-014: a long serverless job is a cost-optimized candidate, but the ~50% DBU
    reduction is modeled (same $/DBU, no matched before/after run), so it is surfaced as
    advisory $0 — the modeled figure is only the max-addressable upper bound (high)."""
    finding = ServerlessCostOptimizedRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "job"
    assert ServerlessCostOptimizedRule.category == "jobs"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_usd == 0.0
    assert finding.monthly_savings_low_usd == 0.0
    # The modeled reduction is surfaced as the ceiling, never as a booked saving.
    modeled = serverless_cost_optimized_savings(
        perf_optimized_cost=2000.0, duration_suitability=1.0, dbu_reduction=0.50)
    assert finding.monthly_savings_high_usd == modeled
    assert finding.monthly_savings_high_usd > 0


def test_pipeline_is_resource_type_pipeline():
    """FIN-014: a DLT/SDP pipeline is a pipeline, not a job — the finding's resource_type
    must reflect that (was hardcoded 'job' for every row)."""
    finding = ServerlessCostOptimizedRule().score(_row(product="DLT"), _ctx())
    assert finding is not None
    assert finding.resource_type == "pipeline"
    assert "SDP pipeline" in finding.why
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_usd == 0.0


def test_books_zero_in_aggregation():
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    f = ServerlessCostOptimizedRule().score(_row(), _ctx())
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1),
        rule_id="serverless_cost_optimized", rule_version="2.0.0", rule_title="t",
        category="jobs", workspace_id="111", resource_type="job", resource_id="j-777",
        resource_name="n", why="", how="", monthly_waste_usd=f.monthly_waste_usd,
        monthly_savings_usd=f.monthly_savings_usd, savings_status="advisory",
        monthly_savings_low_usd=0.0, monthly_savings_high_usd=f.monthly_savings_high_usd,
        effort_band="low", effort_score=2, priority="MEDIUM", nba_score=1.0,
        computed_at=datetime.now(timezone.utc),
    )
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_short_workload_is_suppressed():
    # Short runs are a poor fit for Standard mode (its slower, billed cold start is
    # a large share of a brief run and can erode the saving), so they are not
    # recommended at all. A run at/above the cutoff is not short and does fire.
    assert ServerlessCostOptimizedRule().score(_row(median_min=3.0), _ctx()) is None
    at_cut = ServerlessCostOptimizedRule().score(_row(median_min=10.0), _ctx())
    assert at_cut is not None
    assert "not short" in at_cut.evidence["duration_category"]


def test_unknown_duration_is_suppressed():
    # "Only for non-short jobs": an unknown median cannot be confirmed non-short,
    # so it is suppressed rather than surfaced with a guessed discount.
    assert ServerlessCostOptimizedRule().score(_row(median_min=None), _ctx()) is None


def test_upper_bound_never_exceeds_billed_cost():
    finding = ServerlessCostOptimizedRule().score(_row(cost=1000.0), _ctx())
    assert finding is not None
    assert finding.monthly_savings_high_usd <= 1000.0


def test_suppresses_below_min_cost():
    assert ServerlessCostOptimizedRule().score(_row(cost=50.0), _ctx()) is None


def test_sql_renders_without_workspace_filter_and_is_portable():
    sql = ServerlessCostOptimizedRule().render_sql(_ctx())
    assert "system.billing.usage" in sql
    assert "PERFORMANCE_OPTIMIZED" in sql
    assert "workspace_id IN" not in sql
    # FIN-006/portability: the DBSQL-only QUALIFY latest-version selects (job_meta,
    # pipe_meta) were migrated to the shared rank-then-filter macro (with a delete_time
    # guard) so the hermetic local-Spark gate can parse them.
    code = "\n".join(ln for ln in sql.splitlines() if not ln.strip().startswith("--"))
    assert "QUALIFY" not in code
    assert "delete_time IS NULL" in code


def test_job_duration_median_excludes_skipped_runs():
    """SKIPPED runs never executed and consume no compute, so they must not enter
    the run-duration median. A chronically-skipped job (verified live: 471 of 732
    runs SKIPPED at ~1s each) otherwise collapses median_run_min to ~0 min and gets
    mislabelled 'short (< 10 min)', producing nonsensical evidence. The filter lives
    in the job_dur CTE, not the pipeline path (pipeline updates have no SKIPPED state)."""
    sql = ServerlessCostOptimizedRule().render_sql(_ctx())
    job_dur = sql.split("job_dur AS", 1)[1].split("pipe_dur AS", 1)[0]
    assert "MAX(CASE WHEN result_state = 'SKIPPED' THEN 1 ELSE 0 END) = 0" in job_dur
