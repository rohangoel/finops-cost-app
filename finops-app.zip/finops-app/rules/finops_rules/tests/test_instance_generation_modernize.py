from __future__ import annotations

import re

import pytest

from finops_rules.catalog.instance_generation_modernize import (
    InstanceGenerationModernizeRule,
    choose_target,
    load_mapping,
    lowest_dbr,
    match_entry,
    old_gen_regex,
    parse_mapping,
    target_gen_regex,
)
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    t = {
        "enabled": True,
        "min_memory_ratio": 0.9,
        "max_memory_ratio": 1.6,
        "min_rate_clusters": 3,
        "rate_spread_max": 0.05,
        "min_addressable_usd": 50,
    }
    t.update(over)
    return RuleContext(thresholds=t, lookback_days=30, catalog="system")


def _old(node_type="i3.xlarge", cost=1200.0, rate_std=1.0, rate_photon=2.0, **over):
    d = {
        "node_type": node_type, "node_minutes": 40000, "driver_node_minutes": 10000,
        "core_count": 4, "memory_mb": 31232, "cost_30d_usd": cost,
        "rate_std": rate_std, "rate_photon": rate_photon,
    }
    d.update(over)
    return d


def _alts(for_nt="i3.xlarge"):
    return [
        {"for_node_type": for_nt, "node_type": "i4i.xlarge", "memory_mb": 32768,
         "rate_std": None, "rate_photon": None},
        {"for_node_type": for_nt, "node_type": "i4g.xlarge", "memory_mb": 32768,
         "rate_std": None, "rate_photon": None},
    ]


def _row(**over) -> dict:
    """An all-purpose cluster running entirely on i3.xlarge."""
    row = {
        "workspace_id": "111",
        "resource_kind": "cluster",
        "resource_id": "0101-abc",
        "resource_name": "shared-analytics",
        "cluster_source": "UI",
        "clusters": 1,
        "dbr_versions": ["15.4.x-scala2.12"],
        "observed_days": 20,
        "cost_30d_usd": 1200.0,
        "dbus_30d": 2000.0,
        "unpriced_dbus": 0.0,
        "photon": 0,
        "old_gen_cost_30d_usd": 1200.0,
        "old_gen_core_minutes": 160000,
        "old_node_types": [_old()],
        "alt_node_types": _alts(),
    }
    row.update(over)
    return row


RULE = InstanceGenerationModernizeRule()


# --- the maintained mapping --------------------------------------------------------

def test_mapping_loads_and_every_pattern_compiles():
    entries = load_mapping()
    assert {e.cloud for e in entries} == {"aws", "azure", "gcp"}
    for e in entries:
        assert e.x86 or e.arm
        for fam in (*e.x86, *e.arm):
            re.compile(fam)


@pytest.mark.parametrize("node_type,flagged", [
    ("i3.xlarge", True), ("m5d.2xlarge", True), ("r5.4xlarge", True),
    ("c5d.24xlarge", True), ("m4.large", True),
    ("Standard_DS3_v2", True), ("Standard_E8s_v3", True), ("Standard_F4s", True),
    ("n1-standard-4", True),
    # current generation, GPU, fleet and specialty families are never flagged
    ("i4i.xlarge", False), ("m6id.xlarge", False), ("m7g.2xlarge", False),
    ("rd-fleet.xlarge", False), ("g4dn.xlarge", False), ("i3en.xlarge", False),
    ("m5zn.large", False), ("Standard_D4ds_v5", False), ("Standard_F4s_v2", False),
    ("n2-standard-4", False), ("m5dn.large", True),
])
def test_match_entry(node_type, flagged):
    assert (match_entry(node_type, load_mapping()) is not None) is flagged


def test_family_boundaries_do_not_bleed():
    """'m5' must not match m5d (different successor), and 'm6i' target must not
    match m6id."""
    entries = load_mapping()
    assert match_entry("m5.xlarge", entries).x86[0] == "m7i"
    assert match_entry("m5d.xlarge", entries).x86 == ("m6id",)
    e = match_entry("m5.xlarge", entries)
    alts = [{"node_type": "m6id.xlarge", "memory_mb": 16384}]
    assert choose_target(e, "x86", {}, alts, False) == (None, None)


def test_sql_regexes_are_escaped_and_anchored():
    entries = parse_mapping({"azure": [{"from": r"Standard_DS?\d+_v2",
                                        "x86": [r"Standard_D\d+ds_v5"]}]})
    old = old_gen_regex(entries)
    assert old == r"^(?:(?:Standard_DS?\\d+_v2))$"
    assert "'" not in old and "'" not in target_gen_regex(entries)
    # un-escaping once (what Spark does to a string literal) gives a working regex
    assert re.match(old.replace("\\\\", "\\"), "Standard_DS3_v2")


def test_render_injects_mapping_regexes():
    sql = RULE.render_sql(_ctx())
    assert "RLIKE '^(?:" in sql
    assert "i4i" in sql and "i3\\\\." in sql
    assert not re.search(r"workspace_id\s*(=|IN)\s*['(0-9]", sql)  # no scoping filter


# --- targets -----------------------------------------------------------------------

def test_choose_target_prefers_measured_family_over_earlier_unmeasured():
    e = match_entry("m5.xlarge", load_mapping())  # x86: m7i then m6i
    cur = {"rate_std": 0.69}
    alts = [
        {"node_type": "m7i.xlarge", "memory_mb": 16384, "rate_std": None},
        {"node_type": "m6i.xlarge", "memory_mb": 16384, "rate_std": 0.69},
    ]
    alt, pair = choose_target(e, "x86", cur, alts, photon=False)
    assert alt["node_type"] == "m6i.xlarge" and pair == (0.69, 0.69)


def test_choose_target_falls_back_to_first_family_without_rates():
    e = match_entry("m5.xlarge", load_mapping())
    alts = [
        {"node_type": "m6i.xlarge", "memory_mb": 16384},
        {"node_type": "m7i.xlarge", "memory_mb": 16384},
    ]
    alt, pair = choose_target(e, "x86", {}, alts, photon=False)
    assert alt["node_type"] == "m7i.xlarge" and pair is None


@pytest.mark.parametrize("versions,expected", [
    (["15.4.x-scala2.12"], (15, 4)),
    (["18.x-scala2.13"], (18, 0)),          # must NOT read the scala "2.13"
    (["dlt:17.3.18-delta-pipelines-dlt-release"], (17, 3)),
    (["16.4.x-scala2.12", "7.3.x-scala2.12"], (7, 3)),
    (["custom:image"], None),
    ([], None),
])
def test_lowest_dbr(versions, expected):
    assert lowest_dbr(versions) == expected


# --- score -------------------------------------------------------------------------

def test_flags_old_generation_cluster_as_advisory():
    f = RULE.score(_row(), _ctx())
    assert f is not None
    assert f.monthly_savings_usd == 0.0
    assert f.savings_status == "advisory"
    # $0 addressable as well as booked: the old-generation spend is evidence, not a
    # saving (a like-for-like x86 successor often costs more per hour).
    assert f.monthly_waste_usd == 0.0
    assert f.evidence["old_generation_monthly_usd"] == pytest.approx(1200.0)
    assert "~$1,200/mo" in f.why
    assert f.resource_type == "cluster"
    assert "i4i.xlarge" in f.why and "i4g.xlarge" in f.why
    assert "No saving is shown" in f.why
    assert "ARM64" in f.how
    assert f.evidence["confidence"] == "low"  # no successor rate measured
    assert f.priority == RulePriority.LOW or f.priority == RulePriority.MEDIUM


def test_rule_flags():
    assert RULE.experimental is True
    assert RULE.default_savings_status == "advisory"
    assert RULE.contract_pricing == "none"
    assert RULE.cloud_savings == "none"


def test_insufficient_history_first():
    assert RULE.score(_row(observed_days=2), _ctx()) is None


def test_underpriced_suppressed():
    assert RULE.score(_row(unpriced_dbus=1500.0), _ctx()) is None


def test_below_floor_suppressed():
    row = _row(old_node_types=[_old(cost=30.0)], cost_30d_usd=30.0)
    assert RULE.score(row, _ctx()) is None


def test_no_successor_offered_suppresses():
    assert RULE.score(_row(alt_node_types=[]), _ctx()) is None


def test_unmapped_type_is_ignored():
    row = _row(old_node_types=[_old(node_type="i3en.xlarge")],
               alt_node_types=_alts("i3en.xlarge"))
    assert RULE.score(row, _ctx()) is None


def test_mixed_resource_counts_only_old_generation_share():
    row = _row(cost_30d_usd=3000.0, old_node_types=[_old(cost=1200.0)])
    f = RULE.score(row, _ctx())
    assert f.evidence["old_generation_monthly_usd"] == pytest.approx(1200.0)
    assert f.evidence["old_generation_share"] == pytest.approx(0.4)
    assert "40%" in f.why


def test_old_spend_never_exceeds_resource_cost():
    row = _row(cost_30d_usd=1000.0, old_node_types=[_old(cost=1200.0)])
    assert RULE.score(row, _ctx()).evidence["old_generation_monthly_usd"] == pytest.approx(1000.0)


def test_measured_rates_are_shown_as_dbu_change_not_saving():
    alts = _alts()
    alts[0]["rate_std"] = 1.1
    f = RULE.score(_row(alt_node_types=alts), _ctx())
    assert f.evidence["confidence"] == "medium"
    assert "+10% DBUs" in f.why
    assert f.monthly_savings_usd == 0.0
    assert f.evidence["moves"][0]["x86_dbu_rates"] == [1.0, 1.1]


def test_arm_needs_runtime_upgrade():
    f = RULE.score(_row(dbr_versions=["7.3.x-scala2.12"]), _ctx())
    assert "upgrade the runtime first" in f.how
    assert f.evidence["moves"][0]["arm_needs_dbr_upgrade"] is True
    f2 = RULE.score(_row(dbr_versions=["18.x-scala2.13"]), _ctx())
    assert "upgrade the runtime" not in f2.how


def test_job_resource_type_and_where_to_change():
    f = RULE.score(_row(resource_kind="job", resource_id="42", resource_name="nightly",
                        cluster_source="JOB"), _ctx())
    assert f.resource_type == "job" and f.resource_id == "42"
    assert f.why.startswith("Job 'nightly'")
    assert "Jobs > the job" in f.how


def test_no_arm_target_omits_arm_copy():
    alts = [a for a in _alts() if a["node_type"] == "i4i.xlarge"]
    f = RULE.score(_row(alt_node_types=alts), _ctx())
    assert "Arm" not in f.why and "ARM64" not in f.how


def test_biggest_old_type_leads():
    row = _row(
        cost_30d_usd=2000.0,
        old_node_types=[_old(cost=500.0),
                        _old(node_type="m5d.xlarge", cost=1500.0, core_count=4, memory_mb=16384)],
        alt_node_types=_alts() + [
            {"for_node_type": "m5d.xlarge", "node_type": "m6id.xlarge", "memory_mb": 16384}],
    )
    f = RULE.score(row, _ctx())
    assert f.evidence["old_generation_node_types"] == ["m5d.xlarge", "i3.xlarge"]
    assert "m6id.xlarge" in f.how
    assert "(also: i3.xlarge)" in f.why
