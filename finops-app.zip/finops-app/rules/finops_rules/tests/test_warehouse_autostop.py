from __future__ import annotations

from finops_rules.catalog.warehouse_autostop import WarehouseAutoStopRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import (
    summarize_hourly_states,
    warehouse_autostop_savings,
    warehouse_autostop_savings_from_gaps,
)


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"max_acceptable_minutes": 30},
        lookback_days=30,
        catalog="system",
    )


def _series(active_h: int, idle_h: int, stopped_h: int, days: int = 14) -> list[int]:
    """One day = active hours, then idle-warm hours, then stopped hours."""
    day = [1] * active_h + [2] * idle_h + [0] * stopped_h
    return day * days


def _row(states, cost=2000.0, auto_stop=None) -> dict:
    return {
        "workspace_id": "111",
        "warehouse_id": "w-abc",
        "warehouse_name": "adhoc-sql",
        "auto_stop_minutes": auto_stop,
        "cost_30d_usd": cost,
        "hourly_states": states,
    }


def test_flags_warehouse_and_prices_from_series():
    states = _series(active_h=8, idle_h=4, stopped_h=12)
    finding = WarehouseAutoStopRule().score(_row(states, auto_stop=120), _ctx())
    assert finding is not None
    assert finding.resource_type == "warehouse"
    assert finding.effort == EffortBand.TRIVIAL
    assert finding.priority == RulePriority.HIGH
    # Savings must equal the shared, validated math exactly (no drift).
    agg = summarize_hourly_states(states)
    expected, _ = warehouse_autostop_savings(
        warm_hours=agg["warm_hours"], idle_warm_hours=agg["idle_warm_hours"],
        active_sessions=agg["active_sessions"], monthly_cost=2000.0)
    assert finding.monthly_savings_usd == expected
    assert finding.monthly_savings_usd > 0


def test_prefers_gap_based_pricing_when_available():
    # When SQL supplies fine-grained gap inputs, score() uses the accurate path.
    row = _row(_series(8, 4, 12), auto_stop=120)
    row["reclaimable_minutes"] = 3000.0
    row["warm_minutes"] = 5000.0
    finding = WarehouseAutoStopRule().score(row, _ctx())
    assert finding is not None
    expected, _ = warehouse_autostop_savings_from_gaps(
        reclaimable_min=3000.0, warm_minutes_current=5000.0, monthly_cost=2000.0)
    assert finding.monthly_savings_usd == expected
    # Gap path recovers materially more than the hourly fallback on the same row.
    hourly = WarehouseAutoStopRule().score(_row(_series(8, 4, 12), auto_stop=120), _ctx())
    assert finding.monthly_savings_usd > hourly.monthly_savings_usd


def test_evidence_carries_heatmap_and_confidence():
    finding = WarehouseAutoStopRule().score(_row(_series(8, 4, 12)), _ctx())
    assert finding is not None
    ev = finding.evidence
    assert ev["confidence"] == "high"
    assert ev["viz"]["kind"] == "hour_heatmap"
    assert len(ev["viz"]["grid"]) == 14 and len(ev["viz"]["grid"][0]) == 24


def test_copy_uses_configured_target_and_no_long_dash():
    ctx = RuleContext(
        thresholds={"max_acceptable_minutes": 30, "target_autostop_minutes": 15},
        lookback_days=30,
        catalog="system",
    )
    finding = WarehouseAutoStopRule().score(_row(_series(8, 4, 12), auto_stop=120), ctx)
    assert finding is not None
    assert "15-minute" in finding.why
    assert "15 minutes" in finding.how
    assert "—" not in finding.why + finding.how + finding.evidence["data_basis"]
    assert "–" not in finding.why + finding.how + finding.evidence["data_basis"]


def test_never_exceeds_billed_cost():
    # An always-idle warehouse: estimate is capped and never exceeds monthly cost.
    finding = WarehouseAutoStopRule().score(_row(_series(0, 24, 0), cost=1000.0), _ctx())
    assert finding is not None
    assert finding.monthly_savings_usd <= 1000.0


def test_suppresses_when_no_cost():
    assert WarehouseAutoStopRule().score(_row(_series(8, 4, 12), cost=0), _ctx()) is None


def test_suppresses_when_no_series():
    assert WarehouseAutoStopRule().score(_row([]), _ctx()) is None


def test_suppresses_when_never_idle():
    # Warm and busy every hour => nothing to reclaim.
    assert WarehouseAutoStopRule().score(_row(_series(24, 0, 0)), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = WarehouseAutoStopRule().render_sql(_ctx())
    assert "system.compute.warehouses" in sql
    assert "workspace_id IN" not in sql
