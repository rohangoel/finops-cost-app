from __future__ import annotations

from datetime import date, datetime, timedelta

from finops_rules.catalog.unused_scheduled_jobs import UnusedScheduledJobsRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_days_since_last_run": 30},
        lookback_days=30,
        catalog="system",
    )


def _stale_row() -> dict:
    # Last ran ~120 days ago, as a string like the warehouse might return.
    old = (date.today() - timedelta(days=120)).isoformat() + " 03:00:00"
    return {
        "workspace_id": "111",
        "job_id": "job-1",
        "job_name": "nightly-load-old",
        "last_run_time": old,
        "runs_lookback": 0,
        "cost_30d_usd": 90.0,
    }


def test_flags_stale_job_with_cost():
    finding = UnusedScheduledJobsRule().score(_stale_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "job"
    assert finding.resource_id == "job-1"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.LOW
    assert finding.monthly_savings_usd == 90.0
    assert "days ago" in finding.why


def test_flags_stale_job_zero_cost_as_hygiene():
    row = _stale_row()
    row["cost_30d_usd"] = 0
    finding = UnusedScheduledJobsRule().score(row, _ctx())
    # Zero cost still emits a hygiene finding with zero savings.
    assert finding is not None
    assert finding.monthly_savings_usd == 0.0


def test_suppresses_recently_run_job():
    row = _stale_row()
    row["last_run_time"] = datetime.now() - timedelta(days=2)
    assert UnusedScheduledJobsRule().score(row, _ctx()) is None


def test_flags_job_with_no_last_run():
    row = _stale_row()
    row["last_run_time"] = None
    finding = UnusedScheduledJobsRule().score(row, _ctx())
    assert finding is not None
    assert "never" in finding.why.lower()
    assert finding.evidence["days_since_last_run"] == 999


def test_sql_renders_without_workspace_filter():
    sql = UnusedScheduledJobsRule().render_sql(_ctx())
    assert "system.lakeflow.jobs" in sql
    assert "workspace_id IN" not in sql
