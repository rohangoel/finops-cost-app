from __future__ import annotations

from finops_rules.catalog.warehouse_rightsize import WarehouseRightsizeRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import (
    max_safe_steps_down_by_slots,
    warehouse_downsize_savings,
    warehouse_size_slots,
)


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_monthly_cost_usd": 100,
            "min_queries": 100,
            "max_queued_pct": 0.02,
            "max_spilled_pct": 0.01,
            "max_p95_read_gb": 10,
            "steps_down": 1,
            "slot_headroom_factor": 2.0,
            "max_steps_down": 3,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "finops-test-warehouse-oversized",
        "warehouse_type": "PRO",
        "warehouse_size": "SMALL",
        "queries": 402,
        "queued_pct": 0.0,
        "spilled_pct": 0.0,
        "p95_read_gb": 0.012,
        "p95_runtime_s": 8.69,
        "peak_concurrency": 6,
        "dbus_30d": 1347.0,
        "cost_30d_usd": 741.0,
    }
    row.update(over)
    return row


def test_flags_oversized_warehouse():
    finding = WarehouseRightsizeRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "warehouse"
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM
    # one step down halves the rate -> 50% of $741 = $370.50
    assert finding.monthly_savings_usd == 370.5
    assert finding.evidence["confidence"] == "low"
    viz = finding.evidence["viz"]
    assert viz["kind"] == "wh_rightsize"
    # The viz carries the real guard signals as margins (value vs danger limit),
    # not an abstract size ladder. All three axes present, each under its limit.
    keys = {h["key"] for h in viz["headroom"]}
    assert keys == {"queue", "spill", "scan"}
    for h in viz["headroom"]:
        assert h["value"] <= h["limit"]
    assert finding.evidence["proposed_size"] == "X_SMALL"
    assert "X-Small" in finding.how
    # 'how' names the KPIs to watch after the change.
    assert "p95 query runtime" in finding.how


def test_suppresses_below_cost_floor():
    assert WarehouseRightsizeRule().score(_row(cost_30d_usd=50.0), _ctx()) is None


def test_suppresses_smallest_size():
    # already at the floor -> nothing below to drop to
    assert WarehouseRightsizeRule().score(_row(warehouse_size="2X_SMALL"), _ctx()) is None


def test_downsize_savings_ladder_math():
    # exact rate ratio, not a guess: 1 step = 50%, 2 steps = 75%
    # (default runtime_ratio=1.0 => the work fits the smaller size, full rate cut)
    s1, p1 = warehouse_downsize_savings(monthly_cost=1000, current_size="MEDIUM", steps_down=1)
    s2, p2 = warehouse_downsize_savings(monthly_cost=1000, current_size="MEDIUM", steps_down=2)
    assert (s1, p1) == (500.0, "SMALL")
    assert (s2, p2) == (750.0, "X_SMALL")
    # unknown/floor sizes yield nothing
    assert warehouse_downsize_savings(monthly_cost=1000, current_size="2X_SMALL", steps_down=1) == (0.0, None)
    assert warehouse_downsize_savings(monthly_cost=1000, current_size="BOGUS", steps_down=1) == (0.0, None)


def test_downsize_savings_runtime_elasticity():
    # FIN-016: candidate cost = current * size_ratio * runtime_ratio.
    # Fully compute-bound (runtime doubles when slots halve) => candidate == current
    # => 0 saving, never negative.
    assert warehouse_downsize_savings(
        monthly_cost=1000, current_size="MEDIUM", steps_down=1, runtime_ratio=2.0
    ) == (0.0, "SMALL")
    # Partially elastic (1.5x runtime): rate 0.5 * 1.5 = 0.75 => 25% saving.
    assert warehouse_downsize_savings(
        monthly_cost=1000, current_size="MEDIUM", steps_down=1, runtime_ratio=1.5
    ) == (250.0, "SMALL")
    # runtime_ratio < 1 is clamped to 1 (a smaller size never runs the work faster).
    assert warehouse_downsize_savings(
        monthly_cost=1000, current_size="MEDIUM", steps_down=1, runtime_ratio=0.5
    ) == (500.0, "SMALL")


def test_runtime_ratio_from_measured_slots():
    from finops_rules.catalog.warehouse_rightsize import _runtime_ratio
    # LARGE = 64 slots; one step down => a 32-slot target.
    assert warehouse_size_slots("LARGE") == 64
    # A peak of 8 slots fits the 32-slot target comfortably => no slowdown.
    assert _runtime_ratio(8.0, 64, 1) == 1.0
    # A peak of 48 would exceed the 32-slot target => 48/32 = 1.5x runtime.
    assert _runtime_ratio(48.0, 64, 1) == 1.5
    # No measured signal => best-case 1.0.
    assert _runtime_ratio(None, 64, 1) == 1.0


def test_sql_renders_without_workspace_filter():
    sql = WarehouseRightsizeRule().render_sql(_ctx())
    assert "system.query.history" in sql
    assert "spilled_local_bytes" in sql
    assert "workspace_id IN" not in sql
    # The measured slot signal is computed from task duration.
    assert "total_task_duration_ms" in sql
    assert "slot_util" in sql


# ---- measured Spark slot signal --------------------------------------------

def test_slot_signal_raises_confidence_and_states_it():
    # A LARGE (64 slots) whose peak used only ~2 slots: measured, so confidence
    # rises to medium and the copy must state the slot measurement explicitly.
    finding = WarehouseRightsizeRule().score(
        _row(warehouse_size="LARGE", cost_30d_usd=4000.0, peak_slots_used=2.0), _ctx())
    assert finding is not None
    assert finding.evidence["confidence"] == "medium"
    assert "slot" in finding.why.lower()
    ev = finding.evidence
    assert ev["peak_slots_used"] == 2.0
    assert ev["size_slots"] == 64
    # A slots gauge leads the viz headroom.
    assert finding.evidence["viz"]["headroom"][0]["key"] == "slots"
    assert finding.evidence["viz"]["slot_util_pct"] is not None


def test_recommends_single_step_but_shows_deeper_floor_as_context():
    # LARGE=64 slots, peak ~1 slot: deep headroom. The rule must still RECOMMEND
    # only one step (LARGE->MEDIUM) and price the saving on that step, while
    # surfacing the deeper reachable floor + its total saving as CONTEXT.
    finding = WarehouseRightsizeRule().score(
        _row(warehouse_size="LARGE", cost_30d_usd=8000.0, peak_slots_used=1.0), _ctx())
    assert finding is not None
    ev = finding.evidence
    # Recommended move is exactly one step.
    assert ev["steps_down"] == 1
    assert ev["proposed_size"] == "MEDIUM"
    # One step halves the rate: 50% of $8000.
    assert finding.monthly_savings_usd == 4000.0
    assert finding.monthly_savings_usd <= ev["cost_30d_usd"]
    # The deeper floor is carried as context (more than one step below), with a
    # bigger total saving than the recommended single step.
    assert ev["potential_steps_down"] >= 2
    assert ev["floor_size"] is not None and ev["floor_size"] != ev["proposed_size"]
    assert ev["floor_savings_usd"] > finding.monthly_savings_usd
    # The copy frames iteration explicitly, not a single big jump.
    assert "one size at a time" in finding.why or "one size at a time" in finding.how
    # And the viz carries the floor for the dotted headroom marker.
    assert finding.evidence["viz"]["floor_size"] == ev["floor_size"]
    # Savings band (docs/SAVINGS_CONFIDENCE_MODEL.md): with measured slots and deeper
    # reachable headroom, the single measured step is the floor and the deeper size is
    # the upside — so low = the step saving, high = the deeper floor saving.
    assert finding.monthly_savings_low_usd == finding.monthly_savings_usd
    assert finding.monthly_savings_high_usd == ev["floor_savings_usd"]
    assert "one measured step" in ev["savings_range_basis"]


def test_band_is_zero_to_point_when_no_slot_signal():
    # No task data -> the size is inferred, so the one-step cut is the best case, not a
    # floor: the band must run from $0 (may not hold) to the full one-step saving.
    finding = WarehouseRightsizeRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.evidence["confidence"] == "low"
    assert finding.monthly_savings_low_usd == 0.0
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd
    assert "directional" in finding.evidence["savings_range_basis"]


def test_slot_signal_suppresses_when_peak_leaves_no_margin():
    # A SMALL (16 slots) genuinely using ~10 slots at peak: even one step (8 slots)
    # would not cover 10 * 2 margin, so the measured signal says DON'T downsize —
    # and we trust it rather than falling back to the weaker proxy.
    assert WarehouseRightsizeRule().score(
        _row(warehouse_size="SMALL", peak_slots_used=10.0), _ctx()) is None


def test_proxy_only_path_unchanged_when_no_task_data():
    # No peak_slots_used (older row / no task data): must behave exactly as before —
    # single step, low confidence, no slot gauge.
    finding = WarehouseRightsizeRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.evidence["confidence"] == "low"
    assert finding.evidence["steps_down"] == 1
    assert "slots" not in {h["key"] for h in finding.evidence["viz"]["headroom"]}
    assert finding.evidence.get("peak_slots_used") is None


def test_slot_ladder_and_helper_math():
    assert warehouse_size_slots("SMALL") == 16
    assert warehouse_size_slots("LARGE") == 64
    assert warehouse_size_slots("2X_SMALL") == 4
    assert warehouse_size_slots("bogus") is None
    # LARGE=64, peak 2 * 2x margin = 4 must fit s/2^k: k=1->32, k=2->16, k=3->8, all >=4
    assert max_safe_steps_down_by_slots(current_size="LARGE", peak_slots_used=2.0) == 3
    # peak 10 on SMALL=16: 10*2=20 > 8 (one step), so 0 steps.
    assert max_safe_steps_down_by_slots(current_size="SMALL", peak_slots_used=10.0) == 0
    # never below a single node
    assert max_safe_steps_down_by_slots(current_size="X_SMALL", peak_slots_used=0.1) <= 1
