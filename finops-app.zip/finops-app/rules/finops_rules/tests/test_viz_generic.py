from __future__ import annotations

from datetime import date

from finops_rules.evidence import densify_days, viz_daily_stack, viz_ranked_bars

TODAY = date(2026, 9, 23)


def test_densify_fills_every_day_of_the_closed_open_window():
    days = densify_days([{"d": "2026-09-20", "a": 3, "b": 1.234}], ["a", "b"], 7, TODAY)
    assert [d["d"] for d in days] == [
        "2026-09-16", "2026-09-17", "2026-09-18", "2026-09-19",
        "2026-09-20", "2026-09-21", "2026-09-22",
    ]  # ends yesterday, like window_lower()
    assert days[4]["v"] == [3.0, 1.23]
    assert days[0]["v"] == [0.0, 0.0]


def test_densify_drops_days_outside_the_window_and_accepts_timestamps():
    days = densify_days(
        [{"d": "2026-09-01", "a": 9}, {"d": "2026-09-22 13:00:00", "a": 2}], ["a"], 3, TODAY)
    assert [d["v"][0] for d in days] == [0.0, 0.0, 2.0]


def test_daily_stack_payload_and_marker():
    v = viz_daily_stack(
        title="t", unit="runs",
        series=[("n", "new", "info"), ("z", "none", "not-a-token")],
        rows=[{"d": "2026-09-21", "n": 1, "z": 5}],
        lookback_days=5, marker=("2026-09-21 06:00:00", "last new input"),
        ref=(2, "floor"), note="x", today=TODAY,
    )
    assert v["kind"] == "daily_stack"
    assert len(v["days"]) == 5
    assert v["series"][1]["color"] == "info"  # unknown colour falls back to a token
    assert v["marker"] == {"d": "2026-09-21", "label": "last new input"}
    assert v["ref"] == {"value": 2.0, "label": "floor"}


def test_daily_stack_is_none_when_there_is_nothing_to_draw():
    assert viz_daily_stack(title="t", unit="u", series=[("a", "a", "info")],
                           rows=[], lookback_days=5, today=TODAY) is None
    assert viz_daily_stack(title="t", unit="u", series=[("a", "a", "info")],
                           rows=None, lookback_days=5, today=TODAY) is None


def test_ranked_bars_sorted_and_zero_rows_dropped():
    v = viz_ranked_bars(title="t", unit="$/mo", rows=[
        {"label": "a", "value": 5}, {"label": "b", "value": 50, "color": "warn"},
        {"label": "c", "value": 0},
    ])
    assert [r["label"] for r in v["rows"]] == ["b", "a"]
    assert v["rows"][0]["color"] == "warn" and v["rows"][1]["color"] == "info"
    assert viz_ranked_bars(title="t", unit="u", rows=[]) is None
