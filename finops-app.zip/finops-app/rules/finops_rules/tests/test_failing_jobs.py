from __future__ import annotations

from finops_rules.catalog.failing_jobs import FailingJobsRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.savings import failing_job_savings


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_runs": 20,
            "min_failures": 3,
            "min_fail_rate": 0.10,
            "baseline_fail_rate": 0.05,
            "max_continuous_run_share": 0.5,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "job_id": "job-fail-1",
        "job_name": "flaky-etl",
        "total_runs": 100,
        "failed_runs": 40,
        "fail_rate": 0.40,
        "failed_cost_30d": 80.0,   # $80 burned on failed runs in 30d -> $2.00/run
        "succeeded_runs": 60,
        "succeeded_cost_30d": 60.0,  # $60 over 60 clean runs -> $1.00/run
        "cost_30d_usd": 200.0,
        "days": [
            {"d": "2026-07-01", "s": 8, "f": 5},
            {"d": "2026-07-02", "s": 12, "f": 7},
        ],
    }
    row.update(over)
    return row


def test_flags_chronically_failing_job():
    finding = FailingJobsRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "job"
    assert finding.effort == EffortBand.MEDIUM
    assert finding.priority == RulePriority.MEDIUM
    # 40% fail rate, 5% baseline -> excess fraction (0.40-0.05)/0.40 = 0.875.
    # A failed run costs $2.00, a clean run $1.00, so fixing frees only half of each
    # failed run's spend: reclaim fraction = 1 - 1.00/2.00 = 0.5.
    # savings = $80 * 0.875 * 0.5 = $35.00. Waste (spend burned on failures) is $80.
    assert finding.monthly_savings_usd == 35.0
    assert finding.monthly_waste_usd == 80.0
    assert "40%" in finding.why
    assert finding.evidence["viz"]["kind"] == "job_runs"


def test_savings_net_out_completion_cost():
    """Savings must be below the retire basis by the completion-cost fraction, since
    a fixed run still bills compute. Here reclaim fraction is 0.5."""
    finding = FailingJobsRule().score(_row(), _ctx())
    # Retire basis (full excess-failure spend) would be $70; the fix basis is half.
    assert finding.monthly_savings_usd == 35.0
    assert finding.evidence["avg_failed_run_cost"] == 2.0
    assert finding.evidence["avg_success_run_cost"] == 1.0
    assert "completion" in finding.why.lower()


def test_never_succeeding_job_uses_retire_basis():
    """A job with zero successful runs has no completion cost to net out and is a
    genuine retire candidate, so the full excess-failure spend is credited."""
    row = _row(succeeded_runs=0, succeeded_cost_30d=0.0)
    finding = FailingJobsRule().score(row, _ctx())
    assert finding is not None
    # excess 0.875 * $80 = $70, no completion netting.
    assert finding.monthly_savings_usd == 70.0
    assert "retire" in finding.why.lower()


def test_clean_run_as_costly_as_failure_yields_no_savings():
    """If a successful run costs as much as a failed one, fixing frees no compute —
    it just moves spend from wasted to productive — so savings is 0 (suppressed)."""
    row = _row(succeeded_runs=40, succeeded_cost_30d=80.0)  # $2.00/run, same as failed
    assert FailingJobsRule().score(row, _ctx()) is None


def test_suppresses_healthy_baseline_failures():
    # A job failing right at the baseline should be credited ~nothing.
    row = _row(fail_rate=0.05, failed_runs=5, failed_cost_30d=10.0)
    assert FailingJobsRule().score(row, _ctx()) is None


def test_suppresses_below_min_fail_rate():
    row = _row(fail_rate=0.08, failed_runs=8, failed_cost_30d=16.0)
    assert FailingJobsRule().score(row, _ctx()) is None


def test_zero_failed_cost_suppressed():
    row = _row(failed_cost_30d=0.0)
    assert FailingJobsRule().score(row, _ctx()) is None


def test_savings_helper_excess_scaling():
    # Barely-above-baseline credits little; chronic credits nearly all. With no
    # successful-run cost supplied, the helper uses the retire basis (full spend).
    low = failing_job_savings(failed_run_cost=100, fail_rate=0.06, baseline_fail_rate=0.05)
    high = failing_job_savings(failed_run_cost=100, fail_rate=0.90, baseline_fail_rate=0.05)
    assert 0 < low < 20
    assert high > 90
    # never exceeds the measured failed spend
    assert high <= 100


def test_savings_helper_nets_out_completion_cost():
    """With a successful-run cost, the credit drops by the reclaim fraction
    1 - avg_success/avg_failed."""
    retire = failing_job_savings(
        failed_run_cost=100, fail_rate=0.50, baseline_fail_rate=0.05,
        avg_failed_run_cost=2.0, avg_success_run_cost=None,
    )
    fix = failing_job_savings(
        failed_run_cost=100, fail_rate=0.50, baseline_fail_rate=0.05,
        avg_failed_run_cost=2.0, avg_success_run_cost=0.5,  # reclaim fraction 0.75
    )
    # excess = (0.50-0.05)/0.50 = 0.9 -> retire basis $90; fix basis 0.75 * $90.
    assert retire == 90.0
    assert fix == 67.5


def test_savings_helper_zero_when_fix_costs_as_much():
    s = failing_job_savings(
        failed_run_cost=100, fail_rate=0.50, baseline_fail_rate=0.05,
        avg_failed_run_cost=2.0, avg_success_run_cost=2.5,  # clean run costs MORE
    )
    assert s == 0.0


def test_sql_renders_without_workspace_filter():
    sql = FailingJobsRule().render_sql(_ctx())
    assert "system.lakeflow.job_run_timeline" in sql
    assert "job_run_id" in sql  # per-run cost attribution
    assert "workspace_id IN" not in sql


def test_sql_excludes_streaming_jobs():
    """Continuous/streaming jobs restart on error by design, so a majority-
    CONTINUOUS job must be dropped rather than scored as chronically failing —
    verified on logfood as ~half of the rule's (spurious) credited savings."""
    sql = FailingJobsRule().render_sql(_ctx())
    assert "'CONTINUOUS'" in sql
    # The exclusion rides in the HAVING that also enforces min_runs/min_failures.
    assert "SUM(is_continuous) / COUNT(*) <= 0.5" in sql


# --- reliability signals beyond the failure rate -------------------------------
# result_state has exactly six values (verified live): SUCCEEDED, ERROR, FAILED,
# TIMED_OUT, CANCELLED, SKIPPED. The rule previously matched `TIMEDOUT` — a
# misspelling that can never match — so timed-out runs were silently counted as
# SUCCESSES and every affected job's failure rate read low. It also listed two
# `termination_code` values as if they were states.

def test_sql_uses_the_real_timed_out_state():
    """The misspelling meant a whole failure mode was scored as success."""
    sql = FailingJobsRule().render_sql(_ctx())
    predicate = sql.split("AS failed", 1)[0]
    assert "'TIMED_OUT'" in predicate
    # And the typo must not survive in the executable predicate.
    assert "'TIMEDOUT'" not in predicate


def test_sql_does_not_treat_termination_codes_as_result_states():
    """INTERNAL_ERROR / MAX_CONCURRENT_RUNS_EXCEEDED live in termination_code; as
    result_states they match nothing, so listing them there was dead logic."""
    sql = FailingJobsRule().render_sql(_ctx())
    predicate = sql.split("AS failed", 1)[0]
    assert "'INTERNAL_ERROR'" not in predicate
    assert "'MAXIMUM_CONCURRENT_RUNS_REACHED'" not in predicate


def test_cancelled_and_skipped_are_counted_separately_from_failures():
    """A cancelled run is not broken code, and a skipped one consumed no compute —
    but both are reliability facts an admin should see."""
    sql = FailingJobsRule().render_sql(_ctx())
    assert "cancelled_runs" in sql
    assert "skipped_runs" in sql
    # They must not enter the failure predicate.
    predicate = sql.split("AS failed", 1)[0]
    assert "'CANCELLED'" not in predicate
    assert "'SKIPPED'" not in predicate


def test_skipped_runs_stay_in_the_failure_rate_denominator():
    """Excluding them would RAISE fail_rate and therefore credited savings — the
    wrong direction for an engine whose estimates must never exceed true avoidable
    spend."""
    sql = FailingJobsRule().render_sql(_ctx())
    assert "SUM(failed) / COUNT(*) AS fail_rate" in sql


def test_cancellations_are_reported_but_never_priced_into_savings():
    """Stopping a job someone deliberately cancelled is not an action this rule can
    recommend, so its cost must not inflate the estimate."""
    row = _row(cancelled_runs=4, cancelled_cost_30d=500.0)
    finding = FailingJobsRule().score(row, _ctx())
    assert finding is not None
    assert "cancelled" in finding.why.lower()
    assert finding.evidence["cancelled_runs"] == 4
    # Savings still derive only from the failed-run cost.
    baseline_only = FailingJobsRule().score(_row(), _ctx())
    assert finding.monthly_savings_usd == baseline_only.monthly_savings_usd


def test_termination_code_explains_which_fix_is_needed():
    """CLUSTER_ERROR is infrastructure, RUN_EXECUTION_ERROR is code — different
    work, so the finding should say which."""
    cluster = FailingJobsRule().score(_row(termination_code="CLUSTER_ERROR"), _ctx())
    assert "CLUSTER_ERROR" in cluster.why
    assert "configuration" in cluster.why or "capacity" in cluster.why


# --- FIN-020 repair vs retire tiering ------------------------------------------

def test_repair_candidate_is_estimated():
    """A job with comparable successful runs can be priced as a REPAIR: the credit is
    a real estimate, but a code fix isn't a certain saving, so it is estimated (low 0),
    shown but not booked."""
    finding = FailingJobsRule().score(_row(), _ctx())
    assert finding.savings_status == "estimated"
    assert finding.evidence["action"] == "repair"
    assert finding.monthly_savings_low_usd == 0.0
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd
    assert finding.monthly_savings_usd > 0


def test_retire_candidate_is_advisory_not_booked():
    """FIN-020: a job that never succeeded has no successful run to estimate a repair
    from, and retiring it needs an owner decision — so it is advisory ($0 booked) with
    the excess-failure spend shown as the max-addressable upper bound only."""
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    finding = FailingJobsRule().score(_row(succeeded_runs=0, succeeded_cost_30d=0.0), _ctx())
    assert finding is not None
    assert finding.savings_status == "advisory"
    assert finding.evidence["action"] == "retire"
    assert finding.monthly_savings_low_usd == 0.0
    # addressable (high == point) is the full excess-failure spend, > 0
    assert finding.monthly_savings_high_usd == finding.monthly_savings_usd > 0
    assert "not booked" in finding.why.lower()
    # and the aggregation books nothing for an advisory finding
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1), rule_id="failing_jobs",
        rule_version="2.0.0", rule_title="t", category="jobs", workspace_id="111",
        resource_type="job", resource_id="job-fail-1", resource_name="n", why="", how="",
        monthly_waste_usd=finding.monthly_waste_usd, monthly_savings_usd=finding.monthly_savings_usd,
        savings_status="advisory", monthly_savings_low_usd=0.0,
        monthly_savings_high_usd=finding.monthly_savings_high_usd, effort_band="medium",
        effort_score=3, priority="MEDIUM", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_band_is_ordered_for_both_tiers():
    for row in (_row(), _row(succeeded_runs=0, succeeded_cost_30d=0.0)):
        f = FailingJobsRule().score(row, _ctx())
        assert f.monthly_savings_low_usd <= f.monthly_savings_usd <= f.monthly_savings_high_usd

    code = FailingJobsRule().score(_row(termination_code="RUN_EXECUTION_ERROR"), _ctx())
    assert "RUN_EXECUTION_ERROR" in code.why

    # An unknown/absent code must not produce a dangling sentence.
    silent = FailingJobsRule().score(_row(termination_code=None), _ctx())
    assert "None" not in silent.why


def test_no_cancellations_adds_no_noise():
    finding = FailingJobsRule().score(_row(cancelled_runs=0, skipped_runs=0), _ctx())
    assert "cancelled" not in finding.why.lower()
    assert "skipped" not in finding.why.lower()
