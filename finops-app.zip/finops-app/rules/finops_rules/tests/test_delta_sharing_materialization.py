from __future__ import annotations

from finops_rules.catalog.delta_sharing_materialization import DeltaSharingMaterializationRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_materializations": 10},
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "share_name": "analytics-share",
        "provider_name": "acme",
        "materializations": 600,      # ~24/day over 25 days => HIGH
        "observed_days": 25,
        "distinct_tables": 3,
        "distinct_recipients": 2,
        "days": [{"d": "2026-09-01", "n": 24}, {"d": "2026-09-02", "n": 24}],
    }
    row.update(over)
    return row


def test_flags_churny_share():
    f = DeltaSharingMaterializationRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "share"
    assert f.monthly_waste_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "sharing_materialization"
    assert f.evidence["operational_only"] is True


def test_rule_is_experimental_and_advisory():
    rule = DeltaSharingMaterializationRule()
    assert rule.experimental is True
    assert rule.default_savings_status == "advisory"


def test_suppresses_below_min_materializations():
    assert DeltaSharingMaterializationRule().score(_row(materializations=5), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = DeltaSharingMaterializationRule().render_sql(_ctx())
    assert "system.sharing.materialization_history" in sql
    assert "workspace_id IN" not in sql
