from __future__ import annotations

from finops_rules.catalog.autotermination import AutoTerminationRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def test_flags_idle_cluster_with_savings(autotermination_ctx, idle_no_autoterm_row):
    finding = AutoTerminationRule().score(idle_no_autoterm_row, autotermination_ctx)
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-abc"
    assert finding.effort == EffortBand.TRIVIAL
    assert finding.priority == RulePriority.HIGH
    # Gap-based: 7000 reclaimable min net 20 restarts (=6920) of 10000 running min
    # => ~69% of $3000, less a small residual margin.
    assert 1950 < finding.monthly_savings_usd < 2050
    assert "auto-termination" in finding.how.lower()
    # CPU idle is a proxy for session activity => medium, not high, confidence.
    assert finding.evidence["confidence"] == "medium"
    assert finding.evidence["reclaimable_hours"] > 0


def test_week_heatmap_when_matrix_present(autotermination_ctx, idle_no_autoterm_row):
    # "When was it used" heatmap rides along as an extra chart when the SQL carried
    # the 168-element weekday x hour matrix, with the three-state up/active split
    # and the 1440-element minute drill.
    idle_no_autoterm_row["active_by_dow_hour"] = [1] * 168
    idle_no_autoterm_row["up_by_dow_hour"] = [60] * 168
    idle_no_autoterm_row["active_by_hour_minute"] = [1] * 1440
    finding = AutoTerminationRule().score(idle_no_autoterm_row, autotermination_ctx)
    assert finding is not None
    kinds = [v["kind"] for v in finding.evidence["viz_extra"] if v]
    assert "cluster_week_heatmap" in kinds
    heat = next(v for v in finding.evidence["viz_extra"] if v and v["kind"] == "cluster_week_heatmap")
    assert len(heat["active_by_dow_hour"]) == 168
    assert len(heat["up_by_dow_hour"]) == 168  # three-state split available
    assert len(heat["active_by_hour_minute"]) == 1440  # minute drill available


def test_week_heatmap_degrades_without_up_and_minute_arrays(
    autotermination_ctx, idle_no_autoterm_row
):
    # Older rows may carry only the active matrix. The heatmap still renders (two-
    # state), and the optional up/minute keys are simply absent — not empty.
    idle_no_autoterm_row["active_by_dow_hour"] = [1] * 168
    finding = AutoTerminationRule().score(idle_no_autoterm_row, autotermination_ctx)
    assert finding is not None
    heat = next(v for v in finding.evidence["viz_extra"] if v and v["kind"] == "cluster_week_heatmap")
    assert "up_by_dow_hour" not in heat
    assert "active_by_hour_minute" not in heat


def test_week_heatmap_omitted_without_matrix(autotermination_ctx, idle_no_autoterm_row):
    # Older / precomputed rows without the matrix must not break the finding; the
    # heatmap is simply absent (vizList drops the None).
    finding = AutoTerminationRule().score(idle_no_autoterm_row, autotermination_ctx)
    assert finding is not None
    kinds = [v["kind"] for v in finding.evidence["viz_extra"] if v]
    assert "cluster_week_heatmap" not in kinds


def test_suppresses_busy_cluster(autotermination_ctx, busy_row):
    # No idle gaps longer than the timeout => nothing reclaimable => not a finding.
    assert AutoTerminationRule().score(busy_row, autotermination_ctx) is None


def test_suppresses_when_no_cost(autotermination_ctx, idle_no_autoterm_row):
    idle_no_autoterm_row["cost_30d_usd"] = 0
    assert AutoTerminationRule().score(idle_no_autoterm_row, autotermination_ctx) is None


def test_sql_renders_without_workspace_filter(autotermination_ctx):
    sql = AutoTerminationRule().render_sql(autotermination_ctx)
    assert "system.compute.clusters" in sql
    assert "60" in sql  # max_acceptable_minutes threshold rendered
    assert "workspace_id IN" not in sql  # scoping is injected later, not here
    # "When was it used" weekday x hour matrices, built from the active/up signals,
    # plus the hour x minute matrix for the drill.
    assert "active_by_dow_hour" in sql
    assert "up_by_dow_hour" in sql
    assert "active_by_hour_minute" in sql
    assert "dow_activity" in sql
    assert "up_minute" in sql  # up >= active guaranteed by the union


def test_sql_always_counts_job_task_activity_as_active(autotermination_ctx):
    # Job-task activity is folded into the idle definition unconditionally, so a
    # low-CPU minute during a running job task is NOT counted as reclaimable idle.
    sql = AutoTerminationRule().render_sql(autotermination_ctx)
    assert "job_task_run_timeline" in sql
    assert "job_active_minutes" in sql


def test_job_runs_count_uses_task_level_table(autotermination_ctx):
    # job_run_timeline.compute_ids is always empty; only the TASK-level table
    # populates it, so the job_runs_30d count must come from there (else it's
    # always 0 and the "N job run(s) seen" evidence never renders).
    sql = AutoTerminationRule().render_sql(autotermination_ctx)
    assert "job_run_timeline.compute_ids" not in sql  # no reliance on the empty column
    assert "job_runs_30d" in sql


def test_audit_activity_signal_is_opt_in(autotermination_ctx):
    # Default (use_audit_activity: false) does not read the audit log.
    sql_off = AutoTerminationRule().render_sql(autotermination_ctx)
    assert "access.audit" not in sql_off

    # Enabling it folds notebook runCommand minutes into the active set.
    ctx_on = RuleContext(
        thresholds={**autotermination_ctx.thresholds, "use_audit_activity": True},
        lookback_days=30,
        catalog="system",
    )
    sql_on = AutoTerminationRule().render_sql(ctx_on)
    assert "access.audit" in sql_on
    assert "nb_active_minutes" in sql_on
