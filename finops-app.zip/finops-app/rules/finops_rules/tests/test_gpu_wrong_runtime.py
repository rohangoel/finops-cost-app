from __future__ import annotations

from finops_rules.catalog.gpu_wrong_runtime import GpuWrongRuntimeRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.evidence import CONFIDENCE_HIGH


def _ctx(**over) -> RuleContext:
    thresholds = {"enabled": True, "min_monthly_cost_usd": 25}
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    """A candidate shaped exactly as gpu_wrong_runtime.sql.j2 projects it.

    Modelled on a real observed row: an all-purpose g5.16xlarge cluster (1 GPU per
    worker) running the STANDARD '15.4.x-scala2.12' runtime — no '-gpu-ml', so the
    GPU is billed but unusable."""
    row = {
        "workspace_id": "111",
        "cluster_id": "c-gpu",
        "cluster_name": "ml-dev-shared",
        "cluster_source": "UI",
        "dbr_version": "15.4.x-scala2.12",
        "worker_node_type": "g5.16xlarge",
        "driver_node_type": "g5.16xlarge",
        "worker_count": 2,
        "worker_gpu_count": 1,
        "driver_gpu_count": 1,
        "worker_cores": 64.0,
        "worker_memory_mb": 262144,
        "driver_cores": 64.0,
        "driver_memory_mb": 262144,
        "cost_30d_usd": 1800.0,
        "dbus_30d": 4000.0,
        "unpriced_dbus": 0.0,  # fully priced -> coverage does not block
        "observed_days": 27,
    }
    row.update(over)
    return row


def test_flags_gpu_cluster_on_non_gpu_runtime():
    finding = GpuWrongRuntimeRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-gpu"
    assert finding.effort == EffortBand.MEDIUM
    assert finding.priority == RulePriority.HIGH
    # Detection is pure config -> high confidence.
    assert finding.evidence["confidence"] == CONFIDENCE_HIGH
    # Ranks on the visible at-risk DBU spend (~1800/30d -> ~1800/mo).
    assert 1750 < finding.monthly_waste_usd < 1850


def test_advisory_books_no_dollars():
    """GPU shares the CPU compute SKU and the cloud-VM premium is not in system
    tables, so the saving is unpriceable and nothing is booked."""
    finding = GpuWrongRuntimeRule().score(_row(), _ctx())
    assert finding.monthly_savings_usd == 0.0
    assert GpuWrongRuntimeRule().default_savings_status == "advisory"


def test_why_and_how_name_the_runtime_and_the_confirm_step():
    finding = GpuWrongRuntimeRule().score(_row(), _ctx())
    assert "15.4.x-scala2.12" in finding.why
    assert "-gpu-ml" in finding.why
    # The one false-positive path (custom GPU container / init script) must be
    # surfaced as a confirm-first step.
    assert "confirm" in finding.how.lower()
    assert "init script" in finding.how.lower()


def test_gpu_only_on_driver_is_still_flagged():
    finding = GpuWrongRuntimeRule().score(
        _row(worker_gpu_count=0, worker_node_type="m5.16xlarge"), _ctx()
    )
    assert finding is not None
    assert "driver" in finding.why.lower()


def test_below_cost_floor_is_suppressed():
    # $20 over the 30-day window -> $20/mo, below the $25 floor.
    assert GpuWrongRuntimeRule().score(_row(cost_30d_usd=20.0), _ctx()) is None


def test_short_history_is_suppressed():
    assert GpuWrongRuntimeRule().score(_row(observed_days=2), _ctx()) is None


def test_underpriced_is_suppressed():
    # Most of the DBUs found no list price -> coverage below floor -> not shown.
    assert GpuWrongRuntimeRule().score(_row(unpriced_dbus=3800.0), _ctx()) is None


def test_no_gpu_node_is_suppressed():
    # Defensive: even if a row slipped through the SQL filter, no GPU => no finding.
    assert (
        GpuWrongRuntimeRule().score(
            _row(worker_gpu_count=0, driver_gpu_count=0), _ctx()
        )
        is None
    )


def test_missing_cluster_name_falls_back_to_id():
    finding = GpuWrongRuntimeRule().score(_row(cluster_name=None), _ctx())
    assert finding.resource_name == "c-gpu"


def test_sql_renders_without_workspace_filter_and_uses_gpu_gate():
    sql = GpuWrongRuntimeRule().render_sql(_ctx())
    assert "system.compute.node_types" in sql
    assert "gpu_count" in sql
    assert "-gpu-ml" in sql  # the runtime gate
    assert "workspace_id IN" not in sql  # scoping injected later, not here
    # Persistent all-purpose clusters only (ephemeral job clusters excluded).
    assert "cluster_source IN ('UI', 'API')" in sql
    # Uses the shared closed-open window + rank-then-filter SCD macros.
    assert "< current_date()" in sql
    assert "rn = 1 AND delete_time IS NULL" in sql
