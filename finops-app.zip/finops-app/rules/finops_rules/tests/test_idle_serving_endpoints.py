from __future__ import annotations

from finops_rules.catalog.idle_serving_endpoints import IdleServingEndpointsRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority
from finops_rules.evidence import CONFIDENCE_HIGH
from finops_rules.savings import idle_serving_endpoint_savings


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "max_requests": 0,
        "min_days_billed": 7,
        "min_monthly_cost_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    """A candidate shaped exactly as idle_serving_endpoints.sql.j2 projects it.

    Modelled on a real observed row: a CUSTOM_MODEL agent endpoint with
    min_concurrency=4 that billed every day of the window and served nobody."""
    row = {
        "workspace_id": "111",
        "endpoint_id": "ep-abc",
        "endpoint_name": "agents-rd-search-coscientist",
        "entity_type": "CUSTOM_MODEL",
        "entity_name": "cat.schema.agent_model",
        "created_by": "someone@example.com",
        "min_concurrency": 4,
        "compute_type": "CPU",
        "cost_window_usd": 392.77,
        "dbus_window": 5594.67,
        "unpriced_window": 0.0,  # fully priced -> coverage supports booking (FIN-004)
        "days_billed": 30,
        "is_provisioned_throughput": 0,
        "is_batch_inference": 0,
        "requests_window": 0,
        "ok_requests": 0,
        "distinct_requesters": 0,
        "last_request_time": None,
        # Logged requests before the window then went quiet: usage tracking is
        # demonstrably on, so zero traffic in the window is MEASURED (guard 3).
        "requests_retained": 12,
        "last_request_retained": "2026-06-30T09:15:00Z",
        "observed_days": 30,
        "entity_matched": 1,
        "days_series": [
            {"d": "2026-07-27", "w": 1, "r": 0},
            {"d": "2026-07-28", "w": 1, "r": 0},
        ],
    }
    row.update(over)
    return row


def test_flags_idle_always_on_endpoint():
    finding = IdleServingEndpointsRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "serving_endpoint"
    assert finding.resource_id == "ep-abc"
    assert finding.resource_name == "agents-rd-search-coscientist"
    # Zero requests => the whole always-on cost is reclaimable.
    assert finding.monthly_savings_usd == finding.monthly_waste_usd
    assert finding.effort == EffortBand.LOW
    assert finding.priority == RulePriority.MEDIUM


def test_requests_measured_not_inferred_so_confidence_is_high():
    """The only idleness rule that counts real requests rather than a proxy."""
    finding = IdleServingEndpointsRule().score(_row(), _ctx())
    assert finding.evidence["confidence"] == CONFIDENCE_HIGH


def test_low_traffic_surfaces_scale_to_zero_tier():
    """SME review: a trickle of traffic on an always-warm, scale-to-zero-capable
    endpoint is a real miss. It surfaces at MEDIUM confidence and credits only the
    conservative share scale-to-zero would reclaim (never the full cost)."""
    finding = IdleServingEndpointsRule().score(_row(requests_window=30), _ctx())
    assert finding is not None
    assert finding.evidence["confidence"] == "medium"
    assert finding.evidence["traffic_tier"] == "low"
    # Conservative: only the reclaim fraction of the always-on cost, not all of it.
    assert 0 < finding.monthly_savings_usd < finding.monthly_waste_usd


def test_zero_traffic_is_bookable_low_traffic_is_estimated():
    """Phase 0.3 per-tier status: the MEASURED zero-traffic tier is bookable (its
    low bound enters the headline); the estimated low-traffic scale-to-zero tier is
    out of the booked headline."""
    zero = IdleServingEndpointsRule().score(_row(), _ctx())
    assert zero.savings_status == "bookable"
    low = IdleServingEndpointsRule().score(_row(requests_window=30), _ctx())
    assert low.savings_status == "estimated"


def test_zero_traffic_with_incomplete_price_coverage_is_not_booked():
    """FIN-004 (fail closed): the zero-traffic tier is measured, but if the
    endpoint's serving spend cannot be fully priced (a chunk of its usage found no
    list price) the dollar figure is a partial cost, not the whole. It must stay
    visible but drop OUT of the booked headline (estimated), never book a partial
    cost as if it were the reclaimable total."""
    # Most of the DBUs unpriced -> coverage below the floor -> not bookable.
    mostly_unpriced = IdleServingEndpointsRule().score(
        _row(unpriced_window=5000.0), _ctx()
    )
    assert mostly_unpriced.savings_status == "estimated"
    # Coverage columns absent entirely (an old snapshot) -> unknown -> not booked.
    row = _row()
    del row["unpriced_window"]
    unknown = IdleServingEndpointsRule().score(row, _ctx())
    assert unknown.savings_status == "estimated"


def test_busy_endpoint_suppresses():
    """Above the low-traffic per-day cap the endpoint is genuinely in use => $0."""
    # 30 days * 200/day = 6000 requests => ~200/day, over the 100/day cap.
    assert IdleServingEndpointsRule().score(_row(requests_window=6000), _ctx()) is None


def test_low_traffic_without_scale_to_zero_suppresses():
    """Provisioned throughput has no cheap lever, so a low-traffic PT endpoint is
    not surfaced (deletion is the only option, and it still serves traffic)."""
    row = _row(requests_window=30, is_provisioned_throughput=1, min_concurrency=0)
    assert IdleServingEndpointsRule().score(row, _ctx()) is None


def test_max_requests_threshold_is_configurable():
    """max_requests sets the ZERO-traffic (full-credit, high-confidence) boundary.
    Raising it moves a lightly-used endpoint into the full-cost tier."""
    rule = IdleServingEndpointsRule()
    # requests=5 with default max_requests=0 => low-traffic tier (partial credit).
    low = rule.score(_row(requests_window=5), _ctx())
    assert low is not None and low.evidence["traffic_tier"] == "low"
    # Raising max_requests to 10 makes 5 count as zero-traffic => full credit, high.
    full = rule.score(_row(requests_window=5), _ctx(max_requests=10))
    assert full is not None and full.evidence["traffic_tier"] == "zero"
    assert full.monthly_savings_usd == full.monthly_waste_usd


def test_unmatched_entity_is_unknown_not_idle():
    """THE false-positive guard. served_entities covered only 92 of 591 billing
    endpoints in testing, so a missing join must never read as zero traffic —
    otherwise we recommend deleting BUSY endpoints."""
    assert IdleServingEndpointsRule().score(_row(entity_matched=0), _ctx()) is None


def test_short_history_is_suppressed():
    """A newly deployed endpoint has served nobody because it is NEW."""
    row = _row(observed_days=2, days_billed=2)
    assert IdleServingEndpointsRule().score(row, _ctx()) is None


def test_intermittent_billing_is_not_always_on_waste():
    """Billing on only a few days means it already scales down; no idle waste."""
    row = _row(days_billed=3, observed_days=8)
    assert IdleServingEndpointsRule().score(row, _ctx()) is None


def test_below_cost_floor_is_suppressed():
    assert IdleServingEndpointsRule().score(_row(cost_window_usd=5.0), _ctx()) is None


def test_provisioned_throughput_gets_delete_guidance_and_more_effort():
    """PT has no scale-to-zero toggle, so the lever (and the effort) differ."""
    finding = IdleServingEndpointsRule().score(
        _row(is_provisioned_throughput=1, min_concurrency=None,
             entity_type="FOUNDATION_MODEL", endpoint_name="gpt-oss-demo"),
        _ctx(),
    )
    assert finding is not None
    assert finding.effort == EffortBand.MEDIUM
    assert "provisioned throughput" in finding.how.lower()
    assert finding.evidence["provisioned_throughput"] is True


def test_scale_to_zero_endpoint_gets_config_fix_guidance():
    finding = IdleServingEndpointsRule().score(_row(), _ctx())
    assert "scale-to-zero" in finding.how
    assert "min_provisioned_concurrency" in finding.how


def test_why_states_the_measured_numbers():
    finding = IdleServingEndpointsRule().score(_row(days_billed=21), _ctx())
    assert "21 of the last 30 days" in finding.why
    assert "0 inference requests" in finding.why


def test_fully_billed_window_avoids_off_by_one_prose():
    """date_sub is inclusive on both ends, so a 30-day lookback spans 31 dates and
    an always-on endpoint reports days_billed=31. "31 of the last 30 days" would
    read as a bug, so a full window is phrased as such."""
    finding = IdleServingEndpointsRule().score(_row(days_billed=31), _ctx())
    assert "31 of the last 30" not in finding.why
    assert "every one of the last 30 days" in finding.why


def test_evidence_carries_observation_window_and_viz():
    finding = IdleServingEndpointsRule().score(_row(), _ctx())
    assert finding.evidence["observed_days"] == 30
    assert finding.evidence["min_observation_days"] == 5
    viz = finding.evidence["viz"]
    assert viz["kind"] == "serving_traffic"
    assert viz["total_requests"] == 0
    assert viz["days_billed"] == 30


def test_days_series_merges_duplicate_dates():
    """The SQL unions a billing row and a request row per day, so the same date
    arrives twice and must collapse to one chart entry."""
    row = _row(days_series=[
        {"d": "2026-07-27", "w": 1, "r": 0},
        {"d": "2026-07-27", "w": 0, "r": 0},
        {"d": "2026-07-28", "w": 1, "r": 0},
    ])
    days = IdleServingEndpointsRule().score(row, _ctx()).evidence["viz"]["days"]
    assert [d["d"] for d in days] == ["2026-07-27", "2026-07-28"]
    assert days[0]["w"] == 1


def test_null_elements_in_series_do_not_crash():
    """Spark can hand back nulls inside a collected array."""
    row = _row(days_series=[None, {"d": "2026-07-27", "w": 1, "r": 0}, None])
    days = IdleServingEndpointsRule().score(row, _ctx()).evidence["viz"]["days"]
    assert len(days) == 1


def test_missing_endpoint_name_falls_back_to_id():
    finding = IdleServingEndpointsRule().score(_row(endpoint_name=None), _ctx())
    assert finding.resource_name == "ep-abc"


def test_idle_gpu_endpoint_ranks_higher_and_flags_cpu_lever():
    """An idle endpoint on GPU serving compute is the costliest idle waste, so it
    ranks HIGH (vs MEDIUM for CPU) and the guidance adds the CPU-downgrade lever on
    top of the standard scale-to-zero advice. The idle DETECTION is unchanged."""
    cpu = IdleServingEndpointsRule().score(_row(), _ctx())
    assert cpu.priority == RulePriority.MEDIUM  # baseline (compute_type=CPU)

    gpu = IdleServingEndpointsRule().score(_row(compute_type="GPU_MEDIUM"), _ctx())
    assert gpu is not None
    assert gpu.priority == RulePriority.HIGH
    assert gpu.evidence["is_gpu_compute"] is True
    assert "GPU serving compute" in gpu.why
    assert "cpu" in gpu.how.lower()
    # Same measured idle cost — the GPU flag changes emphasis, not the finding.
    assert gpu.monthly_savings_usd == cpu.monthly_savings_usd


def test_cpu_endpoint_is_not_flagged_as_gpu():
    finding = IdleServingEndpointsRule().score(_row(), _ctx())
    assert finding.evidence["is_gpu_compute"] is False
    assert "GPU serving compute" not in finding.why


# --- the savings function itself --------------------------------------------

def test_savings_credits_full_cost_only_at_zero_requests():
    assert idle_serving_endpoint_savings(
        monthly_cost=400.0, requests=0, scale_to_zero_available=True
    ) == 400.0
    assert idle_serving_endpoint_savings(
        monthly_cost=400.0, requests=1, scale_to_zero_available=True
    ) == 0.0


def test_savings_zero_when_no_cost():
    assert idle_serving_endpoint_savings(
        monthly_cost=0.0, requests=0, scale_to_zero_available=True
    ) == 0.0


# ---- guard 3: zero LOGGED requests may just mean usage tracking is off ----------


def test_never_logged_endpoint_is_flagged_unverified_not_booked():
    """An endpoint that has never logged a request can't be told apart from one
    whose usage tracking is off — so it is surfaced, but at MEDIUM confidence,
    estimated (out of the booked headline), with a prominent warning."""
    f = IdleServingEndpointsRule().score(
        _row(requests_retained=0, last_request_retained=None), _ctx()
    )
    assert f is not None
    assert f.savings_status == "estimated"
    assert f.evidence["confidence"] == "medium"
    assert f.evidence["traffic_tier"] == "zero_unverified"
    assert f.evidence["usage_tracking_verified"] is False
    assert "usage tracking" in f.evidence["data_warning"]
    # The doubt leads the copy and the first step is to verify, not to delete.
    assert "usage tracking may simply be off" in f.why
    assert f.how.startswith("First verify it is really unused")
    assert "never logged a request" in f.evidence["data_basis"]


def test_previously_logged_endpoint_is_measured_idle_and_says_so():
    f = IdleServingEndpointsRule().score(_row(), _ctx())
    assert f is not None
    assert f.savings_status == "bookable"
    assert f.evidence["confidence"] == "high"
    assert f.evidence["usage_tracking_verified"] is True
    assert "data_warning" not in f.evidence
    assert "last logged request was on 2026-06-30" in f.why


def test_low_traffic_endpoint_is_never_unverified():
    """Requests in the window prove tracking works, even if the retained count
    column is missing (older snapshot / defensive read)."""
    f = IdleServingEndpointsRule().score(
        _row(requests_window=5, requests_retained=None), _ctx()
    )
    assert f is not None
    assert f.evidence["traffic_tier"] == "low"
    assert f.evidence["usage_tracking_verified"] is True
    assert "data_warning" not in f.evidence
