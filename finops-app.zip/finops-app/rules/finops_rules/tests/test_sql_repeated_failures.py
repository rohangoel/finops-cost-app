from __future__ import annotations

from finops_rules.catalog.sql_repeated_failures import SqlRepeatedFailuresRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_failed_queries": 20,
            "min_fail_rate": 0.05,
            "min_addressable_usd": 25,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    # A warehouse where ~30% of queries fail, and failed queries account for ~40% of
    # Spark task-time, on a $1,000/mo warehouse => ~$400/mo addressable.
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "etl-nightly-warehouse",
        "warehouse_type": "PRO",
        "warehouse_size": "SMALL",
        "queries": 1000,
        "observed_days": 12,
        "failed_queries": 300,
        "fail_rate": 0.30,
        "distinct_failed_shapes": 3,
        "total_task_ms": 1_000_000.0,
        "failed_task_ms": 400_000.0,
        "total_exec_ms": 900_000.0,
        "failed_exec_ms": 350_000.0,
        "top_failed_statement": "INSERT INTO gold.orders SELECT * FROM silver.orders WHERE dt = current_date()",
        "top_failed_count": 240,
        "cost_30d_usd": 1000.0,
        "dbus_30d": 1800.0,
        "unpriced_dbus": 0.0,
        "days": [
            {"d": "2026-09-01", "t": 90, "f": 27},
            {"d": "2026-09-02", "t": 95, "f": 30},
        ],
    }
    row.update(over)
    return row


def test_flags_repeated_failures():
    f = SqlRepeatedFailuresRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse"
    # Advisory: no dollars booked, low bound is 0, status advisory.
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    # Addressable = 40% of $1000/mo compute.
    assert f.monthly_waste_usd == 400.0
    # 30% fail rate and $400 addressable => HIGH.
    assert f.priority == RulePriority.HIGH
    assert f.effort == EffortBand.MEDIUM
    assert f.evidence["viz"]["kind"] == "sql_failures"
    assert f.evidence["failed_compute_share"] == 0.4
    assert "240" in f.why  # the most-repeated failing query count


def test_rule_is_promoted_advisory_by_default():
    rule = SqlRepeatedFailuresRule()
    assert rule.experimental is False  # promoted out of Labs 2026-09-23 (still advisory)
    assert rule.default_savings_status == "advisory"


def test_task_share_falls_back_to_exec_when_no_task_time():
    # Some warehouses never populate total_task_duration_ms; the share then comes
    # from execution-duration, so the rule still fires.
    f = SqlRepeatedFailuresRule().score(
        _row(total_task_ms=0.0, failed_task_ms=0.0), _ctx()
    )
    assert f is not None
    # 350k / 900k ~= 0.389 exec share on a $1000/mo warehouse.
    assert abs(f.monthly_waste_usd - round(1000.0 * (350_000.0 / 900_000.0), 2)) < 0.01


def test_suppresses_noise_level_failures():
    assert SqlRepeatedFailuresRule().score(
        _row(failed_queries=300, fail_rate=0.02), _ctx()
    ) is None


def test_suppresses_too_few_failures():
    assert SqlRepeatedFailuresRule().score(_row(failed_queries=5), _ctx()) is None


def test_suppresses_below_addressable_floor():
    # High fail rate but almost no compute at stake => not worth surfacing.
    assert SqlRepeatedFailuresRule().score(
        _row(cost_30d_usd=30.0, total_task_ms=1000.0, failed_task_ms=400.0), _ctx()
    ) is None


def test_suppresses_insufficient_history():
    assert SqlRepeatedFailuresRule().score(_row(observed_days=2), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = SqlRepeatedFailuresRule().render_sql(_ctx())
    assert "system.query.history" in sql
    assert "execution_status" in sql
    assert "total_task_duration_ms" in sql
    assert "workspace_id IN" not in sql
