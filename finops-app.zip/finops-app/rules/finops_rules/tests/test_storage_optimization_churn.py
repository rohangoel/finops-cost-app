from __future__ import annotations

from finops_rules.catalog.storage_optimization_churn import StorageOptimizationChurnRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_po_dbus": 50, "min_operations": 30},
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "table_id": "tbl-1",
        "table_full_name": "main.silver.events",
        "operations": 400,
        "observed_days": 20,
        "po_dbus": 620.0,             # >= 500 => HIGH
        "compaction_dbus": 500.0,
        "clustering_dbus": 80.0,
        "vacuum_dbus": 40.0,
        "top_operation": "COMPACTION",
        "top_operation_dbus": 500.0,
        "days": [{"d": "2026-09-01", "n": 30.0}, {"d": "2026-09-02", "n": 31.0}],
    }
    row.update(over)
    return row


def test_flags_churny_table():
    f = StorageOptimizationChurnRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "table"
    assert f.monthly_waste_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "storage_po"
    assert f.evidence["operational_only"] is True
    assert "compaction" in f.why.lower()


def test_rule_is_experimental_and_advisory():
    rule = StorageOptimizationChurnRule()
    assert rule.experimental is True
    assert rule.default_savings_status == "advisory"


def test_suppresses_below_dbu_floor():
    assert StorageOptimizationChurnRule().score(_row(po_dbus=10.0), _ctx()) is None


def test_suppresses_too_few_operations():
    assert StorageOptimizationChurnRule().score(_row(operations=5), _ctx()) is None


def test_suppresses_insufficient_history():
    assert StorageOptimizationChurnRule().score(_row(observed_days=2), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = StorageOptimizationChurnRule().render_sql(_ctx())
    assert "system.storage.predictive_optimization_operations_history" in sql
    assert "workspace_id IN" not in sql
