from __future__ import annotations

import re

import pytest

from finops_rules.catalog.job_no_new_input import JobNoNewInputRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx(**over) -> RuleContext:
    thresholds = {
        "enabled": True,
        "min_runs": 10,
        "min_no_new_input_runs": 5,
        "min_no_new_input_days": 3,
        "min_no_new_input_share": 0.3,
        "min_lineage_run_coverage": 0.5,
        "min_addressable_usd": 25,
    }
    thresholds.update(over)
    return RuleContext(thresholds=thresholds, lookback_days=30, catalog="system")


def _row(**over) -> dict:
    # An hourly job: 720 evaluated runs, 600 of them started with no source write since
    # the previous run; those runs billed $300 over the 30-day window => $300/mo.
    row = {
        "workspace_id": "111",
        "job_id": "42",
        "job_name": "hourly-refresh",
        "evaluated_runs": 720,
        "observed_days": 30,
        "no_new_input_runs": 600,
        "no_new_input_days": 30,
        "no_new_input_cost_30d": 300.0,
        "cost_30d_usd": 360.0,
        "dbus_30d": 700.0,
        "unpriced_dbus": 0.0,
        "last_new_input_run": "2026-09-22 06:00:00",
        "lineage_runs": 715,
        "has_path_read": 0,
        "has_view_read": 0,
        "has_indirect_read": 0,
        "n_sources": 2,
        "n_sources_unwritten": 0,
        "unwritten_sources": [],
        "has_system_source": 0,
        "has_inference_source": 0,
        "sample_sources": ["main.sales.orders", "main.sales.customers"],
    }
    row.update(over)
    return row


def test_flags_scheduled_job_with_no_new_input():
    f = JobNoNewInputRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "job"
    assert f.resource_id == "42"
    # The measured counterfactual is the saving: estimated (shown, ranked, not booked).
    assert f.monthly_savings_usd == pytest.approx(300.0)
    assert f.monthly_savings_low_usd == pytest.approx(300.0)
    assert f.savings_status == "estimated"
    assert f.monthly_waste_usd == pytest.approx(300.0)
    assert f.evidence["addressable_monthly_usd"] == pytest.approx(300.0)
    assert f.evidence["confidence"] == "medium"
    assert f.evidence["no_new_input_share_pct"] == pytest.approx(83.3)
    assert "data_warning" not in f.evidence
    assert f.priority == RulePriority.HIGH
    assert "table-update trigger" in f.how
    assert "main.sales.orders" in f.why


def test_addressable_scales_to_month():
    # $150 of no-new-input runs over a 15-day window => $300/mo
    ctx15 = RuleContext(thresholds=_ctx().thresholds, lookback_days=15, catalog="system")
    f = JobNoNewInputRule().score(_row(no_new_input_cost_30d=150.0, observed_days=15), ctx15)
    assert f is not None
    assert f.monthly_waste_usd == pytest.approx(300.0)


def test_unwritten_source_carries_data_warning():
    f = JobNoNewInputRule().score(
        _row(n_sources_unwritten=1, unwritten_sources=["main.ref.countries"]), _ctx()
    )
    assert f is not None
    assert "main.ref.countries" in f.evidence["data_warning"]
    assert "outside Databricks" in f.evidence["data_warning"]
    # An input we can't see means the run may not be input-less: no saving claimed.
    assert f.savings_status == "advisory"
    assert f.monthly_savings_usd == 0.0 and f.monthly_waste_usd > 0


@pytest.mark.parametrize(
    "over",
    [
        {"has_path_read": 1},  # reads files outside UC tables
        {"has_system_source": 1},  # system.* tables are written outside lineage
        {"has_inference_source": 1},  # serving inference tables likewise
        {"n_sources": 0},  # no observable input at all
        {"has_view_read": 1, "has_indirect_read": 0},  # view not expanded
        {"n_sources_unwritten": 2},  # every source unwritten: no write feed to compare
        {"lineage_runs": 100},  # lineage logged too few of the runs
        {"no_new_input_runs": 4},  # too few to be a pattern
        {"no_new_input_days": 2},  # one quiet stretch, not a pattern
        {"no_new_input_runs": 100, "no_new_input_cost_30d": 300.0},  # share < 30%
        {"no_new_input_cost_30d": 10.0},  # below the dollar floor
        {"evaluated_runs": 0},
        {"observed_days": 2},  # insufficient history
        {"unpriced_dbus": 700.0},  # underpriced
    ],
)
def test_guards_suppress(over):
    assert JobNoNewInputRule().score(_row(**over), _ctx()) is None


def test_rule_is_promoted_estimated():
    r = JobNoNewInputRule()
    assert r.experimental is False  # promoted out of Labs 2026-09-23
    assert r.default_savings_status == "estimated"
    assert r.contract_pricing == "none"
    assert r.cloud_savings == "none"


def test_sql_shape():
    sql = JobNoNewInputRule().render_sql(_ctx())
    assert "trigger_type IN ('CRON', 'PERIODIC')" in sql
    assert "LEFT ANTI JOIN job_targets" in sql  # the job's own outputs are not inputs
    assert "QUALIFY" not in sql
    assert "current_date()" in sql  # closed-open window macro
    # no workspace filter: scoping is injected downstream (joins on it are fine)
    assert not re.search(r"workspace_id\s*(=|IN)\s*['(\d]", sql)


def test_daily_chart_marks_the_last_run_with_new_input():
    from datetime import date, timedelta
    d = (date.today() - timedelta(days=3)).isoformat()
    f = JobNoNewInputRule().score(
        _row(days=[{"d": d, "n": 4, "z": 20}], last_new_input_run=f"{d} 06:00:00"), _ctx())
    v = f.evidence["viz"]
    assert {"d": d, "v": [4.0, 20.0]} in v["days"]
    assert v["marker"] == {"d": d, "label": "last run with new input"}


def test_no_chart_without_a_daily_series():
    f = JobNoNewInputRule().score(_row(), _ctx())
    assert "viz" not in f.evidence  # an older candidate row: no empty frame
