from __future__ import annotations

from finops_rules.catalog.enable_photon_dbr import EnablePhotonDbrRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_dbr_major": 13},
        lookback_days=30,
        catalog="system",
    )


def _old_dbr_row() -> dict:
    return {
        "workspace_id": "111",
        "cluster_id": "c-old",
        "cluster_name": "legacy-etl",
        "dbr_version": "11.3.x-scala2.12",
        "cost_30d_usd": 4000.0,
    }


def test_flags_old_dbr_cluster_as_advisory_zero():
    """FIN-021: an old-runtime cluster is a Photon/DBR-upgrade candidate, but the uplift
    is an unmeasured heuristic, so it is surfaced as advisory $0 — the ~15% figure is the
    UPPER BOUND of what an upgrade might reclaim, not a booked saving."""
    finding = EnablePhotonDbrRule().score(_old_dbr_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-old"
    assert finding.effort == EffortBand.MEDIUM
    assert finding.priority == RulePriority.MEDIUM
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_usd == 0.0
    assert finding.monthly_savings_low_usd == 0.0
    # ~15% of $4000/mo is the max-addressable upper bound (high), never booked.
    assert 550 < finding.monthly_savings_high_usd < 650
    assert finding.monthly_waste_usd == 4000.0
    assert "11.3.x-scala2.12" in finding.why


def test_books_zero_regardless_of_workload_class():
    """The FIN-021 invariant: nothing is booked whatever the runtime class — the uplift
    is a heuristic ceiling, not a measured saving."""
    for dbr in ("11.3.x-scala2.12", "11.3.x-cpu-ml-scala2.12", "11.3.x-photon-scala2.12"):
        row = _old_dbr_row()
        row["dbr_version"] = dbr
        f = EnablePhotonDbrRule().score(row, _ctx())
        assert f is not None
        assert f.monthly_savings_usd == 0.0
        assert f.monthly_savings_low_usd == 0.0
        assert f.monthly_savings_high_usd > 0.0  # upper bound is surfaced


def test_ml_upper_bound_lower_than_mixed():
    """SME review: Photon barely accelerates Python/ML, so an ML runtime's upper bound is
    the floor (~5%), far below the mixed all-purpose default (~15%)."""
    mixed = EnablePhotonDbrRule().score(_old_dbr_row(), _ctx())
    ml_row = _old_dbr_row()
    ml_row["dbr_version"] = "11.3.x-cpu-ml-scala2.12"
    ml = EnablePhotonDbrRule().score(ml_row, _ctx())
    assert mixed is not None and ml is not None
    assert ml.evidence["workload_class"] == "ml"
    assert ml.evidence["uplift_fraction"] == 0.05
    assert ml.monthly_savings_high_usd < mixed.monthly_savings_high_usd
    # The ceiling is still a heuristic, so confidence is stated as low.
    assert ml.evidence["confidence"] == "low"


def test_photon_already_on_credited_dbr_upgrade_only():
    row = _old_dbr_row()
    row["dbr_version"] = "11.3.x-photon-scala2.12"
    finding = EnablePhotonDbrRule().score(row, _ctx())
    assert finding is not None
    assert finding.evidence["workload_class"] == "photon_on"
    assert finding.evidence["uplift_fraction"] == 0.05


def test_advisory_books_zero_in_aggregation():
    from finops.services.aggregation import account_overview
    from finops.models import Recommendation
    from datetime import date, datetime, timezone

    f = EnablePhotonDbrRule().score(_old_dbr_row(), _ctx())
    rec = Recommendation(
        recommendation_id="r1", snapshot_date=date(2026, 9, 1), rule_id="enable_photon_dbr",
        rule_version="2.0.0", rule_title="t", category="compute", workspace_id="111",
        resource_type="cluster", resource_id="c-old", resource_name="n", why="", how="",
        monthly_waste_usd=f.monthly_waste_usd, monthly_savings_usd=f.monthly_savings_usd,
        savings_status="advisory", monthly_savings_low_usd=0.0,
        monthly_savings_high_usd=f.monthly_savings_high_usd, effort_band="medium",
        effort_score=3, priority="MEDIUM", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


def test_suppresses_current_dbr():
    row = _old_dbr_row()
    row["dbr_version"] = "14.3.x"
    assert EnablePhotonDbrRule().score(row, _ctx()) is None


def test_suppresses_custom_dbr():
    row = _old_dbr_row()
    row["dbr_version"] = "custom:my-image"
    assert EnablePhotonDbrRule().score(row, _ctx()) is None


def test_suppresses_when_no_cost():
    row = _old_dbr_row()
    row["cost_30d_usd"] = 0
    assert EnablePhotonDbrRule().score(row, _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = EnablePhotonDbrRule().render_sql(_ctx())
    assert "system.compute.clusters" in sql
    assert "workspace_id IN" not in sql
