from __future__ import annotations

from finops_rules.catalog.ai_gateway_wasted_inference import AiGatewayWastedInferenceRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_failed_requests": 100, "min_error_rate": 0.05},
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "endpoint_id": "ep-1",
        "endpoint_name": "prod-rag-endpoint",
        "requests": 2000,
        "observed_days": 14,
        "failed_requests": 1200,       # 60% error rate
        "server_errors": 900,
        "failed_input_tokens": 2_000_000,
        "error_rate": 0.60,
        "top_status_code": 500,
        "top_status_count": 800,
        "days": [{"d": "2026-09-01", "t": 140, "f": 90}, {"d": "2026-09-02", "t": 150, "f": 95}],
    }
    row.update(over)
    return row


def test_flags_high_error_endpoint():
    f = AiGatewayWastedInferenceRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "serving_endpoint"
    # Operational: no dollars booked or addressed.
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_waste_usd == 0.0
    assert f.savings_status == "advisory"
    # 60% error rate => HIGH.
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "ai_gateway_errors"
    assert f.evidence["failed_input_tokens"] == 2_000_000
    assert "500" in f.why  # the dominant failing status


def test_rule_is_experimental_and_advisory():
    rule = AiGatewayWastedInferenceRule()
    assert rule.experimental is True
    assert rule.default_savings_status == "advisory"


def test_suppresses_noise_level_errors():
    assert AiGatewayWastedInferenceRule().score(
        _row(failed_requests=100, error_rate=0.02), _ctx()
    ) is None


def test_suppresses_too_few_failures():
    assert AiGatewayWastedInferenceRule().score(_row(failed_requests=10), _ctx()) is None


def test_suppresses_insufficient_history():
    assert AiGatewayWastedInferenceRule().score(_row(observed_days=2), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = AiGatewayWastedInferenceRule().render_sql(_ctx())
    assert "system.ai_gateway.usage" in sql
    assert "status_code" in sql
    assert "workspace_id IN" not in sql
