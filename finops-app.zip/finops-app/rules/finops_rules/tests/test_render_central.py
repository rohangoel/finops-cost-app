"""Rendering rules in central mode: the scoped Central Logfood views must appear, the
rule's OWN WHERE predicates must survive verbatim (the inline-view approach must not
touch them), and nested rendering must be byte-identical to the default.
"""

from __future__ import annotations

import pytest

from finops_rules import get_enabled_rules, get_rule, load_thresholds
from finops_rules.contract import RuleContext
from finops_rules.resolver import CENTRAL_NAMESPACE, TableResolver

TH = load_thresholds()


def _central_sql(rule_id: str, account_ids=("acc-1", "acc-2")) -> str:
    rule = get_rule(rule_id)
    ctx = RuleContext(
        thresholds=TH.get(rule_id, {}),
        lookback_days=30,
        currency="USD",
        resolver=TableResolver.central_for(list(account_ids)),
    )
    return rule.render_sql(ctx)


def _nested_sql(rule_id: str) -> str:
    rule = get_rule(rule_id)
    ctx = RuleContext(thresholds=TH.get(rule_id, {}), lookback_days=30, catalog="system",
                      currency="USD")
    return rule.render_sql(ctx)


@pytest.mark.parametrize("rule_id", ["untagged_spend", "idle_zombie_clusters",
                                     "idle_serving_endpoints"])
def test_central_render_uses_flat_namespace_and_scope(rule_id):
    sql = _central_sql(rule_id)
    assert CENTRAL_NAMESPACE in sql
    assert "account_id IN ('acc-1', 'acc-2')" in sql
    assert "{{" not in sql and "}}" not in sql  # no unrendered Jinja
    assert "system.billing" not in sql            # no leftover nested refs


def test_central_render_preserves_the_rules_own_where_clause():
    # untagged_spend filters usage_date + record_type; those must survive the rewrite.
    sql = _central_sql("untagged_spend")
    assert "record_type" in sql
    assert "usage_date >=" in sql


def test_central_price_join_adds_the_account_key():
    # Multi-account scans must join prices on account_id or promo prices leak.
    sql = _central_sql("idle_zombie_clusters")
    assert "u.account_id = lp.account_id" in sql
    assert "SELECT DISTINCT account_id, cloud, sku_name" in sql  # dedup projection


def test_nested_render_has_no_central_account_key():
    # The account key is central-only; nested output stays exactly as before.
    assert "account_id = lp.account_id" not in _nested_sql("idle_zombie_clusters")


def test_every_enabled_rule_renders_or_is_a_known_central_exclusion():
    """Central-render every enabled rule: it must either render cleanly or raise the
    resolver's 'no Central Logfood equivalent' error (the auto-exclusion path)."""
    resolver = TableResolver.central_for(["a"])
    excluded = []
    for rule in get_enabled_rules(TH):
        ctx = RuleContext(thresholds=TH.get(rule.id, {}), lookback_days=30, currency="USD",
                          resolver=resolver)
        try:
            sql = rule.render_sql(ctx)
        except ValueError as exc:
            assert "no Central Logfood equivalent" in str(exc)
            excluded.append(rule.id)
            continue
        assert CENTRAL_NAMESPACE in sql
    # These rules read tables with no Central Logfood equivalent and MUST be auto-excluded
    # (else their candidate flows fail to resolve and take the whole update down):
    #   unused_data_jobs   -> access.table_lineage
    #   alert_hygiene      -> alert.alerts / alert.alert_evaluation_history
    #   instance_pool_idle -> compute.instance_events / compute.instance_pools
    for rid in ("unused_data_jobs", "alert_hygiene", "instance_pool_idle"):
        assert rid in excluded, f"{rid} must be excluded from central mode"


def test_namespace_is_overridable_for_a_slice():
    # Pointing the resolver at a pre-filtered slice namespace rewrites the flat billing
    # tables there (workspaces_latest still resolves to certified). Default is unchanged.
    from finops_rules.resolver import CENTRAL_NAMESPACE, TableResolver

    default = TableResolver.central_for(["a1"])
    assert default("billing", "usage").startswith(f"(SELECT * FROM {CENTRAL_NAMESPACE}.billing_usage")

    sliced = TableResolver.central_for(["a1"], namespace="main.team_field_dsa_ce")
    assert "main.team_field_dsa_ce.billing_usage" in sliced("billing", "usage")
    assert "main.team_field_dsa_ce.billing_list_prices" in sliced("billing", "list_prices")
    # workspaces_latest ignores the namespace (different, certified catalog).
    assert "certified.workspaces_latest" in sliced("access", "workspaces_latest")
