"""The chargeback rule: attribution, not savings.

Two things are load-bearing here and neither is arithmetic:

1. **Savings must stay $0.** Tagging a cluster does not reduce the bill. If this
   rule ever contributed to the savings headline, the total would include money
   nobody can bank — the one thing the engine's core invariant forbids.
2. **`missing_tags` must survive every reader.** The column is an ARRAY<STRING>,
   and the readers disagree: Spark and the SQL connector return a real list, while
   the REST statement API returns JSON *text*. Iterating that text yields single
   characters, which really did produce "missing 22 of 5 tags (a, c, c, e, ...)"
   against the live account before :func:`_missing_tags` existed.
"""

from __future__ import annotations

from finops_rules import load_thresholds
from finops_rules.catalog.untagged_spend import UntaggedSpendRule, _missing_tags
from finops_rules.contract import RuleContext

THRESHOLDS = load_thresholds()["untagged_spend"]


def _ctx(**over) -> RuleContext:
    thresholds = {**THRESHOLDS, **over.pop("thresholds", {})}
    return RuleContext(
        thresholds=thresholds,
        lookback_days=over.pop("lookback_days", 30),
        catalog="system",
        currency="USD",
        min_observation_days=over.pop("min_observation_days", 5),
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "resource_id": "0421-182025-abc",
        "resource_type": "cluster",
        "job_name": None,
        "cost_30d_usd": 1000.0,
        "dbus_30d": 500.0,
        "unpriced_dbus": 0.0,
        "observed_days": 30,
        "identity_hint": "someone@example.com",
        "missing_tags": ["cost_center", "team"],
        "required_tag_count": 5,
    }
    row.update(over)
    return row


# --- the reader-shape trap -------------------------------------------------

def test_missing_tags_accepts_a_real_list():
    assert _missing_tags(["team", "owner"]) == ["owner", "team"]


def test_missing_tags_parses_json_text_from_the_rest_api():
    """The REST statement API returns ARRAY<STRING> as JSON text. Iterating the
    raw string would yield characters, not tag names."""
    assert _missing_tags('["team","cost_center"]') == ["cost_center", "team"]


def test_missing_tags_never_yields_characters():
    """The specific regression: a JSON string must not be treated as an iterable
    of characters."""
    out = _missing_tags('["team"]')
    assert out == ["team"]
    assert all(len(tag) > 1 for tag in out)


def test_missing_tags_handles_empty_and_unparseable():
    assert _missing_tags(None) == []
    assert _missing_tags([]) == []
    assert _missing_tags("[]") == []
    # Garbage suppresses the finding rather than emitting a garbled one.
    assert _missing_tags("not json at all") == []
    assert _missing_tags(42) == []


def test_missing_tags_drops_nulls():
    """array_compact should remove them, but a NULL must never become the string
    "None" in advice telling an admin which tag to add."""
    assert _missing_tags(["team", None, ""]) == ["team"]


# --- the $0-savings invariant ----------------------------------------------

def test_savings_are_always_zero():
    finding = UntaggedSpendRule().score(_row(), _ctx())
    assert finding is not None
    assert finding.monthly_savings_usd == 0.0


def test_unattributable_spend_is_carried_as_waste():
    """The rule's value is the spend it makes attributable, so that figure must be
    present and real even though savings are 0."""
    finding = UntaggedSpendRule().score(_row(cost_30d_usd=1000.0), _ctx())
    assert finding.monthly_waste_usd == 1000.0
    assert finding.evidence["unattributable_monthly_usd"] == 1000.0


# --- suppression guards ----------------------------------------------------

def test_fully_tagged_resource_is_suppressed():
    assert UntaggedSpendRule().score(_row(missing_tags=[]), _ctx()) is None


def test_cheap_resource_is_suppressed():
    """One finding per trivial cluster would bury the rules carrying real money."""
    assert UntaggedSpendRule().score(_row(cost_30d_usd=10.0), _ctx()) is None


def test_new_resource_is_suppressed():
    """A resource seen for two days may simply not have been tagged yet — someone
    is probably still building it."""
    assert UntaggedSpendRule().score(_row(observed_days=2), _ctx()) is None


def test_min_missing_tags_is_configurable():
    row = _row(missing_tags=["cost_center"])
    assert UntaggedSpendRule().score(row, _ctx()) is not None
    strict = _ctx(thresholds={"min_missing_tags": 2})
    assert UntaggedSpendRule().score(row, strict) is None


def test_mostly_unpriced_resource_is_suppressed():
    """Cost too incomplete to state a governance gap in dollars."""
    row = _row(dbus_30d=500.0, unpriced_dbus=450.0)
    assert UntaggedSpendRule().score(row, _ctx()) is None


# --- the advice ------------------------------------------------------------

def test_why_and_how_name_the_actual_missing_tags():
    finding = UntaggedSpendRule().score(_row(missing_tags=["team"]), _ctx())
    assert "team" in finding.why
    assert "team" in finding.how
    # Never the placeholder that shipped before the SQL emitted names.
    assert "required tags)" not in finding.why


def test_how_points_at_the_right_ui_for_each_resource_type():
    for rtype, needle in [
        ("cluster", "Compute >"),
        ("warehouse", "SQL Warehouses >"),
        ("job", "Workflows >"),
    ]:
        finding = UntaggedSpendRule().score(_row(resource_type=rtype), _ctx())
        assert finding.resource_type == rtype
        assert needle in finding.how


def test_identity_hint_is_offered_but_not_called_an_owner():
    """run_as says who ran it, not which cost centre pays. It is a lead to follow,
    never a substitute for the tag."""
    finding = UntaggedSpendRule().score(_row(), _ctx())
    assert "someone@example.com" in finding.how
    assert finding.evidence["identity_hint"] == "someone@example.com"


def test_no_identity_hint_still_produces_clean_prose():
    finding = UntaggedSpendRule().score(_row(identity_hint=None), _ctx())
    assert "None" not in finding.why
    assert "None" not in finding.how


def test_priority_tracks_unattributable_spend_not_tag_count():
    """A $5k/mo resource missing one tag matters more than a $60/mo one missing
    all five."""
    big = UntaggedSpendRule().score(
        _row(cost_30d_usd=5000.0, missing_tags=["team"]), _ctx()
    )
    small = UntaggedSpendRule().score(
        _row(cost_30d_usd=60.0,
             missing_tags=["owner", "team", "project", "environment", "cost_center"]),
        _ctx(),
    )
    assert big.priority.value == "HIGH"
    assert small.priority.value == "LOW"


def test_evidence_splits_present_from_missing_tags():
    finding = UntaggedSpendRule().score(_row(missing_tags=["team"]), _ctx())
    assert finding.evidence["missing_tags"] == ["team"]
    assert "team" not in finding.evidence["present_tags"]
    assert "owner" in finding.evidence["present_tags"]


def test_effort_is_trivial():
    """Adding a tag is a config change with no workload impact — so the NBA
    ranking must not treat it as a migration."""
    assert UntaggedSpendRule().score(_row(), _ctx()).effort.value == "trivial"


# --- SQL shape -------------------------------------------------------------

def test_sql_matches_tags_case_insensitively():
    """Verified live: the same account carries both `Owner` and `owner`. An
    exact-match check would report tagged resources as untagged."""
    sql = UntaggedSpendRule().render_sql(_ctx())
    assert "lower(k) IN" in sql
    assert "'owner'" in sql
    # Aliases from config must reach the SQL.
    assert "'costcenter'" in sql


def test_sql_treats_blank_tag_values_as_absent():
    sql = UntaggedSpendRule().render_sql(_ctx())
    assert "trim(v) <> ''" in sql


def test_sql_applies_corrections_and_excludes_untaggable_usage():
    """FIN-003: usage is an additive ledger, so summing spend must include every
    ``record_type`` — a RETRACTION's negative quantity cancels the superseded
    ORIGINAL. The old ``record_type = 'ORIGINAL'`` filter kept stale rows and
    dropped the correction, so it must be gone."""
    sql = UntaggedSpendRule().render_sql(_ctx())
    assert "record_type = 'ORIGINAL'" not in sql
    # Usage with no resource id (APPS, VECTOR_SEARCH) has nothing to tag.
    assert "IS NOT NULL" in sql


def test_sql_has_no_workspace_filter():
    """Scoping is injected by the data layer, so one query serves both modes."""
    assert "workspace_id IN" not in UntaggedSpendRule().render_sql(_ctx())


def test_demo_mode_honours_the_zero_savings_invariant():
    """Demo mode fabricates findings from a profile table rather than from SQL, so
    the invariant has to be enforced there too — otherwise the demo's savings
    headline would include money that cannot be banked, which is exactly the
    claim the live rule refuses to make."""
    import sys
    from pathlib import Path

    backend = str(Path(__file__).resolve().parents[3] / "backend")
    if backend not in sys.path:
        sys.path.insert(0, backend)

    from finops.config import Settings
    from finops.data.demo_source import DemoRecommendationSource
    from finops.identity import Scope

    src = DemoRecommendationSource(Settings(compute_mode="demo"), None)
    scope = Scope(all_workspaces=True)
    # untagged_spend is the governance/chargeback category, relocated to its own
    # Tagging & Chargeback tab — so it comes back via fetch_sidecar, and must NOT
    # leak into the main recommendation set that fetch() serves.
    tagging = [r for r in src.fetch_sidecar(scope) if r.rule_id == "untagged_spend"]
    assert tagging, "demo mode should surface the chargeback rule (on the tagging tab)"
    assert not [r for r in src.fetch(scope) if r.rule_id == "untagged_spend"], (
        "governance findings must be excluded from the main recommendation set"
    )
    assert all(r.monthly_savings_usd == 0.0 for r in tagging)
    # The unattributable spend is still reported — that IS the finding.
    assert all(r.monthly_waste_usd > 0 for r in tagging)
    # And the copy must not claim the waste is avoidable.
    assert all("avoidable waste" not in r.why for r in tagging)
