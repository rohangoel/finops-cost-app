from __future__ import annotations

from finops_rules.catalog.interactive_to_job import InteractiveToJobRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    # recency_days == 30 here so the SQL's measurement window equals a month and the
    # fixtures' cost_30d_usd/savings_30d_usd values normalize 1:1 (window == monthly).
    # Production uses recency_days=7; the scaling and gate are covered by their own
    # tests below.
    return RuleContext(
        thresholds={"enabled": True, "min_monthly_cost_usd": 200, "min_runs": 3,
                    "recency_days": 30},
        lookback_days=30,
        catalog="system",
    )


def _costly_row(dedicated: bool = True) -> dict:
    # An all-purpose cluster judged as a whole. Its jobs were active for most of
    # its uptime, so ~1000 DBUs are reassignable. At $0.55 all-purpose vs $0.30
    # jobs-compute: cost = $550/mo, savings = 1000 * (0.55 - 0.30) = $250/mo (real
    # price gap). observed_days clears the history guard. ``dedicated`` sets the
    # is_dedicated flag the SQL emits: True = job-only cluster (bookable), False =
    # shared/interactive (estimated, low=0) — FIN-010.
    return {
        "workspace_id": "111",
        "cluster_id": "c-int",
        "cluster_name": "shared-interactive",
        "job_count": 2,
        "recurring_job_count": 2,
        "run_count": 7,
        "runtime_hours": 12.0,
        "observed_days": 30,
        "running_minutes": 10_000,
        "job_active_minutes": 9_000,
        "job_active_frac": 0.90,
        "is_dedicated": dedicated,
        "attributed_dbus": 1000.0,
        "dbus_30d": 1111.0,
        "unpriced_dbus": 0.0,        # fully priced => coverage supports booking
        "price_all_purpose": 0.55,
        "price_jobs_compute": 0.30,
        "cost_30d_usd": 550.0,
        "savings_30d_usd": 250.0,
        "job_breakdown": [{"runs": 4, "job_id": "j-42", "hours": 8.0},
                          {"runs": 3, "job_id": "j-43", "hours": 4.0}],
    }


def test_flags_jobs_on_interactive_compute():
    finding = InteractiveToJobRule().score(_costly_row(), _ctx())
    assert finding is not None
    assert finding.resource_type == "cluster"
    assert finding.resource_id == "c-int"
    assert finding.effort == EffortBand.HIGH
    assert finding.priority == RulePriority.MEDIUM
    # One finding for the whole cluster, naming the recurring job count.
    assert "2 recurring jobs" in finding.why
    assert "7 run" in finding.why


def test_prices_the_real_sku_price_delta_not_a_flat_fraction():
    # Savings come from the SQL's attributed-DBU x price-gap figure, scaled to a
    # month (lookback == 30 days here, so window == monthly).
    finding = InteractiveToJobRule().score(_costly_row(), _ctx())
    assert finding is not None
    assert abs(finding.monthly_savings_usd - 250.0) < 0.5
    # The measured path prices the exact gap, not a fixed fraction, so assert it
    # tracks the price gap when we change ONLY the gap.
    row = _costly_row()
    row["savings_30d_usd"] = 1000.0 * (0.55 - 0.05)  # bigger gap = 500
    finding2 = InteractiveToJobRule().score(row, _ctx())
    assert abs(finding2.monthly_savings_usd - 500.0) < 0.5


def test_falls_back_to_conservative_fraction_when_price_gap_missing():
    # SME review round 2, finding #5: the fallback uses the CONSERVATIVE low end of the
    # 30-55% gap (default 0.30), not the mid 0.45, and drops to MEDIUM confidence.
    row = _costly_row()
    row["savings_30d_usd"] = None           # e.g. no jobs-compute SKU for the cloud
    finding = InteractiveToJobRule().score(row, _ctx())
    assert finding is not None
    # 30% of the $550/mo cost (the conservative default fallback fraction).
    assert abs(finding.monthly_savings_usd - 550.0 * 0.30) < 0.5
    assert finding.evidence["confidence"] == "medium"
    assert "conservative" in finding.why.lower()


def test_measured_path_is_high_confidence_fallback_is_medium():
    measured = InteractiveToJobRule().score(_costly_row(), _ctx())
    assert measured is not None
    assert measured.evidence["confidence"] == "high"
    fallback_row = _costly_row()
    fallback_row["savings_30d_usd"] = None
    fallback = InteractiveToJobRule().score(fallback_row, _ctx())
    assert fallback.evidence["confidence"] == "medium"
    # And the conservative fallback under-promises vs the measured $250 gap here.
    assert fallback.monthly_savings_usd < measured.monthly_savings_usd


def test_fallback_fraction_is_configurable():
    row = _costly_row()
    row["savings_30d_usd"] = None
    ctx = _ctx()
    ctx.thresholds["fallback_savings_fraction"] = 0.35
    finding = InteractiveToJobRule().score(row, ctx)
    assert abs(finding.monthly_savings_usd - 550.0 * 0.35) < 0.5


def test_never_exceeds_monthly_cost():
    row = _costly_row()
    row["savings_30d_usd"] = 10_000.0       # absurd; must be capped at cost
    finding = InteractiveToJobRule().score(row, _ctx())
    assert finding is not None
    assert finding.monthly_savings_usd <= finding.monthly_waste_usd


def test_suppresses_below_min_cost():
    # The min-cost bar applies to the REASSIGNABLE (job-active) cost, not the
    # cluster's whole bill: a mostly-idle cluster with tiny jobs is suppressed.
    row = _costly_row()
    row["cost_30d_usd"] = 100.0  # ~$100/mo reassignable < $200 threshold
    assert InteractiveToJobRule().score(row, _ctx()) is None


def test_mostly_idle_cluster_yields_tiny_saving():
    # Regression for the nh-streaming bug: a 99%-idle streaming cluster whose
    # jobs used ~1% of uptime must attribute ~1% of cost, not the whole bill.
    row = _costly_row()
    row["job_active_frac"] = 0.01
    row["attributed_dbus"] = 21.68
    row["cost_30d_usd"] = 11.93       # ~1% of a $1,200/mo cluster
    row["savings_30d_usd"] = 5.42
    # Below the $200 reassignable-cost bar => no migration recommendation.
    assert InteractiveToJobRule().score(row, _ctx()) is None


def test_recency_days_scales_window_cost_to_month():
    # The SQL measures cost/savings over the recency window; score() normalizes to a
    # month by recency_days. With a 7-day window, a $250 window saving projects to
    # $250 * 30/7 ~= $1071/mo (bounded by the reassignable cost, here $550*30/7).
    ctx = RuleContext(
        thresholds={"enabled": True, "min_monthly_cost_usd": 200, "min_runs": 3,
                    "recency_days": 7},
        lookback_days=30, catalog="system",
    )
    finding = InteractiveToJobRule().score(_costly_row(), ctx)
    assert finding is not None
    assert abs(finding.monthly_savings_usd - 250.0 * 30.0 / 7.0) < 1.0
    assert abs(finding.monthly_waste_usd - 550.0 * 30.0 / 7.0) < 1.0


def test_recency_window_and_frac_cap_render_in_sql():
    ctx = RuleContext(
        thresholds={"enabled": True, "min_monthly_cost_usd": 200, "min_runs": 3,
                    "recency_days": 7},
        lookback_days=30, catalog="system",
    )
    sql = InteractiveToJobRule().render_sql(ctx)
    # Dollars/activity sized on the recency window; recurrence still on the lookback.
    assert "date_sub(current_date(), 7)" in sql
    assert "date_sub(current_date(), 30)" in sql
    # job_active_frac (and the attributed columns) capped at 1.0 so node_timeline
    # under-reporting can never inflate the ratio past the metered spend.
    assert "1.0)" in sql
    assert sql.count("LEAST(COALESCE(jam.job_active_minutes, 0)") >= 4


def test_sql_renders_without_workspace_filter():
    sql = InteractiveToJobRule().render_sql(_ctx())
    assert "system.billing.usage" in sql
    assert "ALL_PURPOSE" in sql
    assert "job_task_run_timeline" in sql
    # Per-cluster, uptime-attributed grain: node_timeline running minutes are the
    # denominator, and the cluster is no longer fragmented per job by a
    # concurrency filter.
    assert "node_timeline" in sql
    assert "job_active_minutes" in sql
    assert "running_minutes" in sql
    assert "concurrency_factor" not in sql
    assert "workspace_id IN" not in sql
    # Region-correct pricing: price each usage row at its OWN sku's rate and pair
    # it with the same-region JOBS_COMPUTE sku — never a global MAX() across all
    # price variants (which grabbed the priciest regional rate, e.g. IN_WEST_JIO).
    assert "MAX(CASE WHEN sku_name LIKE" not in sql
    assert "u.sku_name = ap_lp.sku_name" in sql
    assert "replace(u.sku_name, 'ALL_PURPOSE_COMPUTE', 'JOBS_COMPUTE')" in sql
    # Both price lookups go through the shared macro, so each pins currency to the
    # configured one directly. That subsumes the old trick of correlating the
    # counterpart's currency_code to the all-purpose row's, and additionally pins
    # cloud and usage_unit — see sql/_macros.sql.j2.
    assert sql.count("currency_code = 'USD'") == 2
    for alias in ("ap_lp", "jc_lp"):
        assert f"u.cloud = {alias}.cloud" in sql
        assert f"u.usage_unit = {alias}.usage_unit" in sql


# --- FIN-010 dedicated vs shared counterfactual (Phase 3) --------------------

def test_dedicated_cluster_is_bookable_low_equals_point():
    # A job-DEDICATED all-purpose cluster: removing the jobs eliminates the cluster,
    # so the measured price gap is realized and the finding BOOKS (low == point).
    finding = InteractiveToJobRule().score(_costly_row(dedicated=True), _ctx())
    assert finding is not None
    assert finding.savings_status == "bookable"
    assert finding.evidence["confidence"] == "high"
    lo = finding.monthly_savings_low_usd
    pt = finding.monthly_savings_usd
    hi = finding.monthly_savings_high_usd
    assert lo == pt == hi
    assert abs(pt - 250.0) < 0.5
    assert "job-dedicated" in finding.why.lower()


def test_shared_cluster_is_estimated_with_zero_lower_bound():
    # A SHARED/interactive cluster: moving the jobs off may not shrink the cluster,
    # so the lower bound is $0 and the attributed gap is the upper scenario only.
    finding = InteractiveToJobRule().score(_costly_row(dedicated=False), _ctx())
    assert finding is not None
    assert finding.savings_status == "estimated"
    # Still a HIGH-confidence measurement — the uncertainty is in the counterfactual,
    # not the price gap.
    assert finding.evidence["confidence"] == "high"
    assert finding.monthly_savings_low_usd == 0.0
    assert abs(finding.monthly_savings_usd - 250.0) < 0.5
    assert abs(finding.monthly_savings_high_usd - finding.monthly_savings_usd) < 0.5
    assert "upper estimate" in finding.why.lower()


def test_unmeasured_gap_is_advisory_not_booked():
    # No jobs-compute rate in list_prices => the gap can't be MEASURED. The fixed
    # fraction is a heuristic, so the finding is advisory (books nothing), low=0.
    row = _costly_row(dedicated=True)         # dedicated, but no measured gap
    row["savings_30d_usd"] = None
    finding = InteractiveToJobRule().score(row, _ctx())
    assert finding is not None
    assert finding.savings_status == "advisory"
    assert finding.monthly_savings_low_usd == 0.0
    assert abs(finding.monthly_savings_usd - 550.0 * 0.30) < 0.5


def test_bands_are_ordered_and_bounded_across_tiers():
    # low <= point <= high, and savings never exceed the reassignable cost (waste),
    # for every tier — the portfolio invariants, at the rule level.
    for dedicated in (True, False):
        for measured in (True, False):
            row = _costly_row(dedicated=dedicated)
            if not measured:
                row["savings_30d_usd"] = None
            f = InteractiveToJobRule().score(row, _ctx())
            assert f is not None
            lo, pt, hi = (f.monthly_savings_low_usd, f.monthly_savings_usd,
                          f.monthly_savings_high_usd)
            assert lo <= pt <= hi, (dedicated, measured, lo, pt, hi)
            assert pt <= f.monthly_waste_usd + 1e-6


def test_dedicated_column_flows_into_evidence():
    assert InteractiveToJobRule().score(_costly_row(dedicated=True), _ctx()).evidence[
        "is_dedicated"
    ] is True
    assert InteractiveToJobRule().score(_costly_row(dedicated=False), _ctx()).evidence[
        "is_dedicated"
    ] is False


def test_dedicated_with_unknown_coverage_does_not_book():
    # FIN-004 fail-closed on the booking path: booking requires coverage that is
    # KNOWN and >= the floor. When the coverage columns are absent (an older
    # precompute snapshot), coverage_supports_booking() returns False, so even a
    # job-dedicated cluster must NOT book — it drops to estimated rather than book a
    # dollar it cannot prove is fully priced.
    row = _costly_row(dedicated=True)
    row.pop("dbus_30d", None)
    row.pop("unpriced_dbus", None)          # coverage unknown
    finding = InteractiveToJobRule().score(row, _ctx())
    assert finding is not None              # unknown coverage fails OPEN for visibility
    assert finding.savings_status == "estimated"   # ...but fails CLOSED for booking
    assert finding.monthly_savings_low_usd == 0.0
    # The narrative must match the tier: an ESTIMATED finding must NOT claim it
    # "realizes the exact price gap" (the booked-cluster copy) — that clause is gated
    # on the same booking decision, so it falls to the $0-lower-bound wording here.
    assert "realizes the exact" not in finding.why
    assert "upper estimate" in finding.why


def test_fully_priced_dedicated_books():
    # The positive of the guard above: full coverage (no unpriced DBUs) on a
    # dedicated cluster books normally.
    row = _costly_row(dedicated=True)
    row["dbus_30d"] = 1000.0
    row["unpriced_dbus"] = 0.0
    finding = InteractiveToJobRule().score(row, _ctx())
    assert finding is not None
    assert finding.savings_status == "bookable"
