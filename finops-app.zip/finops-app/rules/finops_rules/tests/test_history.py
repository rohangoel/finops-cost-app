"""The minimum-observation guard: too-new resources must not be recommended on.

Covers the guard itself (finops_rules.history) plus its wiring into every rule
that carries it, because the failure mode being prevented is silent: a rule that
forgets the guard still passes all its OTHER tests while emitting a monthly dollar
figure extrapolated from one afternoon.
"""

from __future__ import annotations

import pytest

from finops_rules.contract import DEFAULT_MIN_OBSERVATION_DAYS, RuleContext
from finops_rules.history import (
    effective_min_days,
    history_evidence,
    history_note,
    insufficient_history,
    observed_days,
)


def _ctx(*, min_days: int = 5, lookback: int = 30) -> RuleContext:
    return RuleContext(
        thresholds={}, lookback_days=lookback, catalog="system",
        min_observation_days=min_days,
    )


# --- the guard itself -------------------------------------------------------

def test_default_minimum_is_five_days():
    assert DEFAULT_MIN_OBSERVATION_DAYS == 5
    assert RuleContext(thresholds={}).min_observation_days == 5


@pytest.mark.parametrize("days,blocked", [(0, True), (1, True), (4, True), (5, False), (30, False)])
def test_blocks_below_minimum_only(days, blocked):
    assert insufficient_history({"observed_days": days}, _ctx()) is blocked


def test_one_day_of_data_is_suppressed():
    """The reported case: a resource that only ran for a single day."""
    assert insufficient_history({"observed_days": 1}, _ctx()) is True


def test_missing_column_does_not_block():
    """Unknown history is not evidence of short history — a rule whose SQL
    predates the guard (or an older snapshot) must not silently empty the app."""
    assert insufficient_history({}, _ctx()) is False
    assert insufficient_history({"observed_days": None}, _ctx()) is False


def test_unparseable_value_does_not_block():
    assert insufficient_history({"observed_days": "n/a"}, _ctx()) is False


def test_observed_days_coerces_strings_and_floats():
    assert observed_days({"observed_days": "7"}) == 7
    assert observed_days({"observed_days": 7.0}) == 7
    assert observed_days({}) is None


def test_threshold_clamped_to_lookback_window():
    """A 3-day window can never yield 5 observed days; demanding it would suppress
    everything rather than filter the unrepresentative rows."""
    assert effective_min_days(_ctx(min_days=5, lookback=3)) == 3
    assert insufficient_history({"observed_days": 3}, _ctx(min_days=5, lookback=3)) is False


def test_zero_observed_days_always_blocked():
    """Even with the threshold configured off, no evidence means no finding."""
    assert insufficient_history({"observed_days": 0}, _ctx(min_days=0)) is True


def test_threshold_is_configurable_upward():
    assert insufficient_history({"observed_days": 6}, _ctx(min_days=10)) is True
    assert insufficient_history({"observed_days": 10}, _ctx(min_days=10)) is False


# --- the honesty payloads ---------------------------------------------------

def test_history_note_states_the_sample_size():
    note = history_note({"observed_days": 7}, _ctx())
    assert "7 days of observed activity" in note
    assert "minimum 5" in note


def test_history_note_singular_day():
    assert "1 day of observed" in history_note({"observed_days": 1}, _ctx())


def test_history_note_empty_when_unknown():
    assert history_note({}, _ctx()) == ""
    assert history_evidence({}, _ctx()) == {}


def test_history_evidence_exposes_both_numbers():
    ev = history_evidence({"observed_days": 9}, _ctx())
    assert ev == {"observed_days": 9, "min_observation_days": 5}


def test_short_lookback_adds_a_cyclicality_caveat():
    """SME review round 2, finding #8: a short window can miss monthly cycles, so the
    note warns the reader. The 30-day precompute window carries no such caveat."""
    short = history_note({"observed_days": 5}, _ctx(min_days=5, lookback=7))
    assert "short 7-day lookback" in short
    assert "monthly cycles" in short
    # The full 30-day window (customer-facing precompute) is not flagged.
    assert "short" not in history_note({"observed_days": 7}, _ctx(lookback=30))


# --- wiring: every guarded rule must actually suppress a one-day row --------

def _one_day(row: dict) -> dict:
    return {**row, "observed_days": 1}


def test_every_guarded_rule_suppresses_a_single_day_row():
    """Each rule is fed a row that WOULD score, with observed_days=1.

    This is the regression that matters: the guard exists to stop the app
    recommending actions off one day of data, and a rule that drops its
    ``insufficient_history`` call would otherwise still pass its own tests."""
    from finops_rules.catalog.autotermination import AutoTerminationRule
    from finops_rules.catalog.enable_photon_dbr import EnablePhotonDbrRule
    from finops_rules.catalog.enable_serverless import EnableServerlessRule
    from finops_rules.catalog.failing_jobs import FailingJobsRule
    from finops_rules.catalog.idle_zombie_clusters import IdleZombieClustersRule
    from finops_rules.catalog.interactive_to_job import InteractiveToJobRule
    from finops_rules.catalog.rightsize_underutilized import RightsizeUnderutilizedRule
    from finops_rules.catalog.serverless_cost_optimized import ServerlessCostOptimizedRule
    from finops_rules.catalog.spot_fallback import SpotFallbackRule
    from finops_rules.catalog.unused_data_jobs import UnusedDataJobsRule
    from finops_rules.catalog.warehouse_autostop import WarehouseAutoStopRule
    from finops_rules.catalog.warehouse_autostop_serverless import (
        WarehouseAutoStopServerlessRule,
    )
    from finops_rules.catalog.warehouse_rightsize import WarehouseRightsizeRule

    # (rule, thresholds, a row that scores to a finding when history is sufficient)
    cases = [
        (
            AutoTerminationRule(),
            {"max_acceptable_minutes": 60, "min_idle_events": 3, "use_audit_activity": False},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "auto_termination_minutes": None, "cost_30d_usd": 3000.0,
                "running_minutes": 10000.0, "idle_minutes": 8000.0,
                "reclaimable_gross_min": 7000.0, "num_reclaim_gaps": 20,
                "longest_idle_gap_min": 500, "job_runs_30d": 0,
            },
        ),
        (
            IdleZombieClustersRule(),
            {"idle_cpu_pct_threshold": 10, "min_idle_windows": 8, "max_job_runs": 0},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "avg_cpu": 2.0, "idle_windows": 95, "total_windows": 100,
                # Tight auto-stop yet still idle => genuine zombie (a loose/absent
                # timeout would defer to cluster_autotermination), so this row
                # exercises the OBSERVATION guard, not the defer guard.
                "auto_termination_minutes": 20,
                "cost_30d_usd": 1500.0, "job_runs_30d": 0,
            },
        ),
        (
            RightsizeUnderutilizedRule(),
            {"cpu_headroom_pct": 40, "mem_bound_pct": 85},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "avg_cpu": 8.0, "avg_mem": 30.0, "worker_count": 8,
                # FIN-016: the p95 peak drives the target size; a low peak (20%) means
                # the cluster can shrink, so the row scores with sufficient history.
                "p95_cpu": 0.20, "cost_30d_usd": 2000.0,
            },
        ),
        (
            InteractiveToJobRule(),
            {"min_monthly_cost_usd": 200, "min_runs": 3},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "job_id": "j", "run_count": 30, "runtime_hours": 100.0,
                "attributed_dbus": 500.0, "cost_30d_usd": 900.0,
                "savings_30d_usd": 400.0,
            },
        ),
        (
            SpotFallbackRule(),
            {"min_monthly_cost_usd": 50, "movable_fraction": 0.5,
             "spot_discount": 0.7, "restart_overhead": 0.1},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "workers": 4, "availability": "ON_DEMAND", "cost_30d_usd": 1000.0,
            },
        ),
        (
            EnablePhotonDbrRule(),
            {"min_dbr_major": 13},
            {
                "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
                "dbr_version": "11.3.x", "cost_30d_usd": 800.0,
            },
        ),
        (
            WarehouseAutoStopRule(),
            {"max_acceptable_minutes": 30},
            {
                "workspace_id": "1", "warehouse_id": "w", "warehouse_name": "w",
                "auto_stop_minutes": 120, "cost_30d_usd": 2000.0,
                "hourly_states": [2] * 24 + [1] * 24,
                "reclaimable_minutes": 5000.0, "warm_minutes": 10000.0,
            },
        ),
        (
            EnableServerlessRule(),
            {"min_monthly_cost_usd": 300},
            {
                "workspace_id": "1", "warehouse_id": "w", "warehouse_name": "w",
                "cost_30d_usd": 1000.0, "avg_cold_start_s": 12.0,
                "hourly_states": ([1] * 4 + [2] * 20) * 14,
            },
        ),
        (
            WarehouseRightsizeRule(),
            {"min_monthly_cost_usd": 100, "min_queries": 100, "steps_down": 1},
            {
                "workspace_id": "1", "warehouse_id": "w", "warehouse_name": "w",
                "warehouse_size": "LARGE", "queries": 5000, "queued_pct": 0.0,
                "spilled_pct": 0.0, "p95_read_gb": 1.0, "p95_runtime_s": 5.0,
                "peak_concurrency": 3, "cost_30d_usd": 4000.0,
            },
        ),
        (
            FailingJobsRule(),
            {"min_runs": 20, "min_failures": 3, "min_fail_rate": 0.10,
             "baseline_fail_rate": 0.05},
            {
                "workspace_id": "1", "job_id": "j", "job_name": "j",
                "total_runs": 100, "failed_runs": 50, "fail_rate": 0.5,
                "failed_cost_30d": 500.0, "cost_30d_usd": 1000.0, "days": [],
            },
        ),
        (
            UnusedDataJobsRule(),
            {"max_output_tables": 5, "min_writes": 10},
            {
                "workspace_id": "1", "job_id": "j", "job_name": "j",
                "n_tables": 1, "total_writes": 60, "sample_table": "a.b.c",
                # FIN-015 sentinel: schema has captured reads, so the row scores with
                # sufficient history (isolating the history guard under test).
                "min_schema_reads": 5,
                "last_write": "2026-08-01", "cost_30d_usd": 600.0, "days": [],
            },
        ),
        (
            WarehouseAutoStopServerlessRule(),
            {"max_acceptable_minutes": 10, "min_autostop_minutes": 5,
             "max_autostop_minutes": 10, "max_extra_stops_per_day": 3,
             "churny_stops_per_day": 30, "startup_penalty_minutes": 1},
            {
                "workspace_id": "1", "warehouse_id": "w", "warehouse_name": "w",
                "warehouse_size": "Small", "auto_stop_minutes": 30,
                "cost_30d_usd": 2000.0, "dbus_30d": 1200.0, "warm_minutes": 5000.0,
                "gap_count": 100, "median_gap_min": 25.0, "p90_gap_min": 90.0,
                "queries_by_hour": [0] * 8 + [12] * 9 + [0] * 7,
                "gap_hist_1": 2, "gap_hist_2": 1, "gap_hist_3": 1, "gap_hist_4": 1,
                "gap_hist_5": 1, "gap_hist_6": 1, "gap_hist_7": 1, "gap_hist_8": 1,
                "gap_hist_9": 1, "gap_hist_10": 1, "gap_hist_15": 4,
                "gap_hist_20": 5, "gap_hist_30": 20, "gap_hist_60": 30,
                "gap_hist_over": 30,
            },
        ),
        (
            ServerlessCostOptimizedRule(),
            {"min_monthly_cost_usd": 15, "dbu_reduction": 0.5, "short_run_minutes": 10,
             "suitability_short": 0.25, "suitability_unknown": 0.40},
            {
                "workspace_id": "1", "entity_id": "e", "entity_name": "e",
                "workload_type": "Job", "billing_origin_product": "JOBS",
                "median_run_min": 45.0, "cost_30d_usd": 900.0, "dbus_30d": 100.0,
            },
        ),
    ]

    for rule, thresholds, row in cases:
        ctx = RuleContext(
            thresholds=thresholds, lookback_days=30, catalog="system",
            min_observation_days=5,
        )
        # Control: with enough history the row DOES produce a finding, so the
        # suppression below is attributable to the guard and not to a stale fixture.
        assert rule.score({**row, "observed_days": 30}, ctx) is not None, (
            f"{rule.id}: fixture no longer scores with sufficient history"
        )
        assert rule.score(_one_day(row), ctx) is None, (
            f"{rule.id}: emitted a finding from a single day of observed activity"
        )


#: Rules that legitimately have no observed-activity minimum, with the reason.
#: A new rule must either emit ``observed_days`` or be listed here deliberately.
_EXEMPT_FROM_HISTORY_GUARD = {
    # Fires on the ABSENCE of runs over 90 days, gated by min_days_since_last_run
    # (default 30) — that threshold IS its history requirement. Demanding recent
    # observed activity would invert the rule. See the module docstring.
    "unused_scheduled_jobs",
}


def test_every_rule_sql_emits_observed_days():
    """A rule whose SQL omits ``observed_days`` gets NO guard: the Python check
    degrades to "unknown, don't block", so the omission is silent. This forces
    the choice to be explicit — emit the column, or be listed as exempt."""
    from finops_rules import load_thresholds
    from finops_rules.contract import RuleContext as Ctx
    from finops_rules.registry import list_rules

    # The REAL config, not a hand-maintained copy of it. An inline dict has to be
    # updated for every new rule, and when someone forgets, this test fails on a
    # missing threshold rather than on the property it exists to check (that was
    # exactly how it broke when untagged_spend was added). Using the shipped
    # thresholds also means the rendering exercised here is the rendering
    # production performs.
    thresholds = load_thresholds()
    missing = []
    for rule in list_rules():
        if rule.id in _EXEMPT_FROM_HISTORY_GUARD:
            continue
        sql = rule.render_sql(
            Ctx(thresholds=thresholds.get(rule.id, {}), lookback_days=30, catalog="system")
        )
        if "observed_days" not in sql:
            missing.append(rule.id)
    assert not missing, (
        f"rules missing observed_days in their SQL (so their history guard is inert): "
        f"{missing}. Emit the column, or add the rule to _EXEMPT_FROM_HISTORY_GUARD "
        f"with a reason."
    )


def test_guarded_findings_carry_the_observation_window_in_evidence():
    """The sample size must be auditable in the UI, not just enforced silently."""
    from finops_rules.catalog.idle_zombie_clusters import IdleZombieClustersRule

    ctx = RuleContext(
        thresholds={"idle_cpu_pct_threshold": 10, "min_idle_windows": 8, "max_job_runs": 0},
        lookback_days=30, catalog="system", min_observation_days=5,
    )
    finding = IdleZombieClustersRule().score(
        {
            "workspace_id": "1", "cluster_id": "c", "cluster_name": "c",
            "avg_cpu": 2.0, "idle_windows": 95, "total_windows": 100,
            # Tight timeout => genuine zombie (else it defers to auto-termination).
            "auto_termination_minutes": 20,
            "cost_30d_usd": 1500.0, "job_runs_30d": 0, "observed_days": 12,
        },
        ctx,
    )
    assert finding is not None
    assert finding.evidence["observed_days"] == 12
    assert finding.evidence["min_observation_days"] == 5
    assert "12 days of observed activity" in finding.evidence["data_basis"]
