from __future__ import annotations

from finops_rules.catalog.instance_pool_idle import InstancePoolIdleRule
from finops_rules.contract import RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={"enabled": True, "min_warm_instances": 2},
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    row = {
        "workspace_id": "111",
        "instance_pool_id": "pool-1",
        "instance_pool_name": "ml-warm-pool",
        "node_type": "i3.xlarge",
        "min_idle_instances": 6,
        "idle_instance_autotermination_minutes": 0,
        "max_capacity": 20,
        "observed_days": 10,
        "launches": 8,
        "acquisitions": 2,
        "days": [{"d": "2026-09-01", "l": 1, "a": 0}, {"d": "2026-09-02", "l": 1, "a": 1}],
    }
    row.update(over)
    return row


def test_flags_warm_pool():
    f = InstancePoolIdleRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "instance_pool"
    # Operational: no dollars (VMs are cloud-billed, unpriceable here).
    assert f.monthly_waste_usd == 0.0
    assert f.monthly_savings_usd == 0.0
    assert f.savings_status == "advisory"
    # 6 warm instances => HIGH.
    assert f.priority == RulePriority.HIGH
    assert f.evidence["viz"]["kind"] == "instance_pool"
    assert f.evidence["min_idle_instances"] == 6
    assert f.evidence["operational_only"] is True
    assert "6" in f.why


def test_rule_is_promoted_advisory():
    rule = InstancePoolIdleRule()
    assert rule.experimental is False  # promoted out of Labs 2026-09-23 (still advisory)
    assert rule.default_savings_status == "advisory"


def test_suppresses_pool_with_no_warm_floor():
    assert InstancePoolIdleRule().score(_row(min_idle_instances=1), _ctx()) is None
    assert InstancePoolIdleRule().score(_row(min_idle_instances=0), _ctx()) is None


def test_low_activity_does_not_suppress():
    # A warm pool that nothing acquires is the WORST case, not a reason to hide it.
    f = InstancePoolIdleRule().score(_row(observed_days=0, launches=0, acquisitions=0), _ctx())
    assert f is not None


def test_sql_renders_without_workspace_filter():
    sql = InstancePoolIdleRule().render_sql(_ctx())
    assert "system.compute.instance_pools" in sql
    assert "system.compute.instance_events" in sql
    assert "min_idle_instances" in sql
    assert "workspace_id IN" not in sql


def test_zero_dollar_finding_says_it_cannot_price_the_pool():
    """Promoted with $0: the warning must tell the reader the cost is unknown, not zero."""
    f = InstancePoolIdleRule().score(_row(), _ctx())
    assert f.monthly_savings_usd == 0.0 and f.monthly_waste_usd == 0.0
    assert "can't tell what this pool costs" in f.evidence["data_warning"]
