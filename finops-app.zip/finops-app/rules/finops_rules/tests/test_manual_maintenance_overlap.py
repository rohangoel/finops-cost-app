from __future__ import annotations

from finops_rules.catalog.manual_maintenance_overlap import ManualMaintenanceOverlapRule
from finops_rules.contract import EffortBand, RuleContext, RulePriority


def _ctx() -> RuleContext:
    return RuleContext(
        thresholds={
            "enabled": True,
            "min_maintenance_runs": 10,
            "min_addressable_usd": 25,
        },
        lookback_days=30,
        catalog="system",
    )


def _row(**over) -> dict:
    # A warehouse whose OPTIMIZE/VACUUM statements are ~20% of its Spark task-time on
    # a $1,000/mo warehouse => ~$200/mo addressable maintenance compute.
    row = {
        "workspace_id": "111",
        "warehouse_id": "wh-1",
        "warehouse_name": "maintenance-warehouse",
        "warehouse_type": "PRO",
        "warehouse_size": "SMALL",
        "maintenance_runs": 60,
        "observed_days": 28,
        "optimize_runs": 30,
        "vacuum_runs": 30,
        "maintenance_task_ms": 200_000.0,
        "total_task_ms": 1_000_000.0,
        "cost_30d_usd": 1000.0,
        "dbus_30d": 1800.0,
        "unpriced_dbus": 0.0,
        "days": [
            {"d": "2026-09-01", "o": 1, "v": 1},
            {"d": "2026-09-02", "o": 1, "v": 1},
        ],
    }
    row.update(over)
    return row


def test_flags_recurring_manual_maintenance():
    f = ManualMaintenanceOverlapRule().score(_row(), _ctx())
    assert f is not None
    assert f.resource_type == "warehouse"
    assert f.monthly_savings_usd == 0.0
    assert f.monthly_savings_low_usd == 0.0
    assert f.savings_status == "advisory"
    assert f.monthly_waste_usd == 200.0  # 20% of $1000/mo
    assert f.effort == EffortBand.LOW
    assert f.evidence["viz"]["kind"] == "sql_maintenance"
    assert f.evidence["optimize_runs"] == 30
    assert f.evidence["vacuum_runs"] == 30
    assert "Predictive Optimization" in f.why
    assert "Catalog Explorer" in f.how


def test_rule_is_experimental_and_advisory():
    rule = ManualMaintenanceOverlapRule()
    assert rule.experimental is True
    assert rule.default_savings_status == "advisory"


def test_priority_scales_with_addressable():
    # $600/mo addressable => MEDIUM; small => LOW.
    hi = ManualMaintenanceOverlapRule().score(
        _row(maintenance_task_ms=600_000.0), _ctx()
    )
    assert hi is not None and hi.priority == RulePriority.MEDIUM
    lo = ManualMaintenanceOverlapRule().score(
        _row(maintenance_task_ms=60_000.0), _ctx()
    )
    assert lo is not None and lo.priority == RulePriority.LOW


def test_suppresses_too_few_runs():
    assert ManualMaintenanceOverlapRule().score(_row(maintenance_runs=4), _ctx()) is None


def test_suppresses_below_addressable_floor():
    assert ManualMaintenanceOverlapRule().score(
        _row(maintenance_task_ms=1000.0), _ctx()
    ) is None


def test_suppresses_insufficient_history():
    assert ManualMaintenanceOverlapRule().score(_row(observed_days=2), _ctx()) is None


def test_sql_renders_without_workspace_filter():
    sql = ManualMaintenanceOverlapRule().render_sql(_ctx())
    assert "system.query.history" in sql
    assert "OPTIMIZE%" in sql
    assert "VACUUM%" in sql
    assert "workspace_id IN" not in sql
