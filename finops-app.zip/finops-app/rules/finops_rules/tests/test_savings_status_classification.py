"""Phase 0.3 headline-containment classification guard.

Locks in which rules may book savings into the headline (docs/
SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md §0.3). If someone flips a rule's
``default_savings_status`` — or a newly added rule defaults to ``bookable``
without review — this suite fails, so the booked headline cannot silently
re-inflate. The economic rebuilds (Phase 1-3) promote rules back to
``bookable`` deliberately, updating this map at the same time.
"""

from __future__ import annotations

from finops_rules import get_enabled_rules, get_rule, list_rules, load_thresholds

# Not bookable until their counterfactual is rebuilt (or $0/governance by design).
ADVISORY = {
    "enable_photon_dbr",
    "unused_scheduled_jobs",
    "spot_fallback",
    "serverless_cost_optimized",
    "unused_data_jobs",
    "cluster_job_contention",
    # GPU node type running a non-'-gpu-ml' runtime: detection is high-confidence
    # config, but GPU shares the CPU compute SKU and the cloud-VM premium is not in
    # system tables, so the dollars are unpriceable and nothing is booked ($0,
    # ranks on the at-risk DBU spend) — advisory by design, like contention above.
    "gpu_wrong_runtime",
    "warehouse_scale_out",
    "untagged_spend",
    # Phase 4 experimental (Labs tab): net-new opportunity rules, advisory until
    # validated + relocated out of the headline (see EXPERIMENTAL below).
    "sql_repeated_failures",
    "manual_maintenance_overlap",
    "ai_gateway_wasted_inference",
    "pipeline_failed_updates",
    "instance_pool_idle",
    "delta_sharing_materialization",
    "storage_optimization_churn",
    # Tier-1 plan workstream B (docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md): experimental
    # until a live run is hand-reviewed; the plan's estimated status applies at promotion.
    "job_runaway_no_timeout",
    "pipeline_full_refresh_churn",
    "allpurpose_shape_mismatch",
    # Tier-2 plan workstream C: same Labs-first convention as workstream B.
    "unviewed_scheduled_dashboards",
    "instance_generation_modernize",
    "unpruned_repeated_queries",
}

# Phase 4 opportunity rules relocated to the Labs tab (Rule.experimental). These are
# a SUBSET of ADVISORY — experimental rules must be advisory (net-new economics are
# unproven), and they are additionally kept out of the main surfaces entirely.
EXPERIMENTAL = {
    "manual_maintenance_overlap",
    "ai_gateway_wasted_inference",
    "delta_sharing_materialization",
    "storage_optimization_churn",
    "gpu_wrong_runtime",
    # Tier-1 plan workstream B (docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md): still in Labs.
    "job_runaway_no_timeout",
    "pipeline_full_refresh_churn",
    "allpurpose_shape_mismatch",
    # Tier-2 plan workstream C: still in Labs.
    "instance_generation_modernize",
}

# Promoted out of Labs on 2026-09-23 after the live run on fevm-finops-stable-us was
# hand-reviewed: shown on the main surfaces. None is bookable — each is in ADVISORY or
# ESTIMATED above — and all must stay out of EXPERIMENTAL.
PROMOTED = {
    "warehouse_keepalive_queries",
    "alert_hygiene",
    "warehouse_min_clusters",
    "unpruned_repeated_queries",
    "unviewed_scheduled_dashboards",
    "pipeline_failed_updates",
    "job_no_new_input",
    "sql_repeated_failures",
    "job_task_retry_waste",
    "serving_provisioned_overcapacity",
    "instance_pool_idle",
}

# Shown and rankable, but out of the booked headline until their rebuild lands.
ESTIMATED = {
    "warehouse_autostop",
    "warehouse_autostop_serverless",
    "warehouse_rightsize",
    "rightsize_underutilized",
    "jobs_compute_rightsize",
    "failing_jobs",
    "continuous_pipeline",
    "idle_zombie_clusters",
    # FIN-010 rebuilt (Phase 3): class default is estimated (the shared tier + the
    # unmeasured fallback). A job-DEDICATED cluster overrides to bookable per-finding
    # in score() — covered by test_interactive_to_job.py, not the class default.
    "interactive_to_job",
    # FIN-013 rebuilt (Phase 3): the DBU-only comparison is measurable (low bound),
    # but the headline credits an ESTIMATED cloud VM cost, so it is estimated, not
    # bookable — covered by test_enable_serverless.py.
    "enable_serverless",
    # Promoted out of Labs 2026-09-23 with their measured counterfactual as the saving
    # (per-finding advisory where there are no dollars / an unknown input).
    "warehouse_min_clusters",
    "warehouse_keepalive_queries",
    "alert_hygiene",
    "serving_provisioned_overcapacity",
    "job_task_retry_waste",
    "job_no_new_input",
}

# Class default is bookable. idle_serving_endpoints books only its zero-traffic tier
# (per-finding override in score(), covered by test_idle_serving_endpoints.py).
BOOKABLE_DEFAULT = {
    "cluster_autotermination",
    "idle_serving_endpoints",
}

DISABLED = {"idle_apps"}


def test_advisory_rules_are_advisory():
    for rid in ADVISORY:
        assert get_rule(rid).default_savings_status == "advisory", rid


def test_estimated_rules_are_estimated():
    for rid in ESTIMATED:
        assert get_rule(rid).default_savings_status == "estimated", rid


def test_bookable_rules_stay_bookable():
    for rid in BOOKABLE_DEFAULT:
        assert get_rule(rid).default_savings_status == "bookable", rid


def test_idle_apps_is_disabled_from_recs_and_totals():
    assert get_rule("idle_apps").default_enabled is False
    enabled = {r.id for r in get_enabled_rules(load_thresholds())}
    assert "idle_apps" not in enabled


def test_experimental_rules_are_flagged_and_advisory():
    """Every rule that self-declares experimental=True is in the EXPERIMENTAL set,
    is advisory (never bookable), and vice-versa — so a Phase 4 opportunity rule can
    never leak into the booked headline or the main surfaces unnoticed."""
    declared = {r.id for r in list_rules() if getattr(r, "experimental", False)}
    assert declared == EXPERIMENTAL
    for rid in EXPERIMENTAL:
        rule = get_rule(rid)
        assert rule.experimental is True, rid
        assert rule.default_savings_status == "advisory", rid
    # EXPERIMENTAL is a subset of ADVISORY (unproven economics book nothing).
    assert EXPERIMENTAL <= ADVISORY


def test_every_rule_is_classified_and_the_map_is_exhaustive():
    """Every registered rule carries a valid status, and the buckets above cover
    exactly the registered rules — so a new rule cannot slip in unclassified."""
    valid = {"bookable", "estimated", "advisory"}
    all_ids = {r.id for r in list_rules()}
    for r in list_rules():
        assert r.default_savings_status in valid, r.id
    assert ADVISORY | ESTIMATED | BOOKABLE_DEFAULT | DISABLED == all_ids


def test_promoted_rules_are_main_surface_and_never_bookable():
    for rid in PROMOTED:
        rule = get_rule(rid)
        assert getattr(rule, "experimental", False) is False, rid
        assert rid in (ADVISORY | ESTIMATED) and rid not in EXPERIMENTAL, rid
