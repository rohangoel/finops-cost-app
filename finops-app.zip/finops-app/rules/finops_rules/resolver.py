"""Table-name resolver — nested ``system`` namespace (default) or Central Logfood flat.

Rule SQL references a system table as ``{{ tbl('schema','table') }}``. The resolver
turns that call into a concrete relation expression:

* **nested / default** (``TableResolver(catalog)``) — returns the historical
  ``{catalog}.schema.table`` string *byte-for-byte*, so the deployed single-account
  app and the golden-diff / SDP-parity tests are unaffected. This is also the mirror
  path (``catalog`` points at a ``system``-shaped mirror).
* **central** (``TableResolver.central_for(account_ids)``) — returns a scope-filtered
  inline view over Databricks' internal **Central Logfood** flat namespace,
  ``main.centralized_system_tables.<schema>_<table>``, filtered to a set of Databricks
  ``account_id``s. One filtered scan serves the whole account list; a Databricks
  ``account_id`` is globally unique and belongs to exactly one cloud, so scoping by
  ``account_id`` alone is sufficient (no ``cloud`` predicate needed on the fact tables).

Verified against the live logfood tables (2026-09): the fact tables carry ``account_id``
+ ``cloud`` (not ``cloud_type``); ``billing_list_prices`` carries
``account_id, cloud, sku_name, usage_unit, currency_code, price_start_time,
price_end_time, pricing``; ``main.certified.workspaces_latest`` carries
``account_id, cloud_type, salesforce_account_name, workspace_id, workspace_name,
deployment_name`` (no ``workspace_url``). Unaliased derived tables and ``SELECT DISTINCT``
over the ``pricing`` struct are both accepted by the logfood Spark. See
``docs/LOGFOOD_LOCAL_PREVIEW.md`` and the internal ``centralized-system-tables-translator``
skill, the source of truth for this mapping.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

#: Flat central namespace: system.<schema>.<table> -> <CENTRAL>.<schema>_<table>.
CENTRAL_NAMESPACE = "main.centralized_system_tables"
#: workspaces_latest lives in a different central catalog and adds salesforce_account_name.
CERTIFIED_WORKSPACES = "main.certified.workspaces_latest"
#: The per-account scope column on every central table.
ACCOUNT_COL = "account_id"

#: (schema, table) pairs with NO Central Logfood equivalent (verified absent from
#: main.centralized_system_tables). A rule that reads one of these cannot run centrally
#: and must be excluded from the enabled set (see precompute/central_pipeline.py): its
#: central render raises below, _central_enabled_rules catches it, and the rule is dropped
#: with a log line instead of failing the whole update. ``access.audit`` is only referenced
#: behind the ``use_audit_activity`` guard (off by default), so it is never emitted
#: centrally. The alert.* / compute.instance_* pairs back the alert_hygiene and
#: instance_pool_idle rules, which were promoted in the single-account app but whose source
#: tables are not centralized — without excluding them the candidate flows fail to resolve.
NO_CENTRAL_EQUIVALENT = frozenset({
    ("access", "audit"),
    ("access", "table_lineage"),
    ("alert", "alerts"),
    ("alert", "alert_evaluation_history"),
    ("compute", "instance_events"),
    ("compute", "instance_pools"),
})


def _quote_str_list(values) -> str:
    """Render a SQL ``IN`` list of single-quoted string literals, defensively.

    Values come from trusted config, but we still reject quote/backslash characters
    rather than risk a malformed or injected predicate."""
    out = []
    for v in values:
        s = str(v)
        if "'" in s or "\\" in s or ";" in s:
            raise ValueError(f"illegal character in scope value: {s!r}")
        out.append(f"'{s}'")
    return ", ".join(out)


@dataclass
class TableResolver:
    """Callable used in templates as ``tbl('schema','table')`` — see module docstring."""

    catalog: str = "system"
    central: bool = False
    account_ids: tuple[str, ...] = field(default_factory=tuple)
    #: Flat central namespace to read from. Defaults to the shared Central Logfood
    #: tables; point it at a pre-filtered SLICE (e.g. main.team_field_dsa_ce, built by
    #: precompute/central/build_billing_slice.py) so a scoped read scans ~20M rows
    #: instead of the full multi-account fact table. Only the flat billing_* tables use
    #: this; workspaces_latest always resolves to the certified catalog.
    namespace: str = CENTRAL_NAMESPACE
    #: Optional schema-name prefix for a system-shaped MIRROR whose schemas are
    #: renamed. e.g. a mirror exposing ``system.billing`` as
    #: ``<catalog>.aapsbilling`` sets ``FINOPS_SCHEMA_PREFIX=aaps``, so
    #: ``tbl('billing','usage')`` -> ``<catalog>.aapsbilling.usage``. Empty
    #: (default) preserves the historical byte-for-byte ``system`` path, so the
    #: golden-diff tests are unaffected.
    schema_prefix: str = field(
        default_factory=lambda: os.getenv("FINOPS_SCHEMA_PREFIX", "")
    )

    @classmethod
    def nested(cls, catalog: str = "system") -> TableResolver:
        return cls(catalog=catalog, central=False)

    @classmethod
    def central_for(cls, account_ids, namespace: str | None = None) -> TableResolver:
        # Preserve order, drop dupes and empty/None ids (certified has a NULL account_id row).
        ids = tuple(dict.fromkeys(str(a) for a in account_ids if a))
        if not ids:
            raise ValueError("central resolver requires at least one non-empty account_id")
        return cls(central=True, account_ids=ids, namespace=namespace or CENTRAL_NAMESPACE)

    # -- rendering -------------------------------------------------------------
    def __call__(self, schema: str, table: str) -> str:
        if not self.central:
            # Backtick-quote a catalog with special chars (e.g. a hyphen, as in
            # ``aaps-use2-systemtables``) so the identifier is valid SQL; apply the
            # mirror schema prefix. With no prefix + a plain catalog this is
            # byte-for-byte the historical ``catalog.schema.table`` path.
            cat = f"`{self.catalog}`" if not self.catalog.replace("_", "").isalnum() else self.catalog
            return f"{cat}.{self.schema_prefix}{schema}.{table}"

        key = (schema, table)
        if key in NO_CENTRAL_EQUIVALENT:
            raise ValueError(
                f"{schema}.{table} has no Central Logfood equivalent; the rule reading "
                f"it must be excluded in central mode"
            )
        in_list = _quote_str_list(self.account_ids)

        if key == ("access", "workspaces_latest"):
            # Different catalog centrally. certified has no workspace_url; synthesize it
            # as NULL to keep the nested column contract, and surface account/cloud/sfdc
            # plus workspace_status (so callers can restrict to RUNNING workspaces).
            return (
                "(SELECT workspace_id, workspace_name, "
                "CAST(NULL AS STRING) AS workspace_url, account_id, cloud_type, "
                "salesforce_account_name, deployment_name, workspace_status "
                f"FROM {CERTIFIED_WORKSPACES} WHERE {ACCOUNT_COL} IN ({in_list}))"
            )

        flat = f"{self.namespace}.{schema}_{table}"

        if key == ("billing", "list_prices"):
            # Dedup to distinct price rows (central replicates per account) and KEEP
            # account_id so the price join can be account-scoped — promotional prices in
            # pricing.effective_list are account-specific, so joining a multi-account
            # usage scan to prices without the account key would leak prices across
            # accounts. price_join() adds ``u.account_id = lp.account_id`` in central mode.
            # Projection keeps every column the macro ON clause + price_rate() need.
            return (
                "(SELECT DISTINCT account_id, cloud, sku_name, usage_unit, currency_code, "
                "price_start_time, price_end_time, pricing "
                f"FROM {flat} WHERE {ACCOUNT_COL} IN ({in_list}))"
            )

        # Default fact table: SELECT * preserves nested structs (pricing, usage_metadata,
        # identity_metadata, …) and the account_id/cloud columns; scope by account_id.
        return f"(SELECT * FROM {flat} WHERE {ACCOUNT_COL} IN ({in_list}))"

    # -- render context --------------------------------------------------------
    def render_context(self) -> dict:
        """Jinja variables this resolver contributes: ``tbl`` and the ``central`` flag
        (the price macro adds the account_id join key only when ``central`` is true)."""
        return {"tbl": self, "central": self.central}
