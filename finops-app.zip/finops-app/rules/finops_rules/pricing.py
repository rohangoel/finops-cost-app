"""Small pricing / normalization helpers shared by rules.

Rules attribute real dollars to a resource by joining ``system.billing.usage``
to ``system.billing.list_prices`` inside their SQL (so the heavy lifting is
pushed to the warehouse). These helpers cover the light Python-side math:
turning a lookback-window cost into a monthly figure, and effort-band lookups.
"""

from __future__ import annotations

from .contract import EFFORT_SCORES, EffortBand

# A calendar-month normalization constant. We report savings per 30-day month.
DAYS_PER_MONTH = 30.0

# Pricing mode (engine-wide). Rules attribute dollars via system.billing.list_prices,
# which is the LIST price. Most enterprise customers have committed discounts (often
# 15-40% below list), so a saving booked at list can overstate what the customer
# actually reclaims — which conflicts with the "never exceed true avoidable spend"
# principle. Until effective/contract rates are wired in (they are not exposed in
# system tables in general), the honest fix is a disclaimer on every $-booking
# finding. SME review 2026-09-03, finding #3.
PRICING_MODE_LIST = "list"
PRICING_MODE_EFFECTIVE = "effective"

_LIST_PRICE_NOTE = (
    " Savings are estimated at LIST price (system.billing.list_prices); under a "
    "committed-discount contract the actual reclaimed amount is proportionally lower."
)


#: Retired env var. It used to name a net-cost source for a global ``effective``
#: mode; contract rates are now read PER FINDING from system.billing.account_prices
#: (see finops_rules.price_basis). Kept only so old imports resolve.
EFFECTIVE_PRICE_SOURCE_ENV = "FINOPS_EFFECTIVE_PRICE_SOURCE"


def validate_pricing_mode(pricing_mode: str | None, *, effective_source: str | None = None) -> str:
    """Normalize and validate the engine-wide pricing mode; fail fast on a misconfig.

    Only ``list`` is valid. The old global ``effective`` mode (Phase 0.4) is RETIRED:
    it dropped the list-price disclaimer from EVERY finding, which would now
    contradict the per-finding basis — contract figures exist only where
    account_prices covers a resource (``price_basis='contract'``), every other finding
    is still list. Contract pricing needs no mode switch: it turns on automatically
    when the capability probe finds account_prices data (finops_rules.price_basis).

    Returns the normalized mode. Raises ``ValueError`` on anything else."""
    mode = (pricing_mode or PRICING_MODE_LIST).strip().lower()
    if mode == PRICING_MODE_LIST:
        return mode
    if mode == PRICING_MODE_EFFECTIVE:
        raise ValueError(
            "pricing_mode='effective' is retired. Contract rates are applied per finding "
            "from system.billing.account_prices whenever that table has data (see "
            "finops_rules.price_basis); findings without a contract price stay at LIST. "
            "Set pricing_mode='list'."
        )
    raise ValueError(
        f"Unknown pricing_mode {pricing_mode!r}. Valid: '{PRICING_MODE_LIST}'."
    )


def pricing_mode_note(pricing_mode: str | None) -> str:
    """List-price disclaimer appended to a $-booking finding's data_basis. Applied
    only to findings WITHOUT a contract figure — contract-priced findings get the
    two-basis note from finops_rules.price_basis instead (per finding, not global)."""
    return _LIST_PRICE_NOTE


def to_monthly(window_cost: float, lookback_days: int) -> float:
    """Scale a cost measured over ``lookback_days`` to a 30-day month."""
    if not window_cost or lookback_days <= 0:
        return 0.0
    return float(window_cost) * (DAYS_PER_MONTH / lookback_days)


def effort_score(effort: EffortBand, overrides: dict[str, int] | None = None) -> int:
    """Numeric effort weight, allowing config overrides from effort.yaml."""
    if overrides and effort.value in overrides:
        return int(overrides[effort.value])
    return EFFORT_SCORES[effort]
