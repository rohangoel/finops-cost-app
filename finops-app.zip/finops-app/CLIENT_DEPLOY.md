# FinOps App — Client Deploy & Test

Live-mode FinOps recommendations app, adapted for the client's **aaps system-table
mirror** (`aaps-use2-systemtables`, schemas `aapsbilling`/`aapscompute`/`aapslakeflow`/
`aapsaccess`/`aapsquery`). No precompute tables, no writable schema, no nightly job —
rules run on the SQL warehouse on demand.

The React SPA is **already built** into `backend/finops/static/`, so this machine does
**not** need Node/npm. (Only rebuild if you change frontend code: `cd frontend && npm ci && npm run build`.)

---

## Prerequisites in the client workspace
- Databricks Apps enabled.
- A running SQL warehouse (grab its **bare id**, not the `/sql/1.0/...` path).
- Databricks CLI ≥ 0.239 authenticated with a profile — referred to below as `client`.

## Step 1 — Fill two placeholders

1. `app.yaml` → `DATABRICKS_WAREHOUSE_ID` → set to the client warehouse id.
2. `databricks.yml` → `targets.client.workspace.host` → set to the client host
   (e.g. `https://adb-xxxx.az.databricks.net`).

Everything else is pre-set: `FINOPS_COMPUTE_MODE=live`, `FINOPS_AUTH_MODE=obo`,
`FINOPS_SCHEMA_PREFIX=aaps`, `FINOPS_CATALOG=aaps-use2-systemtables`,
`FINOPS_HIDDEN_RULES` (12 rules the mirror can't serve), `FINOPS_LOOKBACK_DAYS=30`.

## Step 2 — Deploy (DAB)

```bash
databricks bundle validate -t client -p client
databricks bundle deploy   -t client -p client
databricks bundle run      finops_app -t client -p client   # prints the app URL
```

> Fallback if `bundle`/Apps CLI isn't available: `cp deploy/config.env.client-aaps deploy/config.env`,
> fill in HOST + WAREHOUSE_ID, then `./deploy/deploy.sh --app-only` (needs bash).

## Step 3 — Grants (run once in the client)

Live + OBO means each app user queries the aaps tables **as themselves**, so each needs SELECT:

```sql
GRANT USE CATALOG ON CATALOG `aaps-use2-systemtables` TO `account users`;
GRANT USE SCHEMA, SELECT ON SCHEMA `aaps-use2-systemtables`.aapsbilling  TO `account users`;
GRANT USE SCHEMA, SELECT ON SCHEMA `aaps-use2-systemtables`.aapscompute  TO `account users`;
GRANT USE SCHEMA, SELECT ON SCHEMA `aaps-use2-systemtables`.aapslakeflow TO `account users`;
GRANT USE SCHEMA, SELECT ON SCHEMA `aaps-use2-systemtables`.aapsaccess   TO `account users`;
GRANT USE SCHEMA, SELECT ON SCHEMA `aaps-use2-systemtables`.aapsquery    TO `account users`;
```

(Scope to a specific group instead of `account users` if preferred.)

---

## Step 4 — Test

1. **App comes up:** open the URL from `bundle run`. The UI should render (not blank/404).
   A blank page = the SPA build wasn't uploaded; confirm `backend/finops/static/index.html` exists.
2. **Recommendations load:** the main list should populate within a few seconds (live
   queries hit the warehouse). Each recommendation shows an estimated saving.
3. **29 rules present, 12 absent:** you should NOT see the 12 disabled rules (serving,
   pipelines, instance pools, alerts, ai-gateway, delta-sharing, storage-optimization,
   serverless-cost-optimized, instance-generation). Everything else (all-purpose/jobs
   rightsize, autotermination, idle/zombie clusters, interactive→job, retries, untagged
   spend, spot, SQL-warehouse) should appear.
4. **Warehouse activity:** in the client's Query History (or warehouse monitoring) you
   should see `SELECT`s against `` `aaps-use2-systemtables`.aaps* `` tables — confirming the
   mirror remap works and no bare `system.*` reference leaked.
5. **Permissions:** sign in as a non-admin app user; if recommendations are empty with a
   permission error, the Step-3 grants didn't reach that user/group.

### Quick triage
| Symptom | Likely cause |
|---|---|
| Blank page / 404 | SPA static not deployed (`backend/finops/static` missing) |
| "Table not found `aaps...`" | Warehouse can't see the mirror / wrong catalog name |
| Empty list + permission error | Step-3 grants not applied to the signed-in user |
| A disabled rule still shows | `FINOPS_HIDDEN_RULES` not picked up — check `app.yaml` was uploaded |
| Spinner never resolves | Warehouse stopped or `DATABRICKS_WAREHOUSE_ID` wrong |
