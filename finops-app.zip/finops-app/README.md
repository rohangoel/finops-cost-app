# FinOpsApp — Databricks Cost-Optimization Recommendation App

A Databricks App that reads **account-wide system tables** and tells admins
**what they can do to save money** — which exact cluster / warehouse / job is
wasting spend, **why**, **how much per month**, how much **effort** the fix is,
and a **Next Best Action** ranking that trades savings against effort.

> 💬 **Using the app? Join [#finops-app](https://databricks.enterprise.slack.com/archives/C0BPLDZ2XGB) on Slack.**
> You're strongly encouraged to join to share feedback and keep up with new
> features and improvements as they ship.

## Personas
- **Platform Admin** — sees every workspace in the account (100s+), a savings
  leaderboard, and drills into any workspace.
- **Workspace Admin** — scoped to their own workspace(s).

## What makes it extensible (the point of the design)
Cost-saving criteria are **plugin rules**. Adding a new criterion is: drop one
file in `rules/finops_rules/catalog/`, one SQL template in `rules/finops_rules/sql/`,
and one block in `rules/finops_rules/config/thresholds.yaml`. Rules are
auto-discovered — **there is no central list to edit**, so many people/agents add
rules in parallel without merge conflicts. See [docs/ADDING_A_RULE.md](docs/ADDING_A_RULE.md).

## Two execution modes (one rule, authored once)
| Mode | When | How |
|------|------|-----|
| `live` | development | rule SQL runs on a SQL warehouse on demand |
| `precompute` | production, 100s of workspaces | a scheduled job runs the rules account-wide and writes a Delta table the app just reads |

A parity test (`backend/finops/tests/test_sources_parity.py`) proves both modes
produce identical results.

## Two auth modes
| Mode | When | Identity | Data access |
|------|------|----------|-------------|
| `obo` | dev / user-scoped | logged-in user (`x-forwarded-access-token`) | queries run as the user |
| `sp` | prod | service principal | account-wide read + app-side user→workspace scoping |

See [docs/AUTH_AND_SCOPING.md](docs/AUTH_AND_SCOPING.md).

## Databricks features used
Unity Catalog **system tables** (`system.compute.clusters`, `system.compute.node_timeline`,
`system.lakeflow.pipelines` / `pipeline_update_timeline`,
`system.compute.warehouses`, `system.billing.usage` + `system.billing.list_prices`,
`system.lakeflow.jobs` / `job_run_timeline`), **Databricks SQL warehouse**,
**Databricks Apps** (OBO OAuth), **Databricks Asset Bundles** (the precompute job).

## Tech stack
React (TypeScript, Vite) SPA + FastAPI backend. See [docs/TECH_STACK.md](docs/TECH_STACK.md)
and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Quickstart (local dev = live + OBO)
```bash
cp .env.example .env         # fill in host / warehouse / token
make install                 # backend + dev deps  (needs network for PyPI)
make test                    # 148 tests
make dev-backend             # FastAPI on :8000  (terminal 1)
make dev-frontend            # Vite on :5173, proxies /api -> :8000  (terminal 2)
```
Open http://localhost:5173. Set `FINOPS_DEV_ROLE=workspace_admin` +
`FINOPS_DEV_WORKSPACES=<id>` in `.env` to preview the workspace-admin persona.

## Quick start for teammates — Central Logfood preview (one command)
Exploring customer accounts on **Central Logfood** (no per-workspace deploy)? Grab
`bootstrap.sh` and run it — it clones/pulls the repo, creates the venv, builds the
SPA, logs in to logfood, writes `.env`, and starts the app. Safe to re-run, so it
also becomes your everyday launcher.
```bash
./bootstrap.sh               # clone/pull → set up what's missing → start on :8000
./bootstrap.sh --help        # options: --rebuild, --reinstall, --setup-only, PORT=, WAREHOUSE_ID=
```
You need the Opal grants for `main.centralized_system_tables` + `main.certified`
([go/opal/tile](https://go/opal/tile)). Full walkthrough:
[docs/LOCAL_CENTRAL_DEPLOY.md](docs/LOCAL_CENTRAL_DEPLOY.md).

## Deploy
**Into your own / a customer workspace — one config file, one command:**
```bash
cp deploy/config.env.example deploy/config.env   # host, warehouse, catalog/schema
./deploy/deploy.sh                                # tables + grants, job, app
```
See [deploy/SETUP.md](deploy/SETUP.md). It creates the tables, deploys the daily
precompute job, and deploys the app — all pointed at your workspace, nothing
hardcoded. For the manual step-by-step (and mode/auth reference) see
[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).

> ⚠️ **Multi-region accounts: deploy once per region.** One deployment only
> covers the workspaces in its own region. `system.billing.usage` is
> account-global, but the other system tables the rules read are scoped to the
> region's metastore — so the pipeline can only recommend for workspaces in the
> region it runs in. An account spanning e.g. `westeurope` + `northeurope` needs
> a deployment in each. Out-of-region spend is counted and surfaced as an
> "N workspaces out of scope" KPI, never silently dropped. Details:
> [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md#-multi-region-accounts-deploy-once-per-region).

## Repo layout
```
backend/finops/   FastAPI app (api, identity, data, services, models)
rules/finops_rules/  the plugin rule engine (contract, registry, catalog/, sql/, config/)
precompute/       scheduled job that materializes the recommendation Delta table
frontend/         React SPA
docs/             architecture, data model, auth, and the "add a rule" guide
```

## Status / scope
MVP is **recommend + explain only** (no write-back). One-click "apply" (set
auto-termination via the SDK, with approval + audit) is a deliberate future phase.

> DSA PoC — do not commit customer data, credentials, or `.env`.
