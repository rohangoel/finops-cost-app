"""Profile the REAL system tables so the offline sample can be grounded in them.

This is step 1 of the sample-data pipeline (see ``sample_data/README.md``). It
connects to a live workspace's SQL warehouse and captures, for every system table
the in-scope rules read:

  * the EXACT schema (column names + types, INCLUDING nested struct shapes such as
    ``usage_metadata`` and ``pricing.effective_list.default``) -> ``schema_snapshot.json``
  * a real VALUE VOCABULARY for the categorical/dimensional columns (actual SKU
    names, node types, DBR versions, billing_origin_product values, clouds, …) plus
    numeric ranges (min / p50 / p95 / max) and time bounds -> ``value_vocab.json``
  * real ``billing.list_prices`` rows for a chosen SKU set, so the price-join in
    every rule resolves against genuine ``pricing`` structs -> in ``value_vocab.json``

Why this exists: the curated fixtures (``sample_data/fixtures/*.jsonl``) are built
ONLY from this captured vocabulary and validated against this schema. That is what
keeps them faithful to reality — we compose scenarios from real values and real
shapes rather than inventing numbers, so a fixture can never "prove" behaviour that
real data would never produce.

The two JSON snapshots are COMMITTED (de-customerized: they hold column types,
category vocab, numeric ranges and public list prices — no workspace ids, emails,
resource names or costs tied to an account). The raw row dumps under ``raw/`` are
git-ignored.

Usage:
    python sample_data/profile/profile_system_tables.py \
        --profile fevm-finops-stable-us --warehouse 28ee85f85d49811e

Re-run it whenever the system-table schema changes or you want a fresher vocabulary.
It only READS system tables; it never writes to the workspace.
"""

from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCHEMA_OUT = HERE / "schema_snapshot.json"
VOCAB_OUT = HERE / "value_vocab.json"

# system.<schema>.<table> the rules read (and the tables Phases 2-3 will read).
# billing.list_prices is here because every rule joins it via the shared price macro.
#
# The second block was added for the plan's V0 track: Phase 2 rebuilds warehouse
# auto-stop on system.compute.warehouse_events (listed FIRST — Phase 2 cannot be
# written without its shape), and Phase 3 needs node_timeline (already above), the jobs
# SCD + run timeline, table lineage, serving endpoint usage, and Pipeline Events. A
# table absent or renamed in the target account is recorded as an ``__error__`` entry
# and skipped (the run does not crash), so a wrong name here is visible, not fatal.
TABLES: list[tuple[str, str]] = [
    ("billing", "usage"),
    ("billing", "list_prices"),
    ("access", "audit"),
    ("compute", "clusters"),
    ("compute", "node_timeline"),
    ("compute", "warehouses"),
    ("query", "history"),
    ("lakeflow", "pipelines"),
    ("lakeflow", "pipeline_update_timeline"),
    ("lakeflow", "job_task_run_timeline"),
    # --- V0 additions (Phases 2-3) ---
    ("compute", "warehouse_events"),        # Phase 2 warehouse auto-stop rebuild (FIN-012)
    ("lakeflow", "jobs"),                    # jobs SCD (FIN-010, FIN-020)
    ("lakeflow", "job_run_timeline"),        # run-level timeline / compute overlap
    ("access", "table_lineage"),             # unused_data_jobs / storage lifecycle (FIN-015)
    ("serving", "endpoint_usage"),           # idle_serving_endpoints traffic (FIN-018)
    ("serving", "served_entities"),          # serving endpoint SCD + workspace-safe join
    ("compute", "node_types"),               # node core/memory specs (FIN-016 jobs_compute_rightsize)
    # NB: Pipeline Events (FIN-019, opportunity C) is NOT a system table — verified
    # absent from system.lakeflow in fevm-finops-stable-us. It is the per-pipeline
    # event log (event_log(...) TVF / the pipeline's storage), so it must be sourced
    # that way when FIN-019 is built, not profiled here.
]

# Categorical columns whose REAL distinct values the fixtures should draw from. Kept
# to dimensional / low-cardinality columns — never identifiers, emails or free text,
# so the committed vocab carries no customer-identifying data.
CATEGORICAL: dict[str, list[str]] = {
    "billing.usage": [
        "billing_origin_product", "sku_name", "cloud", "usage_unit", "usage_type",
    ],
    "billing.list_prices": ["cloud", "usage_unit", "currency_code"],
    "access.audit": ["service_name", "action_name"],
    "compute.clusters": [
        "dbr_version", "cluster_source", "worker_node_type", "driver_node_type",
    ],
    "compute.warehouses": ["warehouse_type", "warehouse_channel"],
    "query.history": ["statement_type", "execution_status"],
    "lakeflow.pipelines": [],
    "lakeflow.pipeline_update_timeline": [],
    "lakeflow.job_task_run_timeline": ["result_state", "termination_code"],
    # --- V0 additions ---
    "compute.warehouse_events": ["event_type"],
    "lakeflow.jobs": [],
    "lakeflow.job_run_timeline": ["result_state", "termination_code", "trigger_type", "run_type"],
    "access.table_lineage": ["entity_type", "source_type", "target_type"],
    "serving.endpoint_usage": [],
    "serving.served_entities": ["entity_type", "task"],
}

# Candidate time columns per table, in preference order. The first one that exists
# in the table's real schema bounds every vocab/range scan to the lookback window —
# critical for the per-minute fact tables (node_timeline, query.history) that would
# otherwise scan all history. Dimension tables (clusters, warehouses, pipelines,
# list_prices) have no entry and are read unbounded (they are small).
TIME_BOUND_CANDIDATES: dict[str, list[str]] = {
    "billing.usage": ["usage_end_time", "usage_start_time"],
    "access.audit": ["event_time"],
    "compute.node_timeline": ["start_time"],
    "query.history": ["start_time", "end_time"],
    "lakeflow.pipeline_update_timeline": ["start_time"],
    "lakeflow.job_task_run_timeline": ["period_start_time", "start_time"],
    # --- V0 additions (per-minute / high-volume fact tables must stay bounded) ---
    "compute.warehouse_events": ["event_time"],
    "lakeflow.job_run_timeline": ["period_start_time", "start_time"],
    "access.table_lineage": ["event_time"],
    "serving.endpoint_usage": ["request_time"],   # confirmed column (not usage_start/end_time)
    "lakeflow.pipeline_events": ["timestamp", "event_time"],
    # serving.served_entities, lakeflow.jobs are SCD dimensions (small) — read unbounded.
}

# Numeric columns whose real ranges (min/p50/p95/max) anchor fixture magnitudes.
NUMERIC: dict[str, list[str]] = {
    "billing.usage": ["usage_quantity"],
    "compute.node_timeline": ["cpu_user_percent", "cpu_system_percent", "mem_used_percent"],
    "query.history": [
        "total_duration_ms", "waiting_for_compute_duration_ms",
        "read_bytes", "spilled_local_bytes",
    ],
    # --- V0 additions ---
    "compute.warehouse_events": ["cluster_count"],
    # endpoint_usage has one row per request (no `requests` count column); the token
    # counts are the meaningful numerics (AI-gateway efficiency, Phase 4 D).
    "serving.endpoint_usage": ["input_token_count", "output_token_count"],
}

# Real list_prices rows to capture verbatim (the pricing struct is load-bearing for
# every rule's $ math). We grab the latest-window row per (sku, cloud, unit, ccy) for
# the SKU families the subset rules price. Public list prices — safe to commit.
PRICE_SKU_LIKE = [
    "%ALL_PURPOSE%", "%JOBS_COMPUTE%", "%DLT%", "%SQL%", "%SERVERLESS%",
]

LOOKBACK_DAYS = 30
TOP_N_CATEGORICAL = 25

# Tables whose type must come from ``DESCRIBE ... AS JSON`` rather than
# information_schema. information_schema.full_data_type TRUNCATES very wide struct
# types (measured: billing.usage.usage_metadata came back with ~26 of its ~53 fields),
# so a rule needing a later usage_metadata field (e.g. warehouse_id, dlt_pipeline_id
# variants Phase 2/3 read) would build a struct literal missing that field. AS JSON
# returns the complete nested type. Only the known-wide tables use it — the rest keep
# the proven information_schema path — and AS JSON falls back to information_schema on
# any parse error, so a Databricks version without AS JSON degrades gracefully.
WIDE_STRUCT_TABLES = {"billing.usage"}


def _connect(profile: str, warehouse: str):
    from databricks import sql
    from databricks.sdk.core import Config

    cfg = Config(profile=profile)
    host = (cfg.host or "").replace("https://", "").replace("http://", "").rstrip("/")
    if not host:
        raise SystemExit(f"profile {profile!r} has no host")
    return sql.connect(
        server_hostname=host,
        http_path=f"/sql/1.0/warehouses/{warehouse}",
        credentials_provider=lambda: cfg.authenticate,
        _socket_timeout=120,
    )


def _rows(cur, sql_text: str) -> list[tuple]:
    cur.execute(sql_text)
    return cur.fetchall()


def _jsonable(v):
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def describe_information_schema(cur, sch: str, tbl: str) -> list[dict]:
    """Column name + FULL type, from information_schema.

    NB: ``DESCRIBE TABLE`` abbreviates long struct types as ``... N more fields>``,
    which would corrupt the nested-struct literals the fixtures build. information_
    schema.columns.full_data_type returns a longer type string, but it too TRUNCATES
    the very widest structs (see ``WIDE_STRUCT_TABLES``); those go through
    :func:`describe_as_json` instead."""
    rows = _rows(
        cur,
        "SELECT column_name, full_data_type FROM system.information_schema.columns "
        f"WHERE table_catalog = 'system' AND table_schema = '{sch}' "
        f"AND table_name = '{tbl}' ORDER BY ordinal_position",
    )
    return [{"name": r[0], "type": (r[1] or "").strip()} for r in rows]


def _json_type_to_ddl(t) -> str:
    """Render a ``DESCRIBE ... AS JSON`` type node as a Spark DDL type string
    (``struct<...>`` / ``array<...>`` / ``map<...>`` / ``decimal(p,s)`` / primitive),
    which is exactly what ``harness/typegen.parse_type`` consumes.

    The AS JSON type grammar (GA on recent DBR): a node is either a bare string
    (``"string"``) or an object ``{"name": <kind>, ...}`` where a struct carries
    ``fields`` (each ``{name, type, ...}``), an array carries ``element_type``, a map
    carries ``key_type`` / ``value_type``, and ``decimal`` carries ``precision`` /
    ``scale``. Anything unexpected raises, so :func:`describe` falls back."""
    if isinstance(t, str):
        return t
    if not isinstance(t, dict):
        raise ValueError(f"unexpected type node: {t!r}")
    kind = (t.get("name") or t.get("type") or "").lower()
    if kind == "struct":
        parts = []
        for f in t["fields"]:
            parts.append(f"{f['name']}:{_json_type_to_ddl(f['type'])}")
        return f"struct<{','.join(parts)}>"
    if kind == "array":
        return f"array<{_json_type_to_ddl(t['element_type'])}>"
    if kind == "map":
        return f"map<{_json_type_to_ddl(t['key_type'])},{_json_type_to_ddl(t['value_type'])}>"
    if kind == "decimal":
        return f"decimal({t.get('precision', 10)},{t.get('scale', 0)})"
    if not kind:
        raise ValueError(f"type node has no 'name': {t!r}")
    return kind


def describe_as_json(cur, sch: str, tbl: str) -> list[dict]:
    """Untruncated column types via ``DESCRIBE TABLE EXTENDED ... AS JSON``.

    The statement returns a single JSON document; its ``columns`` array carries each
    column's complete nested type, so a wide ``usage_metadata`` comes back whole. We
    render each type back to a DDL string for the fixtures/typegen. Raises on any
    unexpected shape so the caller can fall back to information_schema."""
    raw = _rows(cur, f"DESCRIBE TABLE EXTENDED system.{sch}.{tbl} AS JSON")
    # One row, one column, holding the JSON text (be tolerant of dict vs str).
    cell = raw[0][0]
    doc = json.loads(cell) if isinstance(cell, str) else cell
    cols = doc["columns"]
    out = []
    for c in cols:
        out.append({"name": c["name"], "type": _json_type_to_ddl(c["type"])})
    if not out:
        raise ValueError("AS JSON returned no columns")
    return out


def describe(cur, sch: str, tbl: str) -> list[dict]:
    """Column name + FULL type. Wide-struct tables use ``DESCRIBE ... AS JSON`` (the
    only untruncated source); everything else uses information_schema. AS JSON falls
    back to information_schema if it errors or the DBR predates it."""
    short = f"{sch}.{tbl}"
    if short in WIDE_STRUCT_TABLES:
        try:
            return describe_as_json(cur, sch, tbl)
        except Exception as exc:
            print(f"  ! AS JSON describe failed for {short} ({str(exc)[:80]}); "
                  f"falling back to information_schema (wide structs may be truncated)")
    return describe_information_schema(cur, sch, tbl)


def _bound(bound_col: str | None) -> str:
    """A `<time_col> >= date_sub(current_date(), N)` predicate, or empty for dims."""
    if not bound_col:
        return ""
    return f"{bound_col} >= date_sub(current_date(), {LOOKBACK_DAYS})"


def categorical_vocab(cur, fq: str, col: str, bound_col: str | None) -> list:
    b = _bound(bound_col)
    where = f"WHERE {col} IS NOT NULL" + (f" AND {b}" if b else "")
    try:
        rows = _rows(
            cur,
            f"SELECT {col} AS v, COUNT(*) AS n FROM {fq} "
            f"{where} GROUP BY {col} ORDER BY n DESC LIMIT {TOP_N_CATEGORICAL}",
        )
        return [_jsonable(r[0]) for r in rows]
    except Exception as exc:  # column absent in this workspace's schema version
        return [f"__unavailable__: {exc}"[:120]]


def numeric_range(cur, fq: str, col: str, bound_col: str | None) -> dict:
    b = _bound(bound_col)
    where = f"WHERE {b}" if b else ""
    try:
        r = _rows(
            cur,
            f"SELECT MIN({col}), percentile_approx({col}, 0.5), "
            f"percentile_approx({col}, 0.95), MAX({col}) FROM {fq} {where}",
        )[0]
        return {"min": _jsonable(r[0]), "p50": _jsonable(r[1]),
                "p95": _jsonable(r[2]), "max": _jsonable(r[3])}
    except Exception as exc:
        return {"__unavailable__": str(exc)[:120]}


def price_rows(cur) -> list[dict]:
    like = " OR ".join(f"sku_name LIKE '{p}'" for p in PRICE_SKU_LIKE)
    # Latest price window per (sku, cloud, unit, ccy); pricing struct kept whole.
    sql_text = f"""
    WITH ranked AS (
      SELECT sku_name, cloud, usage_unit, currency_code, price_start_time,
             price_end_time, pricing,
             ROW_NUMBER() OVER (
               PARTITION BY sku_name, cloud, usage_unit, currency_code
               ORDER BY price_start_time DESC
             ) AS rn
      FROM system.billing.list_prices
      WHERE ({like}) AND currency_code = 'USD'
    )
    SELECT sku_name, cloud, usage_unit, currency_code, price_start_time,
           price_end_time, pricing
    FROM ranked WHERE rn = 1
    ORDER BY sku_name, cloud
    LIMIT 400
    """
    out = []
    for r in _rows(cur, sql_text):
        pricing = r[6]
        # pyarrow decodes the struct to a dict; keep it verbatim for the fixtures.
        out.append({
            "sku_name": r[0], "cloud": r[1], "usage_unit": r[2],
            "currency_code": r[3],
            "price_start_time": _jsonable(r[4]),
            "price_end_time": _jsonable(r[5]),
            "pricing": _decode_struct(pricing),
        })
    return out


def _decode_struct(v):
    """databricks-sql-connector returns structs as dicts (pyarrow) or JSON strings."""
    if isinstance(v, str):
        try:
            return json.loads(v)
        except Exception:
            return v
    if isinstance(v, dict):
        return {k: _decode_struct(x) for k, x in v.items()}
    if isinstance(v, list):
        return [_decode_struct(x) for x in v]
    return _jsonable(v)


def _load_existing(path: Path) -> dict:
    """Existing committed snapshot's ``tables`` map, or empty if none/unreadable."""
    try:
        return json.loads(path.read_text()).get("tables", {})
    except Exception:
        return {}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--profile", required=True, help="Databricks CLI profile")
    ap.add_argument("--warehouse", required=True, help="SQL warehouse id")
    ap.add_argument(
        "--tables", default="",
        help="comma-separated schema.table subset to profile (default: all). "
             "e.g. --tables compute.warehouse_events,lakeflow.jobs",
    )
    ap.add_argument(
        "--merge", action="store_true",
        help="update ONLY the profiled tables in the committed snapshots, preserving "
             "the rest (and the captured price_rows). Use this to ADD a new table "
             "without re-capturing — and possibly changing — the grounded prices/vocab.",
    )
    args = ap.parse_args()

    wanted = {t.strip() for t in args.tables.split(",") if t.strip()}
    targets = [(s, t) for (s, t) in TABLES if not wanted or f"{s}.{t}" in wanted]
    if wanted:
        unknown = wanted - {f"{s}.{t}" for (s, t) in TABLES}
        if unknown:
            raise SystemExit(f"--tables names not in TABLES: {sorted(unknown)}")

    conn = _connect(args.profile, args.warehouse)
    cur = conn.cursor()

    # Merge starts from the committed snapshots so unprofiled tables (and price_rows)
    # survive; a full run starts empty and rewrites everything.
    schema: dict[str, list[dict]] = _load_existing(SCHEMA_OUT) if args.merge else {}
    vocab: dict[str, dict] = _load_existing(VOCAB_OUT) if args.merge else {}

    for sch, tbl in targets:
        short = f"{sch}.{tbl}"
        fq = f"system.{sch}.{tbl}"
        print(f"[profile] {fq}")
        try:
            schema[short] = describe(cur, sch, tbl)
        except Exception as exc:
            print(f"  ! DESCRIBE failed: {exc}")
            schema[short] = [{"__error__": str(exc)[:200]}]
            continue

        # Pick the first candidate time column that actually exists, to bound scans.
        have = {c.get("name") for c in schema[short]}
        bound_col = next(
            (c for c in TIME_BOUND_CANDIDATES.get(short, []) if c in have), None
        )
        if short in TIME_BOUND_CANDIDATES and not bound_col:
            print(f"  ! no bound column found for {short}; scans unbounded")

        entry: dict = {"categorical": {}, "numeric": {}, "_bound_col": bound_col}
        for col in CATEGORICAL.get(short, []):
            entry["categorical"][col] = categorical_vocab(cur, fq, col, bound_col)
        for col in NUMERIC.get(short, []):
            entry["numeric"][col] = numeric_range(cur, fq, col, bound_col)
        vocab[short] = entry

    # Capture list prices only when list_prices was (re)profiled this run; otherwise a
    # merge keeps whatever price_rows the committed vocab already holds.
    if any(f"{s}.{t}" == "billing.list_prices" for (s, t) in targets):
        print("[profile] billing.list_prices real rows")
        vocab.setdefault("billing.list_prices", {})["price_rows"] = price_rows(cur)

    cur.close()
    conn.close()

    meta = {
        "_generated": datetime.now(timezone.utc).isoformat(),
        "_source_profile": args.profile,
        "_note": "De-customerized: types, category vocab, numeric ranges, public list "
                 "prices only. No workspace ids, emails, resource names or account costs.",
    }
    SCHEMA_OUT.write_text(json.dumps({**meta, "tables": schema}, indent=2, default=_jsonable))
    VOCAB_OUT.write_text(json.dumps({**meta, "tables": vocab}, indent=2, default=_jsonable))
    verb = "merged" if args.merge else "wrote"
    print(f"[profile] {verb} {SCHEMA_OUT.name} ({len(schema)} tables) and {VOCAB_OUT.name}")


if __name__ == "__main__":
    main()
