# FinOps sample data — offline rule verification & regression base

This directory lets you run the FinOps rules' **real SQL + scoring** against a small,
committed sample that is **grounded in the actual system tables**, so you can:

- **verify findings offline** — see exactly what each rule produces on known inputs;
- **tweak the model** — change a threshold or SQL and re-run in seconds;
- **regression-test** — a golden suite that tells you which findings moved when you
  change a rule, on realistic data rather than hand-waved dicts.

It exists because the pre-existing tests only cover the **scoring** layer (Python
`score()` fed hand-authored candidate dicts). The **rule SQL** — which reads the
system tables and shapes those candidate rows — was never executed offline, yet that
is where the subtle, expensive bugs have lived (the idle_apps join, the
`interactive_to_job` `MAX()` price inflation, the `continuous_pipeline` active-hours
overcount). This harness runs that SQL.

## The pipeline

```
 profile/                      fixtures/                    harness/                 expected/ + tests/
┌───────────────────┐        ┌────────────────────┐      ┌──────────────────┐      ┌────────────────────┐
│ profile_system_    │  →     │ build_fixtures.py  │  →   │ runner.py        │  →   │ expected/<rule>.json│
│ tables.py          │ schema │ writes *.jsonl,    │ rows │  render real SQL │ recs │ test_rules_on_      │
│ (reads LIVE tables)│ +vocab │  from real vocab   │      │  → warehouse     │      │  sample.py (golden) │
└───────────────────┘        └────────────────────┘      │  → score()       │      └────────────────────┘
   schema_snapshot.json          typed by schema,         └──────────────────┘
   value_vocab.json              @rel dates                offline_resolver + typegen
```

1. **Profile (once, needs a workspace).** `profile/profile_system_tables.py` reads the
   live system tables and captures, de-customerized:
   - `schema_snapshot.json` — every column's **exact type**, including nested structs
     (`usage_metadata`, `pricing.effective_list.default`). Sourced from
     `information_schema.columns.full_data_type` (untruncated).
   - `value_vocab.json` — **real value vocabularies** (SKU names, node types, DBR
     versions, `billing_origin_product`, clouds…), numeric ranges (min/p50/p95/max),
     and **real `billing.list_prices` rows** (verbatim `pricing` structs).

   Committed. It holds types, category vocab, ranges and public list prices — **no**
   workspace ids, emails, resource names, or account-tied costs. Raw row dumps under
   `profile/raw/` are git-ignored.

2. **Build fixtures.** `fixtures/build_fixtures.py` composes **one coherent sample
   workspace** and writes a JSONL per system table. Every value comes from the profiled
   vocab (real SKUs, real price structs) — only the *arrangement* of rows into
   positive/negative scenarios is authored, so we never invent numbers that reality
   wouldn't produce. See [Fixture format](#fixture-format).

3. **Run.** `harness/runner.py` mirrors production (`precompute/job.py`): it renders each
   rule's SQL, executes it, and scores the rows with the shared transform. Two swaps
   only: an `OfflineResolver` points `tbl('schema','table')` at the fixture temp views,
   and the query runs on a pluggable [backend](#backends) instead of the workspace's
   `spark.sql`.

4. **Assert.** `expected/<rule>.json` holds the golden findings and `tests/` re-runs +
   compares. Two suites: `test_rules_on_sample.py` (goldens — did anything move?) and
   `test_value_invariants.py` (the [accounting invariants](#value-invariants) — did a
   change make a rule *wrong*?).

## Backends

The rule SQL is Spark SQL (nested-struct access, `named_struct`, window/date functions),
so it needs a Spark-compatible engine. The runner supports two, behind
`--backend spark|warehouse`:

- **`spark` (default) — hermetic local Spark.** A `local[1]` PySpark session: no
  warehouse, no secrets, no network. This is the **per-PR gate** — goldens + invariants
  run on every PR (fork PRs included) with nothing but a JVM + `pyspark`. It reproduces
  the warehouse-generated goldens byte-for-byte in practice; the fidelity gap
  (open-source Spark ≠ DBSQL/Photon on some decimal / struct / date edge cases) is what
  the backstop below is for. When no JVM / `pyspark` is present the suites **skip
  cleanly** (they don't fail); CI has both, so CI gates.
- **`warehouse` — fidelity backstop (deferred nightly).** `databricks-sql-connector`
  against a real SQL warehouse: the *same engine* the pipeline and the app's live
  fallback use, so it catches Spark-vs-DBSQL divergences the hermetic gate cannot. Point
  it at a workspace with env vars (below). `precompute/golden_diff.py` complements this
  by diffing the legacy job vs the SDP pipeline on live account data.

## Running it

```bash
# from accelerators/apps/finops-app, with the venv active (pyspark + a JVM installed)

# run one or more rules and see their findings — hermetic, no warehouse needed
PYTHONPATH=sample_data/harness python sample_data/harness/runner.py \
    --rule continuous_pipeline --show-rows

# --- ITERATING on one rule (fast, light) ---
# The golden suite is parametrized one-per-expected/*.json, so -k selects a single
# rule. Only that rule's (heavy) SQL executes; the shared fixtures still load (cheap
# CREATE VIEWs). A single-rule run is ~1-3 min on a fresh JVM with NO memory pressure —
# use this while developing a rule. Regenerate just that rule's golden the same way:
pytest sample_data/tests/test_rules_on_sample.py -k enable_serverless
UPDATE_EXPECTED=1 pytest sample_data/tests/test_rules_on_sample.py -k enable_serverless

# --- the FULL pre-PR gate (run once before pushing) ---
# The whole golden set shares ONE long-lived SparkContext, so run the golden and the
# value-invariant files as SEPARATE pytest invocations (two fresh JVMs) — a single
# combined run accumulates plan/exec state and can OOM the driver on a 16g box:
pytest sample_data/tests/test_rules_on_sample.py      # goldens
pytest sample_data/tests/test_value_invariants.py     # value invariants
# (CI / a box with >16g RAM can run `pytest sample_data/tests` in one shot.)

# after an INTENTIONAL rule change, regenerate the goldens (then eyeball the diff):
UPDATE_EXPECTED=1 pytest sample_data/tests/test_rules_on_sample.py

# --- warehouse backstop / (re)profiling (needs a workspace) ---
PROFILE=fevm-finops-stable-us ; WAREHOUSE=28ee85f85d49811e

# (re)profile the live system tables — only when schema/vocab should refresh.
# --tables + --merge ADD a table (e.g. the Phase 2 warehouse_events) WITHOUT
# re-capturing (and possibly changing) the grounded prices/vocab already committed:
python sample_data/profile/profile_system_tables.py --profile $PROFILE --warehouse $WAREHOUSE \
    --tables compute.warehouse_events,lakeflow.jobs --merge

# (re)build the fixtures from the profiled vocab
python sample_data/fixtures/build_fixtures.py

# run the goldens on the warehouse backstop instead of local Spark
FINOPS_SAMPLE_BACKEND=warehouse FINOPS_SAMPLE_PROFILE=$PROFILE \
    FINOPS_SAMPLE_WAREHOUSE=$WAREHOUSE pytest sample_data/tests/test_rules_on_sample.py -v
```

**Use `FINOPS_SAMPLE_SCHEMA` on the warehouse backend** (e.g.
`finops_stable_us_catalog.finops_sample`). Without it every fixture is a temp view over
a literal `SELECT … UNION ALL SELECT …` of all its rows, which the rule SQL references
several times — the warehouse re-analyses that plan each time, so one rule took 7+ min
and then dropped the connection. With it the runner materializes each fixture once as a
real table (created empty, then batched multi-row `INSERT … VALUES`) and every rule is an
ordinary query: **all 20 goldens in ~2 min** on `fevm-finops-stable-us`. The tables hold
only synthetic fixture rows and are recreated on every run (their `@rel` dates move with
today). Don't run two sessions against the same schema at once.

```bash
UPDATE_EXPECTED=1 FINOPS_SAMPLE_BACKEND=warehouse FINOPS_SAMPLE_PROFILE=$PROFILE \
    FINOPS_SAMPLE_WAREHOUSE=$WAREHOUSE FINOPS_SAMPLE_SCHEMA=finops_stable_us_catalog.finops_sample \
    pytest sample_data/tests/test_rules_on_sample.py -k warehouse_min_clusters
```

## Fixture format

One JSONL file per system table (`billing_usage.jsonl`, `access_audit.jsonl`, …). Each
line is a row that specifies **only the columns that matter** for a scenario; every
other column of the real schema is emitted as a correctly-typed `NULL`, so the temp
view matches the real table shape and the unmodified rule SQL always resolves.

- **Types** come from `schema_snapshot.json`; `harness/typegen.py` turns a JSON value +
  Spark type into an exact literal (`named_struct(...)` for structs, `CAST(... AS
  decimal(38,18))`, etc.).
- **Nested structs** are plain JSON objects: `"usage_metadata": {"app_id": "app-1"}`.
- **Relative time** keeps fixtures deterministic across run dates: use
  `{"@rel": -3}` for "3 days ago" (a DATE), or `{"@rel": -3, "@time": "04:00:00"}` for a
  TIMESTAMP. Rules filter on `date_sub(current_date(), lookback)`, so absolute dates
  would drift in and out of the window.

## Rules covered

> **Keep the shared fixture tables small.** Each table is first built as ONE literal
> `UNION ALL` of its rows. The local Spark backend re-registers it over the collected rows
> (a LocalRelation) and the warehouse backend can materialize it (`FINOPS_SAMPLE_SCHEMA`),
> so rules no longer re-expand it — but the first build still analyses the whole union.
> At ~2,000 `billing.usage` rows (before the LocalRelation step) the 8g driver ran out of
> heap. Price at the coarsest grain the rule reads, and give rows only to resources that
> reach the stage that reads them.

Subset-first — the harness is proven, and both the suppressed and firing paths are
exercised. Remaining rules are quick to add (see [Adding a rule](#adding-a-rule)).

| Rule | Tables | Scenario | Expected | What it proves |
|------|--------|----------|----------|----------------|
| `idle_apps` | billing.usage, access.audit, billing.list_prices | 2 always-on Apps; audit has only lifecycle events | **0 findings** | The signal gate correctly suppresses — and, crucially, that **idle_apps cannot fire on real data** (see below). |
| `continuous_pipeline` | billing.usage (DLT), lakeflow.pipelines, lakeflow.pipeline_update_timeline, billing.list_prices | continuous DLT pipeline billed ~24×7, updates ~2h/day | **1 MEDIUM finding, ~$158/mo** | The measured idle-hours path fires and prices only the idle portion. |
| `warehouse_autostop` | compute.warehouses, **compute.warehouse_events**, query.history, billing.usage, billing.list_prices | 3 classic/serverless warehouses: one PRO with no auto-stop running 10h/day but busy ~20min/day, one PRO already at auto_stop=15, one SERVERLESS | **1 HIGH finding, ~$134/mo, bookable** (1 candidate) | **FIN-012 rebuild.** Reclaim is priced from the ACTUAL running time (`warehouse_events` intervals) and a concurrency-merged, exact-interval 10-min counterfactual — not billed-hour buckets. The tight-auto-stop and serverless warehouses are excluded (candidates gate + type filter). Interval-priced findings are `bookable`; the coarse hourly fallback (no events) stays `estimated`. The gate first surfaced a DBSQL-only `QUALIFY` in this rule — migrated to a portable rank-then-filter so the hermetic gate can run it. |
| `idle_serving_endpoints` | **serving.served_entities**, **serving.endpoint_usage**, billing.usage, billing.list_prices | 3 CUSTOM_MODEL endpoints, all billed 14 days: one `min_concurrency=1` with **0 requests**, one same with ~1 request/day, one scale-to-zero (`min_concurrency=0`) | **2 findings: both estimated (~$47/mo zero-traffic, ~$33/mo low-traffic)** (2 candidates) — the zero-traffic endpoint never logged a request, so since 2026-09-23 it is `zero_unverified` (estimated), not bookable | **FIN-018 serving zero-traffic tier.** The zero-traffic tier is MEASURED — requests are counted in the per-request log `serving.endpoint_usage`, not inferred — so its full always-on cost is `bookable`; the low-traffic tier credits only the share scale-to-zero would reclaim and stays `estimated`; the scale-to-zero endpoint is dropped at the candidates gate (it costs ~nothing idle, so deleting it saves $0). The rule's DBSQL-only `QUALIFY` (latest-endpoint SCD select) was migrated to the shared `latest_scd_cte` macro so the hermetic gate can run it. |
| `interactive_to_job` | compute.clusters, **compute.node_timeline**, **lakeflow.job_task_run_timeline**, billing.usage (ALL_PURPOSE), billing.list_prices | 4 all-purpose clusters: a job-DEDICATED one (job active 100% of uptime), a SHARED one (job uses 25% of uptime), a job-dedicated but tiny (~$84/mo) one, and a JOB-source one | **2 findings: 1 bookable (~$463/mo) + 1 estimated (~$579/mo)** (3 candidates) | **FIN-010 rebuild.** `job_active_frac` divides WALL-CLOCK job minutes by WALL-CLOCK running minutes (`COUNT(DISTINCT` clock minute`)`, not `COUNT(*)` node-minutes), so the reassignable fraction is invariant to cluster size — the unit bug. A DEDICATED cluster books the measured `$0.45/DBU` gap (removing the jobs eliminates it; `low == point`); a SHARED cluster stays `estimated` with a `$0` lower bound (moving the jobs off may not shrink the interactive cluster — the attributed gap is the upper scenario only). The tiny cluster is a candidate but suppressed at the reassignable-cost gate; the JOB-source cluster is excluded upstream, so `candidate_row_count=3` pins both filters. |
| `idle_zombie_clusters` | compute.clusters, **compute.node_timeline**, billing.usage, lakeflow.job_task_run_timeline, billing.list_prices | 2 idle UI clusters on a tight (30-min) auto-stop with no jobs: one STILL running idle in the recency window, one that ran idle only 20-27 days ago (now stopped) | **2 findings: 1 estimated (~$501/mo) + 1 advisory ($0)** (2 candidates) | **FIN-017 rebuild.** The actionable saving is sized on the last `recency_days` of billed spend, not the whole lookback. The still-running cluster stays `estimated` (CPU idle is only a proxy for true inactivity, so it is never booked; `low=0`); the stopped cluster drops to `advisory` with `$0` forward savings — terminating an already-stopped cluster reclaims nothing, so its historical idle waste (~$208/mo) is shown as max-addressable context only, NOT the whole-lookback annualization the old code booked. The rule's DBSQL-only `QUALIFY` latest-cluster select was migrated to the shared `latest_scd_cte` macro so the hermetic gate can run it. |
| `failing_jobs` | **lakeflow.job_run_timeline**, **lakeflow.jobs**, billing.usage (per-run via `usage_metadata.job_run_id`), billing.list_prices | 5 jobs: a chronically-failing one WITH successful runs, one that NEVER succeeds, a healthy (5%-fail) one, a majority-CONTINUOUS streaming one, and a low-run one | **2 findings: 1 estimated repair (~$84/mo) + 1 advisory retire ($0, ~$240/mo addressable)** (3 candidates) | **FIN-020 rebuild.** The finding is split into two actions. A REPAIR (the job has comparable successful runs to price the fixed state) stays `estimated` — the excess-failure spend net of completion cost, `low=0`. A RETIRE (the job never succeeded, so no repair credit can be priced and retiring needs an owner/obsolescence decision) drops to `advisory`: it books `$0`, showing the excess-failure spend as max-addressable only. The healthy job is a candidate row but suppressed at the score-side `min_fail_rate` gate; the streaming (majority-CONTINUOUS) and low-run jobs are excluded at the SQL `HAVING`, so `candidate_row_count=3` pins both SQL filters and the score gate. |
| `unused_data_jobs` | **access.table_lineage** (writes + reads), lakeflow.jobs, billing.usage, billing.list_prices | 3 producer jobs: one writing an unread table in a schema that HAS reads, one writing an unread table in a schema with NO reads, and one writing a table that IS read | **1 finding: advisory (~$60/mo addressable, $0 booked)** (2 candidates) | **FIN-015 rebuild.** No recoverable-fraction haircut — the FULL producing cost is shown as max-addressable and books `$0` (advisory) until a human verifies the output is unused. The lineage-availability sentinel distinguishes "lineage observed writes, zero reads" (fires — the schema shows captured reads of other tables) from "no coverage" (suppressed — the schema shows no reads at all, so zero-reads is meaningless). The read table's job is excluded at the SQL `HAVING`, the no-coverage job is a candidate suppressed at the score-side sentinel, so `candidate_row_count=2` pins the sentinel. |
| `spot_fallback` | compute.clusters (`aws_attributes.availability`), billing.usage, billing.list_prices | 4 classic clusters: an ON_DEMAND multi-node one, a tiny ON_DEMAND one, an already-SPOT one, and a single-node ON_DEMAND one | **1 finding: advisory $0 (~$240/mo DBU spend shown as context)** (2 candidates) | **FIN-009 rebuild.** Spot reduces the CLOUD VM bill, but Databricks meters DBUs — the DBU rate is identical on spot vs on-demand — so a spot toggle changes the metered spend by `$0`. The rule surfaces the opportunity as `advisory` with `$0` savings (unquantifiable without a cloud billing export), the DBU spend shown only as context. The already-spot and single-node clusters are excluded at the SQL candidates filter; the tiny cluster is a candidate suppressed at the score-side `min_monthly_cost` gate, so `candidate_row_count=2` pins both. The DBSQL-only `QUALIFY` latest-cluster select was migrated to the shared `latest_scd_cte` macro (adding the `delete_time` guard) so the hermetic gate can run it. |
| `enable_photon_dbr` | compute.clusters (`dbr_version`), billing.usage (ALL_PURPOSE), billing.list_prices | 3 UI clusters on old vs current runtimes: an old-DBR mixed all-purpose one, an old-DBR **ML** one at the SAME spend, and a current-DBR one | **2 findings: both advisory $0, upper bounds ~$58.50 (mixed) vs ~$19.50 (ML)** (10 candidates) | **FIN-021 rebuild.** The price/perf uplift from a runtime upgrade + Photon is an unmeasured HEURISTIC, so the rule now books nothing — the class-based fraction is surfaced only as the max-addressable UPPER BOUND (`high`), never as a booked saving. Two clusters at identical ~$390/mo spend fire `advisory` `$0` with different ceilings purely by workload class (Photon strongly accelerates SQL/Spark but barely helps Python/ML, so the ML floor is ~5% vs the mixed ~15%). A real figure needs matched before/after runs of the same workload across the change, normalized for input. The current-DBR cluster is a candidate row suppressed at score (`major >= min_dbr_major`); the photon SQL returns EVERY UI/API cluster (`LEFT JOIN cost`), so `candidate_row_count=10` is the whole fixture's UI/API cluster set — only the two old-DBR clusters fire. |
| `serverless_cost_optimized` | billing.usage (`product_features.performance_target`, serverless SKUs), lakeflow.job_run_timeline, lakeflow.pipeline_update_timeline, lakeflow.jobs, lakeflow.pipelines, billing.list_prices | 3 serverless PERFORMANCE_OPTIMIZED workloads: a long-running job, a long-running **triggered pipeline**, and a short-running job | **2 findings: both advisory $0, upper bounds ~$270 (job) + ~$210 (pipeline)** (3 candidates) | **FIN-014 rebuild.** The ~50% DBU reduction Standard mode delivers is a MODELED default (same `$/DBU`, no matched before/after run), so the rule books nothing — the modeled figure is surfaced only as the max-addressable UPPER BOUND (`high`). The pipeline finding now carries `resource_type="pipeline"` (the fix — the old rule hardcoded `"job"` for every row and mislabelled DLT/SDP pipelines). The short-run job is a candidate row suppressed at the score-side `short_run_minutes` gate (Standard's slower cold start erodes the saving on a brief run), so `candidate_row_count=3` pins the SQL PERFORMANCE_OPTIMIZED/serverless filters and the duration gate. The DBSQL-only `QUALIFY` `job_meta`/`pipe_meta` latest-version selects were migrated to the shared `latest_scd_cte` macro so the hermetic gate can parse the SQL. |
| `enable_serverless` | compute.warehouses, billing.usage (`product_features.is_serverless=false`, SQL), query.history, billing.list_prices | 2 PRO SQL warehouses warm 10h/day (13 days, ~$429/mo): one active only 4h/day (idle 60%), one active 9h/day (idle 10%) | **1 finding: estimated, books $0, low ~$211 (measurable DBU floor) ≤ point ~$382 (incl. estimated VM)** (2 candidates) | **FIN-013 rebuild.** Classic/pro DBU bills exclude the cloud VM (billed separately, absent from `billing.usage`), so the migration saving splits into a MEASURABLE DBU-only comparison (idle warm-pool DBUs removed minus the higher serverless DBU rate on active hours) = the `low` bound, and a SEPARATE estimated cloud-VM credit = the `high` bound. The headline credits the estimated VM, so it is `estimated` and books `$0` — but the DBU-only floor is what the billing data can prove. The idle-10% warehouse is a candidate row suppressed at the score-side `min_idle_fraction` gate (pro 0.15), so `candidate_row_count=2` pins the SQL `is_serverless=false` filter + the idle gate. **Determinism:** fixtures fill 13 days strictly inside the SQL's 14-day window — never the day exactly 14 days ago, whose hours straddle the `>= now - 14 DAYS` cutoff by time-of-day and drifted the point saving run-to-run. Isolated from `warehouse_autostop` (tight `auto_stop` + no `warehouse_events`); its warehouses never enter this rule (their billing lacks `is_serverless=false`). The DBSQL-only `QUALIFY` latest-warehouse select was migrated to `latest_scd_cte`. |
| `jobs_compute_rightsize` | **compute.node_timeline** (driver/worker), **compute.node_types** (core/mem specs), compute.clusters (JOB source), billing.usage (`usage_metadata.cluster_id`+`job_id`), lakeflow.jobs, billing.list_prices | 3 recurring jobs on ephemeral JOB clusters, each 6 run-clusters over 6 days: one driver-bound (workers idle at avg 2% **and** p95), one **bursty** (workers idle on average ~31% but p95 spikes ~72%), one healthy (workers busy 60%) | **1 finding: estimated (~$96/mo)** (3 candidates) | **FIN-016 rebuild (jobs).** The rule classified the over-provisioning symptom on AVERAGE utilization, which hides a burst the compute exists to serve. The SQL now emits driver/worker **p95** via `percentile_approx`, and `score()` adds a PEAK VETO: a high worker p95 CPU blocks the worker-cut symptoms (`driver_bound`/`idle_workers`), a high p95 memory blocks `memory_oversize`. The driver-bound job fires and reclaims the worker cost share (measured from node core counts); the **bursty** job is a candidate that yields NO finding — the exact false positive the average alone would have booked as `idle_workers`; the healthy job is suppressed on the averages, so `candidate_row_count=3` pins the veto happening in `score()`. Stays `estimated` (CPU/memory are proxies; the veto tightens honesty, it doesn't promote to bookable). `compute.node_types` was added to the profiler + schema snapshot for this rule, and its hand-written `QUALIFY` latest-config select was migrated to a portable rank-then-filter so the hermetic gate can run it. |
| `warehouse_min_clusters` | compute.warehouses, **compute.warehouse_events**, query.history, billing.usage | 2 LARGE serverless warehouses up 08-18h, one query an hour: min_clusters 2 vs 1 | **1 estimated (~$1,100/mo)** (1 candidate) | Cluster-minutes rebuilt from events vs clusters needed; only floor-held minutes priced; min_clusters=1 is not a candidate. |
| `warehouse_keepalive_queries` | compute.warehouses, query.history, billing.usage | a warehouse billed 24h/day by an hourly result-cache ping, real work 09-11h | **2 estimated** (4 candidates) | Keep-alive hours priced less one auto-stop tail per run. The 2nd finding is the enable_serverless fixture warehouse, whose queries have NULL `statement_type` — pins that such rows count as trivial. |
| `job_task_retry_waste` | lakeflow.job_run_timeline, **lakeflow.job_task_run_timeline**, billing.usage | 2 jobs x 20 runs; one retries `load_orders` on 6 runs | **1 estimated (~$50/mo)** (1 candidate) | Failed attempts priced by wall-time share, credited above a 5% baseline; the clean job is dropped at the HAVING. |
| `job_no_new_input` | lakeflow.job_run_timeline, **access.table_lineage** (reads + writes), billing.usage | 2 cron jobs 4x/day: one reads a table last written 5 days ago, one a table written before every run | **1 estimated (~$90/mo)** (1 candidate) | Runs with no source write since the previous run are priced; the fresh-input job is dropped at the HAVING. |
| `unviewed_scheduled_dashboards` | **access.audit** (views vs `lakeview-processing` refreshes), query.history, billing.usage | 2 dashboards refreshed every 2h: last opened 20 vs 2 days ago | **1 advisory ($0, ~$283/mo spend)** (1 candidate) | Task-share of the warehouse-hours it ran in; the recently-viewed one is dropped by the SQL. |
| `unpruned_repeated_queries` | query.history (read/pruned files, bytes), billing.usage | 2 saved queries 6x/day: a 1%-pruned 3 GB scan vs a well-pruned one | **1 advisory ($0, ~$160/mo spend)** (2 candidates) | The no-pruning shape is flagged at its task-time share; the pruned shape is not. |

### Finding: idle_apps cannot fire on real audit data

Building the idle_apps fixture from the real `system.access.audit` surfaced that the
rule's access signal does not exist:

- the rule filters `service_name = 'databricksApps'`, but the real service is **`apps`**;
- and even `apps` events are **control-plane lifecycle actions** (`deployApp`,
  `startApp`, `stopApp`, `changeAppsAcl`…) — there is **no user HTTP-access event** in
  the table.

So on real data every app reads `access_events = 0`, `app_access_events_total = 0`, and
the signal gate (added in the reviewed PR) suppresses the rule everywhere. No false
positives, but the rule can never fire — corroborating the known "Apps have no usage
log" limitation. The fixture encodes this faithfully (real audit shape → no findings)
rather than fabricating a `databricksApps` access event that reality never emits.

## Phase 1 shared-correctness invariants (FIN-001–007)

Phase 1 of `docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md` reworked the shared data layer:
one closed-open window everywhere (FIN-002), all `record_type`s summed in cost
(FIN-003), a canonical corrected-cost macro (FIN-001), coverage that fails closed for
booking (FIN-004), rank-then-filter SCD selection (FIN-006), and workspace-safe join
keys (FIN-007). The shared macros live in `rules/finops_rules/sql/_macros.sql.j2`.

<a name="value-invariants"></a>
Two layers guard this, and **both now run hermetically on every PR** (plan V0 landed the
local-Spark backend, so the value layer is no longer warehouse-gated):

- **Rendered-SQL invariants — `rules/finops_rules/tests/test_phase1_invariants.py`.**
  These assert the properties on each rule's *rendered SQL string*: every window is
  closed-open, no cost sum filters `record_type='ORIGINAL'`, no SCD ranks after a
  pre-QUALIFY `delete_time` filter, and no warehouse analytic/join is keyed on
  `warehouse_id` alone. They catch a defect at authoring time, with no engine at all.
- **Value invariants — `tests/test_value_invariants.py`.** These EXECUTE the rule SQL on
  purpose-built fixtures (`fixtures/build_fixtures.py::invariant_*`) and assert the
  ACCOUNTING properties on the *results* — the layer that fails when a change makes a
  rule *wrong* rather than merely different. The Phase 1 shared-layer invariants drive
  `continuous_pipeline` (it exercises the whole shared cost layer in one rule); the
  FIN-012 interval invariants drive `warehouse_autostop`; the FIN-018 booking-tier
  invariants drive `idle_serving_endpoints`:

  | Invariant | Fixture | Guards |
  |---|---|---|
  | savings ≤ corrected current cost; `low ≤ point ≤ high` | `invariant_baseline` | over-booking bound |
  | advisory/estimated ⇒ booked $0; bookable books its low | `invariant_baseline` + aggregation | headline integrity (FIN-008) |
  | missing price ⇒ **suppressed**, not $0-cost booked | `invariant_missing_price` | FIN-004 fail-closed |
  | ORIGINAL+RETRACTION+RESTATEMENT ⇒ corrected amount | `invariant_correction_triple` | FIN-003 |
  | deleted latest SCD row ⇒ pipeline dropped (older live row NOT resurrected) | `invariant_deleted_scd` | FIN-006 |
  | duplicate id in two workspaces ⇒ no cross-workspace bleed | `invariant_dup_workspace` | FIN-007 |
  | N-day window ⇒ exactly N dates, no partial today | `invariant_window_dates` | FIN-002 |
  | merged busy ≤ running; counterfactual ≤ running; reclaimed ≤ corrected cost; head/tail idle reclaimed | `invariant_wh_gaps` | FIN-012 interval accounting |
  | overlapping queries ⇒ warm counted as the union, not the sum | `invariant_wh_concurrency` | FIN-012 no duplicate warm |
  | zero-traffic endpoint ⇒ bookable, savings == full cost (≤ cost) | `invariant_serving_zero_bookable` | FIN-018 measured zero-traffic books |
  | low-traffic endpoint ⇒ estimated, books $0, credits only the reclaimable share | `invariant_serving_low_estimated` | FIN-018 low-traffic stays estimated |
  | half-priced zero-traffic endpoint ⇒ fires but drops to estimated | `invariant_serving_missing_price_not_bookable` | FIN-004 fail-closed on the booking path |
  | still-running idle cluster ⇒ estimated, books $0, point > 0 | `invariant_iz_running_estimated` | FIN-017 forward saving stays estimated |
  | stopped-for-weeks cluster ⇒ $0 forward (no annualization), high > 0 | `invariant_iz_stopped_books_zero` | FIN-017 forward-spend guard |
  | same cluster idle in two workspaces ⇒ no cross-workspace bleed | `invariant_iz_dup_workspace` | FIN-007 workspace-safe keys |
  | failing job WITH successful runs ⇒ estimated repair, books $0, point > 0 | `invariant_fj_repair_estimated` | FIN-020 repair stays estimated |
  | job that NEVER succeeds ⇒ advisory, books $0, addressable high > 0 | `invariant_fj_retire_books_zero` | FIN-020 obsolescence/owner gate |
  | unread producer, schema HAS reads ⇒ advisory, addressable == full cost (no haircut) | `invariant_udj_addressable_advisory` | FIN-015 no-haircut + books $0 |
  | unread producer, schema has NO reads ⇒ suppressed ("no coverage") | `invariant_udj_no_coverage_suppressed` | FIN-015 lineage-availability sentinel |
  | on-demand cluster ⇒ advisory, $0 (spot toggle leaves DBUs unchanged) | `invariant_spot_books_zero` | FIN-009 no VM savings from DBU data |
  | old-runtime cluster ⇒ advisory, books $0, heuristic uplift is only the upper bound (high > 0) | `invariant_photon_books_zero` | FIN-021 unmeasured uplift never booked |
  | long serverless PERFORMANCE_OPTIMIZED job ⇒ advisory, books $0, modeled reduction is only the upper bound (high > 0) | `invariant_sco_books_zero` | FIN-014 modeled DBU reduction never booked |
  | warm-but-idle classic/pro warehouse ⇒ estimated, books $0, measurable DBU floor ≤ point ≤ VM-included ceiling | `invariant_es_estimated_books_zero` | FIN-013 measurable floor + separate estimated VM range |

**The two existing goldens are unaffected by Phase 1** — verified by construction, not
by luck: the fixtures carry only `record_type='ORIGINAL'` rows (so summing all types
equals the old ORIGINAL-only sum), all dates are strictly in the past (`@rel: -1..-14`,
never today, so excluding the partial current day changes nothing), and the one pipeline
has `delete_time: None` with a single version (so rank-then-filter selects the same
row). Regenerate them with `UPDATE_EXPECTED=1` only if a future fixture adds a
correction, a deletion, or same-day data.

## Adding a rule

1. Add a `_add_<rule>()` section to `fixtures/build_fixtures.py` that appends rows to
   the shared tables, using SKUs/prices from `value_vocab.json`. Aim for one positive
   and, where useful, one negative (a row that should be suppressed).
2. `python sample_data/fixtures/build_fixtures.py`.
3. Seed `expected/<rule>.json` with `{"rule_id": "...", "note": "..."}`, then populate it
   with `UPDATE_EXPECTED=1 pytest ...` and **eyeball the result** before committing.
4. Run the suite without `UPDATE_EXPECTED` to confirm it's green.

## Known caveats

- **Wide structs.** `information_schema.full_data_type` truncates very wide struct types
  (e.g. `usage_metadata` came back with ~26 of its ~53 fields). The profiler now reads
  the tables in `WIDE_STRUCT_TABLES` (currently `billing.usage`) via
  `DESCRIBE ... AS JSON`, which returns the complete nested type, and falls back to
  information_schema if a DBR predates AS JSON. Add a table to that set if a rule needs
  a field its truncated type is missing.
- **Hermetic by default; JVM needed to actually run.** The suites run on local Spark with
  no warehouse, but that engine needs a JVM (Java 11/17) + `pyspark`. Where neither is
  present the suites **skip** (they don't fail); CI installs both (`pyspark` is in the
  `dev` extra) so CI gates. Devs without a JVM can still use `--backend warehouse`.
- **Open-source Spark ≠ DBSQL/Photon** on some edge cases (decimal precision, a few
  struct/date functions). Keep rule SQL within portable Spark SQL; the warehouse backstop
  is there to catch a divergence the hermetic gate would miss.
- **Savings compared with a $0.50 tolerance** (floats); ids/priority/effort/status
  compared exactly.
