"""Value invariants — the "a change that WORSENS a rule fails a test" layer (plan V0).

Three layers guard the savings logic, and they are deliberately different:

* **goldens** (test_rules_on_sample.py) detect *any* change — regenerate and they pass.
* **rendered-SQL invariants** (rules/finops_rules/tests/test_phase1_invariants.py) read
  the SQL *string* and run with no warehouse, catching a defect at authoring time.
* **value invariants (this file)** EXECUTE the rule SQL on purpose-built fixtures and
  assert the ACCOUNTING properties on the *results*. These fail the moment a change
  makes a rule wrong — an over-book, a dropped correction, a resurrected deleted row, a
  cross-workspace bleed — rather than merely different.

They map 1:1 to the plan's V0 invariant list and the backlog's accounting invariants,
and every one is driven by a fixture in ``fixtures/build_fixtures.py`` whose values come
from the profiled vocab (real DLT SKUs + captured pricing), never invented. The Phase 1
shared-layer invariants drive ``continuous_pipeline`` (it exercises the whole shared cost
layer in one rule); the FIN-012 interval invariants drive ``warehouse_autostop`` (the only
rule that reconstructs running intervals from ``system.compute.warehouse_events``); the
FIN-018 booking-tier invariants drive ``idle_serving_endpoints`` (the rule that promotes a
measured zero-traffic endpoint to bookable while keeping the low-traffic tier estimated).

Backend: the hermetic local-Spark engine — no warehouse, no secrets. Skips cleanly when
no JVM / pyspark is present (CI has both, so CI gates).
"""

from __future__ import annotations

import sys
from datetime import date, datetime, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]          # sample_data/
sys.path.insert(0, str(ROOT / "harness"))
sys.path.insert(0, str(ROOT / "fixtures"))

from build_fixtures import (  # noqa: E402  (path set above)
    CL_MAX_ACCEPTABLE_MIN,
    INV_BILLED_DAYS,
    INV_HOURLY_DBU,
    INV_WH_DAYS,
    WS,
    invariant_baseline,
    invariant_cluster_gap_threshold,
    invariant_cluster_job_activity,
    invariant_correction_triple,
    invariant_deleted_scd,
    invariant_dup_workspace,
    invariant_es_estimated_books_zero,
    invariant_i2j_dedicated_bookable,
    invariant_fj_repair_estimated,
    invariant_fj_retire_books_zero,
    invariant_i2j_dup_workspace,
    invariant_i2j_shared_estimated,
    invariant_i2j_size_invariance,
    invariant_iz_dup_workspace,
    invariant_iz_running_estimated,
    invariant_iz_stopped_books_zero,
    invariant_missing_price,
    invariant_photon_books_zero,
    invariant_sco_books_zero,
    invariant_spot_books_zero,
    invariant_udj_addressable_advisory,
    invariant_udj_no_coverage_suppressed,
    invariant_serving_low_estimated,
    invariant_serving_missing_price_not_bookable,
    invariant_serving_zero_bookable,
    invariant_wh_concurrency,
    invariant_wh_gaps,
    invariant_window_dates,
)

WS_B = "1470000000000002"
DLT_RATE = 0.36   # ENTERPRISE_DLT_ADVANCED_COMPUTE $/DBU (captured in value_vocab.json)
BASELINE_WASTE = INV_HOURLY_DBU * 24 * INV_BILLED_DAYS * DLT_RATE   # 1.5*24*14*0.36 = 181.44


@pytest.fixture(scope="module")
def runner():
    from backends import BackendUnavailable
    from runner import SampleRunner

    try:
        r = SampleRunner.for_backend("spark")
    except BackendUnavailable as exc:
        pytest.skip(f"local-Spark backend unavailable: {exc}")
    yield r
    r.close()


@pytest.fixture(scope="module")
def cp():
    """The continuous_pipeline rule + shared config. list_rules(), so it resolves even
    when a rule is disabled from the product."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "continuous_pipeline")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def wh():
    """The warehouse_autostop rule + shared config (FIN-012 interval invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "warehouse_autostop")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def serving():
    """The idle_serving_endpoints rule + shared config (FIN-018 booking-tier invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "idle_serving_endpoints")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def cluster():
    """The cluster_autotermination rule + shared config (FIN §2.4 gap-method invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "cluster_autotermination")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def i2j():
    """The interactive_to_job rule + shared config (FIN-010 rebuild invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "interactive_to_job")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def zombie():
    """The idle_zombie_clusters rule + shared config (FIN-017 forward-spend invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "idle_zombie_clusters")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def failing():
    """The failing_jobs rule + shared config (FIN-020 repair/retire tier invariants)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "failing_jobs")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def unused_jobs():
    """The unused_data_jobs rule + shared config (FIN-015 sentinel + no-haircut)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "unused_data_jobs")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def spot():
    """The spot_fallback rule + shared config (FIN-009 advisory-$0 invariant)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "spot_fallback")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def photon():
    """The enable_photon_dbr rule + shared config (FIN-021 advisory-$0 invariant)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "enable_photon_dbr")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def sco():
    """The serverless_cost_optimized rule + shared config (FIN-014 advisory-$0 invariant)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "serverless_cost_optimized")
    return rule, load_thresholds(), load_effort()


@pytest.fixture(scope="module")
def enserv():
    """The enable_serverless rule + shared config (FIN-013 estimated-with-floor invariant)."""
    from finops_rules import list_rules, load_effort, load_thresholds

    rule = next(r for r in list_rules() if r.id == "enable_serverless")
    return rule, load_thresholds(), load_effort()


def _run(runner, cp, extra):
    """Load one invariant's fixture set (replacing the committed rows) and return the
    rule's (candidate_rows, findings)."""
    rule, thresholds, effort = cp
    runner.load_fixtures(extra=extra)
    rows = runner.candidate_rows(rule, thresholds)          # heavy SQL, run ONCE
    findings = runner.score(rule, rows, thresholds, effort)  # score those rows, no re-query
    return rows, findings


def _rec(status, low, point, high, *, waste=1000.0, rid="r1", ws="w1"):
    """A minimal Recommendation for exercising the booking aggregation contract."""
    from finops.models import Recommendation

    return Recommendation(
        recommendation_id=rid, snapshot_date=date(2026, 9, 1), rule_id="continuous_pipeline",
        rule_version="1.0.0", rule_title="t", category="pipelines", workspace_id=ws,
        resource_type="pipeline", resource_id=rid, resource_name="n", why="", how="",
        monthly_waste_usd=waste, monthly_savings_usd=point, savings_status=status,
        monthly_savings_low_usd=low, monthly_savings_high_usd=high, effort_band="low",
        effort_score=2, priority="LOW", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )


# --- portfolio invariants (hold for ANY firing rule) ------------------------

def test_savings_never_exceeds_corrected_cost(runner, cp):
    """Invariant: savings <= corrected current cost (backlog #7 'bounded result').
    Also: low <= point <= high (booked-headline integrity)."""
    _, findings = _run(runner, cp, invariant_baseline())
    assert len(findings) == 1, "baseline scenario must fire exactly one pipeline"
    f = findings[0]
    assert f["monthly_savings_usd"] <= f["monthly_waste_usd"] + 1e-6, (
        "savings exceed the corrected monthly cost of the affected scope"
    )
    lo = float(f["monthly_savings_low_usd"])
    pt = float(f["monthly_savings_usd"])
    hi = float(f["monthly_savings_high_usd"])
    assert lo <= pt <= hi, f"low<=point<=high violated: {lo} <= {pt} <= {hi}"


def test_status_governs_booking(runner, cp):
    """Invariant: advisory/estimated contribute $0 to the booked headline; only a
    bookable finding books (its low). Driven by the real continuous_pipeline finding
    (emitted 'estimated' per Phase 0.3), then generalized across the three statuses on
    identical numbers via the aggregation authority."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, cp, invariant_baseline())
    f = findings[0]
    assert f["savings_status"] == "estimated", "continuous_pipeline is estimated (Phase 0.3)"
    # The real 'estimated' finding shows as addressable opportunity but books zero.
    base = _rec("estimated", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
                f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
                rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    ov = account_overview([base])
    assert ov.total_monthly_savings_usd == 0.0
    assert ov.total_monthly_savings_addressable_usd == round(float(f["monthly_savings_usd"]), 2)

    # Contract across statuses on the SAME numbers: bookable books low, others book zero.
    low, pt, hi = 50.0, 80.0, 90.0
    assert account_overview([_rec("bookable", low, pt, hi)]).total_monthly_savings_usd == low
    assert account_overview([_rec("estimated", low, pt, hi)]).total_monthly_savings_usd == 0.0
    assert account_overview([_rec("advisory", low, pt, hi)]).total_monthly_savings_usd == 0.0


# --- FIN-004: missing price fails closed ------------------------------------

def test_missing_price_suppresses_not_books_zero(runner, cp):
    """A pipeline billed almost entirely under a SKU with no list price still PROJECTS a
    candidate row (its priced sliver makes cost>0), but its coverage is far below the
    floor, so the rule must SUPPRESS it — a missing price is 'unknown', never a
    confident $0-cost booking."""
    from finops_rules.coverage import priced_fraction

    rows, findings = _run(runner, cp, invariant_missing_price())
    assert len(rows) >= 1, "the SQL should still project the under-priced candidate row"
    frac = priced_fraction(rows[0])
    assert frac is not None and frac < 0.80, f"expected sub-floor coverage, got {frac}"
    assert findings == [], "an under-priced resource must be suppressed, not booked"


# --- FIN-003: corrections applied -------------------------------------------

def test_corrections_yield_corrected_amount(runner, cp):
    """ORIGINAL + RETRACTION + RESTATEMENT in one hour must net to the corrected amount.
    dbus_30d (sum of usage_quantity over ALL record_types) must equal a clean pipeline's
    total, NOT the inflated ORIGINAL-only figure."""
    rows, _ = _run(runner, cp, invariant_correction_triple())
    assert len(rows) == 1
    corrected = INV_HOURLY_DBU * 24 * INV_BILLED_DAYS          # 504.0
    original_only = corrected + (10.0 - INV_HOURLY_DBU)        # 512.5 if ORIGINAL-only
    got = float(rows[0]["dbus_30d"])
    assert abs(got - corrected) < 1e-6, f"expected corrected {corrected}, got {got}"
    assert got < original_only - 1.0, "usage was summed as ORIGINAL-only (correction dropped)"


# --- FIN-006: deleted latest SCD row still selected correctly ---------------

def test_deleted_latest_scd_row_suppresses(runner, cp):
    """When the pipeline's newest version is its deletion (and an older version is still
    'live'), rank-then-filter selects the newest row, sees it deleted, and drops the
    pipeline. The broken shape would resurrect the older live version and keep firing."""
    rows, findings = _run(runner, cp, invariant_deleted_scd())
    assert rows == [], "a deleted pipeline must not survive the latest-SCD join"
    assert findings == []


# --- FIN-007: workspace-safe keys -------------------------------------------

def test_duplicate_id_two_workspaces_no_bleed(runner, cp):
    """The same pipeline_id in two workspaces, billed at different rates, must yield one
    finding per workspace, each carrying its OWN cost. A single-key join would merge the
    streams and corrupt both figures."""
    _, findings = _run(runner, cp, invariant_dup_workspace())
    by_ws = {str(f["workspace_id"]): f for f in findings}
    assert set(by_ws) == {WS, WS_B}, f"expected both workspaces, got {set(by_ws)}"
    assert len(findings) == 2, "no cross-workspace merge — exactly one finding per workspace"
    assert abs(by_ws[WS]["monthly_waste_usd"] - BASELINE_WASTE) < 1.0
    assert abs(by_ws[WS_B]["monthly_waste_usd"] - 2 * BASELINE_WASTE) < 1.0, (
        "ws_b bills 2x ws_a; a bled cost would not preserve that ratio"
    )


# --- FIN-002: closed-open window has exactly N dates ------------------------

def test_window_has_exactly_n_dates(runner, cp):
    """Usage on days {-(N+1) .. 0} (one too-old day, every in-window day, and partial
    today) must yield observed_days == N: the closed-open window [today-N, today) keeps
    exactly the N in-window dates and excludes both today and the (N+1)th day back."""
    rule, thresholds, _ = cp
    lookback = int(thresholds.get("lookback_days", 30))
    rows, _ = _run(runner, cp, invariant_window_dates(lookback))
    assert len(rows) == 1
    assert int(rows[0]["observed_days"]) == lookback, (
        f"window should span exactly {lookback} complete dates, got {rows[0]['observed_days']}"
    )


# --- FIN-012: warehouse auto-stop interval accounting -----------------------

def test_wh_interval_quantities_are_bounded(runner, wh):
    """The rebuilt rule prices reclaim from exact intervals. On a warehouse up 10h/day
    but busy only ~20min/day, every priced quantity must obey its bound:

    * merged busy <= running          (queries only run while the cluster is up)
    * counterfactual warm <= running  (a shorter auto-stop can't add warm time)
    * reclaimable = running - counterfactual, and > 0 (the idle head/tail is recovered)
    * booked savings <= corrected cost (fraction capped at 1), and the row is bookable.
    """
    rows, findings = _run(runner, wh, invariant_wh_gaps())
    assert len(rows) == 1, "the idle warehouse must project exactly one candidate row"
    r = rows[0]
    running = float(r["running_minutes"])
    busy = float(r["merged_busy_minutes"])
    cf = float(r["counterfactual_warm_minutes"])
    reclaim = float(r["reclaimable_minutes"])
    assert busy <= running, f"merged busy {busy} exceeds running {running}"
    assert cf <= running, f"counterfactual warm {cf} exceeds current running {running}"
    assert reclaim > 0, "an idle warm pool must leave reclaimable time"
    assert abs(reclaim - (running - cf)) < 1e-6, "reclaim must equal running - counterfactual"

    assert len(findings) == 1
    f = findings[0]
    assert f["monthly_savings_usd"] <= f["monthly_waste_usd"] + 1e-6, (
        "reclaimed dollars exceed the warehouse's corrected cost"
    )
    assert f["savings_status"] == "bookable", "interval-priced findings book into the headline"


def test_wh_concurrency_adds_no_duplicate_warm(runner, wh):
    """Two overlapping queries on one warm cluster (10:00-10:30 and 10:10-10:40) share
    the cluster; their warm time is the 40-min UNION, not the 60-min sum of durations.
    A merge that summed intervals would double-count concurrency and overstate busy
    time (and, downstream, understate the reclaimable idle)."""
    rows, _ = _run(runner, wh, invariant_wh_concurrency())
    assert len(rows) == 1
    merged = float(rows[0]["merged_busy_minutes"])
    union_min = 40.0 * INV_WH_DAYS       # |[10:00,10:40]| per day
    naive_sum = 60.0 * INV_WH_DAYS       # 30 + 30 per day if intervals were added
    assert abs(merged - union_min) < 1e-6, f"expected merged union {union_min}, got {merged}"
    assert merged < naive_sum - 1.0, "overlapping queries were summed, not merged (dup warm)"


# --- FIN-018: serving endpoint booking tiers --------------------------------

def test_serving_zero_traffic_books_full_cost(runner, serving):
    """A zero-request endpoint kept warm around the clock: the traffic is COUNTED (not
    inferred), so the whole always-on cost is reclaimable and the finding BOOKS. Asserts
    exactly one bookable finding whose savings equal — and never exceed — the cost."""
    rows, findings = _run(runner, serving, invariant_serving_zero_bookable())
    assert len(rows) == 1, "the always-billing endpoint must project one candidate row"
    assert len(findings) == 1
    f = findings[0]
    assert f["savings_status"] == "bookable", "measured zero-traffic tier books into the headline"
    assert f["monthly_savings_usd"] <= f["monthly_waste_usd"] + 1e-6, (
        "reclaimed dollars exceed the endpoint's corrected cost"
    )
    assert abs(f["monthly_savings_usd"] - f["monthly_waste_usd"]) < 1e-6, (
        "zero traffic reclaims the FULL always-on cost"
    )


def test_serving_low_traffic_stays_estimated(runner, serving):
    """A barely-used endpoint (a request or two a day) still kept always-warm: scale-to-
    zero reclaims only a conservative SHARE at a cold-start cost, so the tier stays
    ESTIMATED (books $0 in the headline) and credits strictly less than the full cost."""
    from finops.services.aggregation import account_overview

    rows, findings = _run(runner, serving, invariant_serving_low_estimated())
    assert len(findings) == 1
    f = findings[0]
    assert f["savings_status"] == "estimated", "the low-traffic tier is out of the booked headline"
    assert 0 < f["monthly_savings_usd"] < f["monthly_waste_usd"], (
        "low traffic credits only the reclaimable share, not the whole cost"
    )
    rec = _rec("estimated", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "estimated books zero"


def test_serving_missing_price_not_booked(runner, serving):
    """FIN-004 on the booking path: a zero-traffic endpoint whose serving spend is only
    ~half priced still FIRES (its priced cost clears the floor), but must DROP from
    bookable to ESTIMATED — a partial price is 'unknown', never booked as if it were the
    whole always-on cost."""
    rows, findings = _run(runner, serving, invariant_serving_missing_price_not_bookable())
    assert len(rows) == 1
    assert len(findings) == 1, "cost above the floor still fires the zero-traffic tier"
    f = findings[0]
    assert f["savings_status"] == "estimated", (
        "sub-floor price coverage must not book (FIN-004 fail-closed), even for zero traffic"
    )
    assert f["monthly_savings_usd"] <= f["monthly_waste_usd"] + 1e-6


# --- FIN §2.4: cluster auto-termination gap accounting ----------------------

def test_cluster_reclaims_only_gaps_over_the_timeout(runner, cluster):
    """The gap method reclaims contiguous idle beyond the timeout, NOT scattered idle
    between bursts. A day with a 90-min idle gap (> the 60-min timeout) and a 40-min one
    (<=) must credit only the long gap's excess: reclaimable_gross == 90-60 == 30, from a
    single reclaim gap, while the 40-min stretch is still MEASURED as idle but reclaims
    nothing. Guards against a regression to a flat idle-fraction that would over-book the
    short idle."""
    rows, _ = _run(runner, cluster, invariant_cluster_gap_threshold())
    assert len(rows) == 1, "the idle cluster must project exactly one candidate row"
    r = rows[0]
    excess = 90 - CL_MAX_ACCEPTABLE_MIN
    assert int(r["reclaimable_gross_min"]) == excess, (
        f"only the long gap's excess is reclaimable, expected {excess}, "
        f"got {r['reclaimable_gross_min']}"
    )
    assert int(r["num_reclaim_gaps"]) == 1, "only the >timeout gap counts as reclaimable"
    assert int(r["longest_idle_gap_min"]) == 90
    # The short 40-min stretch is idle but not reclaimed: total idle exceeds the
    # reclaimable excess, so scattered sub-timeout idle was measured, not banked.
    assert int(r["idle_minutes"]) == 130 > int(r["reclaimable_gross_min"])


def test_cluster_job_task_minutes_are_not_reclaimable_idle(runner, cluster):
    """Auto-termination keys on ACTIVITY, not raw CPU. A cluster CPU-idle for a
    contiguous 120-min window, with a job task running dead-centre for 60 min, must not
    treat those 60 minutes as idle: they split the window into two 30-min runs, so only
    60 minutes count as idle and NONE is reclaimable (neither run clears the 60-min
    timeout). Guards the activity caveat — a low-CPU minute during a running job task is
    never mistaken for reclaimable idle."""
    rows, findings = _run(runner, cluster, invariant_cluster_job_activity())
    assert len(rows) == 1
    r = rows[0]
    # 120 CPU-idle minutes, but the 60 job minutes are active => only 60 read as idle.
    assert int(r["idle_minutes"]) == 60, (
        "job-task minutes must be excluded from idle (120 CPU-idle - 60 job = 60)"
    )
    assert int(r["reclaimable_gross_min"]) == 0, (
        "the job splits the idle into two 30-min runs, neither over the 60-min timeout"
    )
    assert int(r["longest_idle_gap_min"]) == 30
    # With no reclaimable gap, the rule books nothing for this cluster.
    assert findings == [], "no gap over the timeout => no auto-termination finding"


# --- FIN-010: interactive_to_job rebuild ------------------------------------

def test_i2j_frac_is_size_invariant(runner, i2j):
    """THE unit bug (FIN-010). The same job (same wall-clock minutes) on a 1-node and a
    4-node all-purpose cluster must yield the SAME job_active_frac (== 1.0): running
    minutes are DISTINCT clock minutes, so the reassignable fraction is invariant to
    cluster size. A COUNT(*) node-minute denominator would make the 4-node cluster read
    ~0.25 and under-attribute its reassignable DBUs 4x — this test fails loudly if that
    division is ever reintroduced."""
    rows, _ = _run(runner, i2j, invariant_i2j_size_invariance())
    by_cid = {str(r["cluster_id"]): r for r in rows}
    assert {"clu-inv-1node", "clu-inv-4node"} <= set(by_cid), (
        f"both clusters must project a candidate row, got {set(by_cid)}"
    )
    one = float(by_cid["clu-inv-1node"]["job_active_frac"])
    four = float(by_cid["clu-inv-4node"]["job_active_frac"])
    assert abs(one - 1.0) < 1e-6, f"1-node frac should be 1.0, got {one}"
    assert abs(one - four) < 1e-6, (
        f"job_active_frac must be invariant to node count: 1-node {one} != 4-node {four} "
        f"(node-minute denominator reintroduced?)"
    )


def test_i2j_dedicated_books_the_measured_gap(runner, i2j):
    """A job-DEDICATED all-purpose cluster (jobs occupy its whole uptime): removing the
    jobs eliminates the cluster, so the measured price gap is realized and the finding
    BOOKS — savings_status bookable, low == point, and savings <= reassignable cost."""
    _, findings = _run(runner, i2j, invariant_i2j_dedicated_bookable())
    assert len(findings) == 1, "the dedicated cluster must fire exactly one finding"
    f = findings[0]
    assert f["savings_status"] == "bookable"
    lo = float(f["monthly_savings_low_usd"])
    pt = float(f["monthly_savings_usd"])
    hi = float(f["monthly_savings_high_usd"])
    assert lo == pt == hi, f"dedicated books low==point==high, got {lo}/{pt}/{hi}"
    assert pt <= float(f["monthly_waste_usd"]) + 1e-6, "savings exceed the reassignable cost"


def test_i2j_shared_stays_estimated_with_zero_floor(runner, i2j):
    """A SHARED/interactive all-purpose cluster (job uses only a quarter of the uptime):
    moving the job off may not shrink the still-interactive cluster, so the lower bound is
    $0 and the finding stays ESTIMATED (out of the booked headline). The attributed gap is
    the upper scenario only — 0 < point <= reassignable cost."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, i2j, invariant_i2j_shared_estimated())
    assert len(findings) == 1
    f = findings[0]
    assert f["savings_status"] == "estimated"
    assert float(f["monthly_savings_low_usd"]) == 0.0, "shared tier's lower bound is $0"
    assert 0 < float(f["monthly_savings_usd"]) <= float(f["monthly_waste_usd"]) + 1e-6
    rec = _rec("estimated", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "estimated books zero"


def test_i2j_duplicate_id_two_workspaces_no_bleed(runner, i2j):
    """FIN-007: the same cluster_id, job-dedicated in two workspaces billed at 40 vs 80
    DBU/day, must yield one finding per workspace, each carrying its OWN cost. A
    single-key join would merge the streams and corrupt both figures (ws_b bills 2x)."""
    _, findings = _run(runner, i2j, invariant_i2j_dup_workspace())
    by_ws = {str(f["workspace_id"]): f for f in findings}
    assert set(by_ws) == {WS, WS_B}, f"expected both workspaces, got {set(by_ws)}"
    assert len(findings) == 2, "no cross-workspace merge — one finding per workspace"
    assert float(by_ws[WS_B]["monthly_waste_usd"]) > float(by_ws[WS]["monthly_waste_usd"]) + 1.0, (
        "ws_b bills 2x ws_a; a bled cost would not preserve that ordering"
    )


# --- FIN-017 idle_zombie_clusters forward-spend invariants -------------------

def test_iz_running_cluster_stays_estimated_with_zero_floor(runner, zombie):
    """A cluster STILL running idle in the recency window: the idle spend is a forward
    saving, but CPU idle is only a proxy, so the finding is ESTIMATED with a $0 lower
    bound (never booked). 0 < point <= reclaimable cost; the aggregation books zero."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, zombie, invariant_iz_running_estimated())
    assert len(findings) == 1, "the running idle cluster must fire exactly one finding"
    f = findings[0]
    assert f["savings_status"] == "estimated"
    assert float(f["monthly_savings_low_usd"]) == 0.0, "estimated tier's lower bound is $0"
    assert 0 < float(f["monthly_savings_usd"]) <= float(f["monthly_waste_usd"]) + 1e-6
    rec = _rec("estimated", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "estimated books zero"


def test_iz_stopped_cluster_books_zero_forward(runner, zombie):
    """THE FIN-017 guard: a cluster that ran idle only 20-27 days ago has STOPPED, so
    terminating it reclaims NOTHING forward — savings_status advisory, point $0, and
    the aggregation books zero. The OLD whole-lookback annualization would have sold
    this as ongoing monthly savings; the high bound preserves the historical waste as
    max-addressable context (> 0), so the row is still surfaced as hygiene."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, zombie, invariant_iz_stopped_books_zero())
    assert len(findings) == 1, "the stopped cluster still surfaces (as hygiene)"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_usd"]) == 0.0, "stopped => $0 forward, no annualization"
    assert float(f["monthly_savings_low_usd"]) == 0.0
    assert float(f["monthly_savings_high_usd"]) > 0.0, (
        "historical idle waste is preserved as the max-addressable upper bound"
    )
    rec = _rec("advisory", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "advisory books zero"


def test_iz_duplicate_id_two_workspaces_no_bleed(runner, zombie):
    """FIN-007: the same cluster_id, idle-and-running in two workspaces billed at 30 vs
    60 DBU/day, must yield one finding per workspace, each with its OWN forward cost. A
    single-key join would merge the streams and corrupt both figures (ws_b bills 2x)."""
    _, findings = _run(runner, zombie, invariant_iz_dup_workspace())
    by_ws = {str(f["workspace_id"]): f for f in findings}
    assert set(by_ws) == {WS, WS_B}, f"expected both workspaces, got {set(by_ws)}"
    assert len(findings) == 2, "no cross-workspace merge — one finding per workspace"
    assert float(by_ws[WS_B]["monthly_waste_usd"]) > float(by_ws[WS]["monthly_waste_usd"]) + 1.0, (
        "ws_b bills 2x ws_a; a bled cost would not preserve that ordering"
    )


# --- FIN-020 failing_jobs repair/retire invariants ---------------------------

def test_fj_repair_candidate_is_estimated(runner, failing):
    """A chronically-failing job WITH comparable successful runs prices the fixed state,
    so the credit is a real REPAIR estimate — estimated, low 0, 0 < point <= failed
    spend; the aggregation books zero."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, failing, invariant_fj_repair_estimated())
    assert len(findings) == 1, "the repair candidate must fire exactly one finding"
    f = findings[0]
    assert f["savings_status"] == "estimated"
    assert float(f["monthly_savings_low_usd"]) == 0.0
    assert 0 < float(f["monthly_savings_usd"]) <= float(f["monthly_waste_usd"]) + 1e-6
    rec = _rec("estimated", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "estimated books zero"


def test_fj_retire_candidate_books_zero(runner, failing):
    """THE FIN-020 obsolescence gate: a job that NEVER succeeded is a RETIRE candidate —
    no successful run to price a repair, and retirement needs an owner decision. It
    books $0 (advisory); the excess-failure spend is the max-addressable upper bound
    (> 0), so the opportunity is surfaced without being counted as savings."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, failing, invariant_fj_retire_books_zero())
    assert len(findings) == 1, "the retire candidate still surfaces (as advisory)"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_low_usd"]) == 0.0
    assert float(f["monthly_savings_high_usd"]) > 0.0, "failed spend shown as max-addressable"
    rec = _rec("advisory", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "advisory books zero"


# --- FIN-015 unused_data_jobs sentinel + no-haircut invariants ----------------

def test_udj_addressable_is_full_cost_and_books_zero(runner, unused_jobs):
    """FIN-015: no recoverable-fraction haircut — the FULL producing cost is the
    max-addressable upper bound, and advisory books $0. point == high == cost, low 0."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, unused_jobs, invariant_udj_addressable_advisory())
    assert len(findings) == 1, "the unread producer with schema read-coverage fires"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_low_usd"]) == 0.0
    assert abs(float(f["monthly_savings_high_usd"]) - float(f["monthly_savings_usd"])) < 1e-6
    assert abs(float(f["monthly_savings_usd"]) - float(f["monthly_waste_usd"])) < 1e-6, (
        "the full producing cost is shown as addressable — no haircut"
    )
    rec = _rec("advisory", f["monthly_savings_low_usd"], f["monthly_savings_usd"],
               f["monthly_savings_high_usd"], waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0, "advisory books zero"


def test_udj_no_read_coverage_is_suppressed(runner, unused_jobs):
    """THE FIN-015 sentinel: an unread producer whose output schema has NO captured
    reads is 'no coverage', not 'dead data' — the rule makes no claim (no finding)."""
    _, findings = _run(runner, unused_jobs, invariant_udj_no_coverage_suppressed())
    assert findings == [], "no schema read-coverage => no claim (suppressed)"


# --- FIN-009 spot_fallback advisory-$0 invariant ------------------------------

def test_spot_toggle_unchanged_dbu_books_zero(runner, spot):
    """THE FIN-009 invariant: an on-demand cluster is surfaced, but a spot toggle leaves
    the metered DBUs unchanged, so the Databricks-measured saving is $0 (advisory).
    Spot reduces the cloud VM bill this app cannot see — never DBUs."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, spot, invariant_spot_books_zero())
    assert len(findings) == 1, "the on-demand cluster is surfaced as an opportunity"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_usd"]) == 0.0
    assert float(f["monthly_savings_low_usd"]) == 0.0
    assert float(f["monthly_savings_high_usd"]) == 0.0
    rec = _rec("advisory", 0.0, 0.0, 0.0, waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


# --- FIN-021 enable_photon_dbr advisory-$0 invariant --------------------------

def test_photon_uplift_is_upper_bound_books_zero(runner, photon):
    """THE FIN-021 invariant: an old-runtime cluster is surfaced, but the price/perf
    uplift is an unmeasured heuristic, so it books $0 (advisory) — the class fraction is
    only the max-addressable upper bound (high > 0). A real figure needs matched runs."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, photon, invariant_photon_books_zero())
    assert len(findings) == 1, "the old-runtime cluster is surfaced as an opportunity"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_usd"]) == 0.0
    assert float(f["monthly_savings_low_usd"]) == 0.0
    # The heuristic uplift is surfaced as the ceiling, never as a booked saving.
    assert float(f["monthly_savings_high_usd"]) > 0.0
    rec = _rec("advisory", 0.0, 0.0, float(f["monthly_savings_high_usd"]),
               waste=f["monthly_waste_usd"], rid=str(f["resource_id"]),
               ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


# --- FIN-014 serverless_cost_optimized advisory-$0 invariant ------------------

def test_sco_modeled_reduction_is_upper_bound_books_zero(runner, sco):
    """THE FIN-014 invariant: a long serverless PERFORMANCE_OPTIMIZED job is surfaced,
    but the ~50% DBU reduction is modeled (same $/DBU, no matched before/after run), so
    it books $0 (advisory) — the modeled figure is only the max-addressable upper bound
    (high > 0). A real figure needs an after-switch re-measurement."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, sco, invariant_sco_books_zero())
    assert len(findings) == 1, "the long serverless job is surfaced as an opportunity"
    f = findings[0]
    assert f["savings_status"] == "advisory"
    assert float(f["monthly_savings_usd"]) == 0.0
    assert float(f["monthly_savings_low_usd"]) == 0.0
    # The modeled reduction is surfaced as the ceiling, never as a booked saving.
    assert float(f["monthly_savings_high_usd"]) > 0.0
    rec = _rec("advisory", 0.0, 0.0, float(f["monthly_savings_high_usd"]),
               waste=f["monthly_waste_usd"], rid=str(f["resource_id"]),
               ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0


# --- FIN-013 enable_serverless estimated-with-measurable-floor invariant ------

def test_enable_serverless_estimated_books_zero_low_le_point_le_high(runner, enserv):
    """THE FIN-013 invariant: a warm-but-idle classic/pro warehouse is surfaced as
    ESTIMATED and books $0 (the headline credits an ESTIMATED cloud VM cost), but the band
    is well-formed: the measurable DBU-only floor (low) <= point <= the VM-included
    ceiling (high). low is what billing rates can prove; high adds the VM estimate."""
    from finops.services.aggregation import account_overview

    _, findings = _run(runner, enserv, invariant_es_estimated_books_zero())
    assert len(findings) == 1, "the warm-but-idle warehouse is surfaced"
    f = findings[0]
    assert f["savings_status"] == "estimated"
    low = float(f["monthly_savings_low_usd"])
    point = float(f["monthly_savings_usd"])
    high = float(f["monthly_savings_high_usd"])
    assert 0.0 <= low <= point <= high
    assert high > 0.0
    # Estimated books $0 in the headline (only bookable lows are booked).
    rec = _rec("estimated", low, point, high, waste=f["monthly_waste_usd"],
               rid=str(f["resource_id"]), ws=str(f["workspace_id"]))
    assert account_overview([rec]).total_monthly_savings_usd == 0.0
