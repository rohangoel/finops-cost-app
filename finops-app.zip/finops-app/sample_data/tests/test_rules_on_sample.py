"""Golden regression: run each rule's REAL SQL + scoring on the sample, compare.

For every ``sample_data/expected/<rule>.json`` this runs the rule end-to-end through
the harness (fixtures -> temp views -> rendered rule SQL -> scoring) and asserts the
findings match the committed golden. Change a rule's SQL or scoring and this tells you
exactly which findings moved, on data grounded in the real system tables.

Backend (plan V0): the default is the **hermetic local-Spark** engine, so this suite
runs on every PR with no warehouse and no secrets — the per-PR gate. It SKIPS (never
fails) when that engine cannot start (no JVM / no ``pyspark`` on this box); CI has both,
so CI gates. To run against a warehouse instead (the fidelity backstop), set::

    FINOPS_SAMPLE_BACKEND=warehouse \
    FINOPS_SAMPLE_PROFILE=fevm-finops-stable-us \
    FINOPS_SAMPLE_WAREHOUSE=28ee85f85d49811e \
    pytest sample_data/tests/test_rules_on_sample.py

To (re)generate the golden files after an INTENTIONAL change (and eyeball the diff):
    UPDATE_EXPECTED=1 pytest sample_data/tests/test_rules_on_sample.py
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]          # sample_data/
sys.path.insert(0, str(ROOT / "harness"))

EXPECTED_DIR = ROOT / "expected"
BACKEND = os.getenv("FINOPS_SAMPLE_BACKEND", "spark")
PROFILE = os.getenv("FINOPS_SAMPLE_PROFILE")
WAREHOUSE = os.getenv("FINOPS_SAMPLE_WAREHOUSE")
# warehouse backend only: materialize fixtures as tables here (<catalog>.<schema>)
SCHEMA = os.getenv("FINOPS_SAMPLE_SCHEMA")
UPDATE = os.getenv("UPDATE_EXPECTED") == "1"
SAVINGS_TOL = 0.5                                    # $ tolerance on float savings

# Fields compared per finding — the stable, meaningful ones (ids, classification,
# money). computed_at / recommendation_id / evidence text are excluded as volatile.
_KEEP = ["resource_type", "resource_id", "resource_name", "category", "rule_title",
         "priority", "effort_band", "workspace_id", "savings_status"]


def _normalize(findings: list[dict]) -> list[dict]:
    out = []
    for f in findings:
        row = {k: f.get(k) for k in _KEEP}
        row["monthly_savings_usd"] = round(float(f["monthly_savings_usd"]), 2)
        row["monthly_waste_usd"] = round(float(f["monthly_waste_usd"]), 2)
        out.append(row)
    return sorted(out, key=lambda r: (r["resource_type"], r["resource_id"]))


@pytest.fixture(scope="module")
def runner():
    from backends import BackendUnavailable
    from runner import SampleRunner

    try:
        r = SampleRunner.for_backend(BACKEND, profile=PROFILE, warehouse=WAREHOUSE,
                                     schema=SCHEMA)
    except BackendUnavailable as exc:
        pytest.skip(f"sample backend {BACKEND!r} unavailable: {exc}")
    r.load_fixtures()
    yield r
    r.close()


@pytest.fixture(scope="module")
def all_rules():
    # list_rules(), not get_enabled_rules(): a rule may be intentionally DISABLED from
    # the product (idle_apps, Phase 0.3) yet still authored and worth regressing — its
    # SQL + scoring must not silently rot. The golden documents that behaviour.
    from finops_rules import list_rules, load_effort, load_thresholds

    return {r.id: r for r in list_rules()}, load_thresholds(), load_effort()


def _expected_files():
    return sorted(EXPECTED_DIR.glob("*.json"))


@pytest.mark.parametrize("expected_path", _expected_files(), ids=lambda p: p.stem)
def test_rule_matches_golden(expected_path, runner, all_rules):
    rules, thresholds, effort = all_rules
    expected = json.loads(expected_path.read_text())
    rule_id = expected["rule_id"]
    rule = rules.get(rule_id)
    assert rule is not None, f"{rule_id} is not a known rule"

    # Fetch the candidate rows ONCE and score those same rows, rather than calling
    # findings() (which re-runs candidate_rows() internally) — that ran each rule's
    # heavy SQL twice per golden, doubling the load on the one long-lived SparkContext
    # the whole suite shares and pushing the driver JVM to OOM/crash mid-run. score()
    # exists precisely for this (see runner.py); the findings are byte-identical.
    candidate_rows = runner.candidate_rows(rule, thresholds)
    findings = _normalize(runner.score(rule, candidate_rows, thresholds, effort))

    if UPDATE:
        expected_path.write_text(json.dumps({
            "rule_id": rule_id,
            "note": expected.get("note", ""),
            "candidate_row_count": len(candidate_rows),
            "findings": findings,
        }, indent=2) + "\n")
        pytest.skip(f"updated golden for {rule_id}")

    assert len(candidate_rows) == expected["candidate_row_count"], (
        f"{rule_id}: candidate-row count changed "
        f"({len(candidate_rows)} vs {expected['candidate_row_count']})"
    )
    exp = expected["findings"]
    assert len(findings) == len(exp), (
        f"{rule_id}: {len(findings)} findings, expected {len(exp)}"
    )
    for got, want in zip(findings, exp, strict=True):
        for k in _KEEP:
            # savings_status was added to the golden after Phase 0; tolerate an older
            # golden that predates it rather than forcing a regen for an additive field.
            if k == "savings_status" and k not in want:
                continue
            assert got[k] == want[k], (
                f"{rule_id} {got['resource_id']}: {k} {got[k]!r} != {want[k]!r}"
            )
        assert abs(got["monthly_savings_usd"] - want["monthly_savings_usd"]) <= SAVINGS_TOL, (
            f"{rule_id} {got['resource_id']}: savings {got['monthly_savings_usd']} "
            f"!= {want['monthly_savings_usd']} (+-{SAVINGS_TOL})"
        )
