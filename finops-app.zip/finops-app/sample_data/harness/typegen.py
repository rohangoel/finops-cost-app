"""Turn a JSON fixture value + a Spark type string into an exact Spark SQL literal.

This is what lets a small, readable JSONL fixture become a typed temp view whose
schema is BYTE-IDENTICAL to the real system table (types captured by the profiler).
Because the view carries the full real schema — every column, every nested struct
field — the *unmodified* rule SQL can reference any column it likes; columns a
fixture doesn't mention are emitted as correctly-typed NULLs.

Two capabilities matter:

  * **Nested types.** ``struct<usage_metadata:struct<app_id:string,...>>`` and
    ``pricing.effective_list.default`` must round-trip, so we parse the Spark type
    string and build ``named_struct(...)`` / ``array(...)`` / ``map(...)`` recursively.
  * **Relative time.** Rules filter on ``date_sub(current_date(), lookback)``, so a
    fixture with an absolute date would drift in/out of the window depending on the
    run date. A temporal value may instead be ``{"@rel": -3}`` (3 days ago) or
    ``{"@rel": -3, "@time": "04:00:00"}``, rendered against ``current_date()`` so the
    fixture means the same thing every day.

No workspace or JVM needed to import this — it only produces SQL strings.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


# --- Spark type-string parser ------------------------------------------------
# A tiny recursive-descent parser for the type grammar DESCRIBE emits:
#   primitive | decimal(p,s) | struct<name:type,...> | array<type> | map<type,type>

@dataclass
class _T:
    kind: str                       # 'prim' | 'struct' | 'array' | 'map'
    raw: str                        # the original type text (for CAST(NULL AS ...))
    fields: list[tuple[str, "_T"]] | None = None   # struct
    element: "_T | None" = None                    # array
    key: "_T | None" = None                        # map
    value: "_T | None" = None                      # map


def parse_type(s: str) -> _T:
    s = s.strip()
    low = s.lower()
    if low.startswith("struct<"):
        return _parse_struct(s)
    if low.startswith("array<"):
        inner = _inside(s)
        return _T("array", s, element=parse_type(inner))
    if low.startswith("map<"):
        inner = _inside(s)
        k, v = _split_top(inner)
        return _T("map", s, key=parse_type(k), value=parse_type(v))
    return _T("prim", s)


def _inside(s: str) -> str:
    """Text between the first '<' and its matching '>'."""
    start = s.index("<")
    depth = 0
    for i in range(start, len(s)):
        if s[i] == "<":
            depth += 1
        elif s[i] == ">":
            depth -= 1
            if depth == 0:
                return s[start + 1:i]
    raise ValueError(f"unbalanced <> in type: {s!r}")


def _split_top(s: str) -> list[str]:
    """Split on top-level commas (ignoring commas nested inside <> or ())."""
    parts, depth, cur = [], 0, []
    for ch in s:
        if ch in "<(":
            depth += 1
        elif ch in ">)":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    if cur:
        parts.append("".join(cur))
    return parts


def _parse_struct(s: str) -> _T:
    fields = []
    for field in _split_top(_inside(s)):
        field = field.strip()
        if not field:
            continue
        # "name:type" — name has no ':' (Spark quotes odd names, but system tables don't)
        name, _, typ = field.partition(":")
        fields.append((name.strip(), parse_type(typ.strip())))
    return _T("struct", s, fields=fields)


# --- value -> SQL literal ----------------------------------------------------

_PRIM_NEEDING_CAST = {"double", "float", "bigint", "int", "smallint", "tinyint",
                      "boolean", "binary"}


def _is_rel(v) -> bool:
    return isinstance(v, dict) and "@rel" in v


def _rel_literal(v: dict, target_low: str) -> str:
    """Render a relative-time value against current_date().

    ``{"@rel": -3}``               -> date_sub(current_date(), 3)          (DATE)
    ``{"@rel": -3, "@time": "HH:MM:SS"}`` -> that day at that clock time    (TIMESTAMP)
    """
    days = int(v["@rel"])
    day_expr = f"date_sub(current_date(), {-days})" if days <= 0 else f"date_add(current_date(), {days})"
    if target_low.startswith("date") and "@time" not in v:
        return day_expr
    tod = v.get("@time", "00:00:00")
    return f"to_timestamp(concat(CAST({day_expr} AS STRING), ' {tod}'))"


def _quote(s: str) -> str:
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"


def literal(value, t: _T) -> str:
    """A Spark SQL expression for ``value`` at type ``t`` (typed NULL when None)."""
    if value is None:
        return f"CAST(NULL AS {t.raw})"

    if t.kind == "struct":
        if not isinstance(value, dict):
            raise ValueError(f"struct value must be an object, got {type(value)}")
        args = []
        for name, ft in t.fields or []:
            args.append(_quote(name))
            args.append(literal(value.get(name), ft))
        return f"named_struct({', '.join(args)})" if args else "named_struct()"

    if t.kind == "array":
        if not isinstance(value, list):
            raise ValueError("array value must be a list")
        if not value:
            return f"CAST(array() AS {t.raw})"
        return "array(" + ", ".join(literal(x, t.element) for x in value) + ")"

    if t.kind == "map":
        if not isinstance(value, dict):
            raise ValueError("map value must be an object")
        if not value:
            return f"CAST(map() AS {t.raw})"
        kv = []
        for k, v in value.items():
            kv.append(literal(k, t.key))
            kv.append(literal(v, t.value))
        return "map(" + ", ".join(kv) + ")"

    # primitive
    low = t.raw.lower()
    if _is_rel(value):
        return _rel_literal(value, low)
    if low in ("date", "timestamp", "timestamp_ntz"):
        # absolute ISO string
        fn = "to_date" if low == "date" else "to_timestamp"
        return f"{fn}({_quote(value)})"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        # decimals arrive as strings to preserve precision
        if low.startswith("decimal"):
            return f"CAST({_quote(value)} AS {t.raw})"
        return _quote(value)
    if isinstance(value, (int, float)):
        if low.startswith("decimal") or low in _PRIM_NEEDING_CAST:
            return f"CAST({value} AS {t.raw})"
        return str(value)
    # fallback: quote it
    return _quote(json.dumps(value))


# --- assemble a temp-view SELECT --------------------------------------------

def view_select(columns: list[dict], rows: list[dict]) -> str:
    """Build the SELECT body of a temp view.

    ``columns`` is the profiled schema for the table ([{name,type}, ...]); ``rows``
    are fixture dicts specifying only the columns that matter (the rest -> typed
    NULL). An empty ``rows`` yields a zero-row view with the correct schema.
    """
    parsed = [(c["name"], parse_type(c["type"])) for c in columns
              if "name" in c and "type" in c]
    if not parsed:
        raise ValueError("no usable columns in schema")

    def _row_select(row: dict) -> str:
        cells = [f"{literal(row.get(name), t)} AS {name}" for name, t in parsed]
        return "SELECT " + ", ".join(cells)

    if not rows:
        # Correct schema, zero rows.
        cells = [f"{literal(None, t)} AS {name}" for name, t in parsed]
        return "SELECT " + ", ".join(cells) + " WHERE 1=0"

    return "\nUNION ALL\n".join(_row_select(r) for r in rows)


def values_tuples(columns: list[dict], rows: list[dict]) -> list[str]:
    """One ``(lit, lit, ...)`` tuple per row, in schema column order — for a batched
    ``INSERT INTO t VALUES ...``. A multi-row VALUES analyses far faster on a
    warehouse than the one-SELECT-per-row UNION ALL :func:`view_select` builds."""
    parsed = [(c["name"], parse_type(c["type"])) for c in columns
              if "name" in c and "type" in c]
    return ["(" + ", ".join(literal(row.get(name), t) for name, t in parsed) + ")"
            for row in rows]
