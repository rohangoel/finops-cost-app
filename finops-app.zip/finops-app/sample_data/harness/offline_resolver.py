"""A TableResolver that points rule SQL at local fixture temp views.

Rule templates reference a system table as ``{{ tbl('schema','table') }}``. In
production the nested resolver renders that to ``system.schema.table``; centrally it
rewrites to scope-filtered Central Logfood views. This third resolver renders it to
a single-identifier temp view name (``fx_schema_table``) that the runner has loaded
the fixtures into — so the EXACT, unmodified rule SQL runs against the sample.

It duck-types the resolver interface ``contract.render_sql`` calls: it is callable
``(schema, table) -> str`` and exposes ``render_context()`` returning ``tbl`` and the
``central`` flag (False here — the price macro then omits the account_id join key,
matching a single-account deployment, which is what the fixtures model).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class OfflineResolver:
    prefix: str = "fx_"
    central: bool = False

    def __call__(self, schema: str, table: str) -> str:
        return f"{self.prefix}{schema}_{table}"

    def view_name(self, schema: str, table: str) -> str:
        return self(schema, table)

    def render_context(self) -> dict:
        return {"tbl": self, "central": self.central}
