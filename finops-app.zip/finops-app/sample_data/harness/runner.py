"""Run the REAL rule SQL + scoring against the local sample.

This is the offline-verification engine. It mirrors the production precompute loop
(``precompute/job.py``: render the rule's SQL -> execute -> ``records_for_rule``) with
exactly two substitutions:

  1. an :class:`OfflineResolver` points ``tbl('schema','table')`` at fixture temp views
     instead of ``system.schema.table``; and
  2. the query runs on a pluggable :mod:`backends` engine instead of the workspace's
     ``spark.sql`` — either a **hermetic local Spark** session (``--backend spark``, the
     default and the per-PR CI gate) or a **SQL warehouse** (``--backend warehouse``, the
     fidelity backstop). See ``sample_data/README.md`` and the plan's V0 track.

Everything else — the rendered SQL string, the thresholds (loaded from the real
``config/thresholds.yaml``), the scoring transform — is the production code path, so a
finding produced here is the finding production would produce on the same inputs.

The fixtures are loaded as TEMP VIEWS on a single session; any in-scope table without a
fixture file becomes a correctly-typed zero-row view, so the SQL always resolves.
Nothing is written to a workspace and no scratch schema is used.

CLI:
    python sample_data/harness/runner.py --rule continuous_pipeline --show-rows
    python sample_data/harness/runner.py --all                       # every fixtured rule
    python sample_data/harness/runner.py --all --backend warehouse \
        --profile fevm-finops-stable-us --warehouse 28ee85f85d49811e
"""

from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timezone
from pathlib import Path

from backends import Backend, BackendUnavailable, make_backend
from offline_resolver import OfflineResolver
from typegen import values_tuples, view_select

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent                       # sample_data/
FIXTURES = ROOT / "fixtures"
SCHEMA_SNAPSHOT = ROOT / "profile" / "schema_snapshot.json"

SNAPSHOT_DATE = date(2026, 9, 1)         # fixed so records are deterministic


def _load_schema() -> dict[str, list[dict]]:
    data = json.loads(SCHEMA_SNAPSHOT.read_text())
    return data["tables"]


def _fixture_files() -> dict[str, Path]:
    """schema.table -> fixture path. Filename ``<schema>_<rest>.jsonl`` (schema names
    have no underscores; the table part may)."""
    out = {}
    for p in sorted(FIXTURES.glob("*.jsonl")):
        schema, _, table = p.stem.partition("_")
        out[f"{schema}.{table}"] = p
    return out


def _read_jsonl(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("//"):   # allow // comment lines
            continue
        rows.append(json.loads(line))
    return rows


class SampleRunner:
    """Loads fixtures into a backend and runs rules through the production transform.

    The backend is injected, so the same runner drives the hermetic local-Spark gate
    and the warehouse backstop identically. Construct via :meth:`for_backend` (which
    also raises :class:`BackendUnavailable` when the chosen engine cannot start), then
    call :meth:`load_fixtures` once and :meth:`candidate_rows` / :meth:`findings` per
    rule."""

    def __init__(self, backend: Backend):
        self.backend = backend
        self.schema = _load_schema()
        self.resolver = OfflineResolver(prefix=f"{backend.table_prefix}fx_")

    @classmethod
    def for_backend(
        cls, kind: str = "spark", *, profile: str | None = None, warehouse: str | None = None,
        schema: str | None = None,
    ) -> SampleRunner:
        return cls(make_backend(kind, profile=profile, warehouse=warehouse, schema=schema))

    # -- fixtures --------------------------------------------------------------
    def load_fixtures(self, extra: dict[str, list[dict]] | None = None) -> dict[str, int]:
        """Create a typed temp view per in-scope table. Fixtured tables get their rows;
        the rest become zero-row views so any rule's SQL still resolves.

        ``extra`` overrides/augments the committed JSONL for a table (short name ->
        rows), used by the value-invariant suite to load a purpose-built scenario
        without touching the shared fixtures on disk. An ``extra`` entry REPLACES the
        table's committed rows (invariant scenarios are self-contained)."""
        extra = extra or {}
        files = _fixture_files()
        counts: dict[str, int] = {}
        for short, columns in self.schema.items():
            if not columns or "__error__" in columns[0]:
                continue
            sch, _, tbl = short.partition(".")
            if short in extra:
                rows = extra[short]
            else:
                rows = _read_jsonl(files[short]) if short in files else []
            view = self.resolver.view_name(sch, tbl)
            if self.backend.table_prefix:  # materialize: real tables, batched inserts
                self.backend.load_table(view, view_select(columns, []),
                                        values_tuples(columns, rows))
            else:
                self.backend.create_view(view, view_select(columns, rows))
            counts[short] = len(rows)
        return counts

    # -- run one rule ----------------------------------------------------------
    def _context(self, rule, thresholds: dict):
        from finops_rules import RuleContext

        return RuleContext(
            thresholds=thresholds.get(rule.id, {}),
            lookback_days=int(thresholds.get("lookback_days", 30)),
            catalog=thresholds.get("catalog", "system"),
            currency=thresholds.get("currency", "USD"),
            resolver=self.resolver,
        )

    def candidate_rows(self, rule, thresholds: dict) -> list[dict]:
        """The rows the rule's SQL projects — the input to score(). Native-typed by the
        backend (see :mod:`backends`), so scoring behaves exactly as in production."""
        ctx = self._context(rule, thresholds)
        return self.backend.query(rule.render_sql(ctx))

    def score(self, rule, rows: list[dict], thresholds: dict, effort: dict) -> list[dict]:
        """Score ALREADY-FETCHED candidate rows into recommendation records — the same
        transform precompute runs. Split out from :meth:`findings` so a caller that
        already holds the rows (e.g. the invariant suite, which inspects both the rows
        and the findings) does not re-execute the heavy rule SQL a second time."""
        from finops.services.precompute_transform import records_for_rule, stamp_computed_at

        recs = records_for_rule(
            rule, rows,
            thresholds=thresholds,
            lookback_days=int(thresholds.get("lookback_days", 30)),
            catalog=thresholds.get("catalog", "system"),
            snapshot=SNAPSHOT_DATE,
            effort_overrides=effort,
            ws_map={}, owner_map={},
            currency=thresholds.get("currency", "USD"),
        )
        return stamp_computed_at(recs, datetime.now(timezone.utc))

    def findings(self, rule, thresholds: dict, effort: dict) -> list[dict]:
        """Full recommendation records — identical to what precompute writes."""
        rows = self.candidate_rows(rule, thresholds)
        return self.score(rule, rows, thresholds, effort)

    def close(self):
        self.backend.close()


def run(rule_ids: list[str] | None, backend_kind: str, profile: str, warehouse: str,
        show_rows: bool, schema: str | None = None):
    from finops_rules import get_enabled_rules, load_effort, load_thresholds

    thresholds = load_thresholds()
    effort = load_effort()
    enabled = {r.id: r for r in get_enabled_rules(thresholds)}

    runner = SampleRunner.for_backend(backend_kind, profile=profile, warehouse=warehouse,
                                      schema=schema)
    try:
        counts = runner.load_fixtures()
        loaded = {k: v for k, v in counts.items() if v}
        print(f"[runner] backend={backend_kind} loaded fixtures: {loaded}\n")

        targets = rule_ids or sorted(_rules_with_fixtures(enabled, counts))
        for rid in targets:
            rule = enabled.get(rid)
            if rule is None:
                print(f"[runner] {rid}: not enabled / unknown — skipped")
                continue
            findings = runner.findings(rule, thresholds, effort)
            print(f"=== {rid} === {len(findings)} finding(s)")
            if show_rows:
                rows = runner.candidate_rows(rule, thresholds)
                print(f"  candidate rows: {len(rows)}")
            for f in findings:
                print(f"  - {f['resource_type']} {f['resource_id']}: "
                      f"${f['monthly_savings_usd']:.0f}/mo saved, {f['priority']}, "
                      f"{f['rule_title']}")
    finally:
        runner.close()


def _rules_with_fixtures(enabled: dict, counts: dict) -> set[str]:
    """Rules whose SQL touches at least one fixtured (non-empty) table."""
    from finops_rules import RuleContext
    from finops_rules.sources import qualified_tables

    fixtured = {k for k, v in counts.items() if v}
    out = set()
    res = OfflineResolver()
    for rid, rule in enabled.items():
        ctx = RuleContext(thresholds={}, resolver=res)
        try:
            sql = rule.render_sql(ctx)
        except Exception:
            continue
        # OfflineResolver renders fx_<schema>_<table>; map back to schema.table.
        refs = {t for t in qualified_tables(sql)}
        for r in refs:
            leaf = r.split(".")[-1]           # fx_billing_usage
            if leaf.startswith("fx_"):
                st = leaf[3:].replace("_", ".", 1)
                if st in fixtured:
                    out.add(rid)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--backend", choices=["spark", "warehouse"], default="spark",
                    help="execution engine: hermetic local Spark (default) or a SQL warehouse")
    ap.add_argument("--profile", help="Databricks CLI profile (warehouse backend only)")
    ap.add_argument("--warehouse", help="SQL warehouse id (warehouse backend only)")
    ap.add_argument("--schema", help="warehouse backend: materialize fixtures as tables in "
                    "this <catalog>.<schema> instead of temp views (much faster)")
    ap.add_argument("--rule", action="append", help="rule id (repeatable)")
    ap.add_argument("--all", action="store_true", help="every fixtured rule")
    ap.add_argument("--show-rows", action="store_true", help="also print candidate-row counts")
    args = ap.parse_args()
    rule_ids = None if args.all else args.rule
    try:
        run(rule_ids, args.backend, args.profile, args.warehouse, args.show_rows, args.schema)
    except BackendUnavailable as exc:
        raise SystemExit(f"[runner] backend unavailable: {exc}") from exc


if __name__ == "__main__":
    main()
