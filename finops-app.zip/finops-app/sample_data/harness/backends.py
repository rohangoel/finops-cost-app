"""Execution backends for the sample-data harness.

Two engines run the SAME rendered rule SQL against the SAME typed fixture views:

* :class:`SparkBackend` — a local PySpark session (``local[1]``): no warehouse, no
  secrets, no network. This is the **hermetic per-PR gate** the plan's V0 track calls
  for (``docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md``): fixtures become local-Spark temp
  views and the unmodified rule SQL runs on open-source Spark, so the golden + invariant
  suites gate every PR (fork PRs included) with nothing but a JVM + ``pyspark``. When
  either is missing it raises :class:`BackendUnavailable`, so the pytest suite SKIPS
  cleanly on a dev box that lacks them (CI has both) rather than failing.

* :class:`WarehouseBackend` — ``databricks-sql-connector`` against a real SQL warehouse.
  The deferred **nightly fidelity backstop**: it is the same engine (DBSQL / Photon) the
  precompute pipeline and the app's live fallback use, so it catches the
  open-source-Spark-vs-DBSQL edge cases (decimal precision, some struct/date functions)
  the hermetic gate cannot see. Not required to run a PR.

Both expose the tiny interface the runner needs, and nothing else::

    create_view(name, select_sql)   # define one typed fixture temp view
    query(sql) -> list[dict]        # run rule SQL, return native-typed row dicts
    close()

Row fidelity: :class:`SparkBackend.query` returns ``row.asDict(recursive=True)`` — nested
structs as dicts, the shape the SDP pipeline's JSON bridge hands ``score()`` — so a
finding scored here is the finding production would score. :class:`WarehouseBackend.query` converts the connector's numpy
scalars/arrays back to native Python (``_to_native``) so its rows match that same shape;
without it, ``score()`` code like ``if row["hourly_states"]`` would hit a numpy array's
ambiguous truth value — a connector artifact, not a real behavioural difference.
"""

from __future__ import annotations

import glob
import os
import subprocess
import sys
from abc import ABC, abstractmethod


class BackendUnavailable(RuntimeError):
    """The requested backend cannot start here (no JVM / pyspark; no warehouse creds).

    Raised — never swallowed — so the caller decides: the CLI reports it, and the
    pytest suite turns it into a clean ``pytest.skip`` rather than a red build."""


class Backend(ABC):
    """The execution surface the runner drives: define fixture views, run rule SQL."""

    name: str = ""
    #: Qualifier the runner puts in front of every fixture name ("" = session temp
    #: views). The warehouse backend sets it to "<catalog>.<schema>." when it
    #: materializes fixtures as tables instead.
    table_prefix: str = ""

    @abstractmethod
    def create_view(self, name: str, select_sql: str) -> None:
        """Create-or-replace one temp view ``name`` from a SELECT body."""

    @abstractmethod
    def query(self, sql: str) -> list[dict]:
        """Execute ``sql`` and return each row as a native-typed Python dict."""

    def close(self) -> None:  # noqa: B027  (optional concrete no-op; backends override)
        """Release the engine (session / connection). Optional — no-op by default."""


# --- local Spark (hermetic) --------------------------------------------------

def _ensure_java_home() -> str | None:
    """Point ``JAVA_HOME`` at a usable JDK so PySpark can launch its JVM.

    PySpark does NOT bundle a JVM; it reads ``JAVA_HOME`` (or ``java`` on PATH) when the
    session starts. A dev box or CI image that has a JDK installed but not exported would
    otherwise fail to start Spark. We probe the usual locations and set ``JAVA_HOME`` for
    this process only. Returns the chosen home, or None if none was found (the caller
    then surfaces :class:`BackendUnavailable`). An already-valid ``JAVA_HOME`` wins."""
    current = os.environ.get("JAVA_HOME")
    if current and os.path.exists(os.path.join(current, "bin", "java")):
        return current

    candidates: list[str] = []
    # macOS system selector (returns the newest matching JDK, if any is registered).
    for ver in ("17", "11", ""):
        try:
            args = ["/usr/libexec/java_home"] + (["-v", ver] if ver else [])
            out = subprocess.run(args, capture_output=True, text=True, timeout=5)
            if out.returncode == 0 and out.stdout.strip():
                candidates.append(out.stdout.strip())
        except Exception:
            pass
    # Homebrew (unlinked), typical Linux CI JDK dirs, macOS JVM bundles.
    candidates += sorted(glob.glob("/opt/homebrew/opt/openjdk@*"), reverse=True)
    candidates += sorted(glob.glob("/opt/homebrew/opt/openjdk"), reverse=True)
    candidates += sorted(glob.glob("/usr/local/opt/openjdk@*"), reverse=True)
    candidates += sorted(glob.glob("/usr/lib/jvm/*"), reverse=True)
    candidates += sorted(
        glob.glob("/Library/Java/JavaVirtualMachines/*/Contents/Home"), reverse=True
    )
    for c in candidates:
        if c and os.path.exists(os.path.join(c, "bin", "java")):
            os.environ["JAVA_HOME"] = c
            return c
    return None


class SparkBackend(Backend):
    """Hermetic local-Spark engine. Constructing it starts the session (and so probes
    for a JVM + pyspark); a missing dependency becomes :class:`BackendUnavailable`."""

    name = "spark"

    def __init__(self) -> None:
        try:
            import pyspark  # noqa: F401
        except ImportError as exc:
            raise BackendUnavailable(
                f"pyspark is not installed ({exc}); install it or use --backend warehouse"
            ) from exc

        java_home = _ensure_java_home()
        if not java_home:
            raise BackendUnavailable(
                "no JDK found (set JAVA_HOME to a Java 11/17 install) — the local-Spark "
                "backend needs a JVM; use --backend warehouse to run on a SQL warehouse"
            )
        # Raise the driver heap BEFORE the JVM launches. In local mode the driver IS the
        # py4j-launched JVM, so `spark.driver.memory` set at runtime is ignored — it must
        # come through PYSPARK_SUBMIT_ARGS at gateway-launch time. The default (~1g) OOMs
        # after several of the rule queries (14-day hourly-spine CROSS JOINs + explode +
        # collect_list, warehouse_autostop's interval reconstruction / gaps-and-islands
        # merge, and cluster_autotermination's per-minute idle sessionization +
        # 168/1440-element collect_list matrices) run back-to-back in one long-lived JVM —
        # the whole sample suite (goldens + value invariants) shares one SparkContext, and
        # plan/broadcast state accumulates. Each Phase 3 rebuild adds another heavy query
        # to the shared JVM (the suite now spans 12 goldens + ~37 value invariants), and 6g
        # began OOMing intermittently on warehouse_autostop's interval reconstruction once
        # the failing_jobs / unused_data_jobs rules joined the session; 8g held for a while,
        # then began OOMing intermittently again once the spot_fallback / enable_photon_dbr /
        # serverless_cost_optimized rules joined. 4g OOMs on the cluster rule alone.
        # Ceiling: 10g OS-kills the process on a 16g machine (heap + JVM/Python/OS
        # overhead + fixtures exceed RAM), so 8g is the working value — DON'T raise it
        # further to fit a bigger suite. The real lever as the suite grows is to run the
        # GOLDEN and VALUE-INVARIANT files as SEPARATE pytest invocations: both share ONE
        # long-lived SparkContext within a process, so a single combined run accumulates
        # plan/broadcast state and OOMs on warehouse_autostop's interval reconstruction;
        # two processes each get a fresh JVM and stay under 8g. (CI with >16g can run them
        # together.) See sample_data/README.md.
        #
        # -Xss8m raises the driver JVM THREAD STACK (default ~512k-1m). enable_serverless
        # builds a 14-day hourly grid and orders it with an array_sort() higher-order
        # lambda comparator; Catalyst's analyzer recurses deeply resolving that plan and
        # StackOverflowErrors on the default stack on local Spark (DBSQL, with a larger
        # stack, handles it fine — this is a local-engine limit, not a query bug, so we
        # size the harness up rather than dumb down the production SQL). Respect an
        # operator's own setting if present.
        os.environ.setdefault(
            "PYSPARK_SUBMIT_ARGS",
            "--driver-memory 8g --driver-java-options -Xss8m pyspark-shell",
        )
        # create_view builds DataFrames from Python rows, which starts Python workers;
        # without this they run whatever `python3` is on PATH, and a minor-version
        # mismatch with the driver fails the job (PYTHON_VERSION_MISMATCH).
        os.environ.setdefault("PYSPARK_PYTHON", sys.executable)
        os.environ.setdefault("PYSPARK_DRIVER_PYTHON", sys.executable)
        try:
            from pyspark.sql import SparkSession

            self.spark = (
                SparkSession.builder.master("local[1]")
                .appName("finops-sample-harness")
                .config("spark.sql.shuffle.partitions", "1")
                .config("spark.ui.enabled", "false")
                .config("spark.ui.showConsoleProgress", "false")
                # Cap retained SQL-execution metadata. The SQL listener keeps the last
                # `spark.sql.ui.retainedExecutions` execution graphs in the status store
                # (default 1000) EVEN with the web UI disabled, so across a long suite on
                # one long-lived SparkContext that store grows without bound — a slow heap
                # leak that compounds the per-query pressure and helped tip the driver JVM
                # into OOM mid-run. We never read the SQL tab here, so keep just a couple.
                .config("spark.sql.ui.retainedExecutions", "2")
                # Deterministic clock arithmetic regardless of the host timezone, so the
                # {"@rel": -N} fixtures land in the same window on any machine.
                .config("spark.sql.session.timeZone", "UTC")
                .getOrCreate()
            )
            self.spark.sparkContext.setLogLevel("ERROR")
        except Exception as exc:  # JVM start failure, incompatible Java, etc.
            raise BackendUnavailable(f"could not start local Spark: {exc}") from exc

    def create_view(self, name: str, select_sql: str) -> None:
        # The invariant suite reloads every table for each of its ~30 scenarios, but
        # only overrides one or two; re-collecting the big unchanged ones each time
        # exhausted the driver heap. Skip a view whose definition is unchanged.
        views = self.__dict__.setdefault("_view_sql", {})
        if views.get(name) == select_sql:
            return
        views[name] = select_sql
        self.spark.sql(f"CREATE OR REPLACE TEMPORARY VIEW {name} AS {select_sql}")
        # Re-register the view over its collected rows. Left as the literal
        # SELECT ... UNION ALL, every reference in the rule SQL re-expands a plan with
        # one branch per fixture row; a rule that reads billing.usage and lineage
        # through several CTEs (job_no_new_input) exhausted the 8g driver heap. A
        # LocalRelation built from the same rows + schema is tiny to re-analyse. The
        # schema is taken from the view, so types are unchanged.
        df = self.spark.table(name)
        self.spark.createDataFrame(df.collect(), df.schema).createOrReplaceTempView(name)

    def query(self, sql: str) -> list[dict]:
        # collect() + Row.asDict(recursive=True). recursive matters: the production
        # SDP pipeline hands score() rows through a to_json/json.loads bridge, so a
        # nested array<struct> arrives as a list of DICTS; plain asDict() (the paused
        # job.py's call) would leave them Spark Rows, which have no .get(). Scalars,
        # Decimals and datetimes come back native either way.
        return [r.asDict(recursive=True) for r in self.spark.sql(sql).collect()]

    def close(self) -> None:
        try:
            self.spark.stop()
        except Exception:
            pass


# --- SQL warehouse (fidelity backstop) --------------------------------------

def _to_native(v):
    """Convert connector-decoded values (numpy arrays/scalars) to native Python, so
    offline candidate rows match what Spark's ``row.asDict()`` gives production.
    Decimals and datetimes pass through unchanged (Spark returns those too)."""
    try:
        import numpy as np
    except Exception:  # numpy always present with pyarrow, but stay defensive
        np = None
    if np is not None:
        if isinstance(v, np.ndarray):
            return [_to_native(x) for x in v.tolist()]
        if isinstance(v, np.generic):
            return v.item()
    if isinstance(v, dict):
        return {k: _to_native(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_to_native(x) for x in v]
    return v


class WarehouseBackend(Backend):
    """databricks-sql-connector against a real warehouse — the fidelity backstop."""

    name = "warehouse"

    def __init__(self, profile: str | None, warehouse: str | None,
                 schema: str | None = None) -> None:
        # ``schema`` ("<catalog>.<schema>") switches fixtures from temp views to real
        # tables. A temp view is an inline literal SELECT of every fixture row, and the
        # rule SQL references each one several times: the warehouse re-analyses that
        # literal plan on every reference, which made one rule take minutes and then
        # drop the connection. Materialized once, each rule is an ordinary query.
        # Only synthetic fixture rows are written, recreated every run (they carry
        # @rel dates relative to today).
        self.schema = schema
        self.table_prefix = f"{schema}." if schema else ""
        if not (profile and warehouse):
            raise BackendUnavailable(
                "the warehouse backend needs --profile and --warehouse "
                "(or FINOPS_SAMPLE_PROFILE / FINOPS_SAMPLE_WAREHOUSE)"
            )
        try:
            from databricks import sql
            from databricks.sdk.core import Config
        except ImportError as exc:
            raise BackendUnavailable(f"databricks-sql-connector not available: {exc}") from exc

        cfg = Config(profile=profile)
        host = (cfg.host or "").replace("https://", "").replace("http://", "").rstrip("/")
        if not host:
            raise BackendUnavailable(f"profile {profile!r} has no host")
        self._conn = sql.connect(
            server_hostname=host,
            http_path=f"/sql/1.0/warehouses/{warehouse}",
            credentials_provider=lambda: cfg.authenticate,
            _socket_timeout=120,
        )
        self._cur = self._conn.cursor()
        if schema:
            self._cur.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")

    def create_view(self, name: str, select_sql: str) -> None:
        self._cur.execute(f"CREATE OR REPLACE TEMPORARY VIEW {name} AS {select_sql}")

    #: rows per INSERT when materializing (keeps each statement well under limits)
    INSERT_BATCH = 200

    def load_table(self, name: str, empty_select: str, tuples: list[str]) -> None:
        """Materialize one fixture table: create it empty with the exact schema, then
        insert the rows in batched multi-row VALUES (see ``__init__`` for why)."""
        self._cur.execute(f"CREATE OR REPLACE TABLE {name} AS {empty_select}")
        for i in range(0, len(tuples), self.INSERT_BATCH):
            self._cur.execute(
                f"INSERT INTO {name} VALUES " + ", ".join(tuples[i:i + self.INSERT_BATCH]))

    def query(self, sql: str) -> list[dict]:
        self._cur.execute(sql)
        cols = [d[0] for d in self._cur.description]
        rows = self._cur.fetchall()
        return [{c: _to_native(v) for c, v in zip(cols, r, strict=True)} for r in rows]

    def close(self) -> None:
        try:
            self._cur and self._cur.close()
            self._conn and self._conn.close()
        except Exception:
            pass


def make_backend(kind: str, *, profile: str | None = None, warehouse: str | None = None,
                 schema: str | None = None) -> Backend:
    """Construct the requested backend. ``kind`` is ``"spark"`` (hermetic, default) or
    ``"warehouse"`` (fidelity backstop). Raises :class:`BackendUnavailable` when the
    chosen engine cannot start here."""
    if kind == "spark":
        return SparkBackend()
    if kind == "warehouse":
        return WarehouseBackend(profile, warehouse, schema)
    raise ValueError(f"unknown backend {kind!r} (expected 'spark' or 'warehouse')")
