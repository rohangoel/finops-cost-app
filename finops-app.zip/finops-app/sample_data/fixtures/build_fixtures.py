"""Compose the sample workspace's fixture tables from REAL profiled values.

The fixtures model ONE small, coherent Databricks workspace, and every rule reads
the same shared system tables (one ``billing.usage`` carries the app rows AND the DLT
rows AND …, exactly as a real ``system.billing.usage`` does). This builder assembles
that workspace and writes the per-table JSONL the harness loads.

Grounding: SKU names and the ``pricing`` structs come verbatim from
``profile/value_vocab.json`` (captured from the live system tables), so no dollar
figure is invented — only the arrangement of rows into positive/negative scenarios
is authored. Temporal columns use ``{"@rel": -N}`` (N days ago) so a fixture means
the same thing on any run date (see ``harness/typegen.py``).

Run it after (re)profiling or when you change a scenario:
    python sample_data/fixtures/build_fixtures.py

Each rule contributes a section below; the docstring of each ``_add_*`` says what the
scenario is and which finding it should (or should not) produce. The expected findings
live in ``sample_data/expected/<rule>.json`` and are asserted by the test suite.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
VOCAB = json.loads((HERE.parent / "profile" / "value_vocab.json").read_text())["tables"]

WS = "1470000000000001"                     # the sample workspace id (not a real one)

# Rows accumulate here per system table, then get written once.
TABLES: dict[str, list[dict]] = defaultdict(list)


def price_row(sku: str, cloud: str = "AWS", unit: str = "DBU") -> dict:
    """The real captured current price row for a SKU (verbatim pricing struct)."""
    for r in VOCAB["billing.list_prices"]["price_rows"]:
        if r["sku_name"] == sku and r["cloud"] == cloud and r["usage_unit"] == unit:
            return {
                "sku_name": sku, "cloud": cloud, "usage_unit": unit,
                "currency_code": "USD",
                "price_start_time": {"@rel": -400}, "price_end_time": None,
                "pricing": r["pricing"],
            }
    raise SystemExit(f"no captured price row for {sku} / {cloud} / {unit}")


# --- idle_apps ---------------------------------------------------------------
def _add_idle_apps():
    """Two always-on Databricks Apps billed continuously, and the REAL app-audit
    shape: only lifecycle events under service_name='apps' — NO HTTP-access events.

    Expected: NO findings. The rule's access signal (service_name='databricksApps'
    HTTP access) does not exist in system.access.audit, so app_access_events_total=0
    for the workspace and the signal gate suppresses the rule. This documents that,
    on real data, idle_apps cannot fire — Apps have no usage/access log.
    """
    sku = "ENTERPRISE_ALL_PURPOSE_SERVERLESS_COMPUTE_US_EAST_N_VIRGINIA"  # Apps bill here
    TABLES["billing.list_prices"].append(price_row(sku))
    for app_id, app_name in [("app-0a1b", "cost-explorer"), ("app-0c2d", "ops-dashboard")]:
        for d in range(1, 15):                       # 14 distinct billed days
            TABLES["billing.usage"].append({
                "workspace_id": WS, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
                "usage_start_time": {"@rel": -d, "@time": "12:00:00"},
                "usage_end_time": {"@rel": -d, "@time": "13:00:00"},
                "usage_date": {"@rel": -d}, "usage_quantity": "4.10",
                "record_type": "ORIGINAL", "billing_origin_product": "APPS",
                "usage_metadata": {"app_id": app_id, "app_name": app_name},
            })
    for act, key in [("startApp", "name"), ("deployApp", "app_name"), ("updateApp", "app")]:
        TABLES["access.audit"].append({
            "workspace_id": WS,
            "event_time": {"@rel": -3, "@time": "09:15:00"}, "event_date": {"@rel": -3},
            "service_name": "apps", "action_name": act,
            "request_params": {key: "cost-explorer"},
            "user_identity": {"email": "platform-admin@example.com"},
        })


# --- continuous_pipeline -----------------------------------------------------
def _add_continuous_pipeline():
    """One production CONTINUOUS DLT pipeline that bills ~24x7 but whose updates
    occupy only a couple of hours a day — the classic 'continuous mode it doesn't
    need' waste.

    Expected: ONE finding. billed_hours ~= 336 (14d x 24), active_hours ~= 28
    (2 short updates/day), so idle_hours ~= 308 (>50%), priced at the DLT rate ->
    well above min_monthly_cost_usd(100) and min_savings_usd(25).
    """
    sku = "ENTERPRISE_DLT_ADVANCED_COMPUTE"
    TABLES["billing.list_prices"].append(price_row(sku))
    pid = "pipe-strm01"
    TABLES["lakeflow.pipelines"].append({
        "workspace_id": WS, "pipeline_id": pid, "pipeline_type": "MANAGED",
        "name": "streaming-ingest-orders", "run_as": "svc-etl@example.com",
        "settings": {"photon": True, "development": False, "continuous": True,
                     "serverless": True, "edition": "ADVANCED"},
        "change_time": {"@rel": -1, "@time": "00:00:00"},
        "create_time": {"@rel": -120, "@time": "00:00:00"}, "delete_time": None,
    })
    # Billed every hour of the last 14 days (always-on continuous compute).
    for d in range(1, 15):
        for h in range(24):
            TABLES["billing.usage"].append({
                "workspace_id": WS, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
                "usage_start_time": {"@rel": -d, "@time": f"{h:02d}:00:00"},
                "usage_end_time": {"@rel": -d, "@time": f"{h:02d}:59:00"},
                "usage_date": {"@rel": -d}, "usage_quantity": "1.50",
                "record_type": "ORIGINAL", "billing_origin_product": "DLT",
                "usage_metadata": {"dlt_pipeline_id": pid},
            })
    # But updates run only twice a day for ~30 min (bursty work a trigger would cover).
    n = 0
    for d in range(1, 15):
        for hh in ("03", "15"):
            n += 1
            TABLES["lakeflow.pipeline_update_timeline"].append({
                "workspace_id": WS, "pipeline_id": pid, "update_id": f"upd-{d:02d}-{hh}",
                "request_id": f"req-{d:02d}-{hh}", "update_type": "PARTIAL",
                "trigger_type": "CONTINUOUS", "result_state": "COMPLETED",
                "period_start_time": {"@rel": -d, "@time": f"{hh}:00:00"},
                "period_end_time": {"@rel": -d, "@time": f"{hh}:30:00"},
            })


# =========================================================================
# Value-invariant fixtures (plan V0 — docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md)
# =========================================================================
# The golden fixtures above detect ANY change (regenerate and they pass). The
# fixtures below instead trigger the accounting INVARIANTS: each is a minimal,
# self-contained scenario that makes a rule WRONG if a Phase 1 correctness
# property (FIN-002/003/004/006/007) regresses. sample_data/tests/
# test_value_invariants.py loads one of these per invariant (via
# runner.load_fixtures(extra=...), which REPLACES a table's committed rows) and
# asserts the property on the candidate rows / findings.
#
# They all drive `continuous_pipeline`, because it exercises the whole shared
# cost layer in one rule: window_lower (FIN-002), the all-record_types corrected
# sum (FIN-003), price_join/price_rate + coverage (FIN-004), latest_scd_cte
# (FIN-006), and (workspace_id, pipeline_id) keys everywhere (FIN-007). Every
# value is drawn from the profiled vocab — real DLT SKUs and their captured
# pricing structs — never invented, exactly as the goldens are.

# Real DLT SKUs from profile/value_vocab.json. ADVANCED is priced in the fixtures;
# CORE is a real SKU whose price row we deliberately OMIT to model a usage row the
# price list does not cover (FIN-004 missing-price).
INV_SKU_PRICED = "ENTERPRISE_DLT_ADVANCED_COMPUTE"      # $0.36/DBU (captured)
INV_SKU_UNPRICED = "ENTERPRISE_DLT_CORE_COMPUTE"        # real SKU, price row omitted
INV_HOURLY_DBU = 1.50                                   # same magnitude as the golden
INV_BILLED_DAYS = 14                                    # >= min_observation_days (5)
INV_UPDATE_HOURS = ("03", "15")                         # 2 short updates/day -> mostly idle


def _dlt_pipeline(ws: str, pid: str, name: str, *, change_rel: int = -1,
                  delete_rel: int | None = None, continuous: bool = True,
                  development: bool = False) -> dict:
    """A lakeflow.pipelines SCD row. `change_rel`/`delete_rel` are @rel day offsets so
    a scenario can stack an older-live and a newer-deleted version (FIN-006)."""
    return {
        "workspace_id": ws, "pipeline_id": pid, "pipeline_type": "MANAGED", "name": name,
        "run_as": "svc-etl@example.com",
        "settings": {"photon": True, "development": development, "continuous": continuous,
                     "serverless": True, "edition": "ADVANCED"},
        "change_time": {"@rel": change_rel, "@time": "00:00:00"},
        "create_time": {"@rel": -120, "@time": "00:00:00"},
        "delete_time": None if delete_rel is None else {"@rel": delete_rel, "@time": "00:00:00"},
    }


def _dlt_usage(ws: str, pid: str, day: int, hour: int, qty: float, *,
               sku: str = INV_SKU_PRICED, record_type: str = "ORIGINAL") -> dict:
    """One billing.usage DLT hour for a pipeline. `record_type` lets a scenario stack
    ORIGINAL/RETRACTION/RESTATEMENT in the same hour (FIN-003)."""
    return {
        "workspace_id": ws, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -day, "@time": f"{hour:02d}:00:00"},
        "usage_end_time": {"@rel": -day, "@time": f"{hour:02d}:59:00"},
        "usage_date": {"@rel": -day}, "usage_quantity": f"{qty:.2f}",
        "record_type": record_type, "billing_origin_product": "DLT",
        "usage_metadata": {"dlt_pipeline_id": pid},
    }


def _dlt_updates(ws: str, pid: str, days: int = INV_BILLED_DAYS) -> list[dict]:
    """Two short updates/day, so an always-billed pipeline reads as mostly idle."""
    rows = []
    for d in range(1, days + 1):
        for hh in INV_UPDATE_HOURS:
            rows.append({
                "workspace_id": ws, "pipeline_id": pid, "update_id": f"upd-{pid}-{d:02d}-{hh}",
                "request_id": f"req-{pid}-{d:02d}-{hh}", "update_type": "PARTIAL",
                "trigger_type": "CONTINUOUS", "result_state": "COMPLETED",
                "period_start_time": {"@rel": -d, "@time": f"{hh}:00:00"},
                "period_end_time": {"@rel": -d, "@time": f"{hh}:30:00"},
            })
    return rows


def _billed_247(ws: str, pid: str, *, qty: float = INV_HOURLY_DBU, days: int = INV_BILLED_DAYS,
                sku: str = INV_SKU_PRICED) -> list[dict]:
    """A pipeline billed every hour of `days` complete days (always-on continuous)."""
    return [_dlt_usage(ws, pid, d, h, qty, sku=sku)
            for d in range(1, days + 1) for h in range(24)]


def invariant_baseline(ws: str = WS, pid: str = "pipe-inv-base") -> dict:
    """A single firing continuous pipeline. Vehicle for the two portfolio invariants
    that hold for ANY firing rule: savings <= corrected current cost, and
    low <= point <= high."""
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],
        "lakeflow.pipelines": [_dlt_pipeline(ws, pid, "inv-baseline")],
        "billing.usage": _billed_247(ws, pid),
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws, pid),
    }


def invariant_missing_price(ws: str = WS, pid: str = "pipe-inv-unpriced") -> dict:
    """FIN-004 fail-closed: a pipeline billed almost entirely under a SKU with NO list
    price (INV_SKU_UNPRICED, its price row omitted) plus a sliver under a priced SKU.
    cost_30d_usd > 0 so the SQL still PROJECTS the candidate row, but priced_fraction
    is far below the coverage floor, so score() must SUPPRESS it — a missing price
    becomes 'unknown', never a confident $0-cost booking."""
    usage = _billed_247(ws, pid, sku=INV_SKU_UNPRICED)          # 336 unpriced DLT hours
    usage += [_dlt_usage(ws, pid, 1, 0, 1.0, sku=INV_SKU_PRICED)]  # one priced hour -> cost > 0
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],     # UNPRICED sku deliberately absent
        "lakeflow.pipelines": [_dlt_pipeline(ws, pid, "inv-unpriced")],
        "billing.usage": usage,
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws, pid),
    }


def invariant_correction_triple(ws: str = WS, pid: str = "pipe-inv-corr") -> dict:
    """FIN-003: billing.usage is an additive ledger. One hour carries a correction
    triple — ORIGINAL 10.0 (wrong), RETRACTION -10.0 (cancels it), RESTATEMENT 1.5
    (the corrected amount) — while every other hour is a clean 1.5. The corrected
    total is therefore identical to a clean pipeline (1.5 x every hour). A rule that
    filtered to record_type='ORIGINAL' would count 10.0 for that hour and overstate
    usage. The test asserts dbus_30d equals the CORRECTED total, not the inflated one."""
    usage = _billed_247(ws, pid)
    # Replace the clean (day 1, hour 0) ORIGINAL 1.5 with the correction triple.
    def _is_cell(u):
        st = u["usage_start_time"]
        return st["@rel"] == -1 and st["@time"] == "00:00:00"
    usage = [u for u in usage if not _is_cell(u)]
    usage += [
        _dlt_usage(ws, pid, 1, 0, 10.0, record_type="ORIGINAL"),
        _dlt_usage(ws, pid, 1, 0, -10.0, record_type="RETRACTION"),
        _dlt_usage(ws, pid, 1, 0, 1.5, record_type="RESTATEMENT"),
    ]
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],
        "lakeflow.pipelines": [_dlt_pipeline(ws, pid, "inv-correction")],
        "billing.usage": usage,
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws, pid),
    }


def invariant_deleted_scd(ws: str = WS, pid: str = "pipe-inv-scd") -> dict:
    """FIN-006: the pipeline's LATEST version (change_time -1d) is its DELETION; an
    OLDER version (change_time -10d) is still 'live'. Rank-then-filter selects the
    newest row, sees delete_time set, and drops the pipeline (nothing to reconfigure).
    The broken shape (filter delete_time before ranking) would remove the deletion row
    and resurrect the older live version as #1 -> a deleted pipeline keeps firing. Its
    billing would otherwise fire, so the test asserts ZERO findings."""
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],
        "lakeflow.pipelines": [
            _dlt_pipeline(ws, pid, "inv-scd-live-old", change_rel=-10, delete_rel=None),
            _dlt_pipeline(ws, pid, "inv-scd-deleted-new", change_rel=-1, delete_rel=-1),
        ],
        "billing.usage": _billed_247(ws, pid),
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws, pid),
    }


def invariant_dup_workspace(ws_a: str = WS, ws_b: str = "1470000000000002",
                            pid: str = "pipe-inv-dup") -> dict:
    """FIN-007: the SAME pipeline_id exists in two workspaces, each billed at a
    DIFFERENT rate (ws_a 1.5, ws_b 3.0 DBU/h). Every join/group in the rule is keyed on
    (workspace_id, pipeline_id), so each workspace must produce its OWN finding with its
    OWN cost. A single-key join would merge the two streams and corrupt both costs. The
    test asserts two findings, one per workspace, each with its own workspace's spend."""
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],
        "lakeflow.pipelines": [
            _dlt_pipeline(ws_a, pid, "inv-dup-ws-a"),
            _dlt_pipeline(ws_b, pid, "inv-dup-ws-b"),
        ],
        "billing.usage": _billed_247(ws_a, pid, qty=1.5) + _billed_247(ws_b, pid, qty=3.0),
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws_a, pid) + _dlt_updates(ws_b, pid),
    }


def invariant_window_dates(lookback_days: int, ws: str = WS, pid: str = "pipe-inv-win") -> dict:
    """FIN-002: bill ONE hour/day on days {-(N+1), -N, ..., -1, 0} — i.e. one day BEFORE
    the window opens, every in-window day, AND partial 'today'. The closed-open window
    [today-N, today) must keep EXACTLY the N in-window dates: the test asserts
    observed_days == lookback_days, proving today (day 0) and day -(N+1) are excluded."""
    days = list(range(0, lookback_days + 2))            # 0 (today) .. N+1 (too old)
    usage = [_dlt_usage(ws, pid, d, 12, INV_HOURLY_DBU) for d in days]
    return {
        "billing.list_prices": [price_row(INV_SKU_PRICED)],
        "lakeflow.pipelines": [_dlt_pipeline(ws, pid, "inv-window")],
        "billing.usage": usage,
        "lakeflow.pipeline_update_timeline": _dlt_updates(ws, pid),
    }


# --- warehouse_autostop (Phase 2 per-rule gate) -----------------------------
# Grounds the rule that Phase 2 rebuilds on system.compute.warehouse_events
# (FIN-012). This golden characterizes the CURRENT rule (billing warm-hours +
# query.history gaps) BEFORE the rebuild, so the diff when warehouse_events is
# wired in is the review signal. Values from the profiled vocab (a real classic
# PRO SQL-warehouse SKU + its captured pricing struct).
WH_SKU = "ENTERPRISE_SQL_PRO_COMPUTE_US_EAST_N_VIRGINIA"   # classic (PRO), has a warm pool
WH_DAYS = 14


def _warehouse(ws: str, wid: str, name: str, *, wtype: str, auto_stop, size: str = "Small") -> dict:
    return {
        "workspace_id": ws, "warehouse_id": wid, "warehouse_name": name,
        "warehouse_type": wtype, "warehouse_channel": "CHANNEL_NAME_CURRENT",
        "warehouse_size": size, "min_clusters": 1, "max_clusters": 1,
        "auto_stop_minutes": auto_stop,
        "change_time": {"@rel": -1, "@time": "00:00:00"}, "delete_time": None,
        "created_by": "svc-sql@example.com",
    }


def _wh_billed_hours(ws: str, wid: str, *, qty: float = 2.0, days: int = WH_DAYS,
                     hours=range(8, 18)) -> list[dict]:
    """Warm/billed hours (a null-auto-stop classic warehouse holds its cluster warm
    across the workday). Keyed by usage_metadata.warehouse_id, priced at the SQL SKU."""
    rows = []
    for d in range(1, days + 1):
        for h in hours:
            rows.append({
                "workspace_id": ws, "sku_name": WH_SKU, "cloud": "AWS", "usage_unit": "DBU",
                "usage_start_time": {"@rel": -d, "@time": f"{h:02d}:00:00"},
                "usage_end_time": {"@rel": -d, "@time": f"{h:02d}:59:00"},
                "usage_date": {"@rel": -d}, "usage_quantity": f"{qty:.2f}",
                "record_type": "ORIGINAL", "billing_origin_product": "SQL",
                "usage_metadata": {"warehouse_id": wid},
            })
    return rows


def _wh_events(ws: str, wid: str, *, days: int = WH_DAYS,
               up_h: int = 8, down_h: int = 18) -> list[dict]:
    """RUNNING/STOPPED events framing one warm interval per workday (FIN-012 source).

    A classic warehouse with no auto-stop starts once in the morning and stays up
    until it is stopped at end of day, so warehouse_events emits a STARTING (cluster
    warm) at ``up_h`` and a STOPPED (cluster_count 0) at ``down_h``. That is the
    ACTUAL running time the rebuilt rule prices reclaim against — here ``down_h-up_h``
    warm hours/day, of which only the few short queries are busy."""
    rows = []
    for d in range(1, days + 1):
        rows.append({
            "workspace_id": ws, "warehouse_id": wid, "event_type": "STARTING",
            "cluster_count": 1, "event_time": {"@rel": -d, "@time": f"{up_h:02d}:00:00"},
        })
        rows.append({
            "workspace_id": ws, "warehouse_id": wid, "event_type": "STOPPED",
            "cluster_count": 0, "event_time": {"@rel": -d, "@time": f"{down_h:02d}:00:00"},
        })
    return rows


def _wh_queries(ws: str, wid: str, *, days: int = WH_DAYS, hours=(9, 11, 13, 15)) -> list[dict]:
    """A few 5-minute queries per workday, spaced ~2h apart, so the gap analysis sees
    long warm-but-idle stretches between them (the reclaimable tail)."""
    rows = []
    for d in range(1, days + 1):
        for h in hours:
            rows.append({
                "workspace_id": ws,
                "statement_id": f"stmt-{wid}-{d:02d}-{h:02d}",
                "executed_by": "analyst@example.com",
                "compute": {"type": "WAREHOUSE", "cluster_id": None, "warehouse_id": wid},
                "start_time": {"@rel": -d, "@time": f"{h:02d}:00:00"},
                "end_time": {"@rel": -d, "@time": f"{h:02d}:05:00"},
            })
    return rows


def _add_warehouse_autostop():
    """Three warehouses that isolate the rule's two suppression gates:

    * wh-analytics-idle — classic PRO, NO auto-stop, billed across the workday but
      queried only a few times an hour apart -> FIRES (idle warm pool reclaimable).
    * wh-etl-tight — identical billing/queries but auto_stop=15 (<= max_acceptable
      30) -> SUPPRESSED at the candidates gate (already well-configured).
    * wh-serverless — SERVERLESS with no auto-stop -> SUPPRESSED by the type filter
      (serverless scales to zero, no warm pool to reclaim).

    Expected: 1 candidate row + 1 HIGH finding (only wh-analytics-idle). The two
    negatives would fire if their gate broke, so the golden proves both filters.
    """
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    ws = WS
    fires, tight, serverless = "wh-analytics-idle", "wh-etl-tight", "wh-serverless"
    TABLES["compute.warehouses"] += [
        _warehouse(ws, fires, "analytics-adhoc", wtype="PRO", auto_stop=None),
        _warehouse(ws, tight, "etl-hourly", wtype="PRO", auto_stop=15),
        _warehouse(ws, serverless, "bi-serverless", wtype="SERVERLESS", auto_stop=None),
    ]
    for wid in (fires, tight):
        TABLES["billing.usage"] += _wh_billed_hours(ws, wid)
        TABLES["query.history"] += _wh_queries(ws, wid)
    # warehouse_events for the firing warehouse: 10 warm hours/day (08:00->18:00),
    # busy only for the four short queries -> a large reclaimable idle warm pool the
    # FIN-012 interval math prices from the ACTUAL running time. The tight/serverless
    # warehouses are dropped at the candidates gate, so they need no events.
    TABLES["compute.warehouse_events"] += _wh_events(ws, fires)
    # Serverless still bills (so it would surface if the type filter regressed), but
    # needs no query rows — it's excluded before the query join.
    TABLES["billing.usage"] += _wh_billed_hours(ws, serverless)


# --- FIN-012 warehouse_autostop value-invariant fixtures --------------------
# Purpose-built scenarios that assert the ACCOUNTING properties of the interval
# rebuild (merged busy <= running; counterfactual <= running; reclaimed <=
# corrected cost; head/tail idle reclaimed; concurrency adds no duplicate warm).
# Self-contained (each REPLACES the committed rows) and driven by the value-
# invariant suite, not the goldens. Values come from the profiled WH SKU/price.
INV_WH_DAYS = 7            # >= min_observation_days (5), within the 14-day window
INV_WH_WID = "inv-wh-idle"


def _wh_query(ws: str, wid: str, d: int, start: str, end: str, tag: str) -> dict:
    return {
        "workspace_id": ws,
        "statement_id": f"stmt-{wid}-{d:02d}-{tag}",
        "executed_by": "analyst@example.com",
        "compute": {"type": "WAREHOUSE", "cluster_id": None, "warehouse_id": wid},
        "start_time": {"@rel": -d, "@time": start},
        "end_time": {"@rel": -d, "@time": end},
    }


def _invariant_wh_common(ws: str, wid: str, queries: list[dict]) -> dict:
    """One PRO warehouse with no auto-stop, running 08:00->18:00/day (events), billed
    across those hours (priced), served by ``queries``. The shared scaffold behind the
    interval invariants — only the query pattern changes between them."""
    return {
        "billing.list_prices": [price_row(WH_SKU)],
        "compute.warehouses": [
            _warehouse(ws, wid, "inv-idle", wtype="PRO", auto_stop=None)
        ],
        "compute.warehouse_events": _wh_events(ws, wid, days=INV_WH_DAYS),
        "billing.usage": _wh_billed_hours(ws, wid, days=INV_WH_DAYS),
        "query.history": queries,
    }


def invariant_wh_gaps() -> dict:
    """Idle warm pool: a warehouse up 10h/day but queried only a few times an hour
    apart, so most of the running time is reclaimable idle (head hour before the first
    query + tails between/after queries). Bounds every priced quantity."""
    ws, wid = WS, INV_WH_WID
    queries = _wh_queries(ws, wid, days=INV_WH_DAYS)     # 4 short queries/day, ~2h apart
    return _invariant_wh_common(ws, wid, queries)


def invariant_wh_concurrency() -> dict:
    """Two OVERLAPPING queries per day (10:00-10:30 and 10:10-10:40). Their union is
    40 min/day; the naive sum of durations is 60. merged_busy must equal the union, so
    concurrency (parallel queries on one warm cluster) never double-counts warm time."""
    ws, wid = WS, INV_WH_WID
    queries = []
    for d in range(1, INV_WH_DAYS + 1):
        queries.append(_wh_query(ws, wid, d, "10:00:00", "10:30:00", "a"))
        queries.append(_wh_query(ws, wid, d, "10:10:00", "10:40:00", "b"))
    return _invariant_wh_common(ws, wid, queries)


# --- idle_serving_endpoints (FIN-018 serving zero-traffic tier) --------------
# Model serving endpoints that bill CONTINUOUSLY (min_concurrency>0 => warm
# replicas billed around the clock) but serve little or no traffic. Grounds the
# FIN-018 promotion: a ZERO-traffic always-billing endpoint books its full always-
# on cost (bookable, requests are COUNTED in endpoint_usage, not inferred), while a
# LOW-traffic one credits only the conservative share scale-to-zero would reclaim
# (estimated). Values from the profiled real-time-inference SKU + its captured
# $0.07/DBU pricing struct. served_entities is the SCD dimension; endpoint_usage is
# the per-request log; billing.usage carries the MODEL_SERVING cost per endpoint_id.
SERV_SKU = "ENTERPRISE_SERVERLESS_REAL_TIME_INFERENCE_US_EAST_N_VIRGINIA"   # $0.07/DBU
# A real serving SKU whose price row we deliberately OMIT (models unpriced usage).
SERV_SKU_UNPRICED = "PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_US_EAST_N_VIRGINIA"
SERV_DAYS = 14


def _served_entity(ws: str, endpoint_id: str, name: str, sid: str, *, min_concurrency: int,
                   compute_type: str = "CPU", entity_type: str = "CUSTOM_MODEL",
                   change_rel: int = -1, delete_rel: int | None = None) -> dict:
    """A serving.served_entities SCD row. min_concurrency>0 means scale-to-zero is
    disabled (warm replicas billed 24/7); 0 means scale-to-zero is on. change_rel/
    delete_rel are @rel day offsets so a scenario can stack versions (FIN-006)."""
    return {
        "workspace_id": ws, "served_entity_id": sid,
        "endpoint_id": endpoint_id, "endpoint_name": name,
        "served_entity_name": f"{name}-served", "entity_type": entity_type,
        "entity_name": f"{name}-model", "entity_version": "1",
        "endpoint_config_version": 1, "task": None, "created_by": "ml-eng@example.com",
        "custom_model_config": {"min_concurrency": min_concurrency,
                                "max_concurrency": max(min_concurrency, 1),
                                "compute_type": compute_type},
        "feature_spec_config": None,
        "change_time": {"@rel": change_rel, "@time": "00:00:00"},
        "endpoint_delete_time": (
            None if delete_rel is None else {"@rel": delete_rel, "@time": "00:00:00"}
        ),
    }


def _serving_billed(ws: str, endpoint_id: str, *, daily_dbu: float = 48.0,
                    days: int = SERV_DAYS, sku: str = SERV_SKU) -> list[dict]:
    """ONE MODEL_SERVING billing.usage row per day for an always-on endpoint (warm
    replicas bill continuously, whether or not requests arrive). Day-grain, not hourly:
    the rule reads only SUM(usage_quantity) and COUNT(DISTINCT usage_date), and a full
    hourly spine of the ~53-field usage_metadata struct across every endpoint overruns
    the Spark parser's statement-complexity limit for the shared billing.usage view.
    Keyed by usage_metadata.endpoint_id, priced at the serving SKU: ~48 DBU/day x $0.07
    x 14 days ~= $47/mo (comfortably over the $25 floor)."""
    return [{
        "workspace_id": ws, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "00:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "23:59:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "MODEL_SERVING",
        "usage_metadata": {"endpoint_id": endpoint_id},
    } for d in range(1, days + 1)]


def _serving_requests(ws: str, sid: str, *, per_day: int, days: int = SERV_DAYS) -> list[dict]:
    """endpoint_usage (per-request log) rows: `per_day` successful requests on each of
    `days` days, keyed by served_entity_id (which carries the endpoint + workspace)."""
    rows = []
    for d in range(1, days + 1):
        for i in range(per_day):
            rows.append({
                "workspace_id": ws, "served_entity_id": sid,
                "databricks_request_id": f"req-{sid}-{d:02d}-{i}",
                "requester": "svc-caller@example.com", "status_code": 200,
                "request_time": {"@rel": -d, "@time": f"{9 + i:02d}:00:00"},
            })
    return rows


def _add_idle_serving_endpoints():
    """Three serving endpoints isolating the FIN-018 tiers and the candidate gate:

    * ep-idle-zero     — CUSTOM_MODEL, min_concurrency=1 (scale-to-zero OFF), billed
      every day, ZERO requests -> FIRES, BOOKABLE (the full always-on cost is
      reclaimable and requests are COUNTED, not inferred).
    * ep-barely-used   — same config but ~1 request/day -> FIRES, ESTIMATED (the low-
      traffic tier credits only the scale-to-zero share, kept out of the headline).
    * ep-scale-to-zero — min_concurrency=0 (scale-to-zero ON), billed every day, zero
      requests -> SUPPRESSED at the candidates gate (a scale-to-zero endpoint costs
      ~nothing idle, so deleting it saves $0). Still fully billed, so it WOULD surface
      if the 'bills while idle' gate regressed.

    Expected: 2 candidate rows (zero + barely-used; scale-to-zero excluded by the WHERE
    gate) and 2 findings — one bookable (~$47/mo) and one estimated (~$33/mo).
    """
    TABLES["billing.list_prices"].append(price_row(SERV_SKU))
    ws = WS
    zero, low, s2z = "ep-idle-zero", "ep-barely-used", "ep-scale-to-zero"
    TABLES["serving.served_entities"] += [
        _served_entity(ws, zero, "fraud-scorer", "se-zero", min_concurrency=1),
        _served_entity(ws, low, "docs-embedder", "se-low", min_concurrency=1),
        _served_entity(ws, s2z, "batch-classifier", "se-s2z", min_concurrency=0),
    ]
    for eid in (zero, low, s2z):
        TABLES["billing.usage"] += _serving_billed(ws, eid)
    # ep-barely-used serves ~1 request/day; the other two serve none.
    TABLES["serving.endpoint_usage"] += _serving_requests(ws, "se-low", per_day=1)


# --- FIN-018 serving value-invariant fixtures --------------------------------
# Purpose-built scenarios asserting the ACCOUNTING properties of the serving tiers:
# zero-traffic books its full cost (bookable, bounded by the cost), low-traffic stays
# estimated (books $0), and a poorly-priced endpoint fails closed to estimated rather
# than booking a partial dollar (FIN-004 on the booking path). Self-contained (each
# REPLACES the committed rows). Values from the profiled serving SKU + captured price.
def _invariant_serving_common(ws: str, eid: str, sid: str, *, min_concurrency: int = 1,
                              requests_per_day: int = 0) -> dict:
    """One CUSTOM_MODEL endpoint billed every day (min_concurrency>0 => bills while
    idle). The shared scaffold behind the zero/low serving invariants — only the
    request pattern changes."""
    return {
        "billing.list_prices": [price_row(SERV_SKU)],
        "serving.served_entities": [
            _served_entity(ws, eid, "inv-endpoint", sid, min_concurrency=min_concurrency)
        ],
        "billing.usage": _serving_billed(ws, eid),
        "serving.endpoint_usage": (
            _serving_requests(ws, sid, per_day=requests_per_day) if requests_per_day else []
        ),
    }


def invariant_serving_zero_bookable() -> dict:
    """Zero-traffic always-billing endpoint: the full always-on cost is reclaimable and
    MEASURED (requests counted in endpoint_usage), so it books -> exactly one finding,
    savings == corrected cost, savings_status 'bookable', savings <= corrected cost.

    One request 60 days ago — outside every rule window, inside the log's retained
    history — proves usage tracking records this endpoint. Without it the endpoint
    has NEVER logged a request, so it is zero_unverified (tracking may be off) and
    correctly stays estimated (2026-09-23); the idle_serving_endpoints golden covers
    that path."""
    sc = _invariant_serving_common(WS, "ep-inv-zero", "se-inv-zero", requests_per_day=0)
    sc["serving.endpoint_usage"] = [{
        "workspace_id": WS, "served_entity_id": "se-inv-zero",
        "databricks_request_id": "req-se-inv-zero-old", "requester": "svc-caller@example.com",
        "status_code": 200, "request_time": {"@rel": -60, "@time": "09:00:00"},
    }]
    return sc


def invariant_serving_low_estimated() -> dict:
    """Low-traffic endpoint (~2 requests/day) kept always-warm: scale-to-zero reclaims
    only a conservative SHARE, so the tier stays ESTIMATED (out of the booked headline)
    and credits strictly less than the full always-on cost."""
    return _invariant_serving_common(WS, "ep-inv-low", "se-inv-low", requests_per_day=2)


def invariant_serving_missing_price_not_bookable() -> dict:
    """FIN-004 on the booking path: a ZERO-traffic endpoint billed half under a serving
    SKU with NO list price (SERV_SKU_UNPRICED, its price row omitted). cost > floor so
    it still FIRES, but priced coverage is only ~0.5 (below the 0.80 floor), so even the
    zero-traffic tier must DROP to 'estimated' rather than book a partial dollar as if
    it were the whole always-on cost. Asserts the finding is emitted but NOT bookable."""
    ws, eid, sid = WS, "ep-inv-cov", "se-inv-cov"
    billed = (_serving_billed(ws, eid)                                  # priced half
              + _serving_billed(ws, eid, sku=SERV_SKU_UNPRICED))        # unpriced half (equal DBU)
    return {
        "billing.list_prices": [price_row(SERV_SKU)],                        # UNPRICED sku absent
        "serving.served_entities": [
            _served_entity(ws, eid, "inv-cov", sid, min_concurrency=1)
        ],
        "billing.usage": billed,
        "serving.endpoint_usage": [],
    }


# --- cluster_autotermination (FIN Phase 2 §2.4) -----------------------------
# Interactive all-purpose clusters left running with loose/no auto-termination.
# The rule sessionizes per-minute node_timeline CPU into contiguous idle GAPS and
# reclaims only the idle time in gaps longer than max_acceptable_minutes (60) — net
# of a restart penalty per gap; scattered idle shorter than the timeout is NOT
# reclaimed, and a minute in which a job TASK ran is active, never idle. Grounds
# §2.4: the QUALIFY->latest_scd_cte migration (portable + delete_time IS NULL), the
# gap method, and the job-activity caveat. Values from the profiled classic
# all-purpose SKU + its captured $0.65/DBU price.
CL_SKU = "ENTERPRISE_ALL_PURPOSE_COMPUTE"     # classic all-purpose, $0.65/DBU (captured)
CL_MAX_ACCEPTABLE_MIN = 60                    # thresholds.yaml max_acceptable_minutes


def _cluster(ws: str, cid: str, name: str, *, source: str = "UI",
             auto_term: int | None = None, worker_count: int = 2,
             change_rel: int = -1, delete_rel: int | None = None) -> dict:
    """A compute.clusters SCD row. `auto_term` None/0/>60 makes it a candidate; a
    JOB/etc `source`, or a set `delete_rel` (the latest row is a deletion), must be
    excluded upstream in latest_clusters."""
    return {
        "workspace_id": ws, "cluster_id": cid, "cluster_name": name,
        "owned_by": "ds@example.com", "cluster_source": source,
        "worker_node_type": "m5.xlarge", "driver_node_type": "m5.xlarge",
        "worker_count": worker_count, "auto_termination_minutes": auto_term,
        "dbr_version": "14.3.x-scala2.12",
        "change_time": {"@rel": change_rel, "@time": "00:00:00"},
        "delete_time": None if delete_rel is None else {"@rel": delete_rel, "@time": "00:00:00"},
    }


def _min_time(minute_of_day: int) -> str:
    return f"{minute_of_day // 60:02d}:{minute_of_day % 60:02d}:00"


def _node_minutes(ws: str, cid: str, day: int, start_min: int, count: int,
                  cpu: float) -> list[dict]:
    """`count` consecutive per-minute node_timeline samples on `day`, from clock
    minute `start_min`, all at CPU `cpu` (user+system). CPU >= 10 reads as active,
    < 10 as idle — the per-minute signal the gap sessionization keys on."""
    return [{
        "workspace_id": ws, "cluster_id": cid,
        "start_time": {"@rel": -day, "@time": _min_time(start_min + i)},
        "end_time": {"@rel": -day, "@time": _min_time(start_min + i + 1)},
        "cpu_user_percent": float(cpu), "cpu_system_percent": 0.0,
        "cpu_wait_percent": 0.0, "mem_used_percent": 20.0, "mem_swap_percent": 0.0,
        "network_received_bytes": 0, "network_sent_bytes": 0,
    } for i in range(count)]


def _cluster_billed(ws: str, cid: str, *, daily_dbu: float = 30.0, days: int = 5,
                    sku: str = CL_SKU) -> list[dict]:
    """One billing.usage row per day for the cluster (day-grain keeps the shared
    billing.usage view small — the rule reads only SUM(usage_quantity) and the
    coverage columns). Keyed by usage_metadata.cluster_id, priced at the AP SKU."""
    return [{
        "workspace_id": ws, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "00:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "23:59:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "INTERACTIVE",
        "usage_metadata": {"cluster_id": cid},
    } for d in range(1, days + 1)]


def _job_task_on_cluster(ws: str, cid: str, day: int, start_min: int, end_min: int,
                         *, job_id: str = "job-nightly") -> dict:
    """A job_task_run_timeline row placing a running TASK on the cluster from clock
    minute `start_min` to `end_min` on `day`. compute_ids carries the cluster, so the
    rule's job_active_minutes marks those minutes ACTIVE — never reclaimable idle,
    however low the CPU (the activity caveat the rule must retain)."""
    return {
        "workspace_id": ws, "job_id": job_id, "run_id": f"run-{cid}-{day}",
        "task_key": "main", "compute_ids": [cid], "result_state": "SUCCEEDED",
        "period_start_time": {"@rel": -day, "@time": _min_time(start_min)},
        "period_end_time": {"@rel": -day, "@time": _min_time(end_min)},
    }


def _add_cluster_autotermination():
    """Interactive all-purpose clusters exercising the candidate + gap gates:

    * clu-adhoc-idle — UI cluster, NO auto-termination, sampled across 5 days with a
      short morning burst and, on its busiest-idle day, left idle for a 90-min
      stretch -> FIRES (a contiguous idle gap beyond the 60-min timeout is
      reclaimable, net of one restart).
    * clu-tight      — identical kind but auto_termination_minutes=15 (<= 60)
      -> SUPPRESSED at the candidates gate (already well-configured).
    * clu-job        — a JOB-source (ephemeral) cluster -> SUPPRESSED by the UI/API
      source filter (a job cluster shouldn't sit idle at all).
    * clu-deleted    — a UI cluster whose latest SCD row is its DELETION
      -> SUPPRESSED by the latest_scd_cte delete_time IS NULL guard (FIN-006 / the
      §2.4 QUALIFY->macro migration; a deleted cluster must not keep firing).

    Expected: 1 candidate row + 1 HIGH finding (only clu-adhoc-idle). Each of the
    three negatives would become a candidate if its gate regressed, so the golden's
    candidate_row_count pins all three filters.
    """
    TABLES["billing.list_prices"].append(price_row(CL_SKU))
    ws = WS
    fires = "clu-adhoc-idle"
    TABLES["compute.clusters"] += [
        _cluster(ws, fires, "ds-adhoc", source="UI", auto_term=None),
        _cluster(ws, "clu-tight", "etl-tight", source="UI", auto_term=15),
        _cluster(ws, "clu-job", "nightly-job", source="JOB", auto_term=None),
        _cluster(ws, "clu-deleted", "old-adhoc", source="UI", auto_term=None, delete_rel=-1),
    ]
    # 5 observed days of a short morning burst (09:00-09:04 active); on the most
    # recent day the cluster is then left idle for 90 contiguous minutes
    # (09:05-10:34) -> one reclaimable gap of 90-60 = 30 min. Only the firing
    # cluster is sampled (the negatives are dropped before any node_timeline join).
    for d in (3, 4, 5, 6, 7):
        TABLES["compute.node_timeline"] += _node_minutes(ws, fires, d, 540, 5, 40.0)
    TABLES["compute.node_timeline"] += _node_minutes(ws, fires, 3, 545, 90, 2.0)
    TABLES["billing.usage"] += _cluster_billed(ws, fires, days=5)


# --- FIN §2.4 cluster_autotermination value-invariant fixtures ---------------
# Purpose-built scenarios asserting the ACCOUNTING properties of the gap method,
# inspected on the CANDIDATE ROW (so they need no 5-day history to fire the finding).
# Self-contained (each REPLACES the committed rows). Values from the profiled AP SKU.
def invariant_cluster_gap_threshold(ws: str = WS, cid: str = "clu-inv-gap") -> dict:
    """One day with a LONG idle gap (90 min > 60) and a SHORT one (40 min <= 60),
    separated by active bursts. reclaimable_gross must credit ONLY the long gap's
    excess (90-60=30) and NOTHING from the short gap, even though both are idle: the
    rule reclaims contiguous idle beyond the timeout, not scattered idle between
    bursts."""
    nt = (_node_minutes(ws, cid, 3, 540, 5, 40.0)      # 09:00-09:04 active
          + _node_minutes(ws, cid, 3, 545, 90, 2.0)    # 09:05-10:34 idle (>60 -> reclaimable)
          + _node_minutes(ws, cid, 3, 635, 5, 40.0)    # 10:35-10:39 active
          + _node_minutes(ws, cid, 3, 640, 40, 2.0))   # 10:40-11:19 idle (<=60 -> not reclaimed)
    return {
        "billing.list_prices": [price_row(CL_SKU)],
        "compute.clusters": [_cluster(ws, cid, "inv-gap")],
        "compute.node_timeline": nt,
        "billing.usage": _cluster_billed(ws, cid, days=1),
        "lakeflow.job_task_run_timeline": [],
    }


def invariant_cluster_job_activity(ws: str = WS, cid: str = "clu-inv-job") -> dict:
    """A cluster at LOW CPU for a contiguous 120-min window (09:00-10:59), with a job
    TASK running dead-centre (09:30-10:29). Auto-termination keys on activity, not raw
    CPU: the 60 job minutes are ACTIVE and split the idle into two 30-min runs, so —
    though every one of the 120 minutes is CPU-idle — only 60 count as idle and NONE
    is reclaimable (neither run clears the 60-min timeout). Proves job-task minutes are
    never mistaken for reclaimable idle."""
    nt = _node_minutes(ws, cid, 3, 540, 120, 2.0)       # 09:00-10:59 all CPU-idle
    job = [_job_task_on_cluster(ws, cid, 3, 570, 629)]  # 09:30-10:29 a TASK runs
    return {
        "billing.list_prices": [price_row(CL_SKU)],
        "compute.clusters": [_cluster(ws, cid, "inv-job")],
        "compute.node_timeline": nt,
        "billing.usage": _cluster_billed(ws, cid, days=1),
        "lakeflow.job_task_run_timeline": job,
    }


# --- interactive_to_job (FIN-010 Phase 3 rebuild) ----------------------------
# Recurring jobs running on ALL-PURPOSE (interactive) compute, which bills ~2x the
# job-compute DBU rate. The rebuilt rule attributes the cluster's all-purpose DBUs by
# the job-active WALL-CLOCK uptime share (never node-minutes — the FIN-010 unit bug),
# prices the real ALL_PURPOSE-vs-JOBS_COMPUTE gap on those DBUs, and splits the
# counterfactual: a job-DEDICATED cluster (jobs ~= all its uptime) books the gap
# (removing the jobs eliminates the cluster), while a SHARED/interactive cluster stays
# estimated with a $0 lower bound (moving jobs off may not shrink the cluster). Values
# from the profiled classic all-purpose SKU ($0.65/DBU) and its JOBS_COMPUTE counterpart
# ($0.20/DBU, gap $0.45), both captured verbatim in value_vocab.json.
I2J_AP_SKU = "ENTERPRISE_ALL_PURPOSE_COMPUTE"      # $0.65/DBU (captured)
I2J_JC_SKU = "ENTERPRISE_JOBS_COMPUTE"             # $0.20/DBU (the migration counterpart)
I2J_DAYS = 6                                       # >= min_observation_days (5), within recency (7)


def _ap_billed(ws: str, cid: str, *, daily_dbu: float, days: int = I2J_DAYS,
               sku: str = I2J_AP_SKU) -> list[dict]:
    """One ALL_PURPOSE billing.usage row per day for a cluster (day-grain keeps the
    shared billing.usage view small — the rule reads SUM(usage_quantity) and the
    coverage columns). Keyed by usage_metadata.cluster_id, billing_origin_product
    ALL_PURPOSE so the rule's filter picks it up, priced at the AP SKU."""
    return [{
        "workspace_id": ws, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "00:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "23:59:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "ALL_PURPOSE",
        "usage_metadata": {"cluster_id": cid},
    } for d in range(1, days + 1)]


def _node_minutes_nodes(ws: str, cid: str, day: int, start_min: int, count: int,
                        nodes: int, cpu: float = 40.0) -> list[dict]:
    """`nodes` node-rows per minute for `count` consecutive minutes on `day` — models a
    multi-node cluster. running WALL-CLOCK minutes are COUNT(DISTINCT clock minute), so
    the node count must NOT change job_active_frac (the FIN-010 size-invariance
    property); a raw COUNT(*) node-minute denominator would."""
    rows = []
    for n in range(nodes):
        for r in _node_minutes(ws, cid, day, start_min, count, cpu):
            r = dict(r)
            r["instance_id"] = f"i-{cid}-{n}"
            rows.append(r)
    return rows


def _i2j_daily_job(ws: str, cid: str, start_min: int, end_min: int, *, days: int = I2J_DAYS,
                   job_id: str = "job-etl") -> list[dict]:
    """One job task run per day on the cluster, `start_min`..`end_min` (clock minutes).
    Distinct run_id per day, so over `days` days the job is recurring (>= min_runs)."""
    return [_job_task_on_cluster(ws, cid, d, start_min, end_min, job_id=job_id)
            for d in range(1, days + 1)]


def _add_interactive_to_job():
    """All-purpose clusters exercising the FIN-010 tiers + the min-cost gate + the
    source filter. The DOLLARS come from the daily billing rows; the node-timeline
    windows only set the job-active uptime FRACTION (and observed_days), so they are
    kept to a few minutes/day — a per-minute spine across every cluster would overrun
    the Spark parser's statement-complexity limit for the shared node_timeline view
    (same constraint the warehouse/serving fixtures note).

    * clu-i2j-dedicated — UI all-purpose, a recurring job active for its WHOLE uptime
      (09:00-09:03/day, node up the same 4 minutes) => job_active_frac 1.0 >=
      dedicated_active_frac => FIRES, BOOKABLE (the measured gap is realized;
      40 DBU/day x6 x $0.45 gap -> ~$463/mo, low==point).
    * clu-i2j-shared    — UI all-purpose up 09:00-09:07/day (8 min) but the job runs
      only 09:00-09:01 (2 min) => frac 0.25 => FIRES, ESTIMATED (low $0; the attributed
      gap ~$579/mo is the upper scenario only — moving the job off may not shrink the
      interactive cluster).
    * clu-i2j-tiny      — same job-dedicated shape but only 5 DBU/day => reassignable
      spend ~$84/mo < min_monthly_cost_usd (200) => CANDIDATE ROW but SUPPRESSED at the
      score() gate (proves the min-cost bar applies to the reassignable spend).
    * clu-i2j-jobsrc    — a JOB-source cluster with identical billing/jobs => EXCLUDED by
      the all_purpose_clusters UI/API source filter (job compute is already cheap), so it
      is not even a candidate row.

    Expected: 3 candidate rows (dedicated + shared + tiny; jobsrc excluded upstream) and
    2 findings — one bookable (~$463/mo) and one estimated (~$579/mo).
    """
    TABLES["billing.list_prices"] += [price_row(I2J_AP_SKU), price_row(I2J_JC_SKU)]
    ws = WS
    ded, shared, tiny, jobsrc = (
        "clu-i2j-dedicated", "clu-i2j-shared", "clu-i2j-tiny", "clu-i2j-jobsrc")
    # auto_term=10 keeps these clusters OUT of the shared-workspace cluster_autotermination
    # candidate set (it excludes anything <= max_acceptable_minutes); interactive_to_job
    # ignores auto-termination, so this does not affect this rule.
    TABLES["compute.clusters"] += [
        _cluster(ws, ded, "etl-dedicated", source="UI", auto_term=10),
        _cluster(ws, shared, "ds-shared", source="UI", auto_term=10),
        _cluster(ws, tiny, "adhoc-tiny", source="UI", auto_term=10),
        _cluster(ws, jobsrc, "nightly-jobcompute", source="JOB", auto_term=10),
    ]
    for d in range(1, I2J_DAYS + 1):
        # Dedicated & tiny: node up 09:00-09:03 (4 min), job the same minutes -> frac 1.0.
        TABLES["compute.node_timeline"] += _node_minutes(ws, ded, d, 540, 4, 40.0)
        TABLES["compute.node_timeline"] += _node_minutes(ws, tiny, d, 540, 4, 40.0)
        # Shared: node up 09:00-09:07 (8 min); job only 09:00-09:01 (2 min) -> frac 0.25.
        TABLES["compute.node_timeline"] += _node_minutes(ws, shared, d, 540, 8, 40.0)
        # jobsrc bills/runs like the dedicated cluster; only its JOB source excludes it.
        TABLES["compute.node_timeline"] += _node_minutes(ws, jobsrc, d, 540, 4, 40.0)
    TABLES["lakeflow.job_task_run_timeline"] += _i2j_daily_job(ws, ded, 540, 543, job_id="job-ded")
    TABLES["lakeflow.job_task_run_timeline"] += _i2j_daily_job(ws, tiny, 540, 543, job_id="job-tiny")
    TABLES["lakeflow.job_task_run_timeline"] += _i2j_daily_job(ws, shared, 540, 541, job_id="job-shared")
    TABLES["lakeflow.job_task_run_timeline"] += _i2j_daily_job(ws, jobsrc, 540, 543, job_id="job-src")
    TABLES["billing.usage"] += _ap_billed(ws, ded, daily_dbu=40.0)      # ~$463/mo saving
    TABLES["billing.usage"] += _ap_billed(ws, shared, daily_dbu=200.0)  # frac 0.25 -> ~$579/mo
    TABLES["billing.usage"] += _ap_billed(ws, tiny, daily_dbu=5.0)      # below the cost gate
    TABLES["billing.usage"] += _ap_billed(ws, jobsrc, daily_dbu=40.0)


# --- FIN-010 interactive_to_job value-invariant fixtures ---------------------
# Purpose-built scenarios asserting the ACCOUNTING properties of the rebuild: the
# size-INVARIANT wall-clock fraction (the unit bug), the dedicated=bookable /
# shared=estimated(low 0) tiers, and workspace-safe keys. Self-contained (each REPLACES
# the committed rows). Values from the profiled AP/JOBS SKUs + captured pricing.
def _i2j_common_prices() -> list[dict]:
    return [price_row(I2J_AP_SKU), price_row(I2J_JC_SKU)]


def invariant_i2j_size_invariance(ws: str = WS) -> dict:
    """FIN-010 unit bug: the SAME job (same wall-clock minutes, 09:00-09:03/day) on a
    1-NODE and a 4-NODE all-purpose cluster. running minutes are DISTINCT clock minutes,
    so both clusters must report the SAME job_active_frac (== 1.0) — the fraction is
    invariant to cluster size. A COUNT(*) node-minute denominator would make the 4-node
    cluster read 0.25 and under-attribute its reassignable DBUs 4x."""
    one, four = "clu-inv-1node", "clu-inv-4node"
    nt = []
    for d in range(1, I2J_DAYS + 1):
        nt += _node_minutes_nodes(ws, one, d, 540, 4, nodes=1)
        nt += _node_minutes_nodes(ws, four, d, 540, 4, nodes=4)
    job = (_i2j_daily_job(ws, one, 540, 543, job_id="job-1n")
           + _i2j_daily_job(ws, four, 540, 543, job_id="job-4n"))
    return {
        "billing.list_prices": _i2j_common_prices(),
        "compute.clusters": [_cluster(ws, one, "inv-1node", source="UI"),
                             _cluster(ws, four, "inv-4node", source="UI")],
        "compute.node_timeline": nt,
        "lakeflow.job_task_run_timeline": job,
        # 4-node bills 4x the DBUs (4 nodes), but the FRACTION is what must match.
        "billing.usage": _ap_billed(ws, one, daily_dbu=40.0) + _ap_billed(ws, four, daily_dbu=160.0),
    }


def invariant_i2j_dedicated_bookable(ws: str = WS, cid: str = "clu-inv-ded") -> dict:
    """A job-dedicated all-purpose cluster (job active for its whole uptime, 09:00-09:03):
    the finding must BOOK the measured gap (low == point), bounded by the reassignable
    cost."""
    nt = []
    for d in range(1, I2J_DAYS + 1):
        nt += _node_minutes(ws, cid, d, 540, 4, 40.0)
    return {
        "billing.list_prices": _i2j_common_prices(),
        "compute.clusters": [_cluster(ws, cid, "inv-ded", source="UI")],
        "compute.node_timeline": nt,
        "lakeflow.job_task_run_timeline": _i2j_daily_job(ws, cid, 540, 543),
        "billing.usage": _ap_billed(ws, cid, daily_dbu=40.0),
    }


def invariant_i2j_shared_estimated(ws: str = WS, cid: str = "clu-inv-shared") -> dict:
    """A shared/interactive all-purpose cluster (job uses only 1/4 of the uptime — 2 of 8
    running minutes): the finding must stay ESTIMATED with a $0 lower bound — removing the
    job is not proven to shrink the still-interactive cluster — and credit strictly less
    than the reassignable cost."""
    nt = []
    for d in range(1, I2J_DAYS + 1):
        nt += _node_minutes(ws, cid, d, 540, 8, 40.0)       # 8 min up
    return {
        "billing.list_prices": _i2j_common_prices(),
        "compute.clusters": [_cluster(ws, cid, "inv-shared", source="UI")],
        "compute.node_timeline": nt,
        "lakeflow.job_task_run_timeline": _i2j_daily_job(ws, cid, 540, 541),  # 2 min active
        "billing.usage": _ap_billed(ws, cid, daily_dbu=200.0),
    }


def invariant_i2j_dup_workspace(ws_a: str = WS, ws_b: str = "1470000000000002",
                                cid: str = "clu-inv-dup") -> dict:
    """FIN-007: the SAME cluster_id, job-dedicated in TWO workspaces, billed at different
    DBU volumes (ws_a 40/day, ws_b 80/day). Every join/partition is keyed on
    (workspace_id, cluster_id), so each workspace yields its own finding with its own
    cost — a single-key join would merge the streams and corrupt both."""
    nt = []
    for d in range(1, I2J_DAYS + 1):
        nt += _node_minutes(ws_a, cid, d, 540, 4, 40.0)
        nt += _node_minutes(ws_b, cid, d, 540, 4, 40.0)
    return {
        "billing.list_prices": _i2j_common_prices(),
        "compute.clusters": [_cluster(ws_a, cid, "inv-dup-a", source="UI"),
                             _cluster(ws_b, cid, "inv-dup-b", source="UI")],
        "compute.node_timeline": nt,
        "lakeflow.job_task_run_timeline": (_i2j_daily_job(ws_a, cid, 540, 543, job_id="job-a")
                                           + _i2j_daily_job(ws_b, cid, 540, 543, job_id="job-b")),
        "billing.usage": (_ap_billed(ws_a, cid, daily_dbu=40.0)
                          + _ap_billed(ws_b, cid, daily_dbu=80.0)),
    }


# --- idle_zombie_clusters (FIN-017 Phase 3 rebuild) --------------------------
# All-purpose clusters that sit idle. The rebuild replaces the old whole-lookback
# annualization with a RECENCY/forward-spend guard: the actionable saving is sized
# on the last recency_days of billed spend, so a cluster that ran idle earlier in
# the lookback but has since STOPPED books $0 (hygiene) instead of being sold as
# ongoing monthly savings. Values from the profiled classic all-purpose SKU
# ($0.65/DBU, ENTERPRISE_ALL_PURPOSE_COMPUTE, deduped in main()).
IZ_SKU = CL_SKU
IZ_RECENCY = 7   # matches thresholds.yaml idle_zombie_clusters.recency_days


def _iz_billed(ws: str, cid: str, day_range, *, daily_dbu: float) -> list[dict]:
    """One INTERACTIVE billing.usage row per day in `day_range` (@rel day offsets),
    priced at the all-purpose SKU. `day_range` lets a scenario put spend either in
    the recent window (still running) or only early in the lookback (stopped)."""
    return [{
        "workspace_id": ws, "sku_name": IZ_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "00:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "23:59:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "INTERACTIVE",
        "usage_metadata": {"cluster_id": cid},
    } for d in day_range]


def _add_idle_zombie_clusters():
    """Two idle all-purpose clusters exercising the FIN-017 forward-spend guard.
    Both are UI clusters on a TIGHT auto-stop (30 min <= max_acceptable 60) with NO
    jobs, so both survive the defer-to-autostop and job-kept-warm guards in score()
    and are genuine terminate candidates — the ONLY thing that differs is whether
    they still run NOW:

    * clu-zomb-live    — idle (~2% CPU) across the last 6 days, still billing in the
      recency window (30 DBU/day x6). recent spend > 0 => STILL running => the idle
      spend is a forward saving, but CPU idle is only a proxy, so ESTIMATED (low $0).
      6 x 30 x $0.65 = $117 / 7d -> ~$501/mo reclaimable.
    * clu-zomb-stopped — same idle shape but ONLY on days 20-27 (all older than the
      7-day recency window); no recent windows and no recent spend => STOPPED =>
      terminating it saves nothing forward => ADVISORY, $0 booked. Its historical
      waste (8 x 40 x $0.65 = $208 / 30d -> ~$208/mo) is shown as max-addressable
      context only. This is the row the OLD whole-lookback annualization would have
      wrongly sold as ~$208/mo ongoing savings.

    Auto-stop is 30 min so neither leaks into the cluster_autotermination candidate
    set (it excludes anything <= max_acceptable_autostop_minutes), and neither has a
    job so neither is an interactive_to_job candidate — they perturb no other golden.

    Expected: 2 candidate rows, 2 findings — clu-zomb-live ESTIMATED ~$501/mo and
    clu-zomb-stopped ADVISORY $0 (waste ~$208/mo). candidate_row_count=2 confirms
    the borderline autotermination idle cluster (avg CPU just >= 10) does NOT leak in.
    """
    TABLES["billing.list_prices"].append(price_row(IZ_SKU))
    ws = WS
    live, stopped = "clu-zomb-live", "clu-zomb-stopped"
    TABLES["compute.clusters"] += [
        _cluster(ws, live, "leftover-live", source="UI", auto_term=30),
        _cluster(ws, stopped, "leftover-stopped", source="UI", auto_term=30),
    ]
    # Live: 3 idle minutes/day (~2% CPU) across the last 6 days (within recency 7 and
    # >= min_observation_days 5) -> 18 idle windows, still running now.
    for d in range(1, 7):
        TABLES["compute.node_timeline"] += _node_minutes(ws, live, d, 540, 3, 2.0)
    # Stopped: same idle shape but only on days 20-27 (8 days, ALL older than the
    # 7-day recency window) -> 24 idle windows over the lookback, 0 recent windows.
    for d in range(20, 28):
        TABLES["compute.node_timeline"] += _node_minutes(ws, stopped, d, 540, 3, 2.0)
    TABLES["billing.usage"] += _iz_billed(ws, live, range(1, 7), daily_dbu=30.0)
    TABLES["billing.usage"] += _iz_billed(ws, stopped, range(20, 28), daily_dbu=40.0)


# --- FIN-017 idle_zombie_clusters value-invariant fixtures -------------------
# Purpose-built scenarios asserting the ACCOUNTING properties of the forward-spend
# guard: a STILL-running idle cluster stays estimated (low 0), a STOPPED one books $0
# forward (no whole-lookback annualization), and workspace-safe keys. Self-contained
# (each REPLACES the committed rows). Values from the profiled AP SKU ($0.65/DBU).
def _iz_idle_nodes(ws: str, cid: str, day_range) -> list[dict]:
    """3 idle minutes/day (~2% CPU) across `day_range` — enough idle windows (>=8) and
    observed days (>=5) to clear the candidate + history gates."""
    nt = []
    for d in day_range:
        nt += _node_minutes(ws, cid, d, 540, 3, 2.0)
    return nt


def invariant_iz_running_estimated(ws: str = WS, cid: str = "clu-iz-run") -> dict:
    """A cluster STILL running idle in the recency window: reclaimable, but CPU idle is
    only a proxy, so the finding is ESTIMATED with a $0 lower bound (0 < point)."""
    return {
        "billing.list_prices": [price_row(IZ_SKU)],
        "compute.clusters": [_cluster(ws, cid, "inv-iz-run", source="UI", auto_term=30)],
        "compute.node_timeline": _iz_idle_nodes(ws, cid, range(1, 7)),
        "billing.usage": _iz_billed(ws, cid, range(1, 7), daily_dbu=30.0),
        "lakeflow.job_task_run_timeline": [],
    }


def invariant_iz_stopped_books_zero(ws: str = WS, cid: str = "clu-iz-stop") -> dict:
    """FIN-017: a cluster that ran idle only 20-27 days ago (all older than the 7-day
    recency window) has STOPPED. Terminating it reclaims nothing forward, so it books
    $0 (advisory) — NOT the whole-lookback annualization the old code sold as savings.
    It still has whole-lookback cost, so the max-addressable (high) bound is > 0."""
    return {
        "billing.list_prices": [price_row(IZ_SKU)],
        "compute.clusters": [_cluster(ws, cid, "inv-iz-stop", source="UI", auto_term=30)],
        "compute.node_timeline": _iz_idle_nodes(ws, cid, range(20, 28)),
        "billing.usage": _iz_billed(ws, cid, range(20, 28), daily_dbu=40.0),
        "lakeflow.job_task_run_timeline": [],
    }


def invariant_iz_dup_workspace(ws_a: str = WS, ws_b: str = "1470000000000002",
                               cid: str = "clu-iz-dup") -> dict:
    """FIN-007: the SAME cluster_id, idle-and-running in TWO workspaces at different DBU
    volumes (ws_a 30/day, ws_b 60/day). Every join is keyed on (workspace_id,
    cluster_id), so each workspace yields its own finding with its own forward cost — a
    single-key join would merge the streams and corrupt both."""
    return {
        "billing.list_prices": [price_row(IZ_SKU)],
        "compute.clusters": [_cluster(ws_a, cid, "inv-iz-dup-a", source="UI", auto_term=30),
                             _cluster(ws_b, cid, "inv-iz-dup-b", source="UI", auto_term=30)],
        "compute.node_timeline": (_iz_idle_nodes(ws_a, cid, range(1, 7))
                                  + _iz_idle_nodes(ws_b, cid, range(1, 7))),
        "billing.usage": (_iz_billed(ws_a, cid, range(1, 7), daily_dbu=30.0)
                          + _iz_billed(ws_b, cid, range(1, 7), daily_dbu=60.0)),
        "lakeflow.job_task_run_timeline": [],
    }


# --- failing_jobs (FIN-020 Phase 3 rebuild) ---------------------------------
# Chronically-failing jobs burn compute on runs that produce nothing. The rebuild
# splits the finding into two actions with different booking tiers: a REPAIR (the
# job has comparable successful runs to price the fixed state -> estimated) and a
# RETIRE (the job never succeeded, so retiring it needs an owner/obsolescence
# decision -> advisory, $0 booked, failed spend shown as max-addressable). Cost is
# attributed per run via usage_metadata.job_run_id at the jobs-compute SKU
# ($0.20/DBU, ENTERPRISE_JOBS_COMPUTE, deduped in main()).
FJ_SKU = "ENTERPRISE_JOBS_COMPUTE"   # $0.20/DBU
FJ_DAYS = 6                          # >= min_observation_days (5)


def _fj_job(ws: str, jid: str, name: str) -> dict:
    """A lakeflow.jobs SCD row (current version: delete_time NULL, single change)."""
    return {
        "workspace_id": ws, "job_id": jid, "name": name,
        "change_time": {"@rel": -1, "@time": "00:00:00"},
        "create_time": {"@rel": -120, "@time": "00:00:00"}, "delete_time": None,
        "trigger_type": "CRON",
    }


def _fj_run(ws: str, jid: str, rid: str, day: int, state: str, *,
            trigger: str = "CRON", code: str | None = None) -> dict:
    """A lakeflow.job_run_timeline terminal run row (run_type JOB_RUN)."""
    return {
        "workspace_id": ws, "job_id": jid, "run_id": rid,
        "run_type": "JOB_RUN", "trigger_type": trigger, "result_state": state,
        "termination_code": code,
        "period_start_time": {"@rel": -day, "@time": "01:00:00"},
        "period_end_time": {"@rel": -day, "@time": "01:30:00"},
    }


def _fj_usage(ws: str, jid: str, rid: str, day: int, dbu: float) -> dict:
    """A billing.usage row for one run, keyed by usage_metadata.job_id + job_run_id
    (how failing_jobs attributes real per-run cost), priced at the jobs SKU."""
    return {
        "workspace_id": ws, "sku_name": FJ_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -day, "@time": "01:00:00"},
        "usage_end_time": {"@rel": -day, "@time": "01:30:00"},
        "usage_date": {"@rel": -day}, "usage_quantity": f"{dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "JOBS",
        "usage_metadata": {"job_id": jid, "job_run_id": rid},
    }


def _fj_runs(ws: str, jid: str, *, failed: int, succeeded: int, failed_dbu: float = 50.0,
             succ_dbu: float = 20.0, trigger: str = "CRON", days: int = FJ_DAYS,
             code: str = "RUN_EXECUTION_ERROR") -> tuple[list[dict], list[dict]]:
    """`failed` FAILED + `succeeded` SUCCEEDED runs spread across `days` calendar days
    (so observed_days clears the history gate), each with a matching per-run usage row.
    Failed runs cost more DBU than successful ones so the repair reclaim fraction > 0."""
    runs, usage = [], []
    idx = 0
    for state, count, dbu in (("FAILED", failed, failed_dbu),
                              ("SUCCEEDED", succeeded, succ_dbu)):
        for _ in range(count):
            day = 1 + (idx % days)
            rid = f"run-{jid}-{idx}"
            runs.append(_fj_run(ws, jid, rid, day, state, trigger=trigger,
                                code=code if state == "FAILED" else None))
            usage.append(_fj_usage(ws, jid, rid, day, dbu))
            idx += 1
    return runs, usage


def _add_failing_jobs():
    """Jobs exercising the FIN-020 repair/retire split + the SQL and score() gates:

    * job-fj-repair   — 40 CRON runs over 6 days, 16 FAILED + 24 SUCCEEDED (40% fail
      rate). Failed runs bill $10 (50 DBU), successful $4 (20 DBU) -> the fixed state
      is priceable => REPAIR, ESTIMATED. excess (0.40-0.05)/0.40=0.875, reclaim
      1-4/10=0.6 -> $160 x 0.875 x 0.6 = ~$84/mo (waste $160/mo).
    * job-fj-retire   — 24 CRON runs, ALL FAILED (0 succeeded). No successful run to
      price a repair, and retiring needs an owner call => RETIRE, ADVISORY, $0 booked;
      excess-failure spend ~$228/mo shown as max-addressable (waste $240/mo).
    * job-fj-healthy  — 60 runs, 3 FAILED + 57 SUCCEEDED (5% fail rate). Passes the SQL
      HAVING (min_failures 3) so it is a CANDIDATE ROW, but score() suppresses it at
      min_fail_rate (0.05 < 0.10) => no finding. Pins the score-side fail-rate gate.
    * job-fj-streaming— 24 CONTINUOUS runs, mostly failed => EXCLUDED at the SQL HAVING
      (majority-continuous share > 0.5): streaming jobs restart on error by design.
    * job-fj-lowrun   — only 10 runs => EXCLUDED at the SQL HAVING (< min_runs 20).

    Expected: 3 candidate rows (repair + retire + healthy; streaming/lowrun excluded
    upstream) and 2 findings — repair ESTIMATED ~$84/mo, retire ADVISORY $0 (waste
    ~$240/mo). candidate_row_count=3 pins the two SQL filters AND the score-side gate.
    """
    TABLES["billing.list_prices"].append(price_row(FJ_SKU))
    ws = WS
    TABLES["lakeflow.jobs"] += [
        _fj_job(ws, "job-fj-repair", "flaky-etl"),
        _fj_job(ws, "job-fj-retire", "broken-nightly"),
        _fj_job(ws, "job-fj-healthy", "steady-etl"),
        _fj_job(ws, "job-fj-streaming", "stream-ingest"),
        _fj_job(ws, "job-fj-lowrun", "adhoc-rare"),
    ]
    specs = [
        ("job-fj-repair", dict(failed=16, succeeded=24)),
        ("job-fj-retire", dict(failed=24, succeeded=0)),
        ("job-fj-healthy", dict(failed=3, succeeded=57)),
        ("job-fj-streaming", dict(failed=20, succeeded=4, trigger="CONTINUOUS")),
        ("job-fj-lowrun", dict(failed=6, succeeded=4)),
    ]
    for jid, kw in specs:
        runs, usage = _fj_runs(ws, jid, **kw)
        TABLES["lakeflow.job_run_timeline"] += runs
        TABLES["billing.usage"] += usage


# --- FIN-020 failing_jobs value-invariant fixtures ---------------------------
# Purpose-built scenarios asserting the ACCOUNTING properties of the split: a REPAIR
# stays estimated, a RETIRE books $0 (advisory) with the failed spend as max-
# addressable. Self-contained (each REPLACES the committed rows). Values from the
# profiled jobs SKU ($0.20/DBU).
def invariant_fj_repair_estimated(ws: str = WS, jid: str = "job-fj-inv-repair") -> dict:
    """A chronically-failing job WITH comparable successful runs: the fixed state is
    priceable, so it is a REPAIR estimate (estimated, low 0, 0 < point)."""
    runs, usage = _fj_runs(ws, jid, failed=16, succeeded=24)
    return {
        "billing.list_prices": [price_row(FJ_SKU)],
        "lakeflow.jobs": [_fj_job(ws, jid, "inv-repair")],
        "lakeflow.job_run_timeline": runs,
        "billing.usage": usage,
    }


def invariant_fj_retire_books_zero(ws: str = WS, jid: str = "job-fj-inv-retire") -> dict:
    """FIN-020: a job that NEVER succeeded has no successful run to estimate a repair
    from, and retiring it needs an owner decision => advisory, $0 booked, with the
    excess-failure spend surfaced as the max-addressable upper bound (> 0)."""
    runs, usage = _fj_runs(ws, jid, failed=24, succeeded=0)
    return {
        "billing.list_prices": [price_row(FJ_SKU)],
        "lakeflow.jobs": [_fj_job(ws, jid, "inv-retire")],
        "lakeflow.job_run_timeline": runs,
        "billing.usage": usage,
    }


# --- unused_data_jobs (FIN-015 Phase 3 rebuild) ------------------------------
# A scheduled job that writes a table nothing ever reads is producing dead data.
# The rebuild (a) drops the 50/70% recoverable-fraction haircut — the FULL producing
# cost is shown as max-addressable and books $0 (advisory) until a human confirms —
# and (b) adds a lineage-availability sentinel: "zero reads on this table" is only a
# signal if lineage is capturing reads in the table's SCHEMA at all; a schema with no
# captured reads is "no coverage", not "dead", and is suppressed. Cost via
# usage_metadata.job_id at the jobs SKU ($0.20/DBU, deduped in main()).
UDJ_SKU = "ENTERPRISE_JOBS_COMPUTE"
UDJ_DAYS = 6   # writes span 6 days >= min_observation_days (5)


def _udj_job(ws: str, jid: str, name: str) -> dict:
    return {
        "workspace_id": ws, "job_id": jid, "name": name,
        "change_time": {"@rel": -1, "@time": "00:00:00"},
        "create_time": {"@rel": -120, "@time": "00:00:00"}, "delete_time": None,
        "trigger_type": "CRON",
    }


def _lineage_write(ws: str, jid: str, tbl: str, day: int) -> dict:
    """A JOB writing a TABLE target (a producer event) in table_lineage."""
    return {
        "workspace_id": ws, "entity_type": "JOB", "entity_id": jid,
        "target_type": "TABLE", "target_table_full_name": tbl,
        "source_table_full_name": None,
        "event_time": {"@rel": -day, "@time": "02:00:00"}, "event_date": {"@rel": -day},
    }


def _lineage_read(ws: str, tbl: str, day: int, *, entity_id: str = "nb-reader") -> dict:
    """A read of a TABLE source (any entity) — what the reads/read_schema CTEs count."""
    return {
        "workspace_id": ws, "entity_type": "NOTEBOOK", "entity_id": entity_id,
        "target_type": "TABLE", "target_table_full_name": None,
        "source_table_full_name": tbl,
        "event_time": {"@rel": -day, "@time": "03:00:00"}, "event_date": {"@rel": -day},
    }


def _udj_usage(ws: str, jid: str, day: int, dbu: float) -> dict:
    return {
        "workspace_id": ws, "sku_name": UDJ_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -day, "@time": "02:00:00"},
        "usage_end_time": {"@rel": -day, "@time": "02:30:00"},
        "usage_date": {"@rel": -day}, "usage_quantity": f"{dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "JOBS",
        "usage_metadata": {"job_id": jid},
    }


def _add_unused_data_jobs():
    """Producer jobs exercising the FIN-015 sentinel + the SQL gates:

    * job-udj-dead      — writes cat.deadschema.dead_tbl 12x over 6 days, NEVER read.
      Its schema (cat.deadschema) HAS captured reads (of live_tbl), so the sentinel
      passes => FIRES advisory, full producing cost (~$60/mo) shown as max-addressable.
    * job-udj-nocoverage— writes cat.darkschema.dark_tbl 12x over 6 days, never read,
      AND cat.darkschema has NO captured reads at all => min_schema_reads=0 =>
      CANDIDATE ROW but SUPPRESSED at the score() sentinel ("no coverage", not dead).
    * job-udj-read      — writes cat.deadschema.read_tbl, which IS read => not unread =>
      EXCLUDED at the SQL HAVING (n_tables != n_unread).

    Expected: 2 candidate rows (dead + nocoverage; read excluded upstream) and 1
    finding — job-udj-dead advisory (~$60/mo addressable, $0 booked). candidate_row_count=2
    pins the sentinel gate.
    """
    TABLES["billing.list_prices"].append(price_row(UDJ_SKU))
    ws = WS
    TABLES["lakeflow.jobs"] += [
        _udj_job(ws, "job-udj-dead", "nightly-dead-table"),
        _udj_job(ws, "job-udj-nocoverage", "dark-schema-writer"),
        _udj_job(ws, "job-udj-read", "used-table-writer"),
    ]
    for d in range(1, UDJ_DAYS + 1):
        # dead producer: 2 writes/day of an unread table in a schema that HAS reads
        TABLES["access.table_lineage"] += [
            _lineage_write(ws, "job-udj-dead", "cat.deadschema.dead_tbl", d),
            _lineage_write(ws, "job-udj-dead", "cat.deadschema.dead_tbl", d),
        ]
        # dark producer: 2 writes/day of an unread table in a schema with NO reads
        TABLES["access.table_lineage"] += [
            _lineage_write(ws, "job-udj-nocoverage", "cat.darkschema.dark_tbl", d),
            _lineage_write(ws, "job-udj-nocoverage", "cat.darkschema.dark_tbl", d),
        ]
        # read producer: writes a table that IS read (2 writes/day)
        TABLES["access.table_lineage"] += [
            _lineage_write(ws, "job-udj-read", "cat.deadschema.read_tbl", d),
            _lineage_write(ws, "job-udj-read", "cat.deadschema.read_tbl", d),
        ]
        TABLES["billing.usage"] += [
            _udj_usage(ws, "job-udj-dead", d, 50.0),
            _udj_usage(ws, "job-udj-nocoverage", d, 50.0),
            _udj_usage(ws, "job-udj-read", d, 50.0),
        ]
    # Reads: cat.deadschema HAS read activity (live_tbl + read_tbl), so the dead
    # table's zero reads is a real signal; cat.darkschema has NONE. read_tbl being
    # read is what drops job-udj-read at the SQL HAVING.
    for d in (2, 4):
        TABLES["access.table_lineage"] += [
            _lineage_read(ws, "cat.deadschema.live_tbl", d),
            _lineage_read(ws, "cat.deadschema.read_tbl", d),
        ]


# --- FIN-015 unused_data_jobs value-invariant fixtures -----------------------
# Self-contained scenarios asserting the sentinel + no-haircut booking. Values from
# the profiled jobs SKU ($0.20/DBU).
def _udj_inv_common(ws: str, jid: str, tbl: str, *, schema_has_reads: bool) -> dict:
    lineage = []
    for d in range(1, UDJ_DAYS + 1):
        lineage += [_lineage_write(ws, jid, tbl, d), _lineage_write(ws, jid, tbl, d)]
    if schema_has_reads:
        cat, sch, _ = tbl.split(".")
        for d in (2, 4):
            lineage.append(_lineage_read(ws, f"{cat}.{sch}.other_tbl", d))
    return {
        "billing.list_prices": [price_row(UDJ_SKU)],
        "lakeflow.jobs": [_udj_job(ws, jid, "inv-udj")],
        "access.table_lineage": lineage,
        "billing.usage": [_udj_usage(ws, jid, d, 50.0) for d in range(1, UDJ_DAYS + 1)],
    }


def invariant_udj_addressable_advisory(ws: str = WS, jid: str = "job-udj-inv-dead") -> dict:
    """An unread producer whose schema HAS read coverage: fires advisory, the FULL
    producing cost is the max-addressable upper bound (no haircut), books $0."""
    return _udj_inv_common(ws, jid, "cat.invschema.inv_dead_tbl", schema_has_reads=True)


def invariant_udj_no_coverage_suppressed(ws: str = WS, jid: str = "job-udj-inv-dark") -> dict:
    """FIN-015 sentinel: an unread producer whose schema has NO captured reads is
    'no coverage', not 'dead' — suppressed (no finding)."""
    return _udj_inv_common(ws, jid, "cat.invdark.inv_dark_tbl", schema_has_reads=False)


# --- spot_fallback (FIN-009 Phase 3 rebuild) ---------------------------------
# On-demand classic clusters are spot candidates, but spot reduces the CLOUD VM bill,
# not DBUs — and Databricks billing.usage meters DBUs (identical on spot vs on-demand).
# So the rebuild surfaces the opportunity as ADVISORY $0 (unquantifiable without a cloud
# billing export) rather than a DBU-derived guess. Cost is context only, at the jobs SKU.
SF_SKU = "ENTERPRISE_JOBS_COMPUTE"   # $0.20/DBU (classic jobs compute)
SF_DAYS = 6                          # >= min_observation_days (5)


def _spot_cluster(ws: str, cid: str, name: str, *, availability: str, workers: int,
                  source: str = "JOB") -> dict:
    """A compute.clusters SCD row carrying aws_attributes.availability + a worker count
    (what spot_fallback reads). Cloud resolves to 'aws' via the availability block."""
    return {
        "workspace_id": ws, "cluster_id": cid, "cluster_name": name,
        "owned_by": "ds@example.com", "cluster_source": source,
        "worker_node_type": "m5.xlarge", "driver_node_type": "m5.xlarge",
        "worker_count": workers,
        "aws_attributes": {"availability": availability},
        "dbr_version": "14.3.x-scala2.12",
        "change_time": {"@rel": -1, "@time": "00:00:00"},
        "delete_time": None,
    }


def _spot_billed(ws: str, cid: str, *, daily_dbu: float, days: int = SF_DAYS) -> list[dict]:
    """Classic (non-serverless) JOBS usage per day for a cluster, keyed by
    usage_metadata.cluster_id — the context-only DBU spend spot_fallback reports."""
    return [{
        "workspace_id": ws, "sku_name": SF_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "01:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "02:00:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "JOBS",
        "usage_metadata": {"cluster_id": cid},
    } for d in range(1, days + 1)]


def _add_spot_fallback():
    """On-demand classic clusters exercising the FIN-009 advisory-$0 rebuild + gates:

    * clu-spot-ondemand — ON_DEMAND, 4 workers, ~$240/mo classic DBU spend => FIRES
      ADVISORY $0 (spot reduces the VM bill, not DBUs — unquantifiable here).
    * clu-spot-tiny     — ON_DEMAND, 2 workers, tiny (~$12/mo) spend => CANDIDATE ROW
      but SUPPRESSED at the score-side min_monthly_cost gate.
    * clu-spot-already  — already SPOT_WITH_FALLBACK => EXCLUDED at the SQL candidates
      filter (the saving is already captured).
    * clu-spot-single   — ON_DEMAND but 0 workers (single-node) => EXCLUDED at the SQL
      candidates filter (the driver always stays on-demand).

    Expected: 2 candidate rows (ondemand + tiny; already-spot and single-node excluded
    upstream) and 1 finding — clu-spot-ondemand advisory $0 (waste ~$240/mo context).
    candidate_row_count=2 pins the SQL availability/worker filters AND the score gate.
    """
    TABLES["billing.list_prices"].append(price_row(SF_SKU))
    ws = WS
    TABLES["compute.clusters"] += [
        _spot_cluster(ws, "clu-spot-ondemand", "on-demand-etl", availability="ON_DEMAND", workers=4),
        _spot_cluster(ws, "clu-spot-tiny", "on-demand-tiny", availability="ON_DEMAND", workers=2),
        _spot_cluster(ws, "clu-spot-already", "already-spot", availability="SPOT_WITH_FALLBACK", workers=4),
        _spot_cluster(ws, "clu-spot-single", "single-node", availability="ON_DEMAND", workers=0),
    ]
    TABLES["billing.usage"] += _spot_billed(ws, "clu-spot-ondemand", daily_dbu=200.0)  # ~$240/mo
    TABLES["billing.usage"] += _spot_billed(ws, "clu-spot-tiny", daily_dbu=10.0)       # ~$12/mo
    TABLES["billing.usage"] += _spot_billed(ws, "clu-spot-already", daily_dbu=200.0)
    TABLES["billing.usage"] += _spot_billed(ws, "clu-spot-single", daily_dbu=200.0)


# --- FIN-009 spot_fallback value-invariant fixture ---------------------------
def invariant_spot_books_zero(ws: str = WS, cid: str = "clu-spot-inv") -> dict:
    """THE FIN-009 invariant: an on-demand cluster is a spot candidate, but a spot
    toggle leaves the metered DBUs unchanged, so the Databricks-measured saving is $0
    (advisory) — no matter the DBU spend. Self-contained (replaces the committed rows)."""
    return {
        "billing.list_prices": [price_row(SF_SKU)],
        "compute.clusters": [
            _spot_cluster(ws, cid, "inv-spot", availability="ON_DEMAND", workers=8),
        ],
        "billing.usage": _spot_billed(ws, cid, daily_dbu=300.0),
    }


# --- FIN-021 enable_photon_dbr fixtures --------------------------------------
# Old-runtime all-purpose clusters, priced but with NO node_timeline and NO jobs,
# so they are INERT to the other cluster rules (idle_zombie INNER-JOINs util from
# node_timeline; interactive_to_job INNER-JOINs cluster_jobs; autotermination gates
# on auto_termination_minutes IS NULL — so a set auto-term excludes them). The
# photon SQL, by contrast, returns EVERY UI/API cluster (LEFT JOIN cost), so the
# candidate set is the whole fixture's UI/API clusters; only these old-DBR ones fire.
PH_DAYS = 6  # >= min_observation_days (5), so insufficient_history passes


def _photon_cluster(ws: str, cid: str, name: str, *, dbr_version: str) -> dict:
    """A UI all-purpose cluster on a given runtime, with auto-termination SET (so the
    autotermination rule excludes it) and no jobs/node_timeline (so idle_zombie and
    interactive_to_job exclude it). Only enable_photon_dbr reads dbr_version."""
    row = _cluster(ws, cid, name, source="UI", auto_term=60, worker_count=2)
    row["dbr_version"] = dbr_version
    return row


def _add_enable_photon_dbr():
    """Old-runtime clusters exercising the FIN-021 advisory-$0 rebuild + class split:

    * clu-photon-old — DBR 11.3.x (mixed all-purpose), ~$390/mo => FIRES ADVISORY $0
      with a ~15% UPPER BOUND (high ~$58.50); nothing booked.
    * clu-photon-ml  — DBR 11.3.x-cpu-ml (ML runtime), SAME ~$390/mo => FIRES ADVISORY
      $0 with the ML-floor ~5% UPPER BOUND (high ~$19.50) — Photon barely helps ML, so
      the ceiling is far lower for identical spend.
    * clu-photon-cur — DBR 14.3.x (current) => CANDIDATE ROW but SUPPRESSED at score
      (major 14 >= min_dbr_major 13). Also every other fixture's UI cluster is a
      candidate row on a current runtime, likewise suppressed.

    Expected: 2 findings, both advisory $0, differing only in the max-addressable
    upper bound (high) by workload class. candidate_row_count is the whole fixture's
    UI/API cluster count (only the two old-DBR clusters fire).
    """
    TABLES["billing.list_prices"].append(price_row(CL_SKU))
    ws = WS
    TABLES["compute.clusters"] += [
        _photon_cluster(ws, "clu-photon-old", "legacy-etl", dbr_version="11.3.x-scala2.12"),
        _photon_cluster(ws, "clu-photon-ml", "legacy-ml", dbr_version="11.3.x-cpu-ml-scala2.12"),
        _photon_cluster(ws, "clu-photon-cur", "current-etl", dbr_version="14.3.x-scala2.12"),
    ]
    # ~$390/mo each (100 DBU x 6 days x $0.65). Identical spend isolates the class split.
    TABLES["billing.usage"] += _cluster_billed(ws, "clu-photon-old", daily_dbu=100.0, days=PH_DAYS)
    TABLES["billing.usage"] += _cluster_billed(ws, "clu-photon-ml", daily_dbu=100.0, days=PH_DAYS)
    TABLES["billing.usage"] += _cluster_billed(ws, "clu-photon-cur", daily_dbu=100.0, days=PH_DAYS)


# --- FIN-021 enable_photon_dbr value-invariant fixture -----------------------
def invariant_photon_books_zero(ws: str = WS, cid: str = "clu-photon-inv") -> dict:
    """THE FIN-021 invariant: an old-runtime cluster is a Photon/DBR-upgrade candidate,
    but the uplift is an unmeasured heuristic, so it books $0 (advisory) — the class
    fraction is only the UPPER BOUND. Self-contained (replaces the committed rows)."""
    return {
        "billing.list_prices": [price_row(CL_SKU)],
        "compute.clusters": [
            _photon_cluster(ws, cid, "inv-photon", dbr_version="11.3.x-scala2.12"),
        ],
        "billing.usage": _cluster_billed(ws, cid, daily_dbu=200.0, days=PH_DAYS),
    }


# --- FIN-014 serverless_cost_optimized fixtures ------------------------------
# Serverless PERFORMANCE_OPTIMIZED jobs/pipelines. Isolated from the other rules:
# each job has < failing_jobs.min_runs (20) runs so failing_jobs never sees it; the
# pipeline is TRIGGERED (settings.continuous=False) so continuous_pipeline skips it
# (its WHERE requires is_continuous); no access.table_lineage / cluster compute, so
# unused_data_jobs and interactive_to_job are untouched. The candidate filter keys on
# product_features.performance_target (present in the schema snapshot).
SCO_JOB_SKU = "ENTERPRISE_JOBS_SERVERLESS_COMPUTE_US_EAST_N_VIRGINIA"        # $0.45/DBU
SCO_PIPE_SKU = "ENTERPRISE_LAKEHOUSE_SERVERLESS_COMPUTE_US_EAST_N_VIRGINIA"  # $0.70/DBU (serverless DLT)
SCO_DAYS = 6  # >= min_observation_days (5)


def _sco_usage(ws: str, entity_id: str, *, product: str, sku: str, daily_dbu: float,
               days: int = SCO_DAYS) -> list[dict]:
    """PERFORMANCE_OPTIMIZED serverless usage/day for a job ('JOBS') or pipeline ('DLT'),
    keyed by the matching usage_metadata id. product_features.performance_target is the
    field the rule's candidate filter selects on."""
    meta = {"job_id": entity_id} if product == "JOBS" else {"dlt_pipeline_id": entity_id}
    return [{
        "workspace_id": ws, "sku_name": sku, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -d, "@time": "02:00:00"},
        "usage_end_time": {"@rel": -d, "@time": "03:00:00"},
        "usage_date": {"@rel": -d}, "usage_quantity": f"{daily_dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": product,
        "product_features": {"performance_target": "PERFORMANCE_OPTIMIZED"},
        "usage_metadata": meta,
    } for d in range(1, days + 1)]


def _sco_job_runs(ws: str, jid: str, *, run_min: int, n: int = 10,
                  days: int = SCO_DAYS) -> list[dict]:
    """n SUCCEEDED job_run_timeline runs of run_min minutes each, for the median-run
    gate. n stays below failing_jobs.min_runs (20) so that rule never picks this up."""
    return [{
        "workspace_id": ws, "job_id": jid, "run_id": f"run-{jid}-{i}",
        "run_type": "JOB_RUN", "trigger_type": "CRON", "result_state": "SUCCEEDED",
        "termination_code": None,
        "period_start_time": {"@rel": -(1 + i % days), "@time": "02:00:00"},
        "period_end_time": {"@rel": -(1 + i % days), "@time": _min_time(120 + run_min)},
    } for i in range(n)]


def _sco_pipe_updates(ws: str, pid: str, *, dur_min: int, n: int = 10,
                      days: int = SCO_DAYS) -> list[dict]:
    """n TRIGGERED pipeline updates of dur_min minutes each, for the median-run gate."""
    return [{
        "workspace_id": ws, "pipeline_id": pid, "update_id": f"upd-{pid}-{i}",
        "request_id": f"req-{pid}-{i}", "update_type": "PARTIAL",
        "trigger_type": "TRIGGERED", "result_state": "COMPLETED",
        "period_start_time": {"@rel": -(1 + i % days), "@time": "02:00:00"},
        "period_end_time": {"@rel": -(1 + i % days), "@time": _min_time(120 + dur_min)},
    } for i in range(n)]


def _add_serverless_cost_optimized():
    """Serverless PERFORMANCE_OPTIMIZED workloads exercising the FIN-014 advisory-$0
    rebuild + the resource_type=pipeline fix + the duration gate:

    * job-sco-long  — serverless JOBS, median run 30 min, ~$540/mo (200 DBU x 6d x
      $0.45) => FIRES ADVISORY $0, resource_type 'job', high=$270 (50% modeled ceiling).
    * pipe-sco-long — serverless DLT pipeline (TRIGGERED), median update 30 min,
      ~$420/mo (100 DBU x 6d x $0.70) => FIRES ADVISORY $0, resource_type 'pipeline'
      (the FIN-014 fix — was always mislabelled 'job'), high=$210.
    * job-sco-short — serverless JOBS, median run 3 min => CANDIDATE ROW but SUPPRESSED
      at the score-side short_run_minutes gate (Standard's slower cold start erodes the
      saving on a brief run).

    Expected: 3 candidate rows, 2 findings (both advisory $0), one carrying
    resource_type 'pipeline'. candidate_row_count=3 pins the SQL
    PERFORMANCE_OPTIMIZED/serverless filters + the score-side duration gate.
    """
    TABLES["billing.list_prices"] += [price_row(SCO_JOB_SKU), price_row(SCO_PIPE_SKU)]
    ws = WS
    TABLES["lakeflow.jobs"] += [
        _fj_job(ws, "job-sco-long", "serverless-nightly-etl"),
        _fj_job(ws, "job-sco-short", "serverless-quick-refresh"),
    ]
    TABLES["lakeflow.pipelines"].append(
        _dlt_pipeline(ws, "pipe-sco-long", "serverless-triggered-ingest", continuous=False))
    TABLES["billing.usage"] += _sco_usage(ws, "job-sco-long", product="JOBS", sku=SCO_JOB_SKU, daily_dbu=200.0)
    TABLES["billing.usage"] += _sco_usage(ws, "pipe-sco-long", product="DLT", sku=SCO_PIPE_SKU, daily_dbu=100.0)
    TABLES["billing.usage"] += _sco_usage(ws, "job-sco-short", product="JOBS", sku=SCO_JOB_SKU, daily_dbu=200.0)
    TABLES["lakeflow.job_run_timeline"] += _sco_job_runs(ws, "job-sco-long", run_min=30)
    TABLES["lakeflow.job_run_timeline"] += _sco_job_runs(ws, "job-sco-short", run_min=3)
    TABLES["lakeflow.pipeline_update_timeline"] += _sco_pipe_updates(ws, "pipe-sco-long", dur_min=30)


# --- FIN-014 serverless_cost_optimized value-invariant fixture ---------------
def invariant_sco_books_zero(ws: str = WS, jid: str = "job-sco-inv") -> dict:
    """THE FIN-014 invariant: a long serverless PERFORMANCE_OPTIMIZED job is surfaced,
    but the ~50% DBU reduction is modeled (same $/DBU, no matched before/after run), so
    it books $0 (advisory) — the modeled figure is only the upper bound (high > 0).
    Self-contained (replaces the committed rows)."""
    return {
        "billing.list_prices": [price_row(SCO_JOB_SKU)],
        "lakeflow.jobs": [_fj_job(ws, jid, "inv-serverless")],
        "billing.usage": _sco_usage(ws, jid, product="JOBS", sku=SCO_JOB_SKU, daily_dbu=200.0),
        "lakeflow.job_run_timeline": _sco_job_runs(ws, jid, run_min=30),
    }


# --- FIN-013 enable_serverless fixtures --------------------------------------
# Classic/pro SQL warehouses that are warm-but-idle. Isolated from warehouse_autostop:
# a tight auto_stop (10 min, <= its max_acceptable_minutes 30) drops them from that
# rule's candidate gate, and they have NO warehouse_events (which warehouse_autostop's
# interval reconstruction needs). Conversely warehouse_autostop's warehouses never
# enter THIS rule: enable_serverless's cost CTE requires product_features.is_serverless
# = false, which their billing rows (via _wh_billed_hours) never set (null != false).
ES_DAYS = 14           # the rule's SQL reconstructs a 14-day hourly grid
# Fill only days 1..13 — NEVER the 14-day boundary day. The SQL window is
# `usage_start_time >= current_timestamp() - INTERVAL 14 DAYS`, so a fixture hour on the
# day exactly 14 days ago (d=14) sits ON the cutoff and clears it or not depending on the
# wall-clock TIME OF DAY the test runs: its 08:00-17:00 hours flip in/out run to run,
# drifting the golden savings by ~$0.6 (> the $0.5 tolerance). Days 1..13 are 13 days ago
# or newer, so they are strictly inside the window at ANY time of day and the reconstructed
# hours — and thus the savings — are deterministic. (13 full days is the most a 14-day
# window can contain without straddling; the rule needs only min_observation_days = 5.)
ES_FILL_DAYS = ES_DAYS - 1


def _es_billed_hours(ws: str, wid: str, *, qty: float, days: int = ES_FILL_DAYS,
                     hours=range(8, 18)) -> list[dict]:
    """Warm/billed SQL-warehouse hours carrying product_features.is_serverless=false
    (the enable_serverless candidate filter), keyed by usage_metadata.warehouse_id and
    priced at the PRO SQL SKU. One idle-warm hour per billed hour with no query."""
    rows = []
    for d in range(1, days + 1):
        for h in hours:
            rows.append({
                "workspace_id": ws, "sku_name": WH_SKU, "cloud": "AWS", "usage_unit": "DBU",
                "usage_start_time": {"@rel": -d, "@time": f"{h:02d}:00:00"},
                "usage_end_time": {"@rel": -d, "@time": f"{h:02d}:59:00"},
                "usage_date": {"@rel": -d}, "usage_quantity": f"{qty:.2f}",
                "record_type": "ORIGINAL", "billing_origin_product": "SQL",
                "product_features": {"is_serverless": False},
                "usage_metadata": {"warehouse_id": wid},
            })
    return rows


def _add_enable_serverless():
    """Warm-but-idle PRO SQL warehouses exercising the FIN-013 estimated rebuild:

    * wh-es-idle — PRO, warm 10h/day but active only 4h/day => idle 60% => FIRES
      ESTIMATED: books $0 (the headline credits an ESTIMATED cloud VM cost), low = the
      MEASURABLE DBU-only floor, high = net incl. VM.
    * wh-es-busy — PRO, warm 10h/day but active 9h/day => idle 10% < the pro gate (0.15)
      => CANDIDATE ROW but SUPPRESSED at the score-side min_idle_fraction gate.

    Both fill ES_FILL_DAYS (13) days of hours, all strictly inside the SQL's 14-day
    window so the reconstructed hourly series is deterministic regardless of run time
    (see the ES_FILL_DAYS note above). 6 DBU/warm-hour => 130 warm h x 6 DBU x $0.55 =
    ~$429/mo, comfortably above the min_monthly_cost_usd=300 gate with margin (the earlier
    4 DBU x 14 days landed at exactly $308, so shrinking to 13 days dropped it below the
    gate — sized up here so the scenario is robust to the day count). Expected: 2 candidate
    rows, 1 finding (estimated, books $0, low <= point <= high). candidate_row_count=2 pins
    the SQL is_serverless=false filter + the idle gate.
    """
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    ws = WS
    TABLES["compute.warehouses"] += [
        _warehouse(ws, "wh-es-idle", "pro-mostly-idle", wtype="PRO", auto_stop=10),
        _warehouse(ws, "wh-es-busy", "pro-mostly-busy", wtype="PRO", auto_stop=10),
    ]
    TABLES["billing.usage"] += _es_billed_hours(ws, "wh-es-idle", qty=6.0)
    TABLES["billing.usage"] += _es_billed_hours(ws, "wh-es-busy", qty=6.0)
    # wh-es-idle: active in 4 of 10 warm hours => 6 idle-warm/day (idle_fraction 0.60).
    TABLES["query.history"] += _wh_queries(ws, "wh-es-idle", days=ES_FILL_DAYS, hours=(9, 11, 13, 15))
    # wh-es-busy: active in 9 of 10 warm hours => 1 idle-warm/day (idle_fraction 0.10).
    TABLES["query.history"] += _wh_queries(ws, "wh-es-busy", days=ES_FILL_DAYS, hours=tuple(range(8, 17)))


# --- FIN-013 enable_serverless value-invariant fixture -----------------------
def invariant_es_estimated_books_zero(ws: str = WS, wid: str = "wh-es-inv") -> dict:
    """THE FIN-013 invariant: a warm-but-idle classic/pro warehouse is surfaced as
    ESTIMATED (the headline credits an estimated cloud VM cost), so it books $0 — but the
    measurable DBU-only floor (low) and the VM-included ceiling (high) bound the estimate
    (low <= point <= high). Self-contained (replaces the committed rows)."""
    return {
        "billing.list_prices": [price_row(WH_SKU)],
        "compute.warehouses": [_warehouse(ws, wid, "inv-serverless", wtype="PRO", auto_stop=10)],
        "billing.usage": _es_billed_hours(ws, wid, qty=6.0),
        "query.history": _wh_queries(ws, wid, days=ES_FILL_DAYS, hours=(9, 11, 13, 15)),
    }


# --- jobs_compute_rightsize (FIN-016 Phase 3: p95 peak veto) -----------------
# Over-provisioned JOB compute. Job clusters are EPHEMERAL (one per run), so the rule
# aggregates node_timeline by the recurring JOB across all its run-clusters (mapped
# via billing.usage.usage_metadata), splits driver vs worker utilization, and
# classifies the dominant symptom. FIN-016 adds a p95 PEAK VETO: a job idle on
# AVERAGE but spiking at its p95 needs the compute at the burst, so it must NOT be
# downsized. These fixtures prove the veto end-to-end on the real percentile_approx
# the SQL emits — the average alone could not see it.
#   * job-driver-bound — workers idle at BOTH the average (2%) and the p95 while the
#                        driver works (40%) -> FIRES driver_bound (reclaim worker share).
#   * job-bursty       — workers idle on AVERAGE (~31%, below headroom) but the p95
#                        spikes to ~72% -> the peak needs them, so VETOED: a candidate
#                        row that yields NO finding (the FIN-016 behaviour the average
#                        would have booked as idle_workers).
#   * job-healthy      — workers busy (60%) -> suppressed on the averages (control).
# candidate_row_count=3 pins that all three survive the SQL gate (cost>0, >=5 runs) and
# the split happens in score(). Priced at the captured JOBS_COMPUTE rate; node specs
# from compute.node_types make the worker cost share real (m5.2xlarge workers, 8 cores,
# over an m5.xlarge driver, 4 cores -> worker share 32/36).
JCR_JC_SKU = "ENTERPRISE_JOBS_COMPUTE"     # $0.20/DBU (captured; the job-compute rate)
JCR_DAYS = 6                               # >= min_observation_days (5) and >= min_runs (5)
JCR_DRIVER_NT = "m5.xlarge"                # 4 cores / 16 GB
JCR_WORKER_NT = "m5.2xlarge"               # 8 cores / 32 GB
JCR_WORKERS = 4


def _jcr_job(ws: str, job_id: str, name: str) -> dict:
    """A lakeflow.jobs SCD row (live: delete_time NULL) supplying the job name."""
    return {
        "workspace_id": ws, "job_id": job_id, "name": name,
        "creator_id": "u1", "run_as": "ds@example.com",
        "change_time": {"@rel": -JCR_DAYS - 1, "@time": "00:00:00"},
        "delete_time": None,
    }


def _jcr_cluster(ws: str, cid: str, day: int) -> dict:
    """A JOB-source cluster SCD row for one ephemeral run-cluster (change_time on its
    run day; the latest across a job's runs supplies latest_cfg's worker count/nodes)."""
    return {
        "workspace_id": ws, "cluster_id": cid, "cluster_name": f"job-run-{cid}",
        "owned_by": "ds@example.com", "cluster_source": "JOB",
        "worker_node_type": JCR_WORKER_NT, "driver_node_type": JCR_DRIVER_NT,
        "worker_count": JCR_WORKERS, "auto_termination_minutes": None,
        "dbr_version": "14.3.x-scala2.12",
        "change_time": {"@rel": -day, "@time": "00:00:00"},
        "delete_time": None,
    }


def _jcr_billed(ws: str, cid: str, job_id: str, day: int, *, dbu: float) -> dict:
    """One JOBS_COMPUTE billing.usage row for a run-cluster, carrying BOTH cluster_id
    and job_id in usage_metadata (the ephemeral cluster -> job map the rule needs)."""
    return {
        "workspace_id": ws, "sku_name": JCR_JC_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -day, "@time": "00:00:00"},
        "usage_end_time": {"@rel": -day, "@time": "23:59:00"},
        "usage_date": {"@rel": -day}, "usage_quantity": f"{dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "JOBS_COMPUTE",
        "usage_metadata": {"cluster_id": cid, "job_id": job_id},
    }


def _jcr_nodes(ws: str, cid: str, day: int, *, driver: bool, cpus: list[float],
               mem: float) -> list[dict]:
    """Per-minute node_timeline samples for one node (driver or worker) on `day`, one
    row per CPU value in `cpus`, all at mem_used_percent `mem`. The `driver` flag is
    what lets the rule split driver from worker utilization and take their p95 peaks."""
    return [{
        "workspace_id": ws, "cluster_id": cid,
        "instance_id": f"i-{cid}-{'d' if driver else 'w'}",
        "start_time": {"@rel": -day, "@time": _min_time(540 + i)},
        "end_time": {"@rel": -day, "@time": _min_time(540 + i + 1)},
        "driver": driver,
        "cpu_user_percent": float(c), "cpu_system_percent": 0.0,
        "cpu_wait_percent": 0.0, "mem_used_percent": float(mem), "mem_swap_percent": 0.0,
        "network_received_bytes": 0, "network_sent_bytes": 0,
    } for i, c in enumerate(cpus)]


def _add_jobs_compute_rightsize():
    """Recurring jobs on ephemeral JOB clusters exercising the FIN-016 p95 peak veto
    (see the section header). Expected: 3 candidate rows, 1 finding (driver_bound)."""
    TABLES["billing.list_prices"].append(price_row(JCR_JC_SKU))
    ws = WS
    TABLES["compute.node_types"] += [
        {"account_id": "acct", "node_type": JCR_DRIVER_NT, "core_count": 4.0,
         "memory_mb": 16384, "gpu_count": 0},
        {"account_id": "acct", "node_type": JCR_WORKER_NT, "core_count": 8.0,
         "memory_mb": 32768, "gpu_count": 0},
    ]
    TABLES["lakeflow.jobs"] += [
        _jcr_job(ws, "jcr-driver-bound", "nightly-pandas-etl"),
        _jcr_job(ws, "jcr-bursty", "hourly-spiky-agg"),
        _jcr_job(ws, "jcr-healthy", "balanced-etl"),
    ]
    # (job_id, cluster prefix, worker CPU profile, driver CPU profile, worker mem, driver mem).
    # The worker CPU list is per-run; percentile_approx pools it across all runs, so the
    # bursty job's pooled p95 (30x15% + 12x72% => ~72%) trips the veto while its pooled
    # average (~31%) stays under headroom — the exact case the average alone missed.
    scenarios = [
        ("jcr-driver-bound", "cdb", [2.0] * 6, [40.0] * 6, 30.0, 50.0),
        ("jcr-bursty", "cbu", [15.0] * 5 + [72.0] * 2, [30.0] * 3, 35.0, 45.0),
        ("jcr-healthy", "che", [60.0] * 6, [55.0] * 6, 65.0, 60.0),
    ]
    for job_id, prefix, wcpus, dcpus, wmem, dmem in scenarios:
        for run in range(JCR_DAYS):
            day = run + 2                     # days -2..-7, strictly inside the 30-day window
            cid = f"{prefix}-{run}"
            TABLES["compute.clusters"].append(_jcr_cluster(ws, cid, day))
            TABLES["billing.usage"].append(_jcr_billed(ws, cid, job_id, day, dbu=300.0))
            TABLES["compute.node_timeline"] += _jcr_nodes(ws, cid, day, driver=False, cpus=wcpus, mem=wmem)
            TABLES["compute.node_timeline"] += _jcr_nodes(ws, cid, day, driver=True, cpus=dcpus, mem=dmem)


# =========================================================================
# Rules promoted out of Labs (2026-09-23). Every warehouse below is SERVERLESS in
# compute.warehouses and bills WITHOUT product_features.is_serverless, so the older
# warehouse rules' goldens (warehouse_autostop's type filter, enable_serverless's
# is_serverless=false filter) never see them. Queries that do real work carry
# statement_type SELECT + task time, so warehouse_keepalive_queries only treats the
# statements meant as keep-alives as trivial.
# =========================================================================
# Kept small on purpose: every fixture table is ONE literal UNION ALL view on local Spark,
# and ~2,000 billing rows exhausted the 8g driver heap (Java heap space) mid-suite.
PR_DAYS = 5          # == min_observation_days (5), inside every 14/30-day window


def _pr_wh(wid: str, name: str, *, size: str = "Small", auto_stop: int = 10,
           min_clusters: int = 1, max_clusters: int = 1) -> dict:
    row = _warehouse(WS, wid, name, wtype="SERVERLESS", auto_stop=auto_stop, size=size)
    row.update(min_clusters=min_clusters, max_clusters=max_clusters)
    return row


def _pr_billed(wid: str, day: int, hour: int, dbu: float) -> dict:
    return {
        "workspace_id": WS, "sku_name": WH_SKU, "cloud": "AWS", "usage_unit": "DBU",
        "usage_start_time": {"@rel": -day, "@time": f"{hour:02d}:00:00"},
        "usage_end_time": {"@rel": -day, "@time": f"{hour:02d}:59:00"},
        "usage_date": {"@rel": -day}, "usage_quantity": f"{dbu:.2f}",
        "record_type": "ORIGINAL", "billing_origin_product": "SQL",
        "usage_metadata": {"warehouse_id": wid},
    }


def _pr_query(wid: str, sid: str, day: int, start: str, end: str, *, task_ms: int = 60_000,
              cached: bool = False, source: dict | None = None, **extra) -> dict:
    row = {
        "workspace_id": WS, "statement_id": sid, "executed_by": "analyst@example.com",
        "compute": {"type": "WAREHOUSE", "cluster_id": None, "warehouse_id": wid},
        "statement_type": "SELECT", "execution_status": "FINISHED",
        "total_task_duration_ms": task_ms, "from_result_cache": cached,
        "start_time": {"@rel": -day, "@time": start}, "end_time": {"@rel": -day, "@time": end},
        "client_application": "Databricks SQL Dashboard",
    }
    if source:
        row["query_source"] = source
    row.update(extra)
    return row


# --- warehouse_min_clusters ---------------------------------------------------
def _add_warehouse_min_clusters():
    """Two LARGE serverless warehouses up 08:00-18:00 on 5 days, each serving a light
    load (one 5-minute query an hour, so ONE cluster covers every minute):

    * wh-mc-floor — min_clusters = 2: warehouse_events show 2 clusters the whole time,
      so half its cluster-minutes are held only by the floor -> FIRES (estimated).
      Billed 80 DBU/h = 2 x LARGE's published 40 DBU/h, so the rate sanity check holds.
    * wh-mc-one — min_clusters = 1 -> not a candidate (SQL filter), so it carries no
      events, billing or queries.

    Expected: 1 candidate row + 1 finding, ~half of wh-mc-floor's cost."""
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    TABLES["compute.warehouses"] += [
        _pr_wh("wh-mc-floor", "bi-floor-2", size="Large", min_clusters=2, max_clusters=4),
        _pr_wh("wh-mc-one", "bi-floor-1", size="Large", min_clusters=1, max_clusters=4),
    ]
    # wh-mc-one needs no events/billing/queries: the candidates filter drops it first.
    for wid, clusters in (("wh-mc-floor", 2),):
        for d in range(1, PR_DAYS + 1):
            TABLES["compute.warehouse_events"] += [
                {"workspace_id": WS, "warehouse_id": wid, "event_type": "STARTING",
                 "cluster_count": clusters, "event_time": {"@rel": -d, "@time": "08:00:00"}},
                {"workspace_id": WS, "warehouse_id": wid, "event_type": "STOPPED",
                 "cluster_count": 0, "event_time": {"@rel": -d, "@time": "18:00:00"}},
            ]
            for h in range(8, 18):
                TABLES["billing.usage"].append(_pr_billed(wid, d, h, 40.0 * clusters))
                TABLES["query.history"].append(_pr_query(
                    wid, f"stmt-{wid}-{d:02d}-{h:02d}", d, f"{h:02d}:10:00", f"{h:02d}:15:00"))


# --- warehouse_keepalive_queries ---------------------------------------------
def _add_warehouse_keepalive_queries():
    """wh-ka-bi (10-min auto-stop) does real work 09:00-11:00 but a dashboard poller
    sends a result-cache SELECT every hour around the clock, so it bills all
    24 hours: 22 of them hold nothing but those cache hits -> FIRES (estimated),
    priced as those hours less one auto-stop tail per contiguous run.

    Expected: 1 candidate row + 1 finding."""
    wid = "wh-ka-bi"
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    TABLES["compute.warehouses"].append(_pr_wh(wid, "bi-keepalive"))
    for d in range(1, PR_DAYS + 1):
        for h in range(24):
            TABLES["billing.usage"].append(_pr_billed(wid, d, h, 6.0))
            # one ping per hour is enough: an hour is keep-alive when a trivial
            # statement starts in it and no real one runs.
            TABLES["query.history"].append(_pr_query(
                wid, f"stmt-{wid}-{d:02d}-{h:02d}-ping", d,
                f"{h:02d}:30:00", f"{h:02d}:30:01", task_ms=0, cached=True))
        for h in (9, 10):
            TABLES["query.history"].append(_pr_query(
                wid, f"stmt-{wid}-{d:02d}-{h:02d}-real", d, f"{h:02d}:05:00", f"{h:02d}:30:00"))


# --- job_task_retry_waste -----------------------------------------------------
def _add_job_task_retry_waste():
    """job-rt-flaky runs twice a day for 10 days; every run ends SUCCEEDED, but on 6
    of them (6 different days) task 'load_orders' FAILED once and passed on retry.
    Each attempt takes 10 minutes, so a retried run spent half its task time on the
    failed attempt. Runs bill 100 DBU ($20) each.

    job-rt-clean — same schedule, never retries -> dropped at the SQL HAVING.

    Expected: 1 candidate row + 1 finding (retry rate 30%, estimated)."""
    TABLES["billing.list_prices"].append(price_row(FJ_SKU))
    for jid, retried_days in (("job-rt-flaky", {1, 2, 4, 5, 7, 9}), ("job-rt-clean", set())):
        TABLES["lakeflow.jobs"].append(_fj_job(WS, jid, jid.replace("job-rt-", "") + "-ingest"))
        for d in range(1, 11):
            for k, hour in enumerate((1, 13)):
                rid = f"run-{jid}-{d:02d}-{k}"
                start = f"{hour:02d}:00:00"
                retried = k == 0 and d in retried_days
                end = f"{hour:02d}:{20 if retried else 10}:00"
                TABLES["lakeflow.job_run_timeline"].append({
                    "workspace_id": WS, "job_id": jid, "run_id": rid, "run_type": "JOB_RUN",
                    "trigger_type": "CRON", "result_state": "SUCCEEDED",
                    "period_start_time": {"@rel": -d, "@time": start},
                    "period_end_time": {"@rel": -d, "@time": end}})
                attempts = [("FAILED", "00", "10"), ("SUCCEEDED", "10", "20")] if retried \
                    else [("SUCCEEDED", "00", "10")]
                for a, (state, m0, m1) in enumerate(attempts):
                    TABLES["lakeflow.job_task_run_timeline"].append({
                        "workspace_id": WS, "job_id": jid, "job_run_id": rid,
                        "parent_run_id": rid, "run_id": f"{rid}-t{a}", "task_key": "load_orders",
                        "result_state": state,
                        "termination_code": "RUN_EXECUTION_ERROR" if state == "FAILED" else "SUCCESS",
                        "period_start_time": {"@rel": -d, "@time": f"{hour:02d}:{m0}:00"},
                        "period_end_time": {"@rel": -d, "@time": f"{hour:02d}:{m1}:00"}})
                if retried_days:  # the clean job is dropped at the HAVING before cost
                    TABLES["billing.usage"].append(_fj_usage(WS, jid, rid, d, 100.0))


# --- job_no_new_input ---------------------------------------------------------
def _add_job_no_new_input():
    """job-nni-rollup runs on a cron 4x a day for 5 days and reads main.sales.orders
    (lineage logs every run). A pipeline last wrote that table 5 days ago at 03:30, so
    only the 06:00 run that day saw new input; every run after it recomputed the same
    answer -> FIRES (estimated).

    job-nni-fresh reads main.sales.events, which a pipeline writes before every run -> every
    run has new input; a candidate row suppressed in score (share 0 / below floors).

    Expected: candidate rows for the job(s) with >= 5 no-new-input runs; 1 finding."""
    TABLES["billing.list_prices"].append(price_row(FJ_SKU))
    for jid, src in (("job-nni-rollup", "main.sales.orders"), ("job-nni-fresh", "main.sales.events")):
        TABLES["lakeflow.jobs"].append(_fj_job(WS, jid, jid.replace("job-nni-", "")))
        for d in range(1, PR_DAYS + 1):
            for hour in (0, 6, 12, 18):
                rid = f"run-{jid}-{d:02d}-{hour:02d}"
                TABLES["lakeflow.job_run_timeline"].append({
                    "workspace_id": WS, "job_id": jid, "run_id": rid, "run_type": "JOB_RUN",
                    "trigger_type": "CRON", "result_state": "SUCCEEDED",
                    "period_start_time": {"@rel": -d, "@time": f"{hour:02d}:00:00"},
                    "period_end_time": {"@rel": -d, "@time": f"{hour:02d}:20:00"}})
                TABLES["access.table_lineage"].append({
                    "workspace_id": WS, "metastore_id": "ms-sample", "entity_type": "JOB",
                    "entity_id": jid, "entity_run_id": rid, "source_type": "TABLE",
                    "source_table_full_name": src, "direct_access": True,
                    "target_table_full_name": None,
                    "event_time": {"@rel": -d, "@time": f"{hour:02d}:05:00"},
                    "event_date": {"@rel": -d}})
                if jid == "job-nni-fresh":
                    continue  # dropped at the HAVING before cost: no billing rows needed
                TABLES["billing.usage"].append({**_fj_usage(WS, jid, rid, d, 25.0),
                    "usage_start_time": {"@rel": -d, "@time": f"{hour:02d}:00:00"},
                    "usage_end_time": {"@rel": -d, "@time": f"{hour:02d}:20:00"}})
    def _write(tbl, d, hour):
        return {"workspace_id": WS, "metastore_id": "ms-sample", "entity_type": "PIPELINE",
                "entity_id": "pipe-sales", "target_type": "TABLE",
                "target_table_full_name": tbl, "source_table_full_name": None,
                "event_time": {"@rel": -d, "@time": f"{hour:02d}:30:00"},
                "event_date": {"@rel": -d}}
    TABLES["access.table_lineage"] += [_write("main.sales.orders", 6, 3),
                                       _write("main.sales.orders", 5, 3)]
    for d in range(1, PR_DAYS + 1):
        for hour in (3, 9, 15, 21):  # before every run of the fresh-input job
            TABLES["access.table_lineage"].append(_write("main.sales.events", d, hour))


# --- unviewed_scheduled_dashboards --------------------------------------------
def _add_unviewed_scheduled_dashboards():
    """Two dashboards refreshed every 2 hours on wh-dash for 5 days by 'lakeview-processing'
    (the scheduler), each query with real task time:

    * dash-unseen — last opened 20 days ago (outside the 14-day unviewed window,
      inside the 30-day audit lookback) -> FIRES (advisory, $0 booked).
    * dash-seen   — opened 2 days ago -> dropped by the SQL (recent view).

    Expected: 1 candidate row + 1 finding."""
    wid = "wh-dash"
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    TABLES["compute.warehouses"].append(_pr_wh(wid, "dash-refresh", auto_stop=10))
    def _audit(dash, day, hour, action, agent):
        return {"workspace_id": WS, "service_name": "dashboards", "action_name": action,
                "user_agent": agent, "request_params": {"dashboard_id": dash},
                "event_time": {"@rel": -day, "@time": f"{hour:02d}:00:30"},
                "event_date": {"@rel": -day}}
    for d in range(1, PR_DAYS + 1):
        for h in range(0, 24, 2):
            TABLES["billing.usage"].append(_pr_billed(wid, d, h, 8.0))
            for dash in ("dash-unseen", "dash-seen"):
                TABLES["query.history"].append(_pr_query(
                    wid, f"stmt-{dash}-{d:02d}-{h:02d}", d, f"{h:02d}:00:00", f"{h:02d}:02:00",
                    task_ms=30_000, source={"dashboard_id": dash}))
        # the audit log only has to SEE each dashboard (the signal-presence gate) and
        # show the refreshes as automated: one scheduler event a day is enough.
        for dash in ("dash-unseen", "dash-seen"):
            TABLES["access.audit"].append(
                _audit(dash, d, 6, "executeQuery", "lakeview-processing_1.0"))
    TABLES["access.audit"] += [
        _audit("dash-unseen", 20, 9, "getPublishedDashboard", "Mozilla/5.0"),
        _audit("dash-seen", 2, 9, "getPublishedDashboard", "Mozilla/5.0"),
    ]


# --- unpruned_repeated_queries ------------------------------------------------
def _add_unpruned_repeated_queries():
    """wh-scan runs two saved queries 6x a day for 5 days:

    * q-full-scan — reads 500 files / 3 GB a run with 1% of files pruned -> the
      no-pruning shape; dominates the task time -> FIRES (advisory, $0 booked).
    * q-pruned    — reads 10 files after pruning 400 -> well clustered, not flagged.

    Expected: 1 candidate row (the warehouse) + 1 finding."""
    wid = "wh-scan"
    TABLES["billing.list_prices"].append(price_row(WH_SKU))
    TABLES["compute.warehouses"].append(_pr_wh(wid, "reporting-scan", size="Medium"))
    for d in range(1, PR_DAYS + 1):
        for h in range(8, 14):
            TABLES["billing.usage"].append(_pr_billed(wid, d, h, 10.0))
            TABLES["query.history"] += [
                _pr_query(wid, f"stmt-{wid}-{d:02d}-{h:02d}-a", d, f"{h:02d}:00:00",
                          f"{h:02d}:08:00", task_ms=600_000,
                          source={"sql_query_id": "q-full-scan"},
                          read_files=500, pruned_files=5, read_bytes=3_000_000_000),
                _pr_query(wid, f"stmt-{wid}-{d:02d}-{h:02d}-b", d, f"{h:02d}:30:00",
                          f"{h:02d}:31:00", task_ms=20_000,
                          source={"sql_query_id": "q-pruned"},
                          read_files=10, pruned_files=400, read_bytes=50_000_000),
            ]


def main():
    _add_idle_apps()
    _add_continuous_pipeline()
    _add_warehouse_autostop()
    _add_idle_serving_endpoints()
    _add_cluster_autotermination()
    _add_interactive_to_job()
    _add_idle_zombie_clusters()
    _add_failing_jobs()
    _add_unused_data_jobs()
    _add_spot_fallback()
    _add_enable_photon_dbr()
    _add_serverless_cost_optimized()
    _add_enable_serverless()
    _add_jobs_compute_rightsize()
    _add_warehouse_min_clusters()
    _add_warehouse_keepalive_queries()
    _add_job_task_retry_waste()
    _add_job_no_new_input()
    _add_unviewed_scheduled_dashboards()
    _add_unpruned_repeated_queries()

    name = {  # system-table short name -> fixture filename
        "billing.usage": "billing_usage.jsonl",
        "billing.list_prices": "billing_list_prices.jsonl",
        "access.audit": "access_audit.jsonl",
        "access.table_lineage": "access_table_lineage.jsonl",
        "lakeflow.pipelines": "lakeflow_pipelines.jsonl",
        "lakeflow.pipeline_update_timeline": "lakeflow_pipeline_update_timeline.jsonl",
        "lakeflow.job_task_run_timeline": "lakeflow_job_task_run_timeline.jsonl",
        "lakeflow.job_run_timeline": "lakeflow_job_run_timeline.jsonl",
        "lakeflow.jobs": "lakeflow_jobs.jsonl",
        "compute.warehouses": "compute_warehouses.jsonl",
        "compute.warehouse_events": "compute_warehouse_events.jsonl",
        "compute.clusters": "compute_clusters.jsonl",
        "compute.node_timeline": "compute_node_timeline.jsonl",
        "compute.node_types": "compute_node_types.jsonl",
        "query.history": "query_history.jsonl",
        "serving.served_entities": "serving_served_entities.jsonl",
        "serving.endpoint_usage": "serving_endpoint_usage.jsonl",
    }
    # De-duplicate list_prices. Several rules legitimately price the SAME SKU
    # (cluster_autotermination and interactive_to_job both use
    # ENTERPRISE_ALL_PURPOSE_COMPUTE), and each _add_* appends its own price row. A
    # duplicate price row fans out the price_join and DOUBLES every cost that matches
    # it — so keep one row per identity. price_row() emits byte-identical dicts for a
    # given SKU, so identical-row dedup is exact.
    seen: set[str] = set()
    deduped: list[dict] = []
    for r in TABLES["billing.list_prices"]:
        key = json.dumps(r, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    TABLES["billing.list_prices"] = deduped

    for short, rows in TABLES.items():
        path = HERE / name[short]
        path.write_text("".join(json.dumps(r) + "\n" for r in rows))
        print(f"wrote {path.name}: {len(rows)} rows")


if __name__ == "__main__":
    main()
