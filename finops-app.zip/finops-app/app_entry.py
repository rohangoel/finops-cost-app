"""Databricks Apps entrypoint.

The app is a monorepo with two source roots (`backend/` and `rules/`). Databricks
Apps run `uvicorn app_entry:app` from the uploaded source root, so this shim adds
both roots to sys.path (via absolute paths derived from __file__, so it is robust
to the working directory) and exposes the FastAPI app.
"""

from __future__ import annotations

import os
import sys

_BASE = os.path.dirname(os.path.abspath(__file__))
for _sub in ("backend", "rules"):
    _path = os.path.join(_BASE, _sub)
    if _path not in sys.path:
        sys.path.insert(0, _path)

from finops.main import app  # noqa: E402  (path setup must run first)

__all__ = ["app"]
