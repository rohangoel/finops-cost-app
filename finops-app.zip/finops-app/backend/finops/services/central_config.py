"""Central-mode account selection — build the certified workspace-scope query that turns
a customer list into concrete Databricks account_ids.

The customer list has two possible sources, both landing in the same pure
:func:`parse_config` path:

* **A Unity Catalog table** (``main.team_field_dsa_ce.finops_central_account_config``) —
  the authoritative source in production. Operators (with a plain ``MODIFY`` table grant)
  maintain the account list there without touching code or redeploying the pipeline. The
  pipeline reads its rows at build time and feeds them through :func:`config_from_rows`.
* **``accounts.yaml``** (bundle data under ``precompute/central/``) — the one-time seed
  for that table and the fallback the pipeline uses when the table is missing/empty. It
  also remains the source of the scalar SETTINGS (lookback_days / currency / running_only
  / output catalog+schema); only the ``accounts`` LIST moved to the table.

Lives in the ``finops`` wheel (not beside ``precompute/central_pipeline.py``) so the SDP
pipeline imports it the same robust way it imports every other shared module — off the
installed wheel — rather than a synced sibling file.

The "overall account filter" is the Salesforce account name. ``cloud_type`` and
``databricks_account_id`` are OPTIONAL narrowings within it (a customer such as
Mercedes-Benz maps to dozens of account_ids across clouds, so narrowing lets you scope
to a subset). At build time ``central_pipeline`` runs :func:`certified_scope_sql` against
``main.certified.workspaces_latest`` to resolve the effective set of account_ids and the
``workspace_id -> account`` maps used to filter the fact tables and tag the output.

Pure/stringy on purpose (no Spark) so it unit-tests without a cluster.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from finops_rules.resolver import CERTIFIED_WORKSPACES

DEFAULT_OUTPUT_CATALOG = "main"
DEFAULT_OUTPUT_SCHEMA = "team_field_dsa_ce"
#: All central output objects share this prefix so nothing else in a shared schema is
#: touched (see the pre-flight collision check in the deploy docs).
TABLE_PREFIX = "finops_central_"


def _sql_str(s: str) -> str:
    """Single-quote a SQL string literal, rejecting quote/backslash/semicolon."""
    s = str(s)
    if "'" in s or "\\" in s or ";" in s:
        raise ValueError(f"illegal character in config value: {s!r}")
    return f"'{s}'"


@dataclass
class AccountSpec:
    """One customer entry. ``cloud_type`` / ``databricks_account_id`` narrow within the
    Salesforce account; both optional (None/empty = no narrowing).

    ``scope_by_account_id`` flips the match: instead of ``salesforce_account_name``,
    the entry matches purely by ``databricks_account_id`` and the
    ``salesforce_account_name`` becomes a DISPLAY LABEL applied to the tagged output.
    This is for an account whose workspaces carry no usable Salesforce name in the
    certified directory — e.g. the FE Vending Machine (one-env) estate, where ~90% of
    workspaces are unnamed but all sit in one Databricks account_id. The pipeline then
    scopes by that account_id and tags every matched workspace with the label so it
    shows up as one customer in the app."""

    salesforce_account_name: str
    cloud_type: tuple[str, ...] = field(default_factory=tuple)
    databricks_account_id: tuple[str, ...] = field(default_factory=tuple)
    scope_by_account_id: bool = False

    def predicate(self) -> str:
        """A WHERE-group matching this customer's workspaces in certified.workspaces_latest."""
        if self.scope_by_account_id:
            # Match by account_id only — salesforce_account_name is a display label here,
            # not a filter (the matched workspaces are largely unnamed in certified).
            vals = ", ".join(_sql_str(a) for a in self.databricks_account_id)
            parts = [f"account_id IN ({vals})"]
            if self.cloud_type:
                cvals = ", ".join(_sql_str(c) for c in self.cloud_type)
                parts.append(f"cloud_type IN ({cvals})")
            return "(" + " AND ".join(parts) + ")"
        parts = [f"salesforce_account_name = {_sql_str(self.salesforce_account_name)}"]
        if self.cloud_type:
            vals = ", ".join(_sql_str(c) for c in self.cloud_type)
            parts.append(f"cloud_type IN ({vals})")
        if self.databricks_account_id:
            vals = ", ".join(_sql_str(a) for a in self.databricks_account_id)
            parts.append(f"account_id IN ({vals})")
        return "(" + " AND ".join(parts) + ")"


#: Workspaces are overwhelmingly CANCELLED in the central estate (e.g. 27.6k of 29.7k for
#: MB+Bayer). Default to RUNNING only — the addressable, live workspaces — which also
#: keeps the scan and output focused.
RUNNING_STATUS = "RUNNING"


@dataclass
class CentralConfig:
    accounts: list[AccountSpec]
    output_catalog: str = DEFAULT_OUTPUT_CATALOG
    output_schema: str = DEFAULT_OUTPUT_SCHEMA
    lookback_days: int = 30
    currency: str = "USD"
    #: Restrict to workspace_status = 'RUNNING'. Default True: cancelled/banned workspaces
    #: are not actionable and dominate the count. Set false to include every status.
    running_only: bool = True

    def workspace_status_clause(self, *, prefix: str = "AND") -> str:
        """SQL predicate restricting to running workspaces, or '' when running_only is off."""
        return f" {prefix} workspace_status = '{RUNNING_STATUS}'" if self.running_only else ""

    def output_fqn(self, table_suffix: str) -> str:
        """Fully-qualified, prefixed output table, e.g. ('recommendations') ->
        main.team_field_dsa_ce.finops_central_recommendations."""
        return f"{self.output_catalog}.{self.output_schema}.{TABLE_PREFIX}{table_suffix}"


def parse_config(data: dict) -> CentralConfig:
    """Build a :class:`CentralConfig` from a parsed YAML/JSON dict. Raises on a malformed
    ``accounts`` list so a bad config fails fast at pipeline start, not mid-scan."""
    raw_accounts = data.get("accounts")
    if not raw_accounts or not isinstance(raw_accounts, list):
        raise ValueError("central config requires a non-empty 'accounts' list")

    accounts: list[AccountSpec] = []
    for i, a in enumerate(raw_accounts):
        if not isinstance(a, dict) or not a.get("salesforce_account_name"):
            raise ValueError(f"accounts[{i}] must be a mapping with 'salesforce_account_name'")
        scope_by_account_id = bool(a.get("scope_by_account_id", False))
        databricks_account_id = tuple(_as_list(a.get("databricks_account_id")))
        if scope_by_account_id and not databricks_account_id:
            # Matching by account_id needs at least one id; the name is only a label.
            raise ValueError(
                f"accounts[{i}] sets scope_by_account_id but has no databricks_account_id"
            )
        accounts.append(
            AccountSpec(
                salesforce_account_name=str(a["salesforce_account_name"]),
                cloud_type=tuple(_as_list(a.get("cloud_type"))),
                databricks_account_id=databricks_account_id,
                scope_by_account_id=scope_by_account_id,
            )
        )
    return CentralConfig(
        accounts=accounts,
        output_catalog=str(data.get("output_catalog", DEFAULT_OUTPUT_CATALOG)),
        output_schema=str(data.get("output_schema", DEFAULT_OUTPUT_SCHEMA)),
        lookback_days=int(data.get("lookback_days", 30)),
        currency=str(data.get("currency", "USD")),
        running_only=bool(data.get("running_only", True)),
    )


def load_config_dict(path: str) -> dict:
    """Read the raw config yaml into a plain dict (``{}`` if empty). Kept separate from
    :func:`load_config` so a caller can split the scalar SETTINGS from the ``accounts``
    list — the pipeline sources settings from the yaml while taking accounts from the
    config table (see :func:`config_from_rows`)."""
    import yaml

    with open(path) as fh:
        return yaml.safe_load(fh) or {}


def load_config(path: str) -> CentralConfig:
    return parse_config(load_config_dict(path))


#: Columns on the account-config table that are operational, not part of an AccountSpec.
#: Dropped when turning a table row into a parse_config account dict.
_ACCOUNT_ROW_META = frozenset({"enabled", "note", "updated_by", "updated_at"})


def _row_to_account_dict(row: dict) -> dict:
    """Map one ``finops_central_account_config`` row (a Spark ``Row.asDict()`` /
    plain dict) to the account-entry shape :func:`parse_config` expects. ARRAY<STRING>
    columns arrive as lists (or NULL); ``_as_list`` normalizes both. Only the AccountSpec
    fields are kept — audit/toggle columns in :data:`_ACCOUNT_ROW_META` are ignored."""
    return {
        "salesforce_account_name": row.get("salesforce_account_name"),
        "cloud_type": _as_list(row.get("cloud_type")),
        "databricks_account_id": _as_list(row.get("databricks_account_id")),
        "scope_by_account_id": bool(row.get("scope_by_account_id", False)),
    }


def config_from_rows(rows, *, settings: dict | None = None) -> CentralConfig:
    """Build a :class:`CentralConfig` from account-config TABLE rows plus the scalar
    ``settings`` (from the yaml). Pure/stringy: ``rows`` are plain dicts, so this
    unit-tests without a cluster. Delegates to :func:`parse_config` verbatim, so all
    validation (non-empty accounts, ``scope_by_account_id`` requires
    ``databricks_account_id``, and the injection guard in :meth:`AccountSpec.predicate`)
    is identical to the yaml path. Rows with ``enabled`` falsy are dropped defensively
    (the pipeline also filters ``WHERE enabled`` in SQL)."""
    settings = {k: v for k, v in dict(settings or {}).items() if k != "accounts"}
    accounts = [_row_to_account_dict(r) for r in rows if r.get("enabled", True)]
    return parse_config({**settings, "accounts": accounts})


def _as_list(v) -> list:
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [x for x in v if x is not None]
    return [v]


def certified_scope_sql(config: CentralConfig) -> str:
    """Resolve the config to concrete workspaces: one row per in-scope workspace with its
    account_id / cloud_type / salesforce_account_name. The pipeline derives (a) the set of
    account_ids to filter the fact tables and (b) the workspace->account tagging map from
    the result. ``account_id IS NOT NULL`` drops the stray NULL-account rows certified
    carries.

    For any ``scope_by_account_id`` entry the certified ``salesforce_account_name`` is
    unusable (mostly NULL), so it is overridden with the entry's display label via a CASE.
    Name-based entries keep the real certified name, and when there are no label entries
    the SELECT is byte-identical to the original single-name projection."""
    groups = " OR ".join(a.predicate() for a in config.accounts)
    label_specs = [a for a in config.accounts if a.scope_by_account_id]
    if label_specs:
        cases = "\n         ".join(
            f"WHEN {a.predicate()} THEN {_sql_str(a.salesforce_account_name)}"
            for a in label_specs
        )
        name_expr = (
            "CASE\n         " + cases
            + "\n         ELSE salesforce_account_name END AS salesforce_account_name"
        )
    else:
        name_expr = "salesforce_account_name"
    return (
        "SELECT DISTINCT workspace_id, workspace_name, account_id, cloud_type, "
        f"{name_expr}\n"
        f"FROM {CERTIFIED_WORKSPACES}\n"
        f"WHERE account_id IS NOT NULL{config.workspace_status_clause()} AND ({groups})"
    )
