"""The ``finops_central_recommendations`` contract — the single-account contract plus
the account dimension that central mode adds.

Central mode runs the identical rule engine + scoring (:mod:`contract_schema` /
``precompute_transform``) across a list of Databricks accounts in one scan, so the
scored rows are exactly ``CONTRACT_COLUMNS``. The account/cloud/customer columns are
attached AFTER scoring by a ``workspace_id`` join (a workspace belongs to one account),
so the ``mapInPandas`` scoring schema stays :func:`contract_schema.contract_ddl`; only
the final sink table carries these extra columns.

Kept beside :mod:`contract_schema` and pinned by
``precompute/tests/test_contract_schema_central.py`` against
``precompute/ddl/finops_central_recommendations.sql`` so the two faces cannot drift.
"""

from __future__ import annotations

from .contract_schema import CONTRACT_FIELDS

#: The account dimension appended to the single-account contract, in DDL order.
CENTRAL_EXTRA_FIELDS: tuple[tuple[str, str], ...] = (
    ("databricks_account_id", "string"),      # the Databricks account_id (globally unique)
    ("cloud_type", "string"),                 # aws | azure | gcp (from certified.workspaces_latest)
    ("salesforce_account_name", "string"),    # the customer (the "overall account filter")
)

#: Full central contract: single-account contract + account dimension.
CENTRAL_CONTRACT_FIELDS: tuple[tuple[str, str], ...] = CONTRACT_FIELDS + CENTRAL_EXTRA_FIELDS

CENTRAL_CONTRACT_COLUMNS: tuple[str, ...] = tuple(name for name, _ in CENTRAL_CONTRACT_FIELDS)

CENTRAL_EXTRA_COLUMNS: tuple[str, ...] = tuple(name for name, _ in CENTRAL_EXTRA_FIELDS)


def central_contract_ddl() -> str:
    """The full central contract as a Spark DDL string."""
    return ", ".join(f"{name} {typ}" for name, typ in CENTRAL_CONTRACT_FIELDS)
