"""Orchestrates a scoped fetch + filtering + sorting for the API layer.

Mode-agnostic: it only talks to a :class:`RecommendationSource`, so live and
precompute behave identically from here up.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..data import RecommendationSource

if TYPE_CHECKING:
    from ..data.account_view import AccountView
from ..identity import Scope
from ..models import (
    ExperimentalOverview,
    Recommendation,
    RecommendationGroup,
    TaggingOverview,
)
from ..models.group import group_id
from .aggregation import resource_count, waste_total
from .serverless_fit import evaluate as evaluate_serverless_fit

#: Sort keys the API accepts. There is deliberately no "waste" sort: the GUI no
#: longer surfaces a wasteful-spend figure to sort by (it was an estimate summed
#: across rules, easily misread as a bill). ``monthly_waste_usd`` survives on the
#: model as the resource's own billed spend, which the detail page labels honestly.
_SORTS = {
    "nba": lambda r: r.nba_score,
    "savings": lambda r: r.monthly_savings_usd,
}

# Effort bands from easiest to hardest — used to pick a group's "easiest win".
_EFFORT_ORDER = {"trivial": 0, "low": 1, "medium": 2, "high": 3}
_PRIORITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


class RecommendationService:
    def __init__(self, source: RecommendationSource):
        self.source = source

    # --- reads ----------------------------------------------------------------
    def list(
        self,
        scope: Scope,
        *,
        workspace_id: str | None = None,
        rule_id: str | None = None,
        resource_type: str | None = None,
        priority: str | None = None,
        min_savings: float | None = None,
        sort: str = "nba",
    ) -> list[Recommendation]:
        recs = self.source.fetch(scope)
        recs = self._filter(
            recs,
            workspace_id=workspace_id,
            rule_id=rule_id,
            resource_type=resource_type,
            priority=priority,
            min_savings=min_savings,
        )
        key = _SORTS.get(sort, _SORTS["nba"])
        recs.sort(key=key, reverse=True)
        return recs

    def facets(self, scope: Scope, account_view: "AccountView | None" = None) -> dict[str, list[str]]:
        """Distinct account-dimension values for the UI filter dropdowns — **dependent**,
        so the cloud / account-id filters cascade *within* the account chosen at the gate.

        Reads with ``apply_account_view=False`` (every account's rows) and then derives
        each facet applying only the filters ABOVE it in the hierarchy, so no dropdown
        collapses to its own current pick:

        * ``salesforce_account_name`` — unconstrained, so the gate always lists every
          customer (and "Change account" can reach any of them).
        * ``cloud_type`` — the clouds present *for the selected account*.
        * ``databricks_account_id`` — cascades one step further: the account-ids for the
          selected account AND the selected cloud, so choosing a cloud narrows the
          account-id dropdown to that cloud's ids only.

        Empty lists in single-account mode (the columns are all None), which the frontend
        uses to hide the controls."""
        recs = self.source.fetch(scope, apply_account_view=False)
        sfdc = account_view.salesforce_account_name if account_view else None
        cloud = account_view.cloud_type if account_view else None
        in_account = [r for r in recs if not sfdc or r.salesforce_account_name == sfdc]
        in_cloud = [r for r in in_account if not cloud or r.cloud_type == cloud]
        return {
            "salesforce_account_name": _distinct(recs, "salesforce_account_name"),
            "cloud_type": _distinct(in_account, "cloud_type"),
            "databricks_account_id": _distinct(in_cloud, "databricks_account_id"),
        }

    def list_grouped(
        self,
        scope: Scope,
        *,
        workspace_id: str | None = None,
        resource_type: str | None = None,
        priority: str | None = None,
        min_savings: float | None = None,
        rule_ids: list[str] | None = None,
        sort: str = "nba",
    ) -> list[RecommendationGroup]:
        """Overview rollup: one group per (workspace, resource) with its options.

        Collapses the several rules that may flag the same resource into a single
        row whose headline savings is the MAX of the options (they overlap, so
        the sum would double-count). Filters that make sense pre-grouping
        (workspace/resource_type) are applied to the members; savings/priority
        filters are applied to the resulting group's representative figure so the
        overview stays consistent with what the row shows.

        ``rule_ids`` filters by which recommendation TYPES apply to a resource,
        with ALL (conjunctive) semantics: a group is kept only when every
        requested rule is among its options — i.e. "resources where all of these
        opportunities apply at once". It is applied AFTER grouping (never as a
        member filter) precisely because a group spans rules: filtering members to
        one rule first would destroy the very overlap this filter selects on."""
        recs = self.source.fetch(scope)
        recs = self._filter(
            recs,
            workspace_id=workspace_id,
            rule_id=None,
            resource_type=resource_type,
            priority=None,
            min_savings=None,
        )
        groups = _group_recommendations(recs)
        wanted = {r for r in (rule_ids or []) if r}
        if wanted:
            groups = [
                g for g in groups
                if wanted <= {opt.rule_id for opt in g.options}
            ]
        if priority:
            groups = [g for g in groups if g.priority == priority.upper()]
        if min_savings is not None:
            groups = [g for g in groups if g.monthly_savings_usd >= min_savings]
        key = _SORTS.get(sort, _SORTS["nba"])
        groups.sort(key=key, reverse=True)
        return groups

    def get(self, scope: Scope, recommendation_id: str) -> Recommendation | None:
        # Searches the sidecar set (governance) and the experimental set (Labs) too,
        # since neither lives in fetch(), so a detail link opened from the Tagging &
        # Chargeback or Labs tab still resolves. Accepts a finding_key as well as a
        # recommendation_id: the latter changes every day, the former doesn't.
        for r in (
            self.source.fetch(scope)
            + self.source.fetch_sidecar(scope)
            + self.source.fetch_experimental(scope)
        ):
            if recommendation_id in (r.recommendation_id, r.finding_key):
                return r
        return None

    # --- the signed-in user's own findings (My findings, StopTheLeak) ------------
    # These deliberately ignore the caller's workspace scope: most recipients are
    # not admins of anything, and the finding is theirs because notify_recipient
    # names them (finops.routing). ``email`` must come from X-Forwarded-Email (see
    # deps.get_caller_email), never from the request. The set is fetch()'s, so
    # hidden rules, sidecar categories and experimental (Labs) rules stay out.
    def for_recipient(self, email: str) -> list[Recommendation]:
        """Every finding routed to ``email``, biggest saving first."""
        me = email.strip().lower()
        if not me:
            return []
        recs = [
            r for r in self.source.fetch(Scope(all_workspaces=True), apply_account_view=False)
            if r.notify_recipient and r.notify_recipient.lower() == me
        ]
        recs.sort(key=lambda r: r.monthly_savings_usd, reverse=True)
        return recs

    def find_for_recipient(self, email: str, key: str) -> Recommendation | None:
        """One of ``email``'s findings by finding_key (or recommendation_id)."""
        for r in self.for_recipient(email):
            if key in (r.finding_key, r.recommendation_id):
                return r
        return None

    def get_group_for_recipient(self, email: str, gid: str) -> RecommendationGroup | None:
        """The resource page for a recipient without workspace scope: only the
        findings on that resource that are routed to them."""
        members = [
            r for r in self.for_recipient(email)
            if group_id(r.workspace_id, r.resource_type, r.resource_id) == gid
        ]
        if not members:
            return None
        return _build_group(members)

    def get_group(self, scope: Scope, gid: str) -> RecommendationGroup | None:
        """Load one resource group by its stable id (for the detail page)."""
        members = [
            r
            for r in self.source.fetch(scope)
            if group_id(r.workspace_id, r.resource_type, r.resource_id) == gid
        ]
        if not members:
            return None
        return _build_group(members)

    def next_best_actions(self, scope: Scope, limit: int = 10) -> list[Recommendation]:
        recs = self.source.fetch(scope)
        recs.sort(key=lambda r: r.nba_score, reverse=True)
        return recs[:limit]

    # --- sidecar categories (Tagging & Chargeback tab) ------------------------
    def list_sidecar(
        self,
        scope: Scope,
        *,
        workspace_id: str | None = None,
        rule_id: str | None = None,
        resource_type: str | None = None,
        priority: str | None = None,
    ) -> list[Recommendation]:
        """The relocated sidecar-category findings (governance/tagging), scoped
        like the main list. Sorted by unattributable spend (``monthly_waste_usd``)
        rather than savings — these carry $0 savings by design, so the size of the
        governance gap is the meaningful ranking."""
        recs = self.source.fetch_sidecar(scope)
        recs = self._filter(
            recs,
            workspace_id=workspace_id,
            rule_id=rule_id,
            resource_type=resource_type,
            priority=priority,
            min_savings=None,
        )
        recs.sort(key=lambda r: r.monthly_waste_usd, reverse=True)
        return recs

    # --- experimental rules (Labs tab, Phase 4) -------------------------------
    def list_experimental(
        self,
        scope: Scope,
        *,
        workspace_id: str | None = None,
        rule_id: str | None = None,
        resource_type: str | None = None,
        priority: str | None = None,
    ) -> list[Recommendation]:
        """The relocated experimental (Phase 4) findings, scoped like the main list.
        Sorted by addressable spend (``monthly_waste_usd``) rather than savings —
        experimental findings are advisory and carry $0 booked savings, so the size
        of the addressable spend is the meaningful ranking."""
        recs = self.source.fetch_experimental(scope)
        recs = self._filter(
            recs,
            workspace_id=workspace_id,
            rule_id=rule_id,
            resource_type=resource_type,
            priority=priority,
            min_savings=None,
        )
        recs.sort(key=lambda r: r.monthly_waste_usd, reverse=True)
        return recs

    def experimental_overview(self, scope: Scope) -> ExperimentalOverview:
        """Headline + items for the Labs tab: the total addressable monthly spend the
        experimental findings identify (never a booked saving — these are advisory),
        plus counts and the findings themselves. The counts are intentionally separate
        from the main recommendation total, which excludes these rules entirely."""
        items = self.list_experimental(scope)
        return ExperimentalOverview(
            # One figure per spend pool, not per finding: overlapping rules on one
            # resource (or on the warehouse an alert bills to) would double it.
            total_addressable_monthly_usd=waste_total(items),
            recommendation_count=len(items),
            resource_count=resource_count(items),
            rule_count=len({r.rule_id for r in items}),
            workspace_count=len({r.workspace_id for r in items}),
            items=items,
        )

    def tagging_overview(self, scope: Scope) -> TaggingOverview:
        """Headline + items for the Tagging & Chargeback tab: the total
        unattributable monthly spend (the size of the governance gap), a count and
        the findings themselves. The count is intentionally separate from the main
        recommendation total, which excludes this category entirely."""
        items = self.list_sidecar(scope)
        return TaggingOverview(
            total_unattributable_monthly_usd=round(
                sum(r.monthly_waste_usd for r in items), 2
            ),
            recommendation_count=len(items),
            workspace_count=len({r.workspace_id for r in items}),
            items=items,
        )

    # --- internals ------------------------------------------------------------
    @staticmethod
    def _filter(
        recs: list[Recommendation],
        *,
        workspace_id: str | None,
        rule_id: str | None,
        resource_type: str | None,
        priority: str | None,
        min_savings: float | None,
    ) -> list[Recommendation]:
        # NB: the account-dimension filters (account/cloud/databricks_account_id) are
        # NOT applied here — they are global and applied once at the source's fetch
        # boundary (see data/account_view.py + deps.get_recommendation_service), so
        # they cover every read path, not only list/list_grouped.
        out = recs
        if workspace_id:
            out = [r for r in out if r.workspace_id == workspace_id]
        if rule_id:
            out = [r for r in out if r.rule_id == rule_id]
        if resource_type:
            out = [r for r in out if r.resource_type == resource_type]
        if priority:
            out = [r for r in out if r.priority == priority.upper()]
        if min_savings is not None:
            out = [r for r in out if r.monthly_savings_usd >= min_savings]
        return out


def _distinct(recs: list[Recommendation], attr: str) -> list[str]:
    """Sorted distinct non-null values of ``attr`` across recs (for filter dropdowns)."""
    return sorted({v for r in recs if (v := getattr(r, attr, None))})


def _group_recommendations(recs: list[Recommendation]) -> list[RecommendationGroup]:
    """Collapse recs sharing a (workspace, resource_type, resource_id) into groups."""
    from collections import defaultdict

    buckets: dict[str, list[Recommendation]] = defaultdict(list)
    for r in recs:
        buckets[group_id(r.workspace_id, r.resource_type, r.resource_id)].append(r)
    return [_build_group(members) for members in buckets.values()]


def _build_group(members: list[Recommendation]) -> RecommendationGroup:
    """Build one group from its member findings.

    Representative savings is the action-aware combination of the options on this
    resource (FIN-008): mutually-exclusive alternatives collapse to the best one,
    compatible tunings (auto-stop + right-size) compose onto the remaining
    counterfactual — bounded by the resource's cost, so it is never the naive sum
    (that survives only as ``options_savings_sum_usd``). Defaults reproduce the old
    MAX-across-options. Waste is the MAX (the resource's own monthly spend). Effort is
    the easiest option; priority the most urgent.

    Options are ordered by **monthly savings, highest first**: a resource usually
    matches several rules at once (an oversized cluster can often be downsized
    *and* moved to serverless), and the detail page lists them all in sequence, so
    the biggest-dollar analysis must lead. The group's ``nba_score`` stays the max
    across options so this ordering never changes where the resource ranks in the
    overview."""
    options = sorted(
        members, key=lambda r: (r.monthly_savings_usd, r.nba_score), reverse=True
    )
    top = options[0]
    # FIN-008: options on one resource share a scope, so combine them action-aware
    # (compatible tunings compose, exclusive alternatives collapse to the best) rather
    # than summing. Defaults to the historical max across options. The naive sum stays
    # available as options_savings_sum_usd below.
    from .aggregation import _contract_or_list, book_scope
    savings = book_scope(options, value=lambda r: float(r.monthly_savings_usd or 0.0))
    contract_savings = basis = cloud_savings = None
    if any(r.price_basis for r in options):
        contract_savings = round(book_scope(options, value=lambda r: _contract_or_list(r, "point")), 2)
        dollar = [r for r in options if r.monthly_savings_usd > 0] or options
        basis = "contract" if all(r.price_basis == "contract" for r in dollar) else "list"
    if any(r.monthly_cloud_savings_usd is not None for r in options):
        cloud_savings = round(book_scope(
            options, value=lambda r: float(r.monthly_cloud_savings_usd or 0.0)), 2)
    waste = max(r.monthly_waste_usd for r in options)
    savings_sum = round(sum(r.monthly_savings_usd for r in options), 2)
    easiest = min(options, key=lambda r: _EFFORT_ORDER.get(r.effort_band, 99))
    top_priority = min(
        (r.priority for r in options), key=lambda p: _PRIORITY_ORDER.get(p, 99)
    )
    n = len(options)
    action_label = top.rule_title if n == 1 else _multi_action_label(top.resource_type, n)
    return RecommendationGroup(
        group_id=group_id(top.workspace_id, top.resource_type, top.resource_id),
        workspace_id=top.workspace_id,
        workspace_name=top.workspace_name,
        workspace_url=top.workspace_url,
        resource_type=top.resource_type,
        resource_id=top.resource_id,
        resource_name=top.resource_name,
        action_label=action_label,
        category=top.category,
        option_count=n,
        monthly_savings_usd=round(savings, 2),
        monthly_waste_usd=round(waste, 2),
        options_savings_sum_usd=savings_sum,
        monthly_savings_contract_usd=contract_savings,
        price_basis=basis,
        monthly_cloud_savings_usd=cloud_savings,
        effort_band=easiest.effort_band,
        priority=top_priority,
        # Max across options, not the (savings-ordered) first one's — the group's
        # rank in the overview must not depend on how options are sorted.
        nba_score=max(r.nba_score for r in options),
        # Serverless-fit verdict for the detail page (warehouses/jobs only). Built
        # from the options so it never contradicts the recommendations shown.
        serverless_fit=evaluate_serverless_fit(top.resource_type, options),
        options=options,
    )


def _multi_action_label(resource_type: str, n: int) -> str:
    noun = {
        "warehouse": "warehouse",
        "cluster": "cluster",
        "job": "job",
        # Slug -> what an admin calls it; "serving_endpoint" would read as a typo.
        "serving_endpoint": "serving endpoint",
    }.get(resource_type, "resource")
    return f"{n} ways to optimize this {noun}"
