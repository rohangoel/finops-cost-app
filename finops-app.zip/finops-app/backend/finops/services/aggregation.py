"""In-memory roll-ups for the account overview and workspace drill-down.

Operates on a list of :class:`Recommendation` (whatever the active source
returned, already scoped). Fine for a PoC; a later optimization can push these
aggregations into SQL for very large accounts.

Overlapping fixes on ONE resource (e.g. a warehouse that could be auto-stopped
OR moved to serverless OR right-sized) must NOT be summed — you can only bank
one. So every dollar total here is computed over *resources*, each contributing
its single best option. This is the same collapse the grouped overview does; see
``services.recommendation_service._build_group``. Counts and breakdowns follow
the same one-per-resource basis so they reconcile with the headline totals.

Phase 0 savings-status scaffold (docs/SAVINGS_LOGIC_IMPLEMENTATION_PLAN.md §0.2):
the SAVINGS headline is a *booked lower bound* — per spend scope, the bookable
``monthly_savings_low_usd`` its options support; ``estimated`` / ``advisory``
options contribute exactly zero. Today every rule defaults to ``bookable`` with
``low == point``, so the booked total equals the old max-per-resource savings sum
(i.e. this change is inert). It only drops once Phase 0.3 reclassifies specific
rules. Waste, counts, and the "top opportunity" labels stay on the point estimate
— they describe the opportunity surface, not the booked floor, and after 0.3 the
per-category breakdown may exceed the booked headline by design (the difference is
the estimated/advisory opportunity).

FIN-008 action-aware aggregation (§2.3): the savings total is booked per SPEND
SCOPE, not naively per resource, so the same dollar is never banked twice. Every
finding names the spend pool it reclaims from via ``affected_spend_scope`` (default:
the resource's own identity). Within a scope, options combine by ``savings_composition``:
``additive`` tunings compose onto the remaining counterfactual (auto-stop cuts hours
while right-size cuts $/hour — a *combined* figure, bounded by the pool), while
``exclusive`` options are mutually-exclusive whole-resource alternatives (only the
best books, so a bigger migration supersedes the source tuning). See :func:`book_scope`.
With everything defaulting to ``exclusive`` + a per-resource scope this reduces to the
historical max-per-resource behavior. The naive "sum of all options" survives only as
the labeled, non-booked ``options_savings_sum_usd`` on each group.
"""

from __future__ import annotations

from collections import defaultdict

from ..models import (
    AccountOverview,
    CategoryBreakdown,
    PricedTotals,
    Recommendation,
    SavingsTier,
    WorkspaceDetail,
    WorkspaceSummary,
)


def _collapse_to_resources(recs: list[Recommendation]) -> list[Recommendation]:
    """One recommendation per (workspace, resource_type, resource_id): its
    single best (max-savings) option. Overlapping options on the same resource
    are mutually exclusive, so this is what's actually bankable and what the
    grouped overview shows as the resource's headline."""
    best: dict[tuple[str, str, str], Recommendation] = {}
    for r in recs:
        key = (r.workspace_id, r.resource_type, r.resource_id)
        cur = best.get(key)
        # Ties (typically several $0 advisory options) keep the one with the most spend
        # behind it, so the representative row doesn't depend on read order.
        if cur is None or (r.monthly_savings_usd, r.monthly_waste_usd) > (
            cur.monthly_savings_usd, cur.monthly_waste_usd
        ):
            best[key] = r
    return list(best.values())


def _scope_key(r: Recommendation) -> tuple[str, str]:
    """The spend pool a finding reclaims from (FIN-008). Findings that share a scope
    compete for the SAME dollars and are deduped to one bankable figure; findings with
    different scopes are additive across the portfolio. ``affected_spend_scope`` lets a
    rule name a pool shared across resources (a job billing on a cluster); absent it, the
    scope is the resource's own identity — the historical per-resource basis. Keyed with
    ``workspace_id`` so an explicit scope string never bleeds across workspaces (FIN-007)."""
    scope = getattr(r, "affected_spend_scope", None)
    if scope:
        return (r.workspace_id, scope)
    return (r.workspace_id, f"{r.resource_type}|{r.resource_id}")


def _is_additive(r: Recommendation) -> bool:
    return getattr(r, "savings_composition", "exclusive") == "additive"


def book_scope(recs: list[Recommendation], *, value, eligible=lambda r: True) -> float:
    """Action-aware savings for the options on ONE spend scope (FIN-008).

    * ``additive`` (compatible) options *compose*: sorted highest-first and applied to
      the REMAINING counterfactual, so two tunings on one resource combine into a bigger
      figure but can never together exceed the pool (auto-stop cuts idle hours, right-size
      cuts $/hour — genuinely stackable).
    * every other option is a mutually-exclusive whole-resource alternative (a migration,
      a delete, or the historical default): only the single best one books, and being an
      alternative to the additive stack a larger migration SUPERSEDES the source tuning.

    The scope books the better of the two paths, bounded by the scope's corrected cost
    (the largest waste among its findings — the pool can't give back more than it costs).
    ``value`` selects the metric (booked ``low`` vs. addressable ``point``); ``eligible``
    filters by status (bookable-only for the booked headline)."""
    cost = max((float(r.monthly_waste_usd or 0.0) for r in recs), default=0.0)
    additive = sorted(
        (value(r) for r in recs if eligible(r) and _is_additive(r)), reverse=True
    )
    remaining, stacked = cost, 0.0
    for v in additive:
        take = min(v, remaining)
        stacked += take
        remaining -= take
    exclusive = max(
        (value(r) for r in recs if eligible(r) and not _is_additive(r)), default=0.0
    )
    return min(max(stacked, exclusive), cost)


def _sum_by_scope(recs: list[Recommendation], *, value, eligible) -> float:
    """Book each spend scope once (:func:`book_scope`) and sum across scopes."""
    by_scope: dict[tuple[str, str], list[Recommendation]] = defaultdict(list)
    for r in recs:
        by_scope[_scope_key(r)].append(r)
    return round(
        sum(book_scope(rs, value=value, eligible=eligible) for rs in by_scope.values()), 2
    )


def waste_total(recs: list[Recommendation]) -> float:
    """Spend behind the findings, each spend pool counted ONCE: the largest
    ``monthly_waste_usd`` per scope (:func:`_scope_key`), summed across scopes. Several
    rules on one warehouse — or an alert / dashboard whose dollars are that warehouse's
    compute (``affected_spend_scope``) — describe the same spend; summing them would
    count it once per rule."""
    by_scope: dict[tuple[str, str], float] = defaultdict(float)
    for r in recs:
        k = _scope_key(r)
        by_scope[k] = max(by_scope[k], float(r.monthly_waste_usd or 0.0))
    return round(sum(by_scope.values()), 2)


def resource_count(recs: list[Recommendation]) -> int:
    """Distinct resources with at least one finding — what a findings count shows, so
    three rules on one warehouse count as one thing to look at."""
    return len({(r.workspace_id, r.resource_type, r.resource_id) for r in recs})


# Confidence tiers, worst→best, so the breakdown always renders in a stable order and a
# reader sees the least-certain money last. "booked" is its own tier (a bookable finding
# is banked regardless of its data-confidence label); estimated findings fall into the
# high/medium/low tier their evidence carries.
SAVINGS_TIER_ORDER = ("booked", "high", "medium", "low")


def _savings_tier(r: Recommendation) -> str:
    """Which headline tier this finding's savings belong to: ``booked`` for a bookable
    finding, else the ``evidence.confidence`` tier of an estimated finding (defaulting to
    ``low`` when a rule left it unset — unknown certainty is treated as least certain)."""
    if r.savings_status == "bookable":
        return "booked"
    conf = (r.evidence or {}).get("confidence")
    return conf if conf in ("high", "medium", "low") else "low"


def book_scope_breakdown(recs: list[Recommendation], *, value, eligible) -> dict[str, float]:
    """Like :func:`book_scope`, but returns the composed total ATTRIBUTED to each tier
    (:func:`_savings_tier`), so the tiers sum EXACTLY to ``book_scope`` for the same scope.

    Composition is identical: additive options stack (each option's actually-taken amount
    is credited to its own tier), otherwise the single best exclusive option wins and the
    whole (cost-bounded) amount is credited to that option's tier. This is what lets the
    account headline show "Booked + High + Medium + Low = the estimate" without double
    counting a dollar two options both claim."""
    cost = max((float(r.monthly_waste_usd or 0.0) for r in recs), default=0.0)
    alloc: dict[str, float] = defaultdict(float)
    remaining, stacked = cost, 0.0
    for v, tier in sorted(
        ((value(r), _savings_tier(r)) for r in recs if eligible(r) and _is_additive(r)),
        key=lambda x: x[0],
        reverse=True,
    ):
        take = min(v, remaining)
        if take > 0:
            alloc[tier] += take
            stacked += take
            remaining -= take
    best_v, best_tier = max(
        ((value(r), _savings_tier(r)) for r in recs if eligible(r) and not _is_additive(r)),
        key=lambda x: x[0],
        default=(0.0, None),
    )
    if best_v > stacked:
        # The exclusive alternative supersedes the additive stack; credit it alone.
        return {best_tier: min(best_v, cost)} if best_tier else {}
    return dict(alloc)


def _savings_tier_breakdown(recs: list[Recommendation]) -> dict[str, float]:
    """The account/workspace headline estimate split by tier, composed per spend scope so
    the tiers sum to :func:`_addressable_savings_total`. Point estimate, non-advisory."""
    by_scope: dict[tuple[str, str], list[Recommendation]] = defaultdict(list)
    for r in recs:
        by_scope[_scope_key(r)].append(r)
    agg: dict[str, float] = defaultdict(float)
    for rs in by_scope.values():
        for tier, amt in book_scope_breakdown(
            rs,
            value=lambda r: float(r.monthly_savings_usd or 0.0),
            eligible=lambda r: r.savings_status != "advisory",
        ).items():
            agg[tier] += amt
    return {t: round(agg[t], 2) for t in SAVINGS_TIER_ORDER if agg.get(t, 0.0) > 0.005}


def _savings_range(recs: list[Recommendation]) -> tuple[float, float]:
    """The (low, high) band around the non-advisory headline estimate: the composed
    conservative low and upper-scenario high, summed per spend scope. The estimate point
    (``_addressable_savings_total``) sits inside this band."""
    low = _sum_by_scope(
        recs,
        value=lambda r: float(r.monthly_savings_low_usd or 0.0),
        eligible=lambda r: r.savings_status != "advisory",
    )
    high = _sum_by_scope(
        recs,
        value=lambda r: float(r.monthly_savings_high_usd or 0.0),
        eligible=lambda r: r.savings_status != "advisory",
    )
    return low, high


def _booked_savings_total(recs: list[Recommendation]) -> float:
    """The booked headline lower bound: per spend scope, the bookable ``low`` its options
    support (additive tunings composed, else the best exclusive alternative), bounded by
    the scope cost; estimated/advisory options contribute zero. Summed across scopes.

    Computed from the RAW (un-collapsed) recs on purpose: a resource's best *point* option
    may be ``estimated`` while a smaller ``bookable`` one exists, and the floor must credit
    the bookable option rather than zero. With everything defaulting to ``bookable``,
    ``exclusive`` and ``low == point`` this equals the old max-per-resource savings sum, so
    the change is inert until rules opt into estimated/advisory (Phase 0.3) or additive."""
    return _sum_by_scope(
        recs,
        value=lambda r: float(r.monthly_savings_low_usd or 0.0),
        eligible=lambda r: r.savings_status == "bookable",
    )


def _addressable_savings_total(recs: list[Recommendation]) -> float:
    """The fuller, ESTIMATED opportunity: per spend scope, its non-advisory options'
    composed point estimate (bookable or estimated), summed across scopes. The booked
    total is the conservative floor of this; advisory findings (no dollars) are excluded.
    Surfaced next to the booked headline so the estimate is visible but never booked."""
    return _sum_by_scope(
        recs,
        value=lambda r: float(r.monthly_savings_usd or 0.0),
        eligible=lambda r: r.savings_status != "advisory",
    )


def _contract_or_list(r: Recommendation, which: str) -> float:
    """A finding's figure at "Your rates": its contract figure when it has one
    (price_basis='contract'), else its list figure. ``which`` = point | low | high."""
    if r.price_basis == "contract" and r.monthly_savings_contract_usd is not None:
        v = {"point": r.monthly_savings_contract_usd,
             "low": r.monthly_savings_contract_low_usd,
             "high": r.monthly_savings_contract_high_usd}[which]
        if v is not None:
            return float(v)
    return float({"point": r.monthly_savings_usd,
                  "low": r.monthly_savings_low_usd,
                  "high": r.monthly_savings_high_usd}[which] or 0.0)


def priced_totals(recs: list[Recommendation]) -> PricedTotals | None:
    """The contract-basis (blended) headline + cloud-VM layer, or None when the recs
    carry no contract/cloud data. Composed per spend scope exactly like the list
    headline, so a resource's overlapping options are still counted once."""
    contract_available = any(r.price_basis for r in recs)
    cloud_available = any(r.cloud_cost_30d_usd is not None for r in recs)
    if not (contract_available or cloud_available):
        return None
    non_adv = lambda r: r.savings_status != "advisory"  # noqa: E731
    out = PricedTotals(contract_available=contract_available, cloud_available=cloud_available)
    if contract_available:
        out.monthly_savings_usd = _sum_by_scope(
            recs, value=lambda r: _contract_or_list(r, "low"),
            eligible=lambda r: r.savings_status == "bookable")
        out.monthly_savings_addressable_usd = _sum_by_scope(
            recs, value=lambda r: _contract_or_list(r, "point"), eligible=non_adv)
        out.monthly_savings_low_usd = _sum_by_scope(
            recs, value=lambda r: _contract_or_list(r, "low"), eligible=non_adv)
        out.monthly_savings_high_usd = _sum_by_scope(
            recs, value=lambda r: _contract_or_list(r, "high"), eligible=non_adv)
        # The still-at-list share of the estimate; the rest is at contract rates.
        list_part = _sum_by_scope(
            recs, value=lambda r: float(r.monthly_savings_usd or 0.0),
            eligible=lambda r: non_adv(r) and r.price_basis != "contract")
        out.list_part_usd = round(min(list_part, out.monthly_savings_addressable_usd), 2)
        out.contract_part_usd = round(out.monthly_savings_addressable_usd - out.list_part_usd, 2)
        dollar = [r for r in recs if non_adv(r) and r.monthly_savings_usd > 0]
        out.contract_findings = sum(1 for r in dollar if r.price_basis == "contract")
        out.list_findings = len(dollar) - out.contract_findings
    if cloud_available:
        out.monthly_cloud_savings_usd = _sum_by_scope(
            recs, value=lambda r: float(r.monthly_cloud_savings_usd or 0.0),
            eligible=lambda r: r.monthly_cloud_savings_usd is not None)
        out.cloud_findings = sum(1 for r in recs if r.cloud_cost_30d_usd is not None)
        out.classic_findings = sum(
            1 for r in recs
            if r.cloud_cost_30d_usd is not None or r.monthly_cloud_savings_usd is not None
            or r.rule_id in _CLOUD_SAVING_RULES())
    return out


def _CLOUD_SAVING_RULES() -> set[str]:
    """Rules whose action can save cloud VM cost (Rule.cloud_savings != 'none')."""
    from finops_rules import list_rules

    return {r.id for r in list_rules() if getattr(r, "cloud_savings", "none") != "none"}


def account_overview(recs: list[Recommendation]) -> AccountOverview:
    # Collapse for the waste + count basis (overlapping fixes on one resource counted
    # once). Savings uses the booked lower bound, computed from the raw recs.
    resources = _collapse_to_resources(recs)
    by_ws_raw: dict[str, list[Recommendation]] = defaultdict(list)
    for r in recs:
        by_ws_raw[r.workspace_id].append(r)

    summaries = [_workspace_summary(wid, rs) for wid, rs in by_ws_raw.items()]
    # Rank by the fuller estimate (booked + estimated), not the booked floor, so a
    # workspace whose opportunity is mostly high/medium-confidence estimate ranks by
    # its real size rather than being buried. Ties break on the booked floor.
    summaries.sort(
        key=lambda s: (s.monthly_savings_addressable_usd, s.monthly_savings_usd),
        reverse=True,
    )

    low, high = _savings_range(recs)
    return AccountOverview(
        total_monthly_savings_usd=_booked_savings_total(recs),
        total_monthly_savings_addressable_usd=_addressable_savings_total(recs),
        total_monthly_savings_low_usd=low,
        total_monthly_savings_high_usd=high,
        savings_tiers=[
            SavingsTier(tier=t, monthly_savings_usd=v)
            for t, v in _savings_tier_breakdown(recs).items()
        ],
        total_monthly_waste_usd=waste_total(recs),
        recommendation_count=len(resources),
        workspace_count=len(by_ws_raw),
        workspaces=summaries,
        priced=priced_totals(recs),
    )


def _workspace_summary(workspace_id: str, raw_recs: list[Recommendation]) -> WorkspaceSummary:
    """``raw_recs`` are this workspace's un-collapsed findings. Waste/count collapse
    to one-per-resource; the savings headline is the booked lower bound. ``top_rule``
    / ``top_category`` rank on the point estimate — they name the biggest OPPORTUNITY,
    which is meaningful even when that opportunity is currently only ``estimated``."""
    resources = _collapse_to_resources(raw_recs)
    savings_by_rule: dict[str, float] = defaultdict(float)
    savings_by_cat: dict[str, float] = defaultdict(float)
    name = None
    for r in resources:
        savings_by_rule[r.rule_id] += r.monthly_savings_usd
        savings_by_cat[r.category] += r.monthly_savings_usd
        name = name or r.workspace_name
    top_rule = max(savings_by_rule, key=savings_by_rule.get) if savings_by_rule else None
    top_cat = max(savings_by_cat, key=savings_by_cat.get) if savings_by_cat else None
    return WorkspaceSummary(
        workspace_id=workspace_id,
        workspace_name=name,
        monthly_savings_usd=_booked_savings_total(raw_recs),
        monthly_savings_addressable_usd=_addressable_savings_total(raw_recs),
        monthly_waste_usd=waste_total(raw_recs),
        recommendation_count=len(resources),
        top_rule_id=top_rule,
        top_category=top_cat,
        monthly_savings_addressable_contract_usd=(
            _sum_by_scope(raw_recs, value=lambda r: _contract_or_list(r, "point"),
                          eligible=lambda r: r.savings_status != "advisory")
            if any(r.price_basis for r in raw_recs) else None),
    )


def workspace_detail(workspace_id: str, recs: list[Recommendation]) -> WorkspaceDetail:
    ws_recs = [r for r in recs if r.workspace_id == workspace_id]
    resources = _collapse_to_resources(ws_recs)
    # by_category stays on the point estimate: it is the opportunity breakdown, not the
    # booked floor, so after Phase 0.3 its sum may exceed the booked headline (the
    # difference being the estimated/advisory opportunity). Intentional.
    by_cat_savings: dict[str, float] = defaultdict(float)
    by_cat_count: dict[str, int] = defaultdict(int)
    name = None
    for r in resources:
        by_cat_savings[r.category] += r.monthly_savings_usd
        by_cat_count[r.category] += 1
        name = name or r.workspace_name
    breakdown = [
        CategoryBreakdown(
            category=c,
            monthly_savings_usd=round(by_cat_savings[c], 2),
            recommendation_count=by_cat_count[c],
        )
        for c in sorted(by_cat_savings, key=by_cat_savings.get, reverse=True)
    ]
    low, high = _savings_range(ws_recs)
    return WorkspaceDetail(
        workspace_id=workspace_id,
        workspace_name=name,
        monthly_savings_usd=_booked_savings_total(ws_recs),
        monthly_savings_addressable_usd=_addressable_savings_total(ws_recs),
        monthly_savings_low_usd=low,
        monthly_savings_high_usd=high,
        savings_tiers=[
            SavingsTier(tier=t, monthly_savings_usd=v)
            for t, v in _savings_tier_breakdown(ws_recs).items()
        ],
        monthly_waste_usd=waste_total(ws_recs),
        recommendation_count=len(resources),
        by_category=breakdown,
        priced=priced_totals(ws_recs),
    )
