"""Central-mode account scoping, shared by every live central reader.

Central Logfood stores one flat, multi-account copy of each system table. To read
ONE customer's data out of it, two things are needed and both are derived here:

* the customer's Databricks ``account_id``(s) — used to scope the resolver's inline
  views (and, specifically, the price table, which has no workspace grain), and
* a ``workspace_scope_sql`` subquery of the workspace_ids that
  ``workspaces_latest`` attributes to the selected Salesforce account. A single
  Databricks ``account_id`` can host workspaces belonging to DIFFERENT Salesforce
  accounts (e.g. Mercedes-Benz and Daimler Truck share account_ids), so scoping
  fact tables by ``account_id`` alone over-counts — the caller scopes billing by
  this workspace set instead.

This was originally private to :class:`~finops.data.spend_source.SpendSource`; it is
lifted here verbatim so the genie, apps and fleet readers scope identically rather
than growing four subtly-different copies.
"""

from __future__ import annotations

from collections.abc import Callable

from finops_rules.resolver import CENTRAL_NAMESPACE, CERTIFIED_WORKSPACES, TableResolver

from ..logging import get_logger
from .account_view import AccountView, _lit

log = get_logger(__name__)


class CentralScope:
    """Resolves the central account_id set, the workspace-scope subquery and a ready
    :class:`TableResolver` for a selected account (``AccountView``).

    ``query`` is a ``Callable[[str], list[dict]]`` — each caller passes its own
    ``_query`` so the one lookup this needs (Salesforce name -> account_id) runs on
    the caller's own connection.
    """

    def __init__(self, settings, query: Callable[[str], list[dict]]):
        self.settings = settings
        self._query = query

    def _workspaces_dir(self) -> str:
        """The workspace directory to read. A configured central SLICE namespace
        carries its own small ``workspaces_latest`` (clustered by account name, so the
        scope subquery is cheap); otherwise the shared certified directory."""
        ns = getattr(self.settings, "central_namespace", "") or ""
        if ns and ns != CENTRAL_NAMESPACE:
            return f"{ns}.workspaces_latest"
        return CERTIFIED_WORKSPACES

    def account_ids(self, account_view: AccountView) -> list[str]:
        """The Databricks ``account_id``(s) for the selection. An explicit account_id
        wins; otherwise map the Salesforce account name (optionally narrowed by cloud)
        to its account_id(s) via the workspace directory. Empty when nothing is
        selected or the lookup fails (the caller then reports ``unavailable``)."""
        if account_view.databricks_account_id:
            return [account_view.databricks_account_id]
        if not account_view.salesforce_account_name:
            return []
        clause = (
            f"salesforce_account_name = {_lit(account_view.salesforce_account_name)} "
            "AND account_id IS NOT NULL"
        )
        if account_view.cloud_type:
            clause += f" AND cloud_type = {_lit(account_view.cloud_type)}"
        sql = f"SELECT DISTINCT account_id FROM {self._workspaces_dir()} WHERE {clause}"
        try:
            rows = self._query(sql)
        except Exception:
            log.warning(
                "could not resolve account_id(s) for %s; central read unavailable",
                account_view.salesforce_account_name,
            )
            return []
        return [str(r["account_id"]) for r in rows if r.get("account_id")]

    def workspace_scope_sql(self, account_view: AccountView) -> str | None:
        """A subquery of the workspace_ids attributed to the selected Salesforce
        account (optionally narrowed by cloud / account_id). ``None`` when nothing is
        selected, so a central read stays ``unavailable`` rather than scanning every
        account."""
        conds = []
        if account_view.salesforce_account_name:
            conds.append(f"salesforce_account_name = {_lit(account_view.salesforce_account_name)}")
        if account_view.cloud_type:
            conds.append(f"cloud_type = {_lit(account_view.cloud_type)}")
        if account_view.databricks_account_id:
            # workspaces_latest's account column is ``account_id`` (not databricks_account_id).
            conds.append(f"account_id = {_lit(account_view.databricks_account_id)}")
        if not conds:
            return None
        where = " AND ".join(conds)
        return (
            f"SELECT workspace_id FROM {self._workspaces_dir()} "
            f"WHERE {where} AND workspace_id IS NOT NULL"
        )

    def resolver(self, account_view: AccountView) -> TableResolver | None:
        """A central ``TableResolver`` scoped to the selection, or ``None`` when the
        account_id set is empty (nothing selected / lookup failed)."""
        ids = self.account_ids(account_view)
        if not ids:
            return None
        return TableResolver.central_for(
            ids, namespace=getattr(self.settings, "central_namespace", None)
        )
