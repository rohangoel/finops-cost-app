"""The StopTheLeak feedback store: Lakebase Postgres ``ops.feedback`` + ``ops.opt_outs``.

StopTheLeak owns the instance, the database and both tables, and grants the app SP's
Postgres role ``USAGE ON SCHEMA ops``, ``SELECT, INSERT`` on both tables and ``DELETE``
on ``ops.opt_outs`` (for undoing an opt-out). The app never updates or deletes a vote:

* **Insert only.** A changed vote is a new row whose ``supersedes_id`` points at the
  voter's previous row on the same ``finding_key``.
* **Idempotent.** ``INSERT ... ON CONFLICT (idempotency_key) DO NOTHING``, so a double
  click or a retried request leaves one row.
* **"You said: ..."** is the latest row per ``(finding_key, voter_email)``.

Only used when ``FINOPS_FEEDBACK_ENABLED`` is on; ``psycopg`` is imported lazily so an
app with feedback off never needs it.

Connection: ``FINOPS_FEEDBACK_DSN`` (a libpq DSN, for a local Postgres) wins. Otherwise
the app database resource's ``PG*`` environment variables are used, with the app SP's
OAuth token as the password (Lakebase accepts a workspace OAuth token), and
``FINOPS_FEEDBACK_DATABASE`` overriding ``PGDATABASE``. A connection is opened per
operation: votes are rare, and a fresh connection always carries a fresh token.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from datetime import date, timedelta

from ..config import Settings
from ..models.feedback import Vote

_VOTE_COLUMNS = (
    "feedback_id", "supersedes_id", "finding_key", "observation_date", "rule_id",
    "voter_email", "voter_relation", "channel", "verdict", "reason_codes",
    "savings_assessment", "free_text", "snooze_until", "created_at",
)
_SELECT_VOTE = ", ".join(
    f"{c}::text" if c in ("feedback_id", "supersedes_id") else c for c in _VOTE_COLUMNS
)


class FeedbackConflict(Exception):
    """The idempotency key was already used by another voter or for another finding."""


def _oauth_password() -> str:
    """The app SP's OAuth access token, used as the Lakebase password."""
    from databricks.sdk.core import Config

    headers = Config().authenticate()
    auth = headers.get("Authorization", "")
    return auth.removeprefix("Bearer ").strip()


def make_connect(settings: Settings) -> Callable:
    """A zero-arg callable that opens a psycopg connection to the feedback store."""

    def connect():
        import psycopg

        if settings.feedback_dsn:
            return psycopg.connect(settings.feedback_dsn, connect_timeout=10)
        return psycopg.connect(
            host=os.environ["PGHOST"],
            port=int(os.getenv("PGPORT", "5432")),
            dbname=settings.feedback_database or os.environ["PGDATABASE"],
            user=os.environ["PGUSER"],
            password=_oauth_password(),
            sslmode=os.getenv("PGSSLMODE", "require"),
            connect_timeout=10,
        )

    return connect


class FeedbackStore:
    def __init__(self, connect: Callable):
        self.connect = connect  # zero-arg callable -> open psycopg connection

    # --- votes -------------------------------------------------------------------
    def record_vote(
        self,
        *,
        idempotency_key: str,
        finding_key: str,
        observation_date: date,
        rule_id: str,
        voter_email: str,
        voter_relation: str,
        channel: str,
        verdict: str,
        reason_codes: list[str],
        savings_assessment: str | None,
        free_text: str | None,
        snooze_days: int | None,
        today: date | None = None,
    ) -> Vote:
        """Append one vote and return the stored row.

        A repeat of the same ``idempotency_key`` returns the row the first request
        wrote, and inserts nothing. If that key belongs to a different voter or
        finding, :class:`FeedbackConflict` is raised rather than leaking their row.
        """
        snooze_until = (
            (today or date.today()) + timedelta(days=snooze_days) if snooze_days else None
        )
        params = {
            "idempotency_key": idempotency_key,
            "finding_key": finding_key,
            "observation_date": observation_date,
            "rule_id": rule_id,
            "voter_email": voter_email,
            "voter_relation": voter_relation,
            "channel": channel,
            "verdict": verdict,
            "reason_codes": list(reason_codes),
            "savings_assessment": savings_assessment,
            "free_text": free_text,
            "snooze_until": snooze_until,
        }
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO ops.feedback (
                  idempotency_key, supersedes_id, finding_key, observation_date, rule_id,
                  voter_email, voter_relation, channel, verdict, reason_codes,
                  savings_assessment, free_text, snooze_until)
                SELECT
                  %(idempotency_key)s,
                  (SELECT f.feedback_id FROM ops.feedback f
                    WHERE f.finding_key = %(finding_key)s AND f.voter_email = %(voter_email)s
                    ORDER BY f.created_at DESC, f.feedback_id DESC LIMIT 1),
                  %(finding_key)s, %(observation_date)s, %(rule_id)s,
                  %(voter_email)s, %(voter_relation)s, %(channel)s, %(verdict)s,
                  %(reason_codes)s::text[], %(savings_assessment)s, %(free_text)s,
                  %(snooze_until)s
                ON CONFLICT (idempotency_key) DO NOTHING
                RETURNING {_SELECT_VOTE}
                """,
                params,
            )
            row = cur.fetchone()
            if row is None:
                cur.execute(
                    f"SELECT {_SELECT_VOTE} FROM ops.feedback WHERE idempotency_key = %s",
                    (idempotency_key,),
                )
                row = cur.fetchone()
            conn.commit()
        vote = _to_vote(row)
        if vote.voter_email != voter_email or vote.finding_key != finding_key:
            raise FeedbackConflict(idempotency_key)
        return vote

    def latest_votes(self, voter_email: str) -> dict[str, Vote]:
        """``finding_key -> latest Vote`` for one voter (what "You said" shows)."""
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT DISTINCT ON (finding_key) {_SELECT_VOTE}
                FROM ops.feedback
                WHERE voter_email = %s
                ORDER BY finding_key, created_at DESC, feedback_id DESC
                """,
                (voter_email,),
            )
            rows = cur.fetchall()
        votes = [_to_vote(r) for r in rows]
        return {v.finding_key: v for v in votes}

    # --- weekly email opt-out ------------------------------------------------------
    def is_opted_out(self, email: str) -> bool:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1 FROM ops.opt_outs WHERE email = %s", (email,))
            return cur.fetchone() is not None

    def opt_out(self, email: str) -> None:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "INSERT INTO ops.opt_outs (email, scope) VALUES (%s, 'all') "
                "ON CONFLICT (email) DO NOTHING",
                (email,),
            )
            conn.commit()

    def opt_in(self, email: str) -> None:
        """Undo an opt-out (needs DELETE on ops.opt_outs)."""
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("DELETE FROM ops.opt_outs WHERE email = %s", (email,))
            conn.commit()


def _to_vote(row) -> Vote:
    return Vote(**dict(zip(_VOTE_COLUMNS, row, strict=True)))
