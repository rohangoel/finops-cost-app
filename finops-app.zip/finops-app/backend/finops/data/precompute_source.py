"""Precompute mode: read the latest snapshot from the Delta recommendation table.

The scheduled job (see ``precompute/``) has already run every rule account-wide
and written rows shaped exactly like :class:`Recommendation`. Reading is a cheap
scoped SELECT, so this scales to 100s of workspaces.
"""

from __future__ import annotations

import json
import os as _os
import time as _time
from datetime import datetime, timezone

from ..identity import Scope
from ..models import Recommendation
from .base import RecommendationSource
from .scoping import where_clause
from .sql_client import qualified_table

# Process-level cache for precompute reads. Unlike live mode this is a cheap
# SELECT, but on a contended shared warehouse it is still seconds per request and
# the recommendation service is NOT a process singleton — so without this, every
# page and every account switch re-queries the warehouse. Keyed by
# (table, scope, account pushdown), so each selected account caches independently
# and the account gate's "warm once, then instant" model works. Enabled by
# FINOPS_PRECOMPUTE_CACHE_TTL (seconds); 0/unset = no caching (unchanged behaviour).
# Safe to share objects because RecommendationService._annotate is non-mutating.
_CACHE_TTL = float(_os.getenv("FINOPS_PRECOMPUTE_CACHE_TTL", "0") or "0")
_CACHE: dict[tuple, tuple[float, list[Recommendation]]] = {}

# NB: additive columns (resource_owner/resource_creator) require the table to carry
# them before this SELECT runs — the pipeline recreates the MV with the new schema
# on its next run, so deploy/run the precompute pipeline before (or with) the app,
# per the additive-contract discipline in contract_schema.py.
_COLUMNS = [
    "recommendation_id", "snapshot_date", "rule_id", "rule_version", "rule_title",
    "category", "workspace_id", "workspace_name", "workspace_url", "resource_type", "resource_id",
    "resource_name", "resource_owner", "resource_creator", "why", "how",
    "monthly_waste_usd", "monthly_savings_usd",
    "monthly_savings_low_usd", "monthly_savings_high_usd", "savings_status",
    "effort_band", "effort_score", "priority", "nba_score", "evidence", "computed_at",
]

# Contract / cloud pricing columns (finops_rules.price_basis). OPTIONAL on read: a
# snapshot written before they existed simply lacks them (GH #108 backward compat),
# so they are selected only when the table actually has them and default to None.
_OPTIONAL_COLUMNS = [
    "price_basis", "contract_price_coverage",
    "monthly_savings_contract_usd", "monthly_savings_contract_low_usd",
    "monthly_savings_contract_high_usd", "cloud_cost_30d_usd", "monthly_cloud_savings_usd",
    # Owner routing (finops.routing). Absent on an older snapshot: the model then
    # derives finding_key and routes on resource_owner alone (no workspace owner).
    "finding_key", "workspace_owner", "resource_owner_kind",
    "notify_recipient", "recipient_source",
]

# Per-table cache of which optional columns exist (one LIMIT 0 probe per process).
_TABLE_COLUMNS: dict[str, frozenset[str]] = {}

# The account dimension the CENTRAL table adds. Selected only in central mode — the
# single-account table has no such columns and would error on the SELECT.
_CENTRAL_COLUMNS = ["databricks_account_id", "cloud_type", "salesforce_account_name"]


class PrecomputeRecommendationSource(RecommendationSource):
    def _columns(self) -> list[str]:
        if getattr(self.settings, "central_mode", False):
            return _COLUMNS + _CENTRAL_COLUMNS
        return _COLUMNS

    def _optional_present(self, table: str) -> list[str]:
        """The optional pricing columns this snapshot table actually carries."""
        cols = _TABLE_COLUMNS.get(table)
        if cols is None:
            try:
                with self.connect() as conn, conn.cursor() as cur:
                    cur.execute(f"SELECT * FROM {table} LIMIT 0")
                    cols = frozenset(d[0] for d in cur.description)
            except Exception:
                cols = frozenset()
            _TABLE_COLUMNS[table] = cols
        return [c for c in _OPTIONAL_COLUMNS if c in cols]

    def load(self, scope: Scope, account_view=None) -> list[Recommendation]:
        # Push the global account/cloud/account_id selection into the SELECT so only the
        # chosen account's rows cross the warehouse and the wire — the multi-account
        # central table would otherwise return every account every request, then filter
        # in Python (see AccountView.apply). Only meaningful in central mode; the
        # single-account table has no such columns and is never passed an account_view.
        acct_pred = account_view.sql_predicate() if account_view is not None else ""
        if _CACHE_TTL <= 0:
            return self._query(scope, acct_pred)
        key = (
            self.settings.finops_table,
            "all" if scope.all_workspaces else ",".join(sorted(scope.workspace_ids)),
            acct_pred,
        )
        hit = _CACHE.get(key)
        if hit is not None and _time.monotonic() - hit[0] < _CACHE_TTL:
            return hit[1]
        recs = self._query(scope, acct_pred)
        _CACHE[key] = (_time.monotonic(), recs)
        return recs

    def _query(self, scope: Scope, acct_pred: str) -> list[Recommendation]:
        table = qualified_table(self.settings.finops_table)
        clause = where_clause(scope)
        columns_wanted = self._columns() + self._optional_present(table)
        cols = ", ".join(columns_wanted)
        sql = (
            f"SELECT {cols} FROM {table} "
            f"WHERE snapshot_date = (SELECT MAX(snapshot_date) FROM {table}) "
            f"{('AND ' + clause[len('WHERE '):]) if clause else ''} "
            f"{('AND ' + acct_pred) if acct_pred else ''} "
            f"ORDER BY nba_score DESC"
        )
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(sql)
            columns = [d[0] for d in cur.description]
            rows = [dict(zip(columns, r)) for r in cur.fetchall()]
        return [self._to_recommendation(r, columns_wanted) for r in rows]

    @staticmethod
    def _to_recommendation(row: dict, columns_wanted: list[str]) -> Recommendation:
        evidence = row.get("evidence")
        if isinstance(evidence, str):
            try:
                evidence = json.loads(evidence)
            except (json.JSONDecodeError, TypeError):
                evidence = {}
        row["evidence"] = evidence or {}
        row.setdefault("computed_at", datetime.now(timezone.utc))
        return Recommendation(**{k: row.get(k) for k in columns_wanted})
