"""Workspace owner: the most common owner-tag email on a workspace's billing rows.

Only 23 % of findings carry an email in ``resource_owner``: most of the rest are
owned by a service principal (on FEVM, the provisioning SP "owns" every workspace's
Serverless Starter Warehouse). Workspace admins inherit CAN_MANAGE on SP-owned
warehouses, so the person who can fix those findings is the workspace owner.

FEVM stamps an ``Owner`` custom tag on every billing row of a workspace. It is
single-valued in 99 % of workspaces and covers all their usage, so the most common
value over the lookback is an authoritative workspace owner (measured on
``fevm-finops-stable-us``, GH #123). Other accounts may use another key, or none:
the key is the pipeline's ``workspace_owner_tag`` bundle variable. It is part of
the optional StopTheLeak integration and off by default (empty); deploy.sh sets
``Owner`` when ``STOPTHELEAK_ENABLED=yes``.

Same definition as StopTheLeak's ``v_workspace_owner`` view, with one addition: a
tie between two values is broken by the value itself, so the result doesn't change
from run to run.

The result is one row per workspace, small enough to broadcast-join onto the scored
findings (unlike the per-resource owner map, see the SDP closure-broadcast note in
``precompute/pipeline.py``).
"""

from __future__ import annotations

import re

DEFAULT_OWNER_TAG = "Owner"

# A tag key goes into the SQL as a string literal. Tag keys are free text, so allow
# only a conservative character set rather than attempting to escape.
_TAG_RE = re.compile(r"^[A-Za-z0-9_.:/\- ]{1,128}$")


def valid_owner_tag(tag: str | None) -> str | None:
    """The tag key if it is set and safe to inline, else None (lookup off)."""
    if tag is None:
        return None
    tag = tag.strip()
    if not tag or not _TAG_RE.match(tag):
        return None
    return tag


def workspace_owner_sql(
    catalog: str = "system",
    lookback_days: int = 30,
    tag: str = DEFAULT_OWNER_TAG,
    usage_ref: str | None = None,
) -> str:
    """``(workspace_id, workspace_owner)``, one row per workspace with an owner tag.

    ``workspace_owner`` is lowercased. Only email-shaped values count, so a tag that
    holds a team name never becomes a recipient.
    """
    safe = valid_owner_tag(tag)
    if safe is None:
        raise ValueError(f"invalid workspace owner tag: {tag!r}")
    usage = usage_ref or f"{catalog}.billing.usage"
    return f"""
WITH tagged AS (
  SELECT
    CAST(u.workspace_id AS STRING) AS workspace_id,
    lower(u.custom_tags['{safe}']) AS owner,
    count(*) AS n
  FROM {usage} u
  WHERE u.usage_date >= date_sub(current_date(), {int(lookback_days)})
    AND u.usage_date < current_date()
    AND u.custom_tags['{safe}'] LIKE '%@%'
  GROUP BY 1, 2
)
SELECT
  workspace_id,
  max_by(owner, struct(n, owner)) AS workspace_owner
FROM tagged
GROUP BY workspace_id
"""
