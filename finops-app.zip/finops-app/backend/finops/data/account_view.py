"""Account-dimension view filter — the global account / cloud / account_id selection.

Central mode tags every recommendation with its ``(databricks_account_id,
cloud_type, salesforce_account_name)``. This object is the server-side reflection
of the UI's **global account switcher**: exactly like the workspace ``?workspace_id=``
view filter, the frontend appends these three params to every request, and the
recommendation source applies them at the :meth:`RecommendationSource.fetch`
boundary — the one choke point every read path crosses. So a single account
selection filters every recommendation surface at once (overview, next-best-actions,
the list, the groups, detail), and findings for two different customers can never
appear together.

It is purely a VIEW narrowing — it only ever removes rows, never grants access, and
the rows it filters are already workspace-scoped server-side — and it is a no-op in
single-account mode, where the three columns are all ``None`` (so the UI hides the
controls and sends nothing).
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from ..models import Recommendation


def _lit(value: str) -> str:
    """A safely single-quote-escaped SQL string literal."""
    return "'" + value.replace("'", "''") + "'"


@dataclass(frozen=True)
class AccountView:
    """The three account-dimension filters currently selected in the UI."""

    salesforce_account_name: str | None = None
    cloud_type: str | None = None
    databricks_account_id: str | None = None

    @property
    def active(self) -> bool:
        """True when at least one filter is set (else :meth:`apply` is a no-op)."""
        return any(
            (self.salesforce_account_name, self.cloud_type, self.databricks_account_id)
        )

    def apply(self, recs: Iterable[Recommendation]) -> list[Recommendation]:
        """Keep only recs matching every set filter (unset filters are ignored).

        This is the source-agnostic filter applied at :meth:`RecommendationSource.fetch`.
        A source that already narrowed by :meth:`sql_predicate` (precompute pushes the
        same predicate into its SELECT) re-runs it here harmlessly over the already-small
        result — the filter is idempotent, so correctness never depends on the pushdown.
        """
        out = list(recs)
        if not self.active:
            return out
        if self.salesforce_account_name:
            out = [r for r in out if r.salesforce_account_name == self.salesforce_account_name]
        if self.cloud_type:
            out = [r for r in out if r.cloud_type == self.cloud_type]
        if self.databricks_account_id:
            out = [r for r in out if r.databricks_account_id == self.databricks_account_id]
        return out

    def sql_predicate(self) -> str:
        """The active filters as a SQL boolean predicate (no ``WHERE``/``AND`` prefix),
        or ``""`` when nothing is set — the pushdown twin of :meth:`apply`.

        String literals are single-quote-escaped. The values come from a fixed facet
        set (the account switcher only offers values the data already contains), but we
        escape defensively so this is safe against any query-param input."""
        conds = []
        if self.salesforce_account_name:
            conds.append(f"salesforce_account_name = {_lit(self.salesforce_account_name)}")
        if self.cloud_type:
            conds.append(f"cloud_type = {_lit(self.cloud_type)}")
        if self.databricks_account_id:
            conds.append(f"databricks_account_id = {_lit(self.databricks_account_id)}")
        return " AND ".join(conds)

    @classmethod
    def from_query(cls, params) -> AccountView:
        """Build from a request's query params (blank / absent values -> unset)."""
        return cls(
            salesforce_account_name=(params.get("salesforce_account_name") or None),
            cloud_type=(params.get("cloud_type") or None),
            databricks_account_id=(params.get("databricks_account_id") or None),
        )
