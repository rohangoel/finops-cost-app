"""Price-basis capability summary — which price views this snapshot can show.

Drives the frontend's "List price | Your rates" switch and the cloud-VM layer
(docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md §A6). Derived from the data actually
served, not from configuration, so the switch can never offer a basis the
findings don't carry.
"""

from __future__ import annotations

from pydantic import BaseModel


class PricingSummary(BaseModel):
    #: True when the run that produced these findings had contract rates
    #: (system.billing.account_prices). False ⇒ the UI shows list only, no switch.
    contract_available: bool = False
    #: Account-level contract coverage, 0–1: the list-$ share of total spend that had
    #: a contract price (from the spend snapshot), else the share of findings' list
    #: savings that carry a contract figure. None when contract data is absent.
    contract_coverage_account: float | None = None
    #: Findings carrying / lacking a contract figure (price_basis contract / list).
    contract_findings: int = 0
    list_fallback_findings: int = 0
    #: True when any finding carries a classic cloud-VM cost (cloud_infra_cost).
    cloud_available: bool = False
    #: Classic findings with cloud cost data vs all findings of classic resource types.
    cloud_findings: int = 0
    cloud_currency: str = "USD"
    #: "contract" when coverage ≥ 95 % (decision D1), else "list".
    default_basis: str = "list"
