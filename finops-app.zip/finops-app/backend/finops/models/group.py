"""Resource-grouped view of recommendations.

Several rules can flag the *same* resource with overlapping, often
mutually-exclusive fixes (e.g. a warehouse that could be auto-stopped, moved to
serverless, OR right-sized down a step). Listing each as its own row in the
overview both clutters the table and — critically — makes the headline savings
double-count, because you cannot bank two overlapping fixes on one resource.

A :class:`RecommendationGroup` collapses those into one row per resource. The
overview shows "there is something to do here" (a synthesized action label + a
single, non-double-counted savings figure); the detail page expands the group's
``options`` so the user can compare and pick. This is a pure read-time rollup
over the same :class:`Recommendation` objects — no new persistence.
"""

from __future__ import annotations

import hashlib

from pydantic import BaseModel, Field

from .recommendation import Recommendation
from .serverless_fit import ServerlessFit


def group_id(workspace_id: str, resource_type: str, resource_id: str) -> str:
    """Stable id for a resource across snapshots (snapshot-independent) so a
    group deep-link survives the nightly recompute."""
    raw = f"{workspace_id}|{resource_type}|{resource_id}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


class RecommendationGroup(BaseModel):
    group_id: str = Field(..., description="Stable hash of workspace+resource_type+resource_id")
    workspace_id: str
    workspace_name: str | None = None
    workspace_url: str | None = None
    resource_type: str  # cluster | warehouse | job
    resource_id: str
    resource_name: str
    # Short synthesized headline for the overview row ("3 ways to optimise this
    # warehouse" when there are options; the single rule title when there's one).
    action_label: str
    category: str  # representative (top option's) category
    option_count: int
    # Representative figures. Savings is the MAX of the options, never the sum:
    # the options overlap, so summing would promise money you can only bank once.
    # Waste is likewise the max, i.e. the resource's own monthly spend.
    monthly_savings_usd: float
    monthly_waste_usd: float
    # The naive sum of option savings, kept only so the UI can show *how much*
    # was collapsed / avoid surprising anyone reading the raw findings.
    options_savings_sum_usd: float
    # The same composed savings at "Your rates" (contract where an option has one, list
    # otherwise) and the cloud-VM layer. None without contract / cloud data. price_basis
    # is 'contract' only when every dollar option is contract-priced, 'list' when at
    # least one fell back (the UI marks it), None when there is no contract data.
    monthly_savings_contract_usd: float | None = None
    price_basis: str | None = None
    monthly_cloud_savings_usd: float | None = None
    effort_band: str  # the lowest-effort option (easiest win)
    priority: str  # the highest priority among the options
    nba_score: float  # the top option's rank
    # Per-resource "should this go serverless?" verdict (warehouses/jobs), shown on
    # the detail page. None where serverless doesn't apply to the resource type.
    # See services/serverless_fit.py — computed at build time from the options.
    serverless_fit: ServerlessFit | None = None
    # The individual findings, best-first, for the detail page.
    options: list[Recommendation] = Field(default_factory=list)
