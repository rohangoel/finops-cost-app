"""Governance-category findings are relocated to their own tab, not removed.

They must not count toward the recommendation total, must not appear as an option
on an optimizable resource, and must not enter the Next Best Actions ranking or the
savings leaderboard — but they must still be fully reachable via the Tagging &
Chargeback surface and by a direct detail link. This pins the partition at the one
boundary every read path crosses (``RecommendationSource.fetch`` /
``fetch_sidecar``; see data/base.py) so no surface can drift back to mixing them in.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from finops.config import Settings
from finops.data.base import RecommendationSource
from finops.identity import Scope
from finops.models import Recommendation
from finops.services import RecommendationService, aggregation

ADMIN = Scope(all_workspaces=True, workspace_ids=[])


def _rec(rec_id, rule, category, *, savings=0.0, waste=0.0, ws="111", res="x") -> Recommendation:
    return Recommendation(
        recommendation_id=rec_id, snapshot_date=date(2026, 9, 1),
        rule_id=rule, rule_version="1", rule_title=rule, category=category,
        workspace_id=ws, resource_type="cluster", resource_id=res, resource_name=res,
        why="w", how="h", monthly_waste_usd=waste, monthly_savings_usd=savings,
        effort_band="trivial", effort_score=2, priority="HIGH", nba_score=savings,
        computed_at=datetime.now(timezone.utc),
    )


class _ListSource(RecommendationSource):
    """A source backed by a fixed in-memory list, so we exercise the real base-class
    fetch/fetch_sidecar partition rather than a duck-typed stub."""

    def __init__(self, recs, settings=None):
        super().__init__(settings or Settings(), connect=None)
        self._recs = recs

    def load(self, scope, account_view=None):
        return [r.model_copy() for r in self._recs]


# A savings finding (optimization) and a governance finding on DIFFERENT resources.
FIXTURE = [
    _rec("opt", "warehouse_autostop", "sql", savings=400.0, waste=1000.0, res="wh-1"),
    _rec("gov", "untagged_spend", "governance", savings=0.0, waste=5000.0, res="cl-9"),
]


def _svc(recs):
    return RecommendationService(_ListSource(recs))


def test_fetch_excludes_governance_and_fetch_sidecar_keeps_only_it():
    src = _ListSource(FIXTURE)
    main = {r.rule_id for r in src.fetch(ADMIN)}
    side = {r.rule_id for r in src.fetch_sidecar(ADMIN)}
    assert main == {"warehouse_autostop"}
    assert side == {"untagged_spend"}


def test_main_service_surfaces_exclude_governance():
    svc = _svc(FIXTURE)
    assert [r.rule_id for r in svc.list(ADMIN)] == ["warehouse_autostop"]
    assert [r.rule_id for r in svc.next_best_actions(ADMIN, limit=10)] == ["warehouse_autostop"]
    # One group per resource, and the governance resource must not appear as a group.
    groups = svc.list_grouped(ADMIN)
    assert all("untagged_spend" not in {o.rule_id for o in g.options} for g in groups)
    assert {g.resource_id for g in groups} == {"wh-1"}


def test_tagging_surface_has_only_governance_with_unattributable_headline():
    svc = _svc(FIXTURE)
    ov = svc.tagging_overview(ADMIN)
    assert ov.recommendation_count == 1
    assert ov.workspace_count == 1
    assert ov.total_unattributable_monthly_usd == 5000.0
    assert [r.rule_id for r in ov.items] == ["untagged_spend"]


def test_detail_link_still_resolves_a_governance_finding():
    """The tab links each finding to /recommendations/{id}; get() must find it even
    though it lives in the sidecar set, not fetch()."""
    svc = _svc(FIXTURE)
    got = svc.get(ADMIN, "gov")
    assert got is not None and got.rule_id == "untagged_spend"


def test_aggregation_counts_exclude_governance():
    """The account overview reads source.fetch directly; governance must not inflate
    the recommendation count or the waste total, nor add a governance category."""
    src = _ListSource(FIXTURE)
    overview = aggregation.account_overview(src.fetch(ADMIN))
    assert overview.recommendation_count == 1
    assert overview.total_monthly_waste_usd == 1000.0  # governance's 5000 excluded
    assert overview.total_monthly_savings_usd == 400.0


def test_sidecar_can_be_disabled_by_config():
    """Empty FINOPS_SIDECAR_CATEGORIES folds the category back into the main set."""
    settings = Settings(sidecar_categories=[])
    src = _ListSource(FIXTURE, settings)
    assert {r.rule_id for r in src.fetch(ADMIN)} == {"warehouse_autostop", "untagged_spend"}
    assert src.fetch_sidecar(ADMIN) == []
