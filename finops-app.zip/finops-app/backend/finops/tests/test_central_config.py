"""Central-mode account config parsing and the certified scope query.

The load-bearing behavior here is the two matching modes:

* **name mode** (default) — an entry matches ``salesforce_account_name`` and the tagged
  output carries that real name. This must stay byte-identical to the original.
* **account_id mode** (``scope_by_account_id``) — for an estate whose workspaces carry no
  usable Salesforce name in certified (e.g. the FE Vending Machine one-env estate, ~90%
  unnamed but all in one account_id). The entry then matches by ``databricks_account_id``
  and the ``salesforce_account_name`` is only a DISPLAY LABEL, applied to the output via a
  CASE so the account still surfaces as one named customer.
"""

from __future__ import annotations

import pytest
from finops.services.central_config import (
    AccountSpec,
    certified_scope_sql,
    config_from_rows,
    parse_config,
)


def _cfg(accounts, **kw):
    return parse_config({"accounts": accounts, **kw})


# --- matching modes -----------------------------------------------------------
def test_name_mode_predicate_matches_the_salesforce_name():
    spec = AccountSpec(salesforce_account_name="Allianz")
    assert spec.predicate() == "(salesforce_account_name = 'Allianz')"


def test_name_mode_narrows_by_cloud_and_account_id():
    spec = AccountSpec(
        salesforce_account_name="Allianz",
        cloud_type=("aws",),
        databricks_account_id=("a1", "a2"),
    )
    assert spec.predicate() == (
        "(salesforce_account_name = 'Allianz' AND cloud_type IN ('aws') "
        "AND account_id IN ('a1', 'a2'))"
    )


def test_account_id_mode_matches_by_account_id_not_name():
    spec = AccountSpec(
        salesforce_account_name="Databricks FEVM",
        cloud_type=("aws",),
        databricks_account_id=("05d08df7",),
        scope_by_account_id=True,
    )
    # The name is a display label only — it must NOT appear in the match predicate.
    assert "salesforce_account_name" not in spec.predicate()
    assert spec.predicate() == "(account_id IN ('05d08df7') AND cloud_type IN ('aws'))"


# --- parsing ------------------------------------------------------------------
def test_parse_reads_scope_by_account_id():
    cfg = _cfg([
        {"salesforce_account_name": "Allianz"},
        {
            "salesforce_account_name": "Databricks FEVM",
            "scope_by_account_id": True,
            "cloud_type": ["aws"],
            "databricks_account_id": ["05d08df7"],
        },
    ])
    assert cfg.accounts[0].scope_by_account_id is False
    fevm = cfg.accounts[1]
    assert fevm.scope_by_account_id is True
    assert fevm.databricks_account_id == ("05d08df7",)


def test_scope_by_account_id_requires_an_account_id():
    with pytest.raises(ValueError, match="databricks_account_id"):
        _cfg([{"salesforce_account_name": "Databricks FEVM", "scope_by_account_id": True}])


# --- certified scope query ----------------------------------------------------
def test_scope_sql_is_unchanged_when_there_are_no_label_entries():
    """Backward-compat guard: a name-only config keeps the original single-name
    projection (no CASE)."""
    sql = certified_scope_sql(_cfg([{"salesforce_account_name": "Allianz"}]))
    assert "CASE" not in sql
    assert "SELECT DISTINCT workspace_id, workspace_name, account_id, cloud_type, " \
           "salesforce_account_name\n" in sql
    assert "(salesforce_account_name = 'Allianz')" in sql


def test_scope_sql_projects_the_label_for_account_id_entries():
    sql = certified_scope_sql(_cfg([
        {"salesforce_account_name": "Allianz"},
        {
            "salesforce_account_name": "Databricks FEVM",
            "scope_by_account_id": True,
            "cloud_type": ["aws"],
            "databricks_account_id": ["05d08df7"],
        },
    ]))
    # The label is applied via CASE on the account_id predicate, real names fall through.
    assert "CASE" in sql
    assert "WHEN (account_id IN ('05d08df7') AND cloud_type IN ('aws')) THEN 'Databricks FEVM'" in sql
    assert "ELSE salesforce_account_name END AS salesforce_account_name" in sql
    # Both entries still appear in the WHERE filter.
    assert "(salesforce_account_name = 'Allianz')" in sql
    assert "(account_id IN ('05d08df7') AND cloud_type IN ('aws'))" in sql


def test_scope_sql_respects_running_only_toggle():
    on = certified_scope_sql(_cfg([{"salesforce_account_name": "Allianz"}], running_only=True))
    off = certified_scope_sql(_cfg([{"salesforce_account_name": "Allianz"}], running_only=False))
    assert "workspace_status = 'RUNNING'" in on
    assert "workspace_status" not in off


# --- config_from_rows: the table-backed account source ------------------------
# The account list moved from accounts.yaml into a UC table; config_from_rows turns its
# rows (plain dicts, as Row.asDict() would yield) into the same CentralConfig the yaml
# produces. These are pure/no-Spark: the pipeline does the spark.sql read.
def test_config_from_rows_equals_yaml_for_the_same_accounts():
    """A table row and the equivalent yaml entry must resolve to the same scope SQL, so
    the migration is a no-op on the pipeline output."""
    rows = [
        {"salesforce_account_name": "Allianz", "cloud_type": None,
         "databricks_account_id": None, "scope_by_account_id": False, "enabled": True},
        {"salesforce_account_name": "Databricks FEVM", "cloud_type": ["aws"],
         "databricks_account_id": ["05d08df7"], "scope_by_account_id": True, "enabled": True},
    ]
    from_table = config_from_rows(rows)
    from_yaml = _cfg([
        {"salesforce_account_name": "Allianz"},
        {"salesforce_account_name": "Databricks FEVM", "scope_by_account_id": True,
         "cloud_type": ["aws"], "databricks_account_id": ["05d08df7"]},
    ])
    assert certified_scope_sql(from_table) == certified_scope_sql(from_yaml)


def test_config_from_rows_coerces_arrays_and_scope_by_account_id():
    cfg = config_from_rows([
        {"salesforce_account_name": "Mercedes-Benz - Global HQ",
         "cloud_type": ["aws", "azure"], "databricks_account_id": ["a1", "a2"],
         "scope_by_account_id": False, "enabled": True},
    ])
    a = cfg.accounts[0]
    assert a.cloud_type == ("aws", "azure") and a.databricks_account_id == ("a1", "a2")


def test_config_from_rows_passes_settings_through_but_ignores_stray_accounts_key():
    cfg = config_from_rows(
        [{"salesforce_account_name": "Allianz", "enabled": True}],
        settings={"lookback_days": 14, "currency": "EUR", "running_only": False,
                  "accounts": [{"salesforce_account_name": "SHOULD-BE-IGNORED"}]},
    )
    assert cfg.lookback_days == 14 and cfg.currency == "EUR" and cfg.running_only is False
    # The table rows are the account source; a stray settings 'accounts' key is dropped.
    assert [a.salesforce_account_name for a in cfg.accounts] == ["Allianz"]


def test_config_from_rows_drops_disabled_rows():
    cfg = config_from_rows([
        {"salesforce_account_name": "Allianz", "enabled": True},
        {"salesforce_account_name": "Old Customer", "enabled": False},
    ])
    assert [a.salesforce_account_name for a in cfg.accounts] == ["Allianz"]


def test_config_from_rows_missing_enabled_defaults_to_included():
    """A row without the 'enabled' key (e.g. a hand-inserted minimal row) is included."""
    cfg = config_from_rows([{"salesforce_account_name": "Allianz"}])
    assert len(cfg.accounts) == 1


def test_config_from_rows_all_disabled_raises():
    with pytest.raises(ValueError, match="non-empty 'accounts'"):
        config_from_rows([{"salesforce_account_name": "Allianz", "enabled": False}])


def test_config_from_rows_still_rejects_injection_at_scope_sql():
    """The injection guard lives in AccountSpec.predicate(); the table path must not bypass
    it (a MODIFY grant means untrusted-ish input reaches this)."""
    cfg = config_from_rows(
        [{"salesforce_account_name": "x'; DROP TABLE y; --", "enabled": True}])
    with pytest.raises(ValueError, match="illegal character"):
        certified_scope_sql(cfg)
