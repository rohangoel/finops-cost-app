"""Per-account result cache on the precompute source.

The cache is the backend half of the "account gate": once a user has selected an
account, every subsequent surface (list, groups, NBA, overview, facets) must be
served without another warehouse round-trip. These tests pin the cache mechanics
without touching a warehouse by stubbing ``_query`` (the SQL) and counting calls.
"""

from __future__ import annotations

import finops.data.precompute_source as ps
from finops.config import Settings
from finops.data.account_view import AccountView
from finops.data.precompute_source import PrecomputeRecommendationSource
from finops.identity import Scope

SCOPE = Scope(all_workspaces=True, workspace_ids=[])
BAYER = AccountView(salesforce_account_name="Bayer AG - Global HQ")
MB = AccountView(salesforce_account_name="Mercedes-Benz - Global HQ")


def _src(monkeypatch, ttl):
    monkeypatch.setattr(ps, "_CACHE_TTL", ttl)
    ps._CACHE.clear()
    settings = Settings(central_mode=True, finops_table="c.s.finops_central_recommendations")
    src = PrecomputeRecommendationSource(settings, connect=None)
    calls: list[str] = []

    def fake_query(scope, acct_pred):
        calls.append(acct_pred)
        return []  # identity is all we assert; content is exercised elsewhere

    monkeypatch.setattr(src, "_query", fake_query)
    return src, calls


def test_cache_hit_avoids_second_query(monkeypatch):
    src, calls = _src(monkeypatch, ttl=100.0)
    src.load(SCOPE, BAYER)
    src.load(SCOPE, BAYER)
    assert calls == ["salesforce_account_name = 'Bayer AG - Global HQ'"]  # one query


def test_each_account_caches_independently(monkeypatch):
    src, calls = _src(monkeypatch, ttl=100.0)
    src.load(SCOPE, BAYER)
    src.load(SCOPE, MB)
    src.load(SCOPE, BAYER)  # still cached
    src.load(SCOPE, MB)     # still cached
    assert calls == [
        "salesforce_account_name = 'Bayer AG - Global HQ'",
        "salesforce_account_name = 'Mercedes-Benz - Global HQ'",
    ]


def test_all_accounts_view_is_a_distinct_key(monkeypatch):
    # Facets read all accounts (no pushdown); that must not collide with a
    # single-account entry, or the dropdowns would show only the selected account.
    src, calls = _src(monkeypatch, ttl=100.0)
    src.load(SCOPE, BAYER)
    src.load(SCOPE, None)  # facets path
    assert calls == ["salesforce_account_name = 'Bayer AG - Global HQ'", ""]


def test_cache_disabled_when_ttl_zero(monkeypatch):
    src, calls = _src(monkeypatch, ttl=0.0)
    src.load(SCOPE, BAYER)
    src.load(SCOPE, BAYER)
    assert calls == [
        "salesforce_account_name = 'Bayer AG - Global HQ'",
        "salesforce_account_name = 'Bayer AG - Global HQ'",
    ]  # every call queries


def test_expired_entry_requeries(monkeypatch):
    src, calls = _src(monkeypatch, ttl=100.0)
    # load1 stores@1000 (miss skips the condition's clock read); load2 checks@1200
    # (>ttl → re-query) then stores@1200.
    times = iter([1000.0, 1200.0, 1200.0])
    monkeypatch.setattr(ps._time, "monotonic", lambda: next(times))
    src.load(SCOPE, BAYER)
    src.load(SCOPE, BAYER)
    assert len(calls) == 2  # second read past the TTL re-queries
