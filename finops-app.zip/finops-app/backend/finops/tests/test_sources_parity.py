"""Live vs precompute parity: the same underlying data must yield identical
recommendations regardless of execution mode. This is what lets us develop in
live mode and ship in precompute mode with confidence."""

from __future__ import annotations

import json

from finops.config import Settings
from finops.data import live_source as live_mod
from finops.data.live_source import LiveRecommendationSource
from finops.data.precompute_source import _COLUMNS, PrecomputeRecommendationSource
from finops.identity import Scope
from finops_rules.catalog.autotermination import AutoTerminationRule

from .conftest import fake_connect

# Columns exactly as autotermination.sql.j2 projects them (gap-based inputs).
RULE_COLUMNS = [
    "workspace_id", "cluster_id", "cluster_name", "auto_termination_minutes",
    "dbr_version", "worker_count", "cost_30d_usd", "dbus_30d",
    "idle_windows", "total_windows", "idle_minutes", "reclaimable_gross_min",
    "num_reclaim_gaps", "longest_idle_gap_min", "running_minutes", "job_runs_30d",
]
RULE_ROW = (
    "111", "c-abc", "adhoc-analytics", None, "13.3.x", 4, 3000.0, 5000.0,
    80, 100, 8000.0, 7000.0, 20, 500, 10000.0, 0,
)

THRESHOLDS = {
    "lookback_days": 30,
    "catalog": "system",
    "cluster_autotermination": {
        "max_acceptable_minutes": 60,
        "min_idle_events": 3,
        "use_audit_activity": False,
    },
}


def _live_recs(monkeypatch):
    monkeypatch.setattr(live_mod, "load_thresholds", lambda: THRESHOLDS)
    monkeypatch.setattr(live_mod, "load_effort", lambda: {})
    monkeypatch.setattr(live_mod, "get_enabled_rules", lambda t: [AutoTerminationRule()])
    source = LiveRecommendationSource(
        Settings(compute_mode="live"), fake_connect(RULE_COLUMNS, [RULE_ROW])
    )
    return source.fetch(Scope(all_workspaces=True))


def _row_from_rec(rec) -> tuple:
    values = rec.model_dump()
    values["evidence"] = json.dumps(values["evidence"])
    return tuple(values[c] for c in _COLUMNS)


def test_live_and_precompute_agree(monkeypatch):
    live = _live_recs(monkeypatch)
    assert len(live) == 1

    # Feed the live results back through the precompute source as if they were
    # rows read from the Delta table.
    rows = [_row_from_rec(r) for r in live]
    precompute = PrecomputeRecommendationSource(
        Settings(compute_mode="precompute"), fake_connect(_COLUMNS, rows)
    ).fetch(Scope(all_workspaces=True))

    assert len(precompute) == len(live)
    a = live[0].model_dump(exclude={"computed_at"})
    b = precompute[0].model_dump(exclude={"computed_at"})
    assert a == b
