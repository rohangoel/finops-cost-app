-- The StopTheLeak feedback store, as the FinOps app sees it. Copied verbatim from
-- StopTheLeak docs/FINOPS_APP_CONTRACT.md §3 (ops.feedback) and §5 (ops.opt_outs).
-- StopTheLeak owns and creates these tables in Lakebase; this copy exists only so
-- test_feedback_store.py / test_my_findings.py can run against a local Postgres.
-- If the contract changes, update this file from it, never the other way round.
CREATE SCHEMA IF NOT EXISTS ops;

CREATE TABLE ops.feedback (
  feedback_id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key    text NOT NULL UNIQUE,
  supersedes_id      uuid REFERENCES ops.feedback(feedback_id),
  finding_key        text NOT NULL,
  observation_date   date NOT NULL,
  rule_id            text NOT NULL,
  rule_fingerprint   text,
  notification_id    uuid,
  voter_email        text NOT NULL,
  voter_relation     text NOT NULL CHECK (voter_relation IN ('object_owner','workspace_owner','other')),
  channel            text NOT NULL CHECK (channel IN ('app','genie','email_link')),
  verdict            text NOT NULL CHECK (verdict IN (
                       'valid_will_fix','valid_cannot_fix','invalid',
                       'comment_only','not_my_resource','already_fixed')),
  reason_codes       text[] NOT NULL DEFAULT '{}',
  savings_assessment text CHECK (savings_assessment IN ('too_high','about_right','too_low','unsure')),
  free_text          text,
  snooze_until       date,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ops.opt_outs (
  email       text PRIMARY KEY,
  scope       text NOT NULL DEFAULT 'all',
  created_at  timestamptz NOT NULL DEFAULT now()
);
