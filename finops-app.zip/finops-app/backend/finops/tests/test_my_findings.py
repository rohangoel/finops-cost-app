"""My findings, recipient access to the resource page, and votes: the security boundary.

A finding is yours when its notify_recipient is your X-Forwarded-Email. That grants
access WITHOUT workspace scope, so these tests pin that it grants nothing more:
another user's finding stays 404, an email in a query parameter or the request body
is ignored, and only the recipient can vote. Read these before changing
deps.get_caller_email, RecommendationService.for_recipient or api/my_findings.py.

All of this is the optional StopTheLeak integration (FINOPS_STOPTHELEAK_ENABLED).
The "integration off" tests at the end pin that, off, none of it is reachable and
the app behaves as before, while finding_key links still resolve (those are core).

The vote tests need a real Postgres (FINOPS_TEST_PG_DSN, see conftest) and skip
without one; everything else runs anywhere.
"""

from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from finops import deps
from finops.config import Settings
from finops.data.base import RecommendationSource
from finops.data.feedback_store import FeedbackStore, make_connect
from finops.identity import Scope
from finops.main import create_app
from finops.models import Recommendation
from finops.services import RecommendationService

SP_ID = "3f2a9c1e-7b4d-4e2a-9f10-0a1b2c3d4e5f"
SNAPSHOT = date(2026, 9, 28)
ANA = "ana@example.com"
BOB = "bob@example.com"


def _rec(rule_id, resource_id, *, ws="111", owner=None, ws_owner=None, status="bookable",
         savings=100.0, rtype="warehouse") -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule_id}-{resource_id}-{SNAPSHOT}", snapshot_date=SNAPSHOT,
        rule_id=rule_id, rule_version="1", rule_title=rule_id, category="sql",
        workspace_id=ws, resource_type=rtype, resource_id=resource_id,
        resource_name=resource_id, resource_owner=owner, workspace_owner=ws_owner,
        why="w", how="h", monthly_waste_usd=savings * 2, monthly_savings_usd=savings,
        savings_status=status, effort_band="low", effort_score=2, priority="HIGH",
        nba_score=savings / 2, computed_at=datetime.now(timezone.utc),
    )


# Ana owns wh-1 outright (two rules on it) and, as workspace 222's owner, the SP-owned
# wh-3. Bob owns wh-2 in the same workspace 111. Nobody gets the ownerless wh-4.
ANA_OBJECT = _rec("warehouse_autostop", "wh-1", owner="Ana@Example.com", savings=300)
ANA_OBJECT_2 = _rec("warehouse_rightsize", "wh-1", owner="Ana@Example.com", savings=50,
                    status="advisory")
BOB_OBJECT = _rec("warehouse_autostop", "wh-2", owner=BOB, savings=200)
ANA_VIA_WS = _rec("warehouse_autostop", "wh-3", ws="222", owner=SP_ID, ws_owner=ANA)
NOBODY = _rec("warehouse_autostop", "wh-4", ws="222", owner=SP_ID)
ANA_HIDDEN = _rec("enable_photon_dbr", "c-9", owner=ANA, rtype="cluster")
ALL = [ANA_OBJECT, ANA_OBJECT_2, BOB_OBJECT, ANA_VIA_WS, NOBODY, ANA_HIDDEN]


class _Source(RecommendationSource):
    """In-memory source that applies workspace scope like scoping.where_clause."""

    def load(self, scope, account_view=None):
        if scope.all_workspaces:
            return list(ALL)
        return [r for r in ALL if r.workspace_id in {str(w) for w in scope.workspace_ids}]


@pytest.fixture
def make_client():
    def _make(*, scope: Scope | None = None, store: FeedbackStore | None = None,
              stoptheleak: bool = True):
        app = create_app()
        app.dependency_overrides[deps.stoptheleak_enabled] = lambda: stoptheleak
        settings = Settings(hidden_rules=["enable_photon_dbr"], experimental_rules=[])
        app.dependency_overrides[deps.get_recommendation_service] = (
            lambda: RecommendationService(_Source(settings, None))
        )
        # Default caller: signed in, but admin of nothing.
        app.dependency_overrides[deps.get_scope] = (
            lambda: scope or Scope(all_workspaces=False, workspace_ids=[])
        )
        if stoptheleak:
            app.dependency_overrides[deps.get_feedback_store] = lambda: store
        return TestClient(app)

    return _make


def _as(email):
    return {"X-Forwarded-Email": email}


def _gid(rec):
    return rec.group_id


# --- My findings ---------------------------------------------------------------------
def test_my_findings_lists_only_mine_including_advisory(make_client):
    body = make_client().get("/api/my-findings", headers=_as("ANA@example.com")).json()
    keys = [f["finding_key"] for f in body["findings"]]
    assert body["email"] == ANA
    assert set(keys) == {ANA_OBJECT.finding_key, ANA_OBJECT_2.finding_key, ANA_VIA_WS.finding_key}
    # Biggest saving first; advisory is included (emails exclude it, this tab doesn't).
    assert keys[0] == ANA_OBJECT.finding_key
    sources = {f["finding_key"]: f["recipient_source"] for f in body["findings"]}
    assert sources[ANA_VIA_WS.finding_key] == "workspace_owner"
    assert sources[ANA_OBJECT.finding_key] == "object_owner"


def test_my_findings_excludes_hidden_rules(make_client):
    body = make_client().get("/api/my-findings", headers=_as(ANA)).json()
    assert ANA_HIDDEN.finding_key not in {f["finding_key"] for f in body["findings"]}


def test_email_query_param_is_ignored(make_client):
    client = make_client()
    spoofed = client.get(f"/api/my-findings?email={BOB}&notify_recipient={BOB}", headers=_as(ANA))
    assert BOB_OBJECT.finding_key not in {f["finding_key"] for f in spoofed.json()["findings"]}
    anon = client.get(f"/api/my-findings?email={BOB}").json()
    assert anon == {"email": None, "feedback_enabled": False, "findings": []}


def test_other_identity_headers_do_not_count_as_the_email(make_client):
    """get_identity falls back to preferred-username / user; My findings must not."""
    body = make_client().get(
        "/api/my-findings", headers={"X-Forwarded-Preferred-Username": ANA}
    ).json()
    assert body["findings"] == []


# --- resource page access ------------------------------------------------------------
def test_recipient_opens_their_resource_without_scope(make_client):
    r = make_client().get(f"/api/recommendation-groups/{_gid(ANA_VIA_WS)}", headers=_as(ANA))
    assert r.status_code == 200
    assert [o["finding_key"] for o in r.json()["options"]] == [ANA_VIA_WS.finding_key]


def test_someone_elses_resource_is_404_without_scope(make_client):
    client = make_client()

    def status(path, **kw):
        return client.get(path, **kw).status_code

    assert status(f"/api/recommendation-groups/{_gid(BOB_OBJECT)}", headers=_as(ANA)) == 404
    assert status(f"/api/recommendation-groups/{_gid(NOBODY)}", headers=_as(ANA)) == 404
    assert status(f"/api/recommendation-groups/{_gid(ANA_OBJECT)}") == 404
    # Nor by id on the single-finding endpoint (old links).
    assert status(f"/api/recommendations/{BOB_OBJECT.finding_key}", headers=_as(ANA)) == 404


def test_scope_still_grants_the_whole_group(make_client):
    admin = make_client(scope=Scope(all_workspaces=True))
    r = admin.get(f"/api/recommendation-groups/{_gid(BOB_OBJECT)}", headers=_as(ANA))
    assert r.status_code == 200


def test_single_finding_resolves_by_finding_key(make_client):
    """A finding_key link keeps working after the recompute changes recommendation_id."""
    r = make_client().get(f"/api/recommendations/{ANA_OBJECT.finding_key}", headers=_as(ANA))
    assert r.status_code == 200
    assert r.json()["recommendation_id"] == ANA_OBJECT.recommendation_id


# --- votes (feedback off) -------------------------------------------------------------
def _vote(rec, verdict="valid_will_fix", **kw):
    return {"finding_key": rec.finding_key, "verdict": verdict,
            "client_request_id": str(uuid.uuid4()), **kw}


def test_feedback_off_means_no_votes(make_client):
    client = make_client(store=None)
    assert client.post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(ANA)).status_code == 404
    assert client.get("/api/feedback/mine", headers=_as(ANA)).json() == {}
    assert client.get("/api/email-preference", headers=_as(ANA)).status_code == 404


def test_bad_verdict_and_reason_codes_are_rejected(make_client):
    client = make_client(store=None)
    maybe = _vote(ANA_OBJECT, "maybe")
    assert client.post("/api/feedback", json=maybe, headers=_as(ANA)).status_code == 422
    bad_reason = _vote(ANA_OBJECT, "invalid", reason_codes=["customer_demo"])
    assert client.post("/api/feedback", json=bad_reason, headers=_as(ANA)).status_code == 422
    bad_snooze = _vote(ANA_OBJECT, "invalid", snooze_days=30)
    assert client.post("/api/feedback", json=bad_snooze, headers=_as(ANA)).status_code == 422


# --- votes (feedback on, real Postgres) -----------------------------------------------
@pytest.fixture
def store(feedback_pg_dsn):
    return FeedbackStore(make_connect(Settings(feedback_dsn=feedback_pg_dsn)))


def _rows(store):
    with store.connect() as conn:
        return conn.execute(
            "SELECT feedback_id::text, supersedes_id::text, voter_email, voter_relation, "
            "channel, verdict, observation_date, rule_id, reason_codes, snooze_until "
            "FROM ops.feedback ORDER BY created_at"
        ).fetchall()


def test_a_vote_inserts_one_row(make_client, store):
    r = make_client(store=store).post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(ANA))
    assert r.status_code == 201
    rows = _rows(store)
    assert len(rows) == 1
    _, supersedes, voter, relation, channel, verdict, obs, rule, _, _ = rows[0]
    assert (supersedes, voter, relation, channel, verdict) == (
        None, ANA, "object_owner", "app", "valid_will_fix",
    )
    assert obs == SNAPSHOT and rule == "warehouse_autostop"


def test_same_idempotency_key_twice_leaves_one_row(make_client, store):
    client = make_client(store=store)
    body = _vote(ANA_OBJECT)
    first = client.post("/api/feedback", json=body, headers=_as(ANA)).json()
    second = client.post("/api/feedback", json=body, headers=_as(ANA)).json()
    assert first["feedback_id"] == second["feedback_id"]
    assert len(_rows(store)) == 1


def test_idempotency_key_of_another_voter_conflicts(make_client, store):
    client = make_client(store=store)
    body = _vote(ANA_OBJECT)
    client.post("/api/feedback", json=body, headers=_as(ANA))
    replay = {**body, "finding_key": BOB_OBJECT.finding_key}
    assert client.post("/api/feedback", json=replay, headers=_as(BOB)).status_code == 409
    assert len(_rows(store)) == 1


def test_changed_vote_supersedes_the_previous_one(make_client, store):
    client = make_client(store=store)
    first = client.post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(ANA)).json()
    second = client.post(
        "/api/feedback",
        json=_vote(ANA_OBJECT, "invalid", reason_codes=["wrong_numbers"],
                   savings_assessment="too_high"),
        headers=_as(ANA),
    ).json()
    assert second["supersedes_id"] == first["feedback_id"]
    mine = client.get("/api/feedback/mine", headers=_as(ANA)).json()
    assert mine[ANA_OBJECT.finding_key]["verdict"] == "invalid"
    assert mine[ANA_OBJECT.finding_key]["reason_codes"] == ["wrong_numbers"]
    # A vote on another finding does not supersede this one.
    other = client.post("/api/feedback", json=_vote(ANA_VIA_WS), headers=_as(ANA)).json()
    assert other["supersedes_id"] is None
    assert other["voter_relation"] == "workspace_owner"


def test_voter_comes_from_the_header_not_the_body(make_client, store):
    spoof = _vote(ANA_OBJECT, voter_email=BOB, voter_relation="other",
                  observation_date="2020-01-01", rule_id="x", channel="app")
    r = make_client(store=store).post("/api/feedback", json=spoof, headers=_as(ANA))
    assert r.status_code == 201
    _, _, voter, relation, _, _, obs, rule, _, _ = _rows(store)[0]
    assert (voter, relation, obs, rule) == (ANA, "object_owner", SNAPSHOT, "warehouse_autostop")


def test_no_header_cannot_vote(make_client, store):
    assert make_client(store=store).post("/api/feedback", json=_vote(ANA_OBJECT)).status_code == 401
    assert _rows(store) == []


def test_non_recipient_cannot_vote(make_client, store):
    # Bob, admin of nothing: Ana's finding doesn't exist for him.
    nobody = make_client(store=store)
    assert nobody.post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(BOB)).status_code == 404
    # Bob as workspace admin of 111 can SEE it, but it isn't his to vote on.
    admin = make_client(store=store, scope=Scope(all_workspaces=False, workspace_ids=["111"]))
    assert admin.post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(BOB)).status_code == 403
    assert _rows(store) == []


def test_snooze_and_email_link_channel(make_client, store):
    body = _vote(ANA_OBJECT, "valid_cannot_fix", reason_codes=["customer_demo"],
                 snooze_days=30, channel="email_link", free_text="customer demo")
    r = make_client(store=store).post("/api/feedback", json=body, headers=_as(ANA)).json()
    assert r["channel"] == "email_link"
    assert r["snooze_until"] == (date.today() + timedelta(days=30)).isoformat()
    assert r["free_text"] == "customer demo"


def test_opening_a_prefill_link_records_nothing(make_client, store):
    """The confirm link carries verdict/reason as query params; loading the page (and
    its API reads) must never write a vote. Only POST /api/feedback does."""
    client = make_client(store=store)
    q = f"?focus={ANA_OBJECT.finding_key}&verdict=valid_cannot_fix&reason=customer+demo"
    client.get(f"/api/recommendation-groups/{_gid(ANA_OBJECT)}{q}", headers=_as(ANA))
    client.get(f"/api/feedback/mine{q}", headers=_as(ANA))
    assert _rows(store) == []


def test_email_opt_out_and_undo(make_client, store):
    client = make_client(store=store)
    assert client.get("/api/email-preference", headers=_as(ANA)).json()["weekly_email"] is True
    stop = "/api/email-preference/weekly-email"
    assert client.delete(stop, headers=_as("Ana@Example.com")).status_code == 204
    assert client.delete(stop, headers=_as(ANA)).status_code == 204  # idempotent
    assert client.get("/api/email-preference", headers=_as(ANA)).json()["weekly_email"] is False
    assert client.get("/api/email-preference", headers=_as(BOB)).json()["weekly_email"] is True
    with store.connect() as conn:
        assert conn.execute("SELECT email, scope FROM ops.opt_outs").fetchall() == [(ANA, "all")]
    assert client.put("/api/email-preference/weekly-email", headers=_as(ANA)).status_code == 204
    assert client.get("/api/email-preference", headers=_as(ANA)).json()["weekly_email"] is True
    assert client.delete("/api/email-preference/weekly-email").status_code == 401


# --- integration off (the default) ------------------------------------------------------
def test_off_by_default():
    assert Settings().stoptheleak_enabled is False
    assert Settings(feedback_enabled=True).feedback_active is False


def test_off_hides_my_findings_votes_and_opt_out(make_client):
    client = make_client(stoptheleak=False)
    assert client.get("/api/my-findings", headers=_as(ANA)).status_code == 404
    assert client.get("/api/feedback/mine", headers=_as(ANA)).status_code == 404
    assert client.post("/api/feedback", json=_vote(ANA_OBJECT), headers=_as(ANA)).status_code == 404
    assert client.get("/api/email-preference", headers=_as(ANA)).status_code == 404


def test_off_means_no_recipient_access_only_scope(make_client):
    """Without the integration, owning a finding grants nothing: scope rules as before."""
    client = make_client(stoptheleak=False)
    r = client.get(f"/api/recommendation-groups/{_gid(ANA_VIA_WS)}", headers=_as(ANA))
    assert r.status_code == 404
    admin = make_client(stoptheleak=False, scope=Scope(all_workspaces=True))
    assert admin.get(f"/api/recommendation-groups/{_gid(ANA_VIA_WS)}").status_code == 200


def test_off_finding_key_links_still_resolve(make_client):
    """finding_key is core: an email/Genie link keeps working for anyone in scope."""
    admin = make_client(stoptheleak=False, scope=Scope(all_workspaces=True))
    r = admin.get(f"/api/recommendations/{ANA_OBJECT.finding_key}")
    assert r.status_code == 200 and r.json()["finding_key"] == ANA_OBJECT.finding_key


def test_config_reports_the_flags(make_client):
    cfg = make_client(stoptheleak=False).get("/api/config").json()
    assert cfg["stoptheleak_enabled"] is False
    assert cfg["feedback_enabled"] is False

