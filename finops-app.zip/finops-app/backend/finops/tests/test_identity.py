from __future__ import annotations

from finops.config import Settings
from finops.identity import Scope
from finops.identity.obo import OboIdentityProvider
from finops.identity.service_principal import SpIdentityProvider


def test_obo_platform_admin_sees_all(request_headers):
    settings = Settings(auth_mode="obo", dev_role="platform_admin", databricks_token="tok")
    provider = OboIdentityProvider(settings)
    identity = provider.resolve(request_headers({"x-forwarded-email": "a@databricks.com"}))
    assert identity.role == "platform_admin"
    assert identity.all_workspaces is True
    assert Scope.from_identity(identity).all_workspaces is True


def test_obo_token_prefers_env_then_header(request_headers):
    settings = Settings(auth_mode="obo", databricks_token="local-tok")
    provider = OboIdentityProvider(settings)
    assert provider.access_token(request_headers({})) == "local-tok"

    settings.databricks_token = ""
    assert provider.access_token(
        request_headers({"x-forwarded-access-token": "obo-tok"})
    ) == "obo-tok"


def test_sp_scopes_user_from_mapping(monkeypatch, request_headers):
    monkeypatch.setenv(
        "FINOPS_USER_SCOPE_JSON",
        '{"wsadmin@databricks.com": {"role": "workspace_admin", "workspace_ids": ["111"]}}',
    )
    provider = SpIdentityProvider(Settings(auth_mode="sp"))
    identity = provider.resolve(request_headers({"x-forwarded-email": "wsadmin@databricks.com"}))
    assert identity.role == "workspace_admin"
    assert identity.all_workspaces is False
    assert identity.workspace_ids == ["111"]


def test_sp_unknown_user_is_least_privilege(request_headers):
    provider = SpIdentityProvider(Settings(auth_mode="sp"))
    identity = provider.resolve(request_headers({"x-forwarded-email": "nobody@databricks.com"}))
    assert identity.role == "workspace_admin"
    assert identity.workspace_ids == []
