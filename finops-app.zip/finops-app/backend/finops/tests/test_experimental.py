"""The experimental-rule filter: Phase 4 opportunity rules relocated to the Labs tab.

Experimental rules (``Rule.experimental``) are computed and stored, but must never
appear in the main recommendation surfaces — not in a list, group, chart, savings
total or NBA ranking. Like the hidden-rule and sidecar-category filters, this lives
at the ONE boundary every read path crosses (``RecommendationSource``), and these
tests pin it. See data/base.py and services/recommendation_service.py.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from finops.config import Settings
from finops.data.base import RecommendationSource
from finops.identity import Scope
from finops.models import Recommendation
from finops.services import aggregation
from finops.services.recommendation_service import RecommendationService

ADMIN = Scope(all_workspaces=True, workspace_ids=[])

# Pin the experimental set explicitly so the test does not depend on the live
# registry (which derives it from Rule.experimental).
EXPERIMENTAL = ["sql_repeated_failures", "manual_maintenance_overlap"]


def _rec(rule: str, savings: float, waste: float, resource: str, category: str = "compute") -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule}-{resource}",
        snapshot_date=date(2026, 9, 20),
        rule_id=rule,
        rule_version="1.0.0",
        rule_title=rule.replace("_", " ").title(),
        category=category,
        workspace_id="111",
        resource_type="warehouse",
        resource_id=resource,
        resource_name=resource,
        why="because",
        how="do this",
        monthly_waste_usd=waste,
        monthly_savings_usd=savings,
        savings_status="advisory" if rule in EXPERIMENTAL else "bookable",
        effort_band="low",
        effort_score=2,
        priority="MEDIUM",
        nba_score=savings / 2,
        evidence={},
        computed_at=datetime(2026, 9, 20, tzinfo=timezone.utc),
    )


class _Source(RecommendationSource):
    def __init__(self, settings, recs):
        super().__init__(settings, None)
        self._recs = recs

    def load(self, scope, account_view=None):
        return list(self._recs)


_ALL = [
    _rec("cluster_autotermination", 100.0, 200.0, "c-1"),
    _rec("untagged_spend", 0.0, 400.0, "c-2", category="governance"),
    _rec("sql_repeated_failures", 0.0, 300.0, "wh-1", category="sql"),
    _rec("manual_maintenance_overlap", 0.0, 150.0, "wh-2", category="sql"),
]


def _source(experimental: list[str] | None = EXPERIMENTAL) -> _Source:
    settings = Settings(experimental_rules=experimental, sidecar_categories=["governance"])
    return _Source(settings, _ALL)


def test_experimental_rules_dropped_from_main_fetch():
    ids = {r.rule_id for r in _source().fetch(ADMIN)}
    # Main surface keeps only the real, non-governance rule.
    assert ids == {"cluster_autotermination"}


def test_experimental_served_only_by_fetch_experimental():
    ids = {r.rule_id for r in _source().fetch_experimental(ADMIN)}
    assert ids == set(EXPERIMENTAL)


def test_experimental_excluded_from_sidecar():
    # Governance findings still come through the sidecar; experimental ones never do.
    ids = {r.rule_id for r in _source().fetch_sidecar(ADMIN)}
    assert ids == {"untagged_spend"}


def test_experimental_savings_excluded_from_account_totals():
    overview = aggregation.account_overview(_source().fetch(ADMIN))
    # Only the bookable cluster_autotermination (100) — the advisory experimental
    # findings ($0 savings) and the governance one never reach the headline.
    assert overview.total_monthly_savings_usd == 100.0
    assert overview.recommendation_count == 1


def test_experimental_overview_reports_addressable_spend():
    svc = RecommendationService(_source())
    ov = svc.experimental_overview(ADMIN)
    # Addressable = sum of monthly_waste_usd across the two experimental findings.
    assert ov.total_addressable_monthly_usd == 450.0
    assert ov.recommendation_count == 2
    assert ov.rule_count == 2
    assert ov.workspace_count == 1
    # Sorted by addressable spend, descending.
    assert [i.rule_id for i in ov.items] == [
        "sql_repeated_failures",
        "manual_maintenance_overlap",
    ]


def test_experimental_absent_from_groups_and_nba():
    svc = RecommendationService(_source())
    group_rules = {o.rule_id for g in svc.list_grouped(ADMIN) for o in g.options}
    assert not group_rules & set(EXPERIMENTAL)
    nba_rules = {r.rule_id for r in svc.next_best_actions(ADMIN, limit=50)}
    assert not nba_rules & set(EXPERIMENTAL)


def test_detail_lookup_resolves_an_experimental_finding():
    # A detail link opened from the Labs tab must still resolve via get().
    svc = RecommendationService(_source())
    rec = svc.get(ADMIN, "sql_repeated_failures-wh-1")
    assert rec is not None and rec.rule_id == "sql_repeated_failures"


def test_empty_config_folds_experimental_back():
    # A deploy can resurface them into the main surfaces by clearing the set.
    ids = {r.rule_id for r in _source(experimental=[]).fetch(ADMIN)}
    assert set(EXPERIMENTAL) <= ids
    assert _source(experimental=[]).fetch_experimental(ADMIN) == []


def test_experimental_overview_counts_overlapping_findings_once():
    """Two Labs rules on ONE resource: the addressable headline counts that resource's
    spend once (the larger figure), and the resource count shows it is one thing."""
    recs = [
        _rec("sql_repeated_failures", 0.0, 300.0, "wh-1", category="sql"),
        _rec("manual_maintenance_overlap", 0.0, 150.0, "wh-1", category="sql"),
    ]
    settings = Settings(experimental_rules=EXPERIMENTAL, sidecar_categories=["governance"])
    ov = RecommendationService(_Source(settings, recs)).experimental_overview(ADMIN)
    assert ov.total_addressable_monthly_usd == 300.0  # not 450
    assert ov.recommendation_count == 2
    assert ov.resource_count == 1
