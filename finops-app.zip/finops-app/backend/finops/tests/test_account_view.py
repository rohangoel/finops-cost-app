"""The global account view — one account/cloud/account_id selection filtering
every recommendation surface at once, so two customers' findings never mix.

Like the hidden-rule filter, it lives at the ONE boundary every read path crosses
(``RecommendationSource.fetch``), so these tests pin it there and through the
service methods and the aggregation path that reads ``service.source`` directly.
The facets read must BYPASS it (the dropdowns list every account regardless of the
current pick).
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from starlette.datastructures import QueryParams

from finops.config import Settings
from finops.data.account_view import AccountView
from finops.data.base import RecommendationSource
from finops.identity import Scope
from finops.models import Recommendation
from finops.services import aggregation
from finops.services.recommendation_service import RecommendationService

ADMIN = Scope(all_workspaces=True, workspace_ids=[])


def _rec(account: str, cloud: str, acct_id: str, resource: str, savings: float) -> Recommendation:
    return Recommendation(
        recommendation_id=f"{acct_id}-{resource}",
        snapshot_date=date(2026, 9, 1),
        rule_id="cluster_autotermination",
        rule_version="1.0.0",
        rule_title="Cluster Autotermination",
        category="compute",
        workspace_id=resource,
        resource_type="cluster",
        resource_id=resource,
        resource_name=resource,
        why="because",
        how="do this",
        monthly_waste_usd=savings * 2,
        monthly_savings_usd=savings,
        effort_band="low",
        effort_score=2,
        priority="MEDIUM",
        nba_score=savings / 2,
        evidence={},
        computed_at=datetime(2026, 9, 1, tzinfo=timezone.utc),
        databricks_account_id=acct_id,
        cloud_type=cloud,
        salesforce_account_name=account,
    )


_ALL = [
    _rec("Mercedes-Benz - Global HQ", "aws", "mb-aws", "c-1", 100.0),
    _rec("Mercedes-Benz - Global HQ", "azure", "mb-az", "c-2", 200.0),
    _rec("Bayer AG - Global HQ", "aws", "bayer-aws", "c-3", 400.0),
    _rec("Bayer AG - Global HQ", "azure", "bayer-az", "c-4", 800.0),
]


class _Source(RecommendationSource):
    def __init__(self, account_view=None):
        super().__init__(Settings(hidden_rules=[]), None, account_view=account_view)

    def load(self, scope, account_view=None):
        return list(_ALL)


def test_no_view_returns_everything():
    assert len(_Source().fetch(ADMIN)) == 4


def test_account_filter_isolates_one_customer():
    src = _Source(AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    names = {r.salesforce_account_name for r in src.fetch(ADMIN)}
    assert names == {"Bayer AG - Global HQ"}


def test_cloud_and_account_id_narrow_further():
    src = _Source(AccountView(cloud_type="azure"))
    assert {r.cloud_type for r in src.fetch(ADMIN)} == {"azure"}
    src = _Source(AccountView(databricks_account_id="mb-aws"))
    assert [r.databricks_account_id for r in src.fetch(ADMIN)] == ["mb-aws"]


def test_filters_compose_conjunctively():
    src = _Source(AccountView(salesforce_account_name="Mercedes-Benz - Global HQ", cloud_type="aws"))
    got = src.fetch(ADMIN)
    assert len(got) == 1
    assert got[0].databricks_account_id == "mb-aws"


def test_filter_applies_across_every_service_surface():
    # The whole point: a customer selection isolates that customer on the list, the
    # groups, the NBA ranking and the account overview — not just the raw list.
    src = _Source(AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    svc = RecommendationService(src)
    assert {r.salesforce_account_name for r in svc.list(ADMIN)} == {"Bayer AG - Global HQ"}
    assert {o.salesforce_account_name for g in svc.list_grouped(ADMIN) for o in g.options} == {
        "Bayer AG - Global HQ"
    }
    assert {r.salesforce_account_name for r in svc.next_best_actions(ADMIN, limit=50)} == {
        "Bayer AG - Global HQ"
    }
    overview = aggregation.account_overview(src.fetch(ADMIN))
    assert overview.total_monthly_savings_usd == 1200.0  # 400 + 800, no MB


def test_facets_ignore_the_current_selection():
    # Picking one account must not collapse the dropdowns to that account alone.
    src = _Source(AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    facets = RecommendationService(src).facets(ADMIN)
    assert facets["salesforce_account_name"] == [
        "Bayer AG - Global HQ",
        "Mercedes-Benz - Global HQ",
    ]
    assert facets["cloud_type"] == ["aws", "azure"]


def test_from_query_treats_blank_as_unset():
    view = AccountView.from_query(QueryParams("salesforce_account_name=&cloud_type=aws"))
    assert view.salesforce_account_name is None
    assert view.cloud_type == "aws"
    assert view.active is True
    assert AccountView.from_query(QueryParams("")).active is False


# --- SQL pushdown (the pushdown twin of apply(); precompute folds it into its SELECT) ---

def test_sql_predicate_empty_when_no_filter():
    assert AccountView().sql_predicate() == ""


def test_sql_predicate_single_and_conjunction():
    assert (
        AccountView(salesforce_account_name="Bayer AG - Global HQ").sql_predicate()
        == "salesforce_account_name = 'Bayer AG - Global HQ'"
    )
    view = AccountView(cloud_type="aws", databricks_account_id="12c245b4")
    assert view.sql_predicate() == (
        "cloud_type = 'aws' AND databricks_account_id = '12c245b4'"
    )


def test_sql_predicate_escapes_single_quotes():
    # Defensive: a quote in a value must not break out of the string literal.
    got = AccountView(salesforce_account_name="O'Brien Corp").sql_predicate()
    assert got == "salesforce_account_name = 'O''Brien Corp'"


class _SpySource(RecommendationSource):
    """Records the account_view hint fetch() passes to load()."""

    def __init__(self, account_view=None):
        super().__init__(Settings(hidden_rules=[]), None, account_view=account_view)
        self.seen_hint = "unset"

    def load(self, scope, account_view=None):
        self.seen_hint = account_view
        return list(_ALL)


def test_fetch_passes_active_view_as_pushdown_hint():
    view = AccountView(salesforce_account_name="Bayer AG - Global HQ")
    src = _SpySource(view)
    src.fetch(ADMIN)
    assert src.seen_hint is view  # active selection is pushed down


def test_fetch_withholds_hint_for_facets_and_when_inactive():
    # Facets (apply_account_view=False) must see every account, so no pushdown.
    src = _SpySource(AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    src.fetch(ADMIN, apply_account_view=False)
    assert src.seen_hint is None
    # No selection at all → nothing to push down.
    src2 = _SpySource(AccountView())
    src2.fetch(ADMIN)
    assert src2.seen_hint is None


def test_facets_cascade_within_the_selected_account():
    # Account list stays complete (the gate must reach every customer); cloud narrows
    # to the selected account; account-id cascades one step further to account + cloud.
    svc = RecommendationService(_Source())
    mb = svc.facets(ADMIN, AccountView(salesforce_account_name="Mercedes-Benz - Global HQ"))
    assert mb["salesforce_account_name"] == ["Bayer AG - Global HQ", "Mercedes-Benz - Global HQ"]
    assert set(mb["cloud_type"]) == {"aws", "azure"}
    assert set(mb["databricks_account_id"]) == {"mb-aws", "mb-az"}  # Mercedes only, both clouds

    # Pick a cloud too → the account-id dropdown narrows to that cloud's ids, but the
    # cloud dropdown itself does NOT collapse to the single pick.
    mb_aws = svc.facets(
        ADMIN, AccountView(salesforce_account_name="Mercedes-Benz - Global HQ", cloud_type="aws")
    )
    assert mb_aws["databricks_account_id"] == ["mb-aws"]
    assert set(mb_aws["cloud_type"]) == {"aws", "azure"}
