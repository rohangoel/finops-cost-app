from __future__ import annotations

from datetime import date, datetime, timezone

from finops.identity import Scope
from finops.models import Recommendation
from finops.models.group import group_id
from finops.services import RecommendationService


def _rec(
    rec_id="r1",
    rule="warehouse_autostop",
    title="Enable auto-stop",
    ws="111",
    res_type="warehouse",
    res="wh-1",
    savings=400.0,
    waste=1000.0,
    effort="trivial",
    priority="HIGH",
    nba=500.0,
    category="sql",
    comp="exclusive",
) -> Recommendation:
    return Recommendation(
        recommendation_id=rec_id, snapshot_date=date(2026, 7, 13),
        rule_id=rule, rule_version="1", rule_title=title, category=category,
        workspace_id=ws, resource_type=res_type, resource_id=res, resource_name=res,
        why="w", how="h", monthly_waste_usd=waste, monthly_savings_usd=savings,
        savings_composition=comp,
        effort_band=effort, effort_score=2, priority=priority, nba_score=nba,
        computed_at=datetime.now(timezone.utc),
    )


class _FakeSource:
    def __init__(self, recs):
        self._recs = recs

    def fetch(self, scope):
        return [r.model_copy() for r in self._recs]

    def fetch_sidecar(self, scope):
        return []  # no governance/sidecar recs in these fixtures


def _svc(recs):
    return RecommendationService(_FakeSource(recs))


ADMIN = Scope(all_workspaces=True, workspace_ids=[])


def test_groups_same_resource_and_uses_max_not_sum():
    # Two overlapping fixes on ONE warehouse: auto-stop ($400) + rightsize ($423).
    svc = _svc([
        _rec("r1", rule="warehouse_autostop", title="Auto-stop", savings=404.0, nba=505.0),
        _rec("r2", rule="warehouse_rightsize", title="Right-size", savings=423.0,
             effort="low", priority="MEDIUM", nba=211.0),
    ])
    groups = svc.list_grouped(ADMIN)
    assert len(groups) == 1
    g = groups[0]
    assert g.option_count == 2
    # Representative savings is the MAX (423), never the sum (827).
    assert g.monthly_savings_usd == 423.0
    assert g.options_savings_sum_usd == 827.0
    # Easiest effort wins (trivial < low); most urgent priority wins (HIGH).
    assert g.effort_band == "trivial"
    assert g.priority == "HIGH"
    assert "2 ways to optimize this warehouse" == g.action_label
    # Options are ordered by SAVINGS, highest first — the detail page lists every
    # applicable recommendation in sequence, so the biggest-dollar one must lead
    # (rightsize $423 ahead of auto-stop $404, even though auto-stop ranks higher
    # on NBA because it is less effort).
    assert [o.rule_id for o in g.options] == ["warehouse_rightsize", "warehouse_autostop"]
    # The group's own rank is the max NBA across options, so the option ordering
    # never changes where this resource sits in the overview.
    assert g.nba_score == 505.0


def test_additive_options_compose_the_group_representative_savings():
    # FIN-008: when the two options on a resource are COMPATIBLE tunings (additive), the
    # group's representative savings COMPOSES them onto the remaining counterfactual —
    # bounded by the resource's cost — instead of taking the max. Here auto-stop ($300) +
    # right-size ($400) exceed the $600 the warehouse costs, so the composition clips to
    # $600: distinct from both the max option ($400) and the naive sum ($700).
    svc = _svc([
        _rec("r1", rule="warehouse_autostop", title="Auto-stop", savings=300.0,
             waste=600.0, comp="additive"),
        _rec("r2", rule="warehouse_rightsize", title="Right-size", savings=400.0,
             waste=600.0, comp="additive"),
    ])
    g = svc.list_grouped(ADMIN)[0]
    assert g.monthly_savings_usd == 600.0        # composed, capped at the $600 cost
    assert g.options_savings_sum_usd == 700.0    # naive theoretical sum (300 + 400)


def test_single_finding_uses_rule_title_as_label():
    svc = _svc([_rec("r1", title="Retire unused job", res_type="job", res="j-1")])
    g = svc.list_grouped(ADMIN)[0]
    assert g.option_count == 1
    assert g.action_label == "Retire unused job"


def test_distinct_resources_are_separate_groups():
    svc = _svc([
        _rec("r1", res="wh-1"),
        _rec("r2", res="wh-2"),
        _rec("r3", res_type="cluster", res="c-1"),
    ])
    groups = svc.list_grouped(ADMIN)
    assert len(groups) == 3


def test_get_group_by_stable_id():
    svc = _svc([
        _rec("r1", rule="warehouse_autostop", savings=404.0),
        _rec("r2", rule="warehouse_rightsize", savings=423.0),
    ])
    gid = group_id("111", "warehouse", "wh-1")
    g = svc.get_group(ADMIN, gid)
    assert g is not None and g.option_count == 2
    assert svc.get_group(ADMIN, "nonexistent") is None


def test_min_savings_filters_on_group_representative():
    svc = _svc([
        _rec("r1", res="wh-1", savings=404.0),
        _rec("r2", res="wh-2", savings=50.0),
    ])
    groups = svc.list_grouped(ADMIN, min_savings=100.0)
    assert len(groups) == 1 and groups[0].resource_id == "wh-1"


def test_serving_endpoint_filter_and_label():
    """A serving-endpoint finding must be filterable and read naturally.

    The Recommendations tab filters by resource_type, and the grouped label is
    built from a slug->noun map — an unmapped type silently degrades to the
    generic "resource", so both are pinned here."""
    svc = _svc([
        _rec("r1", rule="idle_serving_endpoints", title="Scale to zero",
             res_type="serving_endpoint", res="ep-1", category="serving"),
        _rec("r2", rule="warehouse_autostop", res_type="warehouse", res="wh-1"),
    ])
    only = svc.list_grouped(ADMIN, resource_type="serving_endpoint")
    assert [g.resource_id for g in only] == ["ep-1"]
    assert only[0].category == "serving"


def test_multi_option_serving_endpoint_label_reads_naturally():
    svc = _svc([
        _rec("r1", rule="idle_serving_endpoints", title="Scale to zero",
             res_type="serving_endpoint", res="ep-1", savings=400.0, category="serving"),
        _rec("r2", rule="some_other_serving_rule", title="Other", savings=300.0,
             res_type="serving_endpoint", res="ep-1", category="serving"),
    ])
    g = svc.list_grouped(ADMIN)[0]
    assert g.action_label == "2 ways to optimize this serving endpoint"


def _rule_id_fixture():
    # Cluster A: both interactive_to_job AND rightsize apply.
    # Cluster B: only rightsize.  Cluster C: only interactive_to_job.
    return _svc([
        _rec("a1", rule="interactive_to_job", res_type="cluster", res="c-A", savings=300.0),
        _rec("a2", rule="rightsize_underutilized", res_type="cluster", res="c-A", savings=500.0),
        _rec("b1", rule="rightsize_underutilized", res_type="cluster", res="c-B", savings=200.0),
        _rec("c1", rule="interactive_to_job", res_type="cluster", res="c-C", savings=250.0),
    ])


def test_rule_ids_single_keeps_any_resource_with_that_rule():
    svc = _rule_id_fixture()
    only = svc.list_grouped(ADMIN, rule_ids=["interactive_to_job"])
    # A (has it, among two) and C (only it) — B has only rightsize, excluded.
    assert {g.resource_id for g in only} == {"c-A", "c-C"}


def test_rule_ids_all_semantics_keeps_only_the_overlap():
    # The user's case: only resources where BOTH selected types apply.
    svc = _rule_id_fixture()
    both = svc.list_grouped(
        ADMIN, rule_ids=["interactive_to_job", "rightsize_underutilized"]
    )
    assert [g.resource_id for g in both] == ["c-A"]
    # The group still carries BOTH options (the filter selects groups, not members).
    assert {o.rule_id for o in both[0].options} == {
        "interactive_to_job",
        "rightsize_underutilized",
    }


def test_rule_ids_empty_is_no_filter():
    svc = _rule_id_fixture()
    assert len(svc.list_grouped(ADMIN, rule_ids=[])) == 3
    assert len(svc.list_grouped(ADMIN, rule_ids=None)) == 3


def test_rule_ids_combines_with_other_filters():
    # AND with min_savings: c-A's representative (max option) is 500, kept; if we
    # also demanded both rules, only c-A qualifies anyway.
    svc = _rule_id_fixture()
    out = svc.list_grouped(
        ADMIN, rule_ids=["interactive_to_job", "rightsize_underutilized"], min_savings=100.0
    )
    assert [g.resource_id for g in out] == ["c-A"]
    # Demanding a rule no resource has yields nothing.
    assert svc.list_grouped(ADMIN, rule_ids=["nonexistent_rule"]) == []
