"""Databricks Apps inventory reads, and the guarantee that it makes NO claims.

The unusual assertions here are the negative ones. This surface exists to show facts
without verdicts, because the data cannot support verdicts: system tables have no app
request/page-view log, only lifecycle events, so "is this app used?" is unanswerable
(verified live 2026-08-06). Tests therefore pin:

* the SQL selects apps by ``billing_origin_product``, since **no part of the Apps SKU
  name says "app"** — they bill under
  ``PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_<REGION>``, which is the same fact that
  made apps invisible in the spend breakdown;
* the window is exactly N days (``date_sub`` is inclusive at both ends, so the naive
  filter yields N+1 and an always-on app reports "billed 31 of the last 30 days");
* the model carries no savings/priority/NBA field that a UI could render as a
  recommendation;
* scoping and the per-workspace drill-in behave like Genie's.
"""

from __future__ import annotations

import json

from finops.config import Settings
from finops.data.apps_source import AppsSource, DemoAppsSource, _rollup
from finops.data.apps_sql import (
    apps_daily_sql,
    apps_inventory_sql,
    apps_size_summary_sql,
)
from finops.identity import Scope

from .conftest import fake_connect

ADMIN = Scope(all_workspaces=True, workspace_ids=[])
SCOPED = Scope(all_workspaces=False, workspace_ids=["111"])

# Mirrors the real snapshot table: workspace_id/name/url are REAL columns and are NOT
# inside the payload (see ddl/finops_apps_usage.sql).
_SNAPSHOT_COLUMNS = ["kind", "workspace_id", "workspace_name", "workspace_url", "payload"]


def _app(app_id="a1", *, wid="111", name="sales-cockpit", size="MEDIUM",
         days=30, spend=700.0, deploys=0):
    return {
        "workspace_id": wid, "app_id": app_id, "app_name": name,
        "compute_size": size, "size_changes": 1,
        "days_billed": days, "observed_days": days,
        "first_seen_date": "2026-07-07", "last_billed_date": "2026-08-05",
        "dbus": spend, "spend_usd": spend, "monthly_spend_usd": spend,
        "last_deploy_time": "2026-07-30 12:00:00" if deploys else None,
        "last_start_time": None, "last_stop_time": None,
        "deploys": deploys, "last_deployed_by": "dev@x.com" if deploys else None,
    }


def _snapshot_rows(inventory=(), size=(), daily=()):
    rows = []
    for kind, items in (("inventory", inventory), ("size", size), ("daily", daily)):
        for it in items:
            payload = {k: v for k, v in it.items() if k != "workspace_id"}
            wid = it.get("workspace_id")
            rows.append((
                kind,
                str(wid) if wid is not None else None,
                f"Workspace {wid}" if wid is not None else None,
                f"https://ws{wid}.example.net" if wid is not None else None,
                json.dumps(payload),
            ))
    return rows


def _source(rows, *, mode="precompute") -> AppsSource:
    return AppsSource(Settings(compute_mode=mode), fake_connect(_SNAPSHOT_COLUMNS, rows))


# --- the SQL contract ---------------------------------------------------------
def test_apps_are_selected_by_product_not_sku_name():
    """The central billing fact: Apps bill under a generic serverless SKU whose name
    contains no hint of "app", so sku_name matching cannot find them."""
    for builder in (apps_inventory_sql, apps_size_summary_sql, apps_daily_sql):
        sql = builder("system", 30)
        assert "billing_origin_product = 'APPS'" in sql
        assert "sku_name LIKE" not in sql


def test_the_window_is_exactly_n_days():
    """date_sub is inclusive at both ends, so `>= date_sub(current_date(), 30)` alone
    spans 31 dates and an always-on app reports days_billed = 31 for a 30-day window.
    Excluding today makes "billed 30 of the last 30 days" literally true."""
    for builder in (apps_inventory_sql, apps_size_summary_sql, apps_daily_sql):
        sql = builder("system", 30)
        assert "date_sub(current_date(), 30)" in sql
        assert "usage_date < current_date()" in sql


def test_sql_prices_at_list_and_is_region_scoped_not_persona_filtered():
    sql = apps_inventory_sql("system", 30)
    assert "billing.list_prices" in sql
    # Persona scoping (a literal id list) is still injected by the caller, like the
    # rule SQL. The builder itself carries only the region filter: billing.usage is
    # account-global, so it is restricted to this metastore's workspaces (region.py).
    assert sql.count("workspace_id IN (") == 1
    assert "workspace_id IN (SELECT workspace_id FROM system.access.workspaces_latest" in sql


def test_lifecycle_reads_both_audit_parameter_keys():
    """Verified live: deployApp carries request_params.app_name while
    startApp/stopApp carry request_params['name']. Reading only app_name (the obvious
    guess) returns nothing at all for start/stop."""
    sql = apps_inventory_sql("system", 30)
    assert "request_params.app_name" in sql
    assert "request_params['name']" in sql


def test_lifecycle_is_a_left_join_so_apps_without_audit_rows_survive():
    """Most apps have no lifecycle event inside a given window (146 of 1,239 on a
    real account). An inner join would silently drop the rest."""
    sql = apps_inventory_sql("system", 30)
    assert "LEFT JOIN lifecycle" in sql


# --- no verdicts -------------------------------------------------------------
def test_the_model_carries_no_recommendation_fields():
    """The guarantee this whole surface rests on. If a savings or priority field ever
    appears here, something will render it as advice we cannot justify."""
    from finops.models.apps import AppInfo, AppsInventory

    forbidden = {
        "monthly_savings_usd", "monthly_waste_usd", "nba_score", "priority",
        "effort_band", "effort_score", "why", "how", "recommendation_id",
    }
    for model in (AppInfo, AppsInventory):
        assert not (forbidden & set(model.model_fields)), model.__name__


def test_the_analysis_note_explains_why_there_are_no_recommendations():
    inv = _rollup({}, lookback_days=30, unavailable=False)
    note = inv.analysis_note.lower()
    # It must name the actual limitation, not just say "not available".
    assert "audit" in note
    assert "lifecycle" in note
    assert "guess" in note


def test_days_billed_is_reported_as_a_neutral_count():
    """Apps are always-on while running, so a full-window count is NORMAL. It is
    surfaced as a plain tally with no verdict attached — there is deliberately no
    "idle" or "underused" flag for the UI to render."""
    inv = _rollup(
        {"inventory": [_app(days=30)]}, lookback_days=30, unavailable=False
    )
    assert inv.always_on_count == 1
    assert inv.apps[0].days_billed == 30
    assert not hasattr(inv.apps[0], "idle")


# --- rollup ------------------------------------------------------------------
def test_totals_come_from_the_daily_series_and_normalize_to_a_month():
    daily = [
        {"workspace_id": "111", "usage_date": "2026-08-01", "apps": 2,
         "dbus": 50.0, "spend_usd": 50.0},
        {"workspace_id": "111", "usage_date": "2026-08-02", "apps": 2,
         "dbus": 50.0, "spend_usd": 50.0},
    ]
    inv = _rollup({"daily": daily}, lookback_days=15, unavailable=False)
    assert inv.total_spend_usd == 100.0
    # $100 over 15 days is $200/month, not $100.
    assert inv.monthly_spend_usd == 200.0


def test_daily_is_summed_across_workspaces_and_date_ordered():
    daily = [
        {"workspace_id": "222", "usage_date": "2026-08-02", "apps": 1,
         "dbus": 5.0, "spend_usd": 5.0},
        {"workspace_id": "111", "usage_date": "2026-08-01", "apps": 3,
         "dbus": 30.0, "spend_usd": 30.0},
        {"workspace_id": "222", "usage_date": "2026-08-01", "apps": 1,
         "dbus": 10.0, "spend_usd": 10.0},
    ]
    inv = _rollup({"daily": daily}, lookback_days=30, unavailable=False)
    assert [d.usage_date for d in inv.daily] == ["2026-08-01", "2026-08-02"]
    # An app lives in exactly one workspace, so summing counts per date is exact.
    assert inv.daily[0].apps == 4
    assert inv.daily[0].spend_usd == 40.0


def test_size_groups_are_merged_across_workspaces_and_ranked_by_spend():
    """The size aggregate arrives per (workspace, size); the account view wants one
    row per size, not 300."""
    size = [
        {"workspace_id": "111", "compute_size": "MEDIUM", "apps": 3,
         "dbus": 100.0, "spend_usd": 100.0, "monthly_spend_usd": 100.0},
        {"workspace_id": "222", "compute_size": "MEDIUM", "apps": 2,
         "dbus": 60.0, "spend_usd": 60.0, "monthly_spend_usd": 60.0},
        {"workspace_id": "111", "compute_size": "LARGE", "apps": 1,
         "dbus": 200.0, "spend_usd": 200.0, "monthly_spend_usd": 200.0},
    ]
    inv = _rollup({"size": size}, lookback_days=30, unavailable=False)
    assert [g.compute_size for g in inv.by_size] == ["LARGE", "MEDIUM"]
    medium = next(g for g in inv.by_size if g.compute_size == "MEDIUM")
    assert medium.apps == 5
    assert medium.spend_usd == 160.0


def test_apps_are_ranked_by_monthly_spend():
    inv = _rollup(
        {"inventory": [
            _app("cheap", spend=10.0), _app("dear", spend=900.0), _app("mid", spend=90.0),
        ]},
        lookback_days=30, unavailable=False,
    )
    assert [a.app_id for a in inv.apps] == ["dear", "mid", "cheap"]


def test_always_on_count_uses_the_window_not_a_hardcoded_30():
    inv = _rollup(
        {"inventory": [_app("a", days=7), _app("b", days=3)]},
        lookback_days=7, unavailable=False,
    )
    assert inv.always_on_count == 1


def test_app_count_falls_back_to_the_size_rollup_when_inventory_is_missing():
    """The inventory query joins the audit log and is the one likely to miss the live
    budget. The count is still knowable from the cheaper aggregate."""
    inv = _rollup(
        {"size": [{"compute_size": "MEDIUM", "apps": 12, "spend_usd": 5.0,
                   "dbus": 5.0, "monthly_spend_usd": 5.0}]},
        lookback_days=30, unavailable=False,
    )
    assert inv.app_count == 12
    assert "inventory" in inv.missing_sections


def test_no_usage_is_distinguished_from_unavailable():
    empty = _rollup({}, lookback_days=30, unavailable=False)
    assert empty.no_usage is True and empty.unavailable is False
    broken = _rollup({}, lookback_days=30, unavailable=True)
    assert broken.unavailable is True


def test_unavailable_still_carries_the_notes():
    """The UI renders the explanation even when there are no figures."""
    inv = _rollup({}, lookback_days=30, unavailable=True)
    assert inv.analysis_note and inv.data_basis
    assert inv.lookback_days == 30


# --- reads and scoping -------------------------------------------------------
def test_reads_the_snapshot_in_precompute_mode():
    rows = _snapshot_rows(inventory=[_app("a1", spend=700.0)])
    inv = _source(rows).apps_inventory(ADMIN)
    assert inv.unavailable is False
    assert inv.apps[0].app_id == "a1"


def test_snapshot_read_selects_the_workspace_columns():
    """workspace_id is a real column and is removed from the payload, so a read of
    just (kind, payload) loses all attribution — the bug that shipped on Genie."""
    src = _source([])
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.apps_inventory(ADMIN)
    for col in ("workspace_id", "workspace_name", "workspace_url"):
        assert col in seen[0]


def test_workspace_attribution_survives_the_snapshot_round_trip():
    rows = _snapshot_rows(inventory=[_app("a1", wid="111")])
    inv = _source(rows).apps_inventory(ADMIN)
    assert inv.apps[0].workspace_id == "111"
    assert inv.apps[0].workspace_name == "Workspace 111"
    assert inv.workspace_count == 1


def test_falls_back_to_live_when_the_snapshot_is_empty():
    src = _source([], mode="precompute")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        # Snapshot returns nothing; the live aggregates return one app.
        if "finops_apps_usage" in sql:
            return []
        return [_app("live-1")] if "per_app" in sql else []

    src._query = spy
    inv = src.apps_inventory(ADMIN)
    assert any("billing.usage" in c for c in calls)
    assert inv.apps and inv.apps[0].app_id == "live-1"


def test_unavailable_when_every_read_fails():
    src = _source([], mode="live")

    def boom(sql):
        raise RuntimeError("no grant on system.billing")

    src._query = boom
    inv = src.apps_inventory(ADMIN)
    assert inv.unavailable is True
    assert inv.apps == []


def test_one_failing_aggregate_drops_only_its_own_section():
    src = _source([], mode="live")

    def partial(sql):
        if "per_app" in sql:
            raise RuntimeError("audit log timed out")
        if "GROUP BY 1, 2" in sql and "compute_size" in sql:
            return [{"workspace_id": "111", "compute_size": "MEDIUM", "apps": 4,
                     "dbus": 10.0, "spend_usd": 10.0, "monthly_spend_usd": 10.0}]
        return []

    src._query = partial
    inv = src.apps_inventory(ADMIN)
    assert inv.unavailable is False
    assert inv.by_size and inv.by_size[0].apps == 4
    assert "inventory" in inv.missing_sections


def test_live_path_is_scoped_to_the_callers_workspaces():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.apps_inventory(SCOPED)
    assert seen and all("workspace_id IN (111)" in s for s in seen)


def test_scoped_caller_with_no_workspaces_reads_nothing():
    src = _source([], mode="live")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return []

    src._query = spy
    inv = src.apps_inventory(Scope(all_workspaces=False, workspace_ids=[]))
    assert calls == []
    assert inv.no_usage is True


def test_the_drill_in_is_scoped_to_the_single_workspace():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.apps_inventory(ADMIN.narrowed_to("222"))
    assert seen and all("workspace_id IN (222)" in s for s in seen)


def test_a_foreign_workspace_reads_nothing():
    src = _source([], mode="live")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return []

    src._query = spy
    inv = src.apps_inventory(SCOPED.narrowed_to("999"))
    assert calls == []
    assert inv.no_usage is True


def test_platform_and_drill_in_do_not_share_a_cache_entry():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.apps_inventory(ADMIN)
    before = len(seen)
    src.apps_inventory(ADMIN.narrowed_to("111"))
    assert len(seen) > before


def test_results_are_cached_per_scope():
    src = _source([], mode="live")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return []

    src._query = spy
    src.apps_inventory(ADMIN)
    n = len(calls)
    src.apps_inventory(ADMIN)
    assert len(calls) == n


# --- the live window: central reads the full month, single-account probes 3 days ------
def test_central_live_read_uses_the_full_lookback_not_the_live_cap():
    """In central mode the Apps tab has no snapshot, so the live read IS the tab and it
    must use the full ``lookback_days`` (30), the same window ``SpendSource`` uses over
    the pre-built slice — NOT ``live_lookback_days`` (3). The 3-day cap is a
    single-account probe against the full ``system.*`` tables; against a batch-built
    slice it both shows only a few days and blanks the tab entirely whenever the slice's
    newest data is older than that tiny window. This is the bug that emptied the Apps tab
    for a large account (the slice was a few days stale, the 3-day window found nothing).
    """
    from finops.data.account_view import AccountView

    src = AppsSource(
        Settings(compute_mode="live", central_mode=True,
                 central_namespace="main.team_field_dsa_ce"),
        lambda: None,
    )
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        # The CentralScope account_id lookup (workspaces_latest, no billing_usage).
        if "workspaces_latest" in sql and "billing_usage" not in sql:
            return [{"account_id": "acc-1"}]
        # The inventory aggregate returns one app; size/daily return nothing.
        return [_app("live-1")] if "per_app" in sql else []

    src._query = spy
    inv = src.apps_inventory(ADMIN, AccountView(salesforce_account_name="Mercedes-Benz - Global HQ"))

    assert inv.lookback_days == 30
    assert inv.apps and inv.apps[0].app_id == "live-1"
    aggregates = [s for s in seen if "billing_usage" in s]
    assert aggregates, "expected at least one central aggregate query"
    assert all("date_sub(current_date(), 30)" in s for s in aggregates)
    assert not any("date_sub(current_date(), 3)" in s for s in aggregates)


def test_single_account_live_read_still_uses_the_live_cap():
    """Regression guard: the fix must NOT widen the single-account live fallback. That
    path scans the full ``system.*`` tables synchronously on a page load, so it stays
    capped at ``live_lookback_days`` (3)."""
    src = _source([], mode="live")  # central_mode defaults to False
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    inv = src.apps_inventory(ADMIN)

    assert inv.lookback_days == 3
    assert seen and all("date_sub(current_date(), 3)" in s for s in seen)


# --- demo mode ---------------------------------------------------------------
def test_demo_source_reconciles_its_aggregates():
    """The KPI must not contradict the chart beside it: all three aggregates are
    derived from one synthetic stream, so the size rollup has to sum to the headline."""
    inv = DemoAppsSource(
        Settings(compute_mode="demo"), lambda: None
    ).apps_inventory(ADMIN)
    assert inv.app_count > 0
    assert round(sum(g.monthly_spend_usd for g in inv.by_size), 2) == inv.monthly_spend_usd


def test_demo_source_is_scoped():
    src = DemoAppsSource(Settings(compute_mode="demo"), lambda: None)
    from finops.data.demo_source import _WORKSPACES

    wid = _WORKSPACES[0][0]
    inv = src.apps_inventory(Scope(all_workspaces=False, workspace_ids=[wid]))
    assert {a.workspace_id for a in inv.apps} <= {wid}


def test_demo_source_has_a_size_mix():
    """A single-size estate would make the configuration panel look broken."""
    inv = DemoAppsSource(
        Settings(compute_mode="demo"), lambda: None
    ).apps_inventory(ADMIN)
    assert len(inv.by_size) >= 2
