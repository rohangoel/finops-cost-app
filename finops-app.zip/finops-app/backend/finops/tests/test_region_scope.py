"""The regional workspace filter that keeps account-global billing in region.

``billing.usage`` spans the whole account across regions; the other system tables
are metastore-scoped. These tests pin that every billing-first query builder
restricts ``billing.usage`` to the regional workspace union, so spend / Genie /
Apps can never report a workspace the rules cannot analyze. They assert on the
generated SQL text (not a live warehouse), the same seam-level check the SDP
parity suite uses.
"""

from __future__ import annotations

from finops.data.apps_sql import apps_daily_sql, apps_inventory_sql, apps_size_summary_sql
from finops.data.genie_sql import (
    genie_daily_sql,
    genie_space_sql,
    genie_surface_sql,
    genie_user_sql,
)
from finops.data.region import (
    _REGIONAL_TABLES,
    out_of_scope_count_sql,
    regional_workspaces_sql,
)
from finops.data.spend_sql import workspace_spend_sql
from finops_rules.resolver import TableResolver

# Every catalog-based builder that reads billing.usage. Each must carry the regional
# filter, or a whole surface silently goes account-global again. (workspace_spend_sql
# now takes a resolver, so it is checked separately below.)
_BILLING_BUILDERS = [
    genie_user_sql,
    genie_surface_sql,
    genie_space_sql,
    genie_daily_sql,
    apps_inventory_sql,
    apps_size_summary_sql,
    apps_daily_sql,
]


def test_union_covers_every_regional_table():
    sql = regional_workspaces_sql("system")
    for table in _REGIONAL_TABLES:
        assert f"system.{table}" in sql
    # Distinct ids: UNION, never UNION ALL (which would duplicate across tables).
    assert "UNION ALL" not in sql
    assert sql.count("UNION") == len(_REGIONAL_TABLES) - 1


def test_timeline_tables_are_excluded():
    """Excluded on purpose (subset + hundreds of millions of rows). If someone adds
    them, this fails so the cost/benefit decision is made deliberately."""
    sql = regional_workspaces_sql("system")
    assert "node_timeline" not in sql
    assert "job_run_timeline" not in sql


def test_catalog_is_threaded_through():
    sql = regional_workspaces_sql("main")
    assert "main.access.workspaces_latest" in sql
    assert "system." not in sql


def test_every_billing_builder_filters_to_the_region():
    for builder in _BILLING_BUILDERS:
        sql = builder(catalog="system", lookback_days=30)
        assert "workspace_id IN (" in sql, f"{builder.__name__} lost workspace scoping"
        # The filter is the region union, not just a literal id list.
        assert "workspaces_latest" in sql, f"{builder.__name__} not scoped to region"
    # Spend uses a resolver; nested mode must still carry the regional filter.
    spend = workspace_spend_sql(TableResolver.nested("system"), lookback_days=30)
    assert "workspace_id IN (" in spend and "workspaces_latest" in spend


def test_central_spend_reads_central_tables_with_account_keyed_prices():
    # Central reads the flat central billing table; the price join adds the account key
    # so prices don't leak across accounts. With no workspace scope passed, no regional
    # union is emitted.
    sql = workspace_spend_sql(TableResolver.central_for(["acc-1", "acc-2"]), lookback_days=30)
    assert "centralized_system_tables.billing_usage" in sql
    assert "account_id IN ('acc-1', 'acc-2')" in sql
    assert "SELECT workspace_id FROM system.access.workspaces_latest" not in sql  # no regional union
    assert "u.account_id = lp.account_id" in sql


def test_central_spend_scopes_billing_to_the_account_workspaces():
    # The caller passes the SFDC account's workspaces; billing is scoped to them, which
    # separates two Salesforce accounts sharing a Databricks account_id.
    ws_sql = "SELECT workspace_id FROM main.certified.workspaces_latest WHERE salesforce_account_name = 'X'"
    sql = workspace_spend_sql(
        TableResolver.central_for(["acc-1"]), lookback_days=30, workspace_scope_sql=ws_sql
    )
    assert f"u.workspace_id IN ({ws_sql})" in sql


def test_filter_uses_the_query_catalog_not_a_hardcoded_one():
    sql = workspace_spend_sql(TableResolver.nested("main"), lookback_days=7)
    assert "main.access.workspaces_latest" in sql
    assert "system.access.workspaces_latest" not in sql


def test_out_of_scope_count_sql_counts_billing_workspaces_outside_the_region():
    sql = out_of_scope_count_sql("system", 30)
    assert "system.billing.usage" in sql
    # The inverse of the region filter: NOT IN the regional union.
    assert "NOT IN (" in sql
    assert "workspaces_latest" in sql
    # Account-level usage (no workspace id) is not a workspace and must not count.
    assert "workspace_id IS NOT NULL" in sql
    assert "date_sub(current_date(), 30)" in sql
    assert "out_of_scope_workspaces" in sql
