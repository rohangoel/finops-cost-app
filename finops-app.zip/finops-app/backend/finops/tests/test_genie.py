"""Genie cost reads: the free-tier split, cross-workspace user merging, and the
fallback chain.

The interesting assertions here are the ones that protect facts about the *billing
data* rather than arithmetic:

* free-vs-paid must be decided by the presence of paid DBUs (the free allowance is
  a separately-billed zero-priced SKU), never by a spend threshold;
* the SQL must select on ``billing_origin_product``, because paid Genie bills under
  an inference SKU whose name contains no "GENIE" at all — a ``sku_name LIKE
  '%GENIE%'`` filter would silently report all paid spend as zero;
* per-space figures must not silently absorb Genie Code / Genie One usage, which
  carries no space id.
"""

from __future__ import annotations

import json
import threading
import time

import pytest
from finops.config import Settings
from finops.data.genie_source import GenieSource, _rollup
from finops.data.genie_sql import (
    genie_daily_sql,
    genie_space_sql,
    genie_surface_sql,
    genie_user_sql,
)
from finops.identity import Scope

from .conftest import fake_connect

ADMIN = Scope(all_workspaces=True, workspace_ids=[])
SCOPED = Scope(all_workspaces=False, workspace_ids=["111"])

# The real snapshot table's shape: workspace_id/name/url are REAL columns and are
# NOT inside the JSON payload (the pipeline lifts workspace_id out so that scoping
# never parses JSON — see ddl/finops_genie_usage.sql). The fixture must mirror that,
# or it hides the exact bug it should catch: a read that selects only (kind, payload)
# passes every test while losing all workspace attribution in production.
_SNAPSHOT_COLUMNS = ["kind", "workspace_id", "workspace_name", "workspace_url", "payload"]


def _user(principal="ana@example.com", *, wid="111", free=100.0, paid=0.0, spend=0.0,
          days=10, surfaces=(("GENIE_CODE", "UI", 100.0),)):
    return {
        "workspace_id": wid, "principal": principal,
        "free_dbus": free, "paid_dbus": paid, "spend_usd": spend,
        "active_days": days, "last_active_date": "2026-08-01",
        "by_surface": json.dumps(
            [{"surface": s, "channel": c, "dbus": d} for s, c, d in surfaces]
        ),
    }


def _snapshot_rows(users=(), surfaces=(), spaces=(), daily=()):
    """Build snapshot rows the way the SDP pipeline writes them: workspace_id (and
    name/url) as their own columns, everything else as the JSON payload."""
    rows = []
    for kind, items in (("user", users), ("surface", surfaces),
                        ("space", spaces), ("daily", daily)):
        for it in items:
            payload = {k: v for k, v in it.items() if k != "workspace_id"}
            wid = it.get("workspace_id")
            rows.append((
                kind,
                str(wid) if wid is not None else None,
                f"Workspace {wid}" if wid is not None else None,
                f"https://ws{wid}.example.net" if wid is not None else None,
                json.dumps(payload),
            ))
    return rows


def _source(rows, *, mode="precompute") -> GenieSource:
    return GenieSource(Settings(compute_mode=mode), fake_connect(_SNAPSHOT_COLUMNS, rows))


# --- the free-tier question ---------------------------------------------------
def test_free_only_is_decided_by_paid_dbus_not_by_spend():
    # The headline stat. A user with free DBUs and no paid DBUs is free-tier, and a
    # user with paid DBUs is not — even if their priced spend rounds to $0.00.
    data = {"user": [
        _user("free@x.com", free=140.0, paid=0.0, spend=0.0),
        _user("tiny@x.com", free=10.0, paid=0.004, spend=0.0),
        _user("paid@x.com", free=150.0, paid=900.0, spend=63.0),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    ft = costs.free_tier
    assert ft.total_users == 3
    assert ft.free_only_users == 1
    assert ft.paid_users == 2
    assert ft.free_only_pct == pytest.approx(33.3)
    # Only the genuinely-free user's allowance counts as absorbed at $0.
    assert ft.free_dbus_free_only_users == 140.0


def test_free_tier_percentage_with_no_users_does_not_divide_by_zero():
    costs = _rollup({"user": []}, lookback_days=30, unavailable=False)
    assert costs.free_tier.free_only_pct == 0.0
    assert costs.no_usage is True


# --- users -------------------------------------------------------------------
def test_a_user_active_in_several_workspaces_is_merged_not_double_listed():
    # Otherwise one heavy user appears as several mid-sized ones and the
    # leaderboard understates the real top spender.
    data = {"user": [
        _user("ana@x.com", wid="111", free=50.0, paid=400.0, spend=28.0, days=12,
              surfaces=(("GENIE_CODE", "UI", 450.0),)),
        _user("ana@x.com", wid="222", free=20.0, paid=600.0, spend=42.0, days=20,
              surfaces=(("GENIE_CODE", "UI", 300.0), ("GENIE_AGENTS", "API", 320.0))),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert len(costs.top_users) == 1
    u = costs.top_users[0]
    assert u.paid_dbus == 1000.0
    assert u.spend_usd == 70.0
    # Distinct days can't be summed across workspaces; the max is the honest floor.
    assert u.active_days == 20
    # Same surface+channel from both workspaces is combined, not duplicated.
    code = [s for s in u.by_surface if s.surface == "GENIE_CODE"]
    assert len(code) == 1 and code[0].dbus == 750.0
    assert u.by_surface[0].dbus >= u.by_surface[-1].dbus  # biggest first


def test_top_users_are_ranked_by_spend():
    data = {"user": [
        _user("small@x.com", paid=100.0, spend=7.0),
        _user("big@x.com", paid=2000.0, spend=140.0),
        _user("mid@x.com", paid=800.0, spend=56.0),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert [u.principal for u in costs.top_users] == [
        "big@x.com", "mid@x.com", "small@x.com",
    ]


def test_malformed_surface_json_degrades_without_losing_the_user():
    row = _user("ana@x.com", paid=500.0, spend=35.0)
    row["by_surface"] = "{not json"
    costs = _rollup({"user": [row]}, lookback_days=30, unavailable=False)
    assert costs.top_users[0].spend_usd == 35.0
    assert costs.top_users[0].by_surface == []


# --- spaces ------------------------------------------------------------------
def test_space_api_share_is_computed_and_zero_dbu_spaces_do_not_divide_by_zero():
    data = {"space": [
        {"workspace_id": "111", "space_id": "abc", "dbus": 200.0, "spend_usd": 14.0,
         "users": 4, "active_days": 9, "api_dbus": 150.0,
         "last_active_date": "2026-08-02"},
        {"workspace_id": "111", "space_id": "empty", "dbus": 0.0, "spend_usd": 0.0,
         "users": 0, "active_days": 0, "api_dbus": 0.0, "last_active_date": None},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    by_id = {s.space_id: s for s in costs.spaces}
    assert by_id["abc"].api_share == 0.75
    assert by_id["empty"].api_share == 0.0


def test_spaces_are_ranked_by_spend():
    data = {"space": [
        {"space_id": "cheap", "dbus": 10.0, "spend_usd": 0.7},
        {"space_id": "dear", "dbus": 900.0, "spend_usd": 63.0},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert [s.space_id for s in costs.spaces] == ["dear", "cheap"]


# --- totals ------------------------------------------------------------------
def test_headline_total_comes_from_the_daily_series_and_normalizes_to_a_month():
    # A 15-day window must be doubled so the figure is comparable with the
    # monthly savings the rest of the app reports.
    data = {"daily": [
        {"workspace_id": "111", "usage_date": "2026-08-01", "free_dbus": 10.0,
         "paid_dbus": 100.0, "spend_usd": 250.0, "users": 5},
        {"workspace_id": "111", "usage_date": "2026-08-02", "free_dbus": 20.0,
         "paid_dbus": 100.0, "spend_usd": 250.0, "users": 6},
    ]}
    costs = _rollup(data, lookback_days=15, unavailable=False)
    assert costs.total_spend_usd == 500.0
    assert costs.monthly_spend_usd == 1000.0
    assert costs.total_dbus == 230.0


def test_daily_series_is_summed_across_workspaces_and_date_ordered():
    data = {"daily": [
        {"workspace_id": "222", "usage_date": "2026-08-02", "paid_dbus": 5.0,
         "spend_usd": 1.0, "users": 2},
        {"workspace_id": "111", "usage_date": "2026-08-01", "paid_dbus": 3.0,
         "spend_usd": 2.0, "users": 1},
        {"workspace_id": "111", "usage_date": "2026-08-02", "paid_dbus": 7.0,
         "spend_usd": 4.0, "users": 3},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert [d.usage_date for d in costs.daily] == ["2026-08-01", "2026-08-02"]
    assert costs.daily[1].paid_dbus == 12.0
    assert costs.daily[1].users == 5
    assert costs.workspace_count == 2


def test_surfaces_are_labelled_and_ranked_by_spend():
    data = {"surface": [
        {"workspace_id": "111", "surface": "GENIE_AGENTS", "channel": "UI",
         "is_free": False, "dbus": 100.0, "spend_usd": 7.0, "users": 30},
        {"workspace_id": "111", "surface": "GENIE_CODE", "channel": "UI",
         "is_free": False, "dbus": 1000.0, "spend_usd": 70.0, "users": 9},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert costs.surfaces[0].surface == "GENIE_CODE"
    assert costs.surfaces[0].surface_label == "Genie Code"
    assert costs.surfaces[1].surface_label == "Genie Spaces"


def test_top_paid_surface_share_groups_across_channels_and_ignores_free():
    # "Genie Code dominates" is a claim about the surface, so its UI and API
    # channels must be summed before comparing. Free usage never counts toward the
    # paid share, or an all-free surface could look like it drives the bill.
    data = {"surface": [
        {"surface": "GENIE_CODE", "channel": "UI", "is_free": False,
         "dbus": 700.0, "spend_usd": 70.0, "users": 9},
        {"surface": "GENIE_CODE", "channel": "API", "is_free": False,
         "dbus": 200.0, "spend_usd": 20.0, "users": 3},
        {"surface": "GENIE_AGENTS", "channel": "UI", "is_free": False,
         "dbus": 100.0, "spend_usd": 10.0, "users": 30},
        {"surface": "GENIE_AGENTS", "channel": "UI", "is_free": True,
         "dbus": 5000.0, "spend_usd": 0.0, "users": 40},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    # Code = (70 + 20) of 100 paid = 90%.
    assert costs.top_paid_surface_label == "Genie Code"
    assert costs.top_paid_surface_pct == pytest.approx(90.0)


def test_top_paid_surface_is_absent_when_all_usage_is_free():
    data = {"surface": [
        {"surface": "GENIE_CODE", "channel": "UI", "is_free": True,
         "dbus": 500.0, "spend_usd": 0.0, "users": 5},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert costs.top_paid_surface_label is None
    assert costs.top_paid_surface_pct == 0.0


# --- per-workspace rollup ----------------------------------------------------
def test_workspaces_are_rolled_up_from_user_rows_with_exact_distinct_counts():
    # Built from user rows (one per workspace+principal), so distinct users and
    # paying users are exact per workspace and spend is summable — unlike the
    # surface/daily aggregates whose user counts would double-count.
    data = {"user": [
        _user("ana@x.com", wid="111", paid=400.0, spend=28.0),
        _user("ben@x.com", wid="111", paid=0.0, spend=0.0),   # free-only
        _user("cara@x.com", wid="222", paid=900.0, spend=63.0),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    by_id = {w.workspace_id: w for w in costs.workspaces}
    assert by_id["111"].users == 2
    assert by_id["111"].paid_users == 1     # ben is free-only
    assert by_id["111"].spend_usd == 28.0
    assert by_id["222"].spend_usd == 63.0
    # Ranked by spend: the pricier workspace leads.
    assert [w.workspace_id for w in costs.workspaces] == ["222", "111"]


def test_workspace_paying_user_counted_on_unrounded_paid_dbus():
    # A genuinely-paying user whose spend rounds to $0.00 must still count as
    # paying, the same guard the free-tier headline uses.
    data = {"user": [
        _user("tiny@x.com", wid="111", free=10.0, paid=0.004, spend=0.0),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert costs.workspaces[0].paid_users == 1


def test_all_free_workspace_is_kept_and_sinks_below_paying_ones():
    data = {"user": [
        _user("free@x.com", wid="111", free=100.0, paid=0.0, spend=0.0),
        _user("paid@x.com", wid="222", paid=500.0, spend=35.0),
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert [w.workspace_id for w in costs.workspaces] == ["222", "111"]
    assert costs.workspaces[-1].spend_usd == 0.0
    assert costs.workspaces[-1].users == 1


# --- read path ---------------------------------------------------------------
def test_reads_the_snapshot_in_precompute_mode():
    rows = _snapshot_rows(
        users=[_user("ana@x.com", paid=500.0, spend=35.0)],
        daily=[{"workspace_id": "111", "usage_date": "2026-08-01",
                "paid_dbus": 500.0, "spend_usd": 35.0, "users": 1}],
    )
    costs = _source(rows).genie_costs(ADMIN)
    assert costs.unavailable is False
    assert costs.total_spend_usd == 35.0
    assert costs.top_users[0].principal == "ana@x.com"


def test_falls_back_to_live_when_the_snapshot_is_empty():
    src = _source([])
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        if len(calls) == 1:  # the snapshot read
            return []
        return [_user("ana@x.com", paid=500.0, spend=35.0)]

    src._query = spy
    costs = src.genie_costs(ADMIN)
    assert costs.unavailable is False
    # One snapshot probe, then the four live aggregates.
    assert len(calls) == 5
    assert any("billing.usage" in c for c in calls[1:])


def test_unavailable_when_every_read_fails():
    src = _source([])

    def boom(_sql):
        raise RuntimeError("no grant on system.billing")

    src._query = boom
    costs = src.genie_costs(ADMIN)
    # Honest emptiness: the tab explains itself rather than claiming $0 of Genie.
    assert costs.unavailable is True
    assert costs.total_spend_usd == 0.0
    assert costs.top_users == []
    # The notes still travel, so the UI can explain why it is empty.
    assert "budget_policy_id" in costs.budgets_note


def test_one_failing_aggregate_drops_only_its_own_section():
    # A missing per-space table must not cost us the spender leaderboard.
    src = _source([], mode="live")

    def spy(sql):
        if "space_id IS NOT NULL" in sql:
            raise RuntimeError("boom")
        if "GROUP BY workspace_id, principal" in sql:
            return [_user("ana@x.com", paid=500.0, spend=35.0)]
        return []

    src._query = spy
    costs = src.genie_costs(ADMIN)
    assert costs.unavailable is False
    assert costs.top_users[0].principal == "ana@x.com"
    assert costs.spaces == []


def test_live_path_is_scoped_to_the_callers_workspaces():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(SCOPED)
    assert seen and all("workspace_id IN ('111')" in s for s in seen)


def test_scoped_caller_with_no_workspaces_reads_nothing():
    src = _source([], mode="live")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return []

    src._query = spy
    costs = src.genie_costs(Scope(all_workspaces=False, workspace_ids=[]))
    assert calls == []          # no query at all, rather than an unscoped one
    assert costs.unavailable is False
    assert costs.no_usage is True


def test_results_are_cached_per_scope():
    rows = _snapshot_rows(users=[_user("ana@x.com", paid=1.0, spend=1.0)])
    src = _source(rows)
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return [{"kind": "user", "payload": json.dumps(_user("ana@x.com", paid=1.0, spend=1.0))}]

    src._query = spy
    src.genie_costs(ADMIN)
    src.genie_costs(ADMIN)
    assert len(calls) == 1


# --- the SQL contract --------------------------------------------------------
@pytest.mark.parametrize(
    "builder", [genie_user_sql, genie_surface_sql, genie_space_sql, genie_daily_sql]
)
def test_sql_selects_on_product_not_sku_name(builder):
    """Paid Genie bills as PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_<REGION>, so a
    SKU-name filter would return free usage only and make paid spend look like $0."""
    sql = builder("system", 30)
    assert "billing_origin_product = 'GENIE'" in sql
    assert "sku_name LIKE" not in sql
    # Persona scoping (a literal id list) is still injected by the caller, like the
    # rule SQL. The builder itself carries only the region filter: billing.usage is
    # account-global, so it is restricted to this metastore's workspaces (region.py).
    assert sql.count("workspace_id IN (") == 1
    assert "workspace_id IN (SELECT workspace_id FROM system.access.workspaces_latest" in sql
    # Real dollars, priced from list_prices.
    assert "billing.list_prices" in sql
    # Corrections must NET, not be filtered out. Waivers (e.g. Genie Spaces /
    # Genie One) are posted as retractions to zero: ORIGINAL (+X), RETRACTION
    # (-X), RESTATEMENT (0). Summing all record types nets to the corrected
    # value; an ORIGINAL-only filter would report the waived amount as spend.
    assert "record_type = 'ORIGINAL'" not in sql
    assert "date_sub(current_date(), 30)" in sql


def test_free_tier_is_identified_by_its_own_zero_priced_sku():
    sql = genie_user_sql("system", 30)
    assert "GENIE_FREE_USAGE" in sql


def test_space_sql_excludes_rows_without_a_space_id():
    """Genie Code / Genie One carry no agent_id; lumping them in would invent an
    'unknown space' that owns most of the spend."""
    assert "space_id IS NOT NULL" in genie_space_sql("system", 30)


def test_lookback_is_honoured():
    assert "date_sub(current_date(), 7)" in genie_user_sql("system", 7)


# --- demo mode ---------------------------------------------------------------
def test_demo_aggregates_reconcile_with_each_other():
    """Demo data must add up across views.

    The four aggregates are four projections of one usage stream, so the surface
    totals, the per-user totals and the daily series must agree on total paid spend
    and total DBUs. Generating each independently is the easy mistake, and it shows
    up in the UI as a headline figure that contradicts the chart beside it — which
    reads as an app bug rather than a fixture bug.
    """
    from finops.data.genie_source import DemoGenieSource

    src = DemoGenieSource(Settings(compute_mode="demo"), lambda: None)
    costs = src.genie_costs(ADMIN)

    assert costs.unavailable is False and costs.no_usage is False

    user_spend = sum(u.spend_usd for u in costs.top_users)
    surface_spend = sum(s.spend_usd for s in costs.surfaces)
    daily_spend = sum(d.spend_usd for d in costs.daily)
    # The daily series is the headline basis; surfaces must match it.
    assert surface_spend == pytest.approx(daily_spend, rel=0.02)
    assert costs.total_spend_usd == pytest.approx(daily_spend, rel=0.001)
    # top_users is truncated, so it can only be a lower bound.
    assert user_spend <= surface_spend + 1.0

    # DBUs must reconcile between the free/paid split and the daily series.
    ft = costs.free_tier
    assert costs.total_dbus == pytest.approx(
        sum(d.free_dbus + d.paid_dbus for d in costs.daily), rel=0.001
    )
    assert ft.free_dbus + ft.paid_dbus == pytest.approx(costs.total_dbus, rel=0.02)


def test_demo_free_tier_majority_matches_the_observed_shape():
    """Most Genie users never leave the free tier (77% live). A demo that shows a
    50/50 split would misrepresent the one stat this tab leads with."""
    from finops.data.genie_source import DemoGenieSource

    costs = DemoGenieSource(Settings(compute_mode="demo"), lambda: None).genie_costs(ADMIN)
    assert 60.0 <= costs.free_tier.free_only_pct <= 92.0
    # Every ranked spender must actually have paid usage.
    assert all(u.paid_dbus > 0 for u in costs.top_users)


def test_demo_spaces_only_cover_the_surface_that_has_space_ids():
    """Genie Code / Genie One carry no agent_id, so per-space spend must be a
    strict subset of total spend — never equal to it."""
    from finops.data.genie_source import DemoGenieSource

    costs = DemoGenieSource(Settings(compute_mode="demo"), lambda: None).genie_costs(ADMIN)
    assert costs.spaces
    assert sum(s.spend_usd for s in costs.spaces) < costs.total_spend_usd


# --- the live budget ---------------------------------------------------------
def test_live_window_is_truncated_so_the_page_does_not_hang():
    """The live path scans billing.usage while a page load waits, so it must use
    the short window like LiveRecommendationSource — the full 30-day account-wide
    scan does not finish in time. Precompute keeps the full window."""
    src = GenieSource(
        Settings(compute_mode="live", lookback_days=30, live_lookback_days=3),
        fake_connect(_SNAPSHOT_COLUMNS, []),
    )
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(ADMIN)
    assert seen
    assert all("date_sub(current_date(), 3)" in s for s in seen)
    assert not any("date_sub(current_date(), 30)" in s for s in seen)


def test_the_budget_is_enforced_and_does_not_wait_for_stragglers():
    """The budget must be a real deadline.

    The first implementation collected results inside a `with ThreadPoolExecutor`
    block, and exiting that context manager JOINS every worker — so a slow query
    held the response open regardless of the budget. On the live account that turned
    a 45s budget into a >5 minute request. The pool is now shut down with
    `wait=False`, so a straggler is abandoned rather than awaited.
    """
    import finops.data.genie_source as gs

    src = GenieSource(Settings(compute_mode="live"), fake_connect(_SNAPSHOT_COLUMNS, []))
    released = threading.Event()

    def one_fast_one_hanging(sql):
        if "GROUP BY workspace_id, principal" in sql:
            return [_user("ana@x.com", paid=500.0, spend=35.0)]
        released.wait(30)  # never released within the budget
        return []

    src._query = one_fast_one_hanging
    original = gs._LIVE_BUDGET_S
    gs._LIVE_BUDGET_S = 0.3
    started = time.monotonic()
    try:
        costs = src.genie_costs(ADMIN)
    finally:
        gs._LIVE_BUDGET_S = original
        released.set()  # let the abandoned worker exit

    elapsed = time.monotonic() - started
    # Returned near the budget, not after the hanging query's 30s.
    assert elapsed < 10, f"took {elapsed:.1f}s — the budget was not enforced"
    # The fast query still contributed: a partial answer beats no answer.
    assert costs.unavailable is False
    assert costs.top_users and costs.top_users[0].principal == "ana@x.com"
    assert costs.spaces == []


def test_live_budget_exceeds_the_connection_socket_timeout():
    """A budget below the socket timeout can only cancel queries that were about to
    succeed: the socket timeout already bounds each concurrent query."""
    import inspect

    from finops.data import genie_source, sql_client

    assert genie_source._LIVE_BUDGET_S > 40
    # Keep the two in step if sql_client's timeout ever changes.
    assert "_socket_timeout" in inspect.getsource(sql_client)


# --- partial reads must stay honest ------------------------------------------
def test_headline_total_falls_back_through_the_aggregates_not_to_zero():
    """Each aggregate partitions the same usage, so any one of them yields the true
    total. A live read where only the surface query beat the budget used to report
    $0.00 while the surface table showed hundreds of dollars — a confident zero,
    which is precisely what `unavailable` exists to avoid."""
    data = {"surface": [
        {"workspace_id": "111", "surface": "GENIE_CODE", "channel": "UI",
         "is_free": False, "dbus": 8323.1, "spend_usd": 596.55, "users": 58},
        {"workspace_id": "111", "surface": "GENIE_CODE", "channel": "UI",
         "is_free": True, "dbus": 4856.8, "spend_usd": 0.0, "users": 135},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert costs.total_spend_usd == pytest.approx(596.55)
    assert costs.total_dbus == pytest.approx(13179.9)
    assert costs.no_usage is False


def test_missing_aggregates_are_reported_so_empty_sections_are_explained():
    data = {"surface": [
        {"workspace_id": "111", "surface": "GENIE_CODE", "channel": "UI",
         "is_free": False, "dbus": 10.0, "spend_usd": 1.0, "users": 2},
    ]}
    costs = _rollup(data, lookback_days=30, unavailable=False)
    # An empty per-space table must not read as "this account has no Genie Spaces".
    assert set(costs.missing_sections) == {"user", "space", "daily"}


def test_nothing_is_reported_missing_when_every_aggregate_arrives():
    data = {
        "user": [_user("ana@x.com", paid=1.0, spend=1.0)],
        "surface": [{"workspace_id": "111", "surface": "GENIE_CODE", "channel": "UI",
                     "is_free": False, "dbus": 1.0, "spend_usd": 1.0, "users": 1}],
        "space": [{"workspace_id": "111", "space_id": "abc", "dbus": 1.0,
                   "spend_usd": 1.0, "users": 1, "active_days": 1, "api_dbus": 0.0}],
        "daily": [{"workspace_id": "111", "usage_date": "2026-08-01",
                   "paid_dbus": 1.0, "spend_usd": 1.0, "users": 1}],
    }
    costs = _rollup(data, lookback_days=30, unavailable=False)
    assert costs.missing_sections == []


def test_the_reported_window_is_the_one_actually_queried():
    """Live mode truncates the window, so it must SAY so. Every figure on the tab
    is window-dependent and the monthly normalization divides by this number, so
    labelling a 7-day read as 30 days mislabels the whole page."""
    src = GenieSource(
        Settings(compute_mode="live", lookback_days=30, live_lookback_days=7),
        fake_connect(_SNAPSHOT_COLUMNS, []),
    )
    src._query = lambda sql: [
        {"workspace_id": "111", "usage_date": "2026-08-01", "paid_dbus": 10.0,
         "spend_usd": 70.0, "users": 1}
    ] if "GROUP BY workspace_id, usage_date" in sql else []

    costs = src.genie_costs(ADMIN)
    assert costs.lookback_days == 7
    # $70 over 7 days normalizes to $300/month, not $70.
    assert costs.monthly_spend_usd == pytest.approx(300.0)


def test_precompute_reports_the_full_configured_window():
    rows = _snapshot_rows(daily=[
        {"workspace_id": "111", "usage_date": "2026-08-01", "paid_dbus": 10.0,
         "spend_usd": 30.0, "users": 1}
    ])
    costs = GenieSource(
        Settings(compute_mode="precompute", lookback_days=30, live_lookback_days=3),
        fake_connect(_SNAPSHOT_COLUMNS, rows),
    ).genie_costs(ADMIN)
    assert costs.lookback_days == 30
    assert costs.monthly_spend_usd == pytest.approx(30.0)


# --- per-workspace drill-in (GET /api/genie/{workspace_id}) -------------------
# The workspace id on that route comes from the CLIENT, so `Scope.narrowed_to` has
# to behave as a filter inside the caller's server-derived scope and never as a
# grant. These tests are the guard on that: a bug here leaks one customer
# workspace's Genie spend (principals by name) to an admin of another.
def test_narrowing_a_platform_admin_yields_just_that_workspace():
    narrowed = ADMIN.narrowed_to("111")
    assert narrowed.all_workspaces is False
    assert narrowed.workspace_ids == ["111"]


def test_narrowing_keeps_a_workspace_the_caller_owns():
    assert SCOPED.narrowed_to("111").workspace_ids == ["111"]


def test_narrowing_to_a_foreign_workspace_yields_an_empty_scope():
    """The privilege-escalation case: asking for a workspace you don't own must
    return nothing, NOT that workspace's data and NOT your whole scope."""
    narrowed = SCOPED.narrowed_to("999")
    assert narrowed.all_workspaces is False
    assert narrowed.workspace_ids == []


def test_narrowing_never_re_grants_all_workspaces():
    for scope in (ADMIN, SCOPED, Scope(all_workspaces=False, workspace_ids=[])):
        assert scope.narrowed_to("111").all_workspaces is False


def test_narrowing_does_not_mutate_the_original_scope():
    scope = Scope(all_workspaces=False, workspace_ids=["111", "222"])
    scope.narrowed_to("111")
    assert scope.workspace_ids == ["111", "222"]


def test_narrowing_accepts_an_int_like_id():
    """Workspace ids are numeric and arrive as strings from the path; a caller
    passing an int must not silently fall through to the deny branch."""
    scope = Scope(all_workspaces=False, workspace_ids=[111])
    assert scope.narrowed_to("111").workspace_ids == ["111"]


def test_a_foreign_workspace_issues_no_query_at_all():
    """End to end: the empty scope must stop before the SQL, not filter after it."""
    src = _source([], mode="live")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return []

    src._query = spy
    costs = src.genie_costs(SCOPED.narrowed_to("999"))
    assert calls == []
    assert costs.no_usage is True


def test_the_drill_in_query_is_scoped_to_the_single_workspace():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(ADMIN.narrowed_to("222"))
    assert seen and all("workspace_id IN ('222')" in s for s in seen)


def test_platform_and_drill_in_views_do_not_share_a_cache_entry():
    """Same source, two scopes: the narrowed read must not be served the
    account-wide rows (or vice versa)."""
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(ADMIN)
    before = len(seen)
    src.genie_costs(ADMIN.narrowed_to("111"))
    assert len(seen) > before, "narrowed scope reused the account-wide cache entry"


def test_an_empty_scope_does_not_share_a_cache_entry_with_a_real_one():
    """Both used to key on the empty string; a cached "nothing" must not be
    returned for a scope that does have workspaces."""
    src = _source([], mode="live")
    src.genie_costs(Scope(all_workspaces=False, workspace_ids=[]))
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(SCOPED)
    assert seen, "a real scope was served the empty scope's cached result"


# --- workspace attribution comes from real columns, not the payload -----------
# The SDP pipeline stores workspace_id as its own column and REMOVES it from the
# JSON payload, so a read that selects only (kind, payload) loses every workspace
# attribution — silently, since each figure is still individually correct. That
# shipped once: the tab showed "across 0 workspaces" and unnamed spaces.
def test_snapshot_read_selects_the_workspace_columns():
    src = _source([])
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.genie_costs(ADMIN)
    assert seen, "no snapshot query was issued"
    for col in ("workspace_id", "workspace_name", "workspace_url"):
        assert col in seen[0], f"snapshot read does not select {col}"


def test_workspace_count_is_populated_from_the_snapshot():
    rows = _snapshot_rows(users=[
        _user("ana@x.com", wid="111", paid=1.0, spend=1.0),
        _user("bo@x.com", wid="222", paid=1.0, spend=1.0),
    ])
    costs = _source(rows).genie_costs(ADMIN)
    assert costs.workspace_count == 2


def test_spaces_carry_their_workspace_from_the_snapshot_columns():
    rows = _snapshot_rows(spaces=[
        {"workspace_id": "111", "space_id": "sp-1", "dbus": 10.0, "spend_usd": 5.0,
         "users": 2, "active_days": 3, "api_dbus": 0.0},
    ])
    costs = _source(rows).genie_costs(ADMIN)
    assert costs.spaces
    assert costs.spaces[0].workspace_id == "111"
    assert costs.spaces[0].workspace_name == "Workspace 111"


def test_users_carry_their_workspace_from_the_snapshot_columns():
    rows = _snapshot_rows(users=[_user("ana@x.com", wid="111", paid=1.0, spend=1.0)])
    costs = _source(rows).genie_costs(ADMIN)
    assert costs.top_users[0].workspace_id == "111"


def test_narrowing_rejects_a_non_numeric_id():
    """The route turns this into a 400. Workspace ids are inlined into SQL after a
    digit check (see data/scoping.py), so anything else is a malformed request."""
    from finops.data.scoping import ScopeError

    for bad in ("1;DROP TABLE x", "abc", "", "1 OR 1=1", "1,2"):
        with pytest.raises(ScopeError):
            ADMIN.narrowed_to(bad)


# --- the live window: central reads the full month, single-account probes 3 days ------
def test_central_live_read_uses_the_full_lookback_not_the_live_cap():
    """Same fix as the Apps tab: in central mode the Genie tab has no snapshot, so the
    live read IS the tab and must use the full ``lookback_days`` (30) over the pre-built
    slice, not the ``live_lookback_days`` (3) cap meant for single-account ``system.*``
    probes. Truncating blanks the tab whenever the batch-built slice is a few days stale.
    """
    from finops.data.account_view import AccountView

    src = GenieSource(
        Settings(compute_mode="live", central_mode=True,
                 central_namespace="main.team_field_dsa_ce"),
        lambda: None,
    )
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        # The CentralScope account_id lookup (workspaces_latest, no billing_usage).
        if "workspaces_latest" in sql and "billing_usage" not in sql:
            return [{"account_id": "acc-1"}]
        return []

    src._query = spy
    costs = src.genie_costs(ADMIN, AccountView(salesforce_account_name="Mercedes-Benz - Global HQ"))

    assert costs.lookback_days == 30
    aggregates = [s for s in seen if "billing_usage" in s]
    assert aggregates, "expected at least one central aggregate query"
    assert all("date_sub(current_date(), 30)" in s for s in aggregates)
    assert not any("date_sub(current_date(), 3)" in s for s in aggregates)


def test_single_account_live_read_still_uses_the_live_cap():
    """Regression guard: the single-account live fallback stays capped at
    ``live_lookback_days`` (3) — it scans the full ``system.*`` tables on a page load."""
    src = _source([], mode="live")  # central_mode defaults to False
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    costs = src.genie_costs(ADMIN)

    assert costs.lookback_days == 3
    assert seen and all("date_sub(current_date(), 3)" in s for s in seen)
