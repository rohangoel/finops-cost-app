from __future__ import annotations

import pytest

from finops.data.scoping import ScopeError, where_clause, wrap_live
from finops.identity import Scope


def test_platform_admin_has_no_filter():
    scope = Scope(all_workspaces=True)
    assert where_clause(scope) == ""


def test_workspace_admin_filters_to_their_workspaces():
    scope = Scope(all_workspaces=False, workspace_ids=["111", "222"])
    assert where_clause(scope) == "WHERE workspace_id IN (111, 222)"


def test_scoped_user_with_no_workspaces_sees_nothing():
    scope = Scope(all_workspaces=False, workspace_ids=[])
    assert where_clause(scope) == "WHERE workspace_id IN (NULL)"


def test_forged_non_numeric_workspace_id_is_rejected():
    # A workspace admin cannot smuggle SQL / another workspace via a bad id.
    scope = Scope(all_workspaces=False, workspace_ids=["111 OR 1=1"])
    with pytest.raises(ScopeError):
        where_clause(scope)


def test_wrap_live_wraps_and_scopes():
    scope = Scope(all_workspaces=False, workspace_ids=["111"])
    wrapped = wrap_live("SELECT workspace_id FROM t", scope)
    assert wrapped.startswith("SELECT * FROM (")
    assert wrapped.endswith("WHERE workspace_id IN (111)")
