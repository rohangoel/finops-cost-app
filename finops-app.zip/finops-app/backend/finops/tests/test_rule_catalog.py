"""The rule-knowledge catalog that backs the Ask Genie space's what-if ability.

The value of this table is that it carries the ACTUAL calculation, not a summary:
the rendered detection SQL, the thresholds with their live values, and the
verbatim scoring source. These tests pin exactly that — a catalog row that dropped
the SQL or the thresholds would still "look" populated but be useless for the
push-back-on-the-numbers use case.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from finops.services.rule_catalog import rule_catalog_records
from finops_rules import get_enabled_rules, load_thresholds

_DDL_PATH = (
    Path(__file__).resolve().parents[3]
    / "precompute" / "ddl" / "finops_rule_catalog.sql"
)


def _ddl_columns() -> list[str]:
    txt = _DDL_PATH.read_text()
    create = txt.index("CREATE TABLE")
    body = txt[txt.index("(", create) + 1 : txt.index("\n)", create)]
    cols = []
    for line in body.splitlines():
        line = line.split("--")[0].strip().rstrip(",")
        if not line:
            continue
        m = re.match(r"^(\w+)\s+", line)
        if m:
            cols.append(m.group(1))
    return cols


def test_catalog_record_keys_match_the_ddl():
    """The builder's record keys plus the two stamped columns must equal the DDL,
    so a column added to one and not the other can't silently drop at write time."""
    record_keys = set(rule_catalog_records()[0].keys())
    stamped = {"snapshot_date", "computed_at"}  # added by the writer, not the builder
    assert record_keys | stamped == set(_ddl_columns())


def test_pipeline_inline_schema_covers_every_ddl_column():
    """pipeline.py declares the catalog's Spark schema inline (_RULE_CATALOG_DDL)
    because the SDP sink builds the DataFrame from it. Read as text (the module
    needs `dlt`, absent locally) and confirm it names every DDL column — a missing
    one would write NULLs for a field the DDL promises."""
    pipeline = (
        Path(__file__).resolve().parents[3] / "precompute" / "pipeline.py"
    ).read_text()
    block = pipeline[pipeline.index("_RULE_CATALOG_DDL = ") :]
    block = block[: block.index(")") + 1]
    for col in _ddl_columns():
        assert col in block, f"pipeline _RULE_CATALOG_DDL is missing {col}"


def test_one_row_per_enabled_rule():
    recs = rule_catalog_records()
    enabled = {r.id for r in get_enabled_rules(load_thresholds())}
    assert {r["rule_id"] for r in recs} == enabled
    # Disabled rules must not appear (the space should reflect the live config).
    assert all(r["enabled"] for r in recs)


def test_each_row_carries_the_actual_calculation():
    recs = rule_catalog_records()
    for r in recs:
        # Detection SQL is real, rendered SQL (not a template with {{ }} left in).
        assert "SELECT" in r["detection_sql"].upper()
        assert "{{" not in r["detection_sql"], f"{r['rule_id']}: SQL not rendered"
        # Thresholds parse as a JSON object.
        assert isinstance(json.loads(r["thresholds"]), dict)
        # Source tables parse as a JSON array of schema.table names.
        tables = json.loads(r["source_tables"])
        assert isinstance(tables, list)


def test_thresholds_carry_current_values():
    """A what-if question needs the value to change FROM, not just the knob name."""
    recs = {r["rule_id"]: r for r in rule_catalog_records()}
    wa = json.loads(recs["warehouse_autostop"]["thresholds"])
    # The rule's real, configured parameter and its value.
    assert wa.get("max_acceptable_minutes") == 30


def test_scoring_logic_is_the_verbatim_source():
    recs = {r["rule_id"]: r for r in rule_catalog_records()}
    src = recs["warehouse_autostop"]["scoring_logic"]
    # The actual guards/logic a user would push back on, not a paraphrase.
    assert "def score" in src
    assert "insufficient_history" in src


def test_nba_and_weights_are_present_for_what_if_on_ranking():
    recs = rule_catalog_records()
    r = recs[0]
    assert "monthly_savings_usd" in r["nba_formula"]
    weights = json.loads(r["effort_weights"])
    assert weights.get("trivial") and weights.get("high")
    mults = json.loads(r["priority_multipliers"])
    assert mults.get("HIGH") and mults.get("LOW")


def test_source_tables_match_what_the_rule_reads():
    """The catalog's source_tables must match the dependency extractor, so Genie is
    pointed at the same tables the deploy granted it."""
    from finops_rules import RuleContext
    from finops_rules.registry import get_rule
    from finops_rules.sources import rule_dependencies

    th = load_thresholds()
    recs = {r["rule_id"]: r for r in rule_catalog_records()}
    rid = "warehouse_autostop"
    ctx = RuleContext(thresholds=th.get(rid, {}), lookback_days=30, catalog="system")
    expected = sorted(rule_dependencies(get_rule(rid), ctx))
    assert json.loads(recs[rid]["source_tables"]) == expected
