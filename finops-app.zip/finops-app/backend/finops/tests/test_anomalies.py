"""Cost anomaly reads, the detection method, and the guarantee it makes NO savings claim.

Mirrors ``test_apps.py``: the SQL contract, the negative "no recommendation fields"
guarantee, the rollup, and snapshot → live → unavailable plus scope narrowing. The
method itself is pinned through :func:`detect`, the Python mirror of the SQL rule, on
the shapes that matter: a real step change, a one-day spike, a new spender, and the
two false-positive traps (a flat always-on resource, a weekly job).
"""

from __future__ import annotations

import json

from finops.config import Settings
from finops.data.anomaly_source import AnomalySource, DemoAnomalySource, _rollup, detect
from finops.data.anomaly_sql import anomalies_sql, anomaly_daily_sql
from finops.identity import Scope
from finops_rules.resolver import TableResolver

from .conftest import fake_connect

ADMIN = Scope(all_workspaces=True, workspace_ids=[])
SCOPED = Scope(all_workspaces=False, workspace_ids=["111"])

_SNAPSHOT_COLUMNS = ["kind", "workspace_id", "workspace_name", "workspace_url", "payload"]


def _anom(key="k1", *, grain="resource", wid="111", kind="step_change", excess=500.0):
    return {
        "workspace_id": wid, "grain": grain, "anomaly_key": key, "anomaly_type": kind,
        "product": "SQL", "sku_name": "PREMIUM_SQL" if grain == "sku" else None,
        "resource_type": "warehouse" if grain == "resource" else None,
        "resource_id": "abc" if grain == "resource" else None,
        "resource_name": "bi-wh" if grain == "resource" else None,
        "first_flag_date": "2026-09-16", "last_flag_date": "2026-09-22",
        "peak_date": "2026-09-20", "flagged_days": 7, "longest_run": 7,
        "peak_cost_usd": 900.0, "baseline_median_usd": 400.0, "baseline_mad_usd": 20.0,
        "baseline_active_days": 28, "robust_z": 16.9, "excess_usd": excess,
        "floor_usd": 200.0, "eval_cost_usd": 6000.0,
        "series_json": json.dumps([400.0] * 28 + [900.0] * 7),
        "run_as": "a@x.com", "owned_by": None,
    }


def _snapshot_rows(anomaly=(), daily=()):
    rows = []
    for kind, items in (("anomaly", anomaly), ("daily", daily)):
        for it in items:
            payload = {k: v for k, v in it.items() if k != "workspace_id"}
            wid = it.get("workspace_id")
            rows.append((kind, str(wid), f"Workspace {wid}", f"https://ws{wid}.example.net",
                         json.dumps(payload)))
    return rows


def _source(rows, *, mode="precompute") -> AnomalySource:
    return AnomalySource(Settings(compute_mode=mode), fake_connect(_SNAPSHOT_COLUMNS, rows))


# --- the SQL contract ---------------------------------------------------------
def test_today_is_excluded_and_the_window_is_baseline_plus_eval():
    for builder in (anomalies_sql, anomaly_daily_sql):
        sql = builder("system", 30)
        assert "usage_date < current_date()" in sql
        # 28 baseline + 7 evaluation days, independent of the app's lookback.
        assert "date_sub(current_date(), 35)" in sql
        assert sql == builder("system", 3), "window must not follow lookback_days"


def test_baseline_excludes_the_evaluation_window():
    """A step change must not drag its own baseline up."""
    sql = anomalies_sql()
    assert "percentile(CASE WHEN NOT in_eval THEN cost END, 0.5)" in sql
    assert "date_sub(current_date(), 7) AS in_eval" in sql


def test_no_intermediate_step_is_read_more_than_twice():
    """Spark inlines CTEs, so each extra reference re-plans everything beneath it.
    The first version joined its own aggregates back and filtered the name lookups
    with `IN (SELECT … FROM anomalous)`: 524 scans of billing.usage in a 5.5 MB plan.
    The warehouse survived it (~2 min); the SDP pipeline sat in STARTING for 35 min.
    Keep the chain linear: window aggregates instead of join-backs."""
    import re

    sql = anomalies_sql()
    ctes = re.findall(r"(?:WITH|,)\s*(\w+) AS \(", sql)
    assert "dense" in ctes and "anomalous" in ctes
    for cte in ctes:
        refs = len(re.findall(rf"\b(?:FROM|JOIN)\s+{cte}\b", sql))
        assert refs <= 2, f"{cte} is read {refs} times"
    assert len(re.findall(r"\bFROM\s+anomalous\b", sql)) == 1


def test_sql_prices_at_list_via_the_shared_join_and_is_region_scoped():
    sql = anomalies_sql()
    assert "billing.list_prices" in sql
    assert "pricing.effective_list.default" in sql
    assert sql.count("workspace_id IN (") == 1  # region filter only; scope is the caller's


def test_jobs_are_keyed_before_clusters():
    """A job cluster gets a new cluster_id every run; keying by cluster would make
    every run a 'new spender'."""
    sql = anomalies_sql()
    assert sql.index("usage_metadata.job_id IS NOT NULL THEN 'job'") < sql.index(
        "usage_metadata.cluster_id IS NOT NULL THEN 'cluster'")


def test_warehouse_rows_are_not_named_after_the_llm_endpoint_they_call():
    """Verified live: ai_query() usage on a warehouse carries the model's
    endpoint_name, which labelled warehouses 'databricks-meta-llama-…'."""
    sql = anomalies_sql()
    name_case = sql[sql.index("AS resource_id,"):sql.index("AS resource_name,")]
    assert name_case.index("warehouse_id IS NOT NULL THEN NULL") < name_case.index(
        "endpoint_name IS NOT NULL THEN u.usage_metadata.endpoint_name")


def test_central_mode_skips_the_name_lookups():
    """The central namespace has billing tables only; joining compute.* would fail."""
    nested = anomalies_sql()
    assert "compute.warehouses" in nested and "lakeflow.jobs" in nested
    central = anomalies_sql(resolver=TableResolver.central_for(["acc-1"]),
                            workspace_scope_sql="SELECT 1")
    assert "compute.warehouses" not in central
    assert "a.* EXCEPT" not in central


def test_thresholds_are_rendered_from_parameters():
    sql = anomalies_sql(z_threshold=6.0, min_delta_usd=500.0)
    assert "z > 6.0" in sql
    assert ">= 500.0" in sql


# --- the method (Python mirror of the SQL) ------------------------------------
def test_detects_a_step_change():
    hit = detect([400.0] * 28 + [400.0, 400.0] + [1400.0] * 5)
    assert hit and hit["anomaly_type"] == "step_change"
    assert hit["flagged_days"] == 5 and hit["longest_run"] == 5
    assert hit["excess_usd"] == 5000.0


def test_detects_a_one_day_spike():
    hit = detect([400.0] * 32 + [3000.0] + [400.0] * 2)
    assert hit and hit["anomaly_type"] == "spike" and hit["flagged_days"] == 1


def test_detects_a_new_spender_without_a_z_score():
    hit = detect([0.0] * 31 + [600.0] * 4)
    assert hit and hit["anomaly_type"] == "new_spender"
    assert hit["robust_z"] is None
    assert hit["excess_usd"] == 2400.0


def test_a_flat_always_on_resource_is_not_anomalous():
    """MAD is 0 for a flat series; the 10%-of-median floor keeps cents of drift from
    being infinitely anomalous."""
    assert detect([800.0] * 28 + [805.0, 810.0, 795.0, 800.0, 812.0, 790.0, 801.0]) is None


def test_a_small_absolute_move_is_below_the_floor():
    """z can be huge on a $5/day resource; the $ floor is what keeps it quiet."""
    assert detect([5.0] * 28 + [150.0] * 7) is None


def test_a_weekly_job_is_not_a_spike_every_week():
    """$0 median, one busy day in seven: without the same-weekday baseline every
    run would be flagged."""
    series = [3000.0 if i % 7 == 3 else 0.0 for i in range(35)]
    assert detect(series) is None


def test_an_intermittent_job_is_not_flagged_for_running():
    """Busy roughly every third day — the upper-quartile spread absorbs the rhythm
    (verified live on a ~$3k/run scraping job)."""
    series = [2500.0 if i % 3 == 0 else 0.0 for i in range(35)]
    assert detect(series) is None


# --- no verdicts -------------------------------------------------------------
def test_the_model_carries_no_recommendation_fields():
    from finops.models.anomaly import AnomalyDay, CostAnomalies, CostAnomaly

    forbidden = {
        "monthly_savings_usd", "monthly_waste_usd", "nba_score", "priority",
        "effort_band", "effort_score", "why", "how", "recommendation_id",
    }
    for model in (CostAnomaly, CostAnomalies, AnomalyDay):
        assert not (forbidden & set(model.model_fields)), model.__name__


def test_the_notes_say_an_anomaly_is_not_a_saving():
    out = _rollup({}, unavailable=False)
    assert "not a saving" in out.analysis_note.lower()
    assert "baseline" in out.method_note.lower()
    assert "list price" in out.data_basis.lower()


# --- rollup ------------------------------------------------------------------
def test_totals_come_from_the_sku_grain_only():
    """The grains overlap (a warehouse anomaly is usually also a SKU anomaly), so
    summing both would double count."""
    out = _rollup({"anomaly": [
        _anom("r1", grain="resource", excess=1000.0),
        _anom("s1", grain="sku", excess=1000.0),
        _anom("s2", grain="sku", kind="spike", excess=300.0),
    ], "daily": []}, unavailable=False)
    assert out.total_excess_usd == 1300.0
    assert out.anomaly_count == 2
    assert len(out.resource_anomalies) == 1 and len(out.sku_anomalies) == 2
    by = {t.anomaly_type: t for t in out.by_type}
    assert by["step_change"].count == 1 and by["spike"].excess_usd == 300.0


def test_series_is_parsed_from_json():
    out = _rollup({"anomaly": [_anom()], "daily": []}, unavailable=False)
    assert len(out.resource_anomalies[0].series) == 35


def test_daily_is_summed_across_workspaces_and_labels_the_window():
    daily = [
        {"workspace_id": "222", "usage_date": "2026-09-22", "cost_usd": 5.0},
        {"workspace_id": "111", "usage_date": "2026-09-21", "cost_usd": 30.0},
        {"workspace_id": "222", "usage_date": "2026-09-21", "cost_usd": 10.0},
    ]
    out = _rollup({"anomaly": [], "daily": daily}, unavailable=False)
    assert [d.usage_date for d in out.daily] == ["2026-09-21", "2026-09-22"]
    assert out.daily[0].cost_usd == 40.0
    assert out.eval_end == "2026-09-22" and out.eval_start == "2026-09-16"


def test_no_anomalies_is_distinguished_from_unavailable():
    quiet = _rollup({"anomaly": [], "daily": []}, unavailable=False)
    assert quiet.no_anomalies and not quiet.unavailable
    broken = _rollup({}, unavailable=True)
    assert broken.unavailable and broken.method_note


def test_a_dropped_anomaly_query_is_missing_not_quiet():
    """On a large account the anomaly query misses the live budget. That must read as
    'missing', never as 'no anomalies'."""
    out = _rollup({"daily": [{"workspace_id": "1", "usage_date": "2026-09-22",
                              "cost_usd": 1.0}]}, unavailable=False)
    assert "anomaly" in out.missing_sections
    assert out.no_anomalies is False


# --- reads and scoping -------------------------------------------------------
def test_reads_the_snapshot_and_keeps_workspace_attribution():
    rows = _snapshot_rows(anomaly=[_anom(wid="111")])
    out = _source(rows).cost_anomalies(ADMIN)
    a = out.resource_anomalies[0]
    assert a.workspace_id == "111" and a.workspace_name == "Workspace 111"
    assert out.workspace_count == 1


def test_snapshot_read_selects_the_workspace_columns():
    src = _source([])
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.cost_anomalies(ADMIN)
    for col in ("workspace_id", "workspace_name", "workspace_url"):
        assert col in seen[0]
    assert "finops_cost_anomalies" in seen[0]


def test_falls_back_to_live_when_the_snapshot_is_empty():
    src = _source([], mode="precompute")
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        if "finops_cost_anomalies" in sql:
            return []
        return [_anom("live-1")] if "anomalous AS" in sql else []

    src._query = spy
    out = src.cost_anomalies(ADMIN)
    assert any("billing.usage" in c for c in calls)
    assert out.resource_anomalies[0].anomaly_key == "live-1"


def test_unavailable_when_every_read_fails():
    src = _source([], mode="live")

    def boom(sql):
        raise RuntimeError("no grant on system.billing")

    src._query = boom
    assert src.cost_anomalies(ADMIN).unavailable is True


def test_live_path_is_scoped_to_the_callers_workspaces():
    src = _source([], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return []

    src._query = spy
    src.cost_anomalies(SCOPED)
    assert seen and all(s.rstrip().endswith("WHERE workspace_id IN (111)") for s in seen)


def test_scoped_caller_with_no_workspaces_reads_nothing():
    src = _source([], mode="live")
    calls: list[str] = []
    src._query = lambda sql: calls.append(sql) or []
    out = src.cost_anomalies(Scope(all_workspaces=False, workspace_ids=[]))
    assert calls == []
    assert out.no_anomalies is True


def test_the_drill_in_is_scoped_to_the_single_workspace():
    src = _source([], mode="live")
    seen: list[str] = []
    src._query = lambda sql: seen.append(sql) or []
    src.cost_anomalies(ADMIN.narrowed_to("222"))
    assert seen and all("workspace_id IN (222)" in s for s in seen)


def test_a_foreign_workspace_reads_nothing():
    """A workspace admin naming a workspace they don't own gets an empty scope."""
    src = _source([], mode="live")
    calls: list[str] = []
    src._query = lambda sql: calls.append(sql) or []
    out = src.cost_anomalies(SCOPED.narrowed_to("999"))
    assert calls == []
    assert out.no_anomalies is True


def test_platform_and_drill_in_do_not_share_a_cache_entry():
    src = _source([], mode="live")
    seen: list[str] = []
    src._query = lambda sql: seen.append(sql) or []
    src.cost_anomalies(ADMIN)
    before = len(seen)
    src.cost_anomalies(ADMIN.narrowed_to("111"))
    assert len(seen) > before


def test_results_are_cached_per_scope():
    src = _source([], mode="live")
    seen: list[str] = []
    src._query = lambda sql: seen.append(sql) or []
    src.cost_anomalies(ADMIN)
    n = len(seen)
    src.cost_anomalies(ADMIN)
    assert len(seen) == n


# --- demo --------------------------------------------------------------------
def test_demo_anomalies_are_ones_the_method_flags():
    out = DemoAnomalySource(Settings(compute_mode="demo"), None).cost_anomalies(ADMIN)
    assert out.anomaly_count > 0 and out.daily
    for a in out.resource_anomalies + out.sku_anomalies:
        assert detect(a.series)["anomaly_type"] == a.anomaly_type
    assert {t.anomaly_type for t in out.by_type if t.count} >= {"step_change", "new_spender"}


def test_demo_respects_scope():
    src = DemoAnomalySource(Settings(compute_mode="demo"), None)
    out = src.cost_anomalies(SCOPED.narrowed_to("999"))
    assert out.anomaly_count == 0


# --- the endpoint ------------------------------------------------------------
def test_drill_in_rejects_a_non_numeric_workspace_id():
    import pytest
    from fastapi import HTTPException

    from finops.api.anomalies import cost_anomalies_for_workspace

    with pytest.raises(HTTPException) as exc:
        cost_anomalies_for_workspace("1;DROP", scope=ADMIN, source=None, account_view=None)
    assert exc.value.status_code == 400
