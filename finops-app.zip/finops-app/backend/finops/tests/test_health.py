"""Data-source health: the difference between "no waste" and "no permission".

The behaviour under test is a reporting guarantee, not arithmetic. Before this
existed, an unreadable system table made the dependent rules return zero findings
and the UI said "no savings found" — so a grant problem looked like good news.
These tests pin the three states apart: healthy (say nothing), degraded (say what
is blocked), and unknown (admit we could not check).
"""

from __future__ import annotations

from finops.config import Settings
from finops.services.health_service import HealthService
from finops_rules.sources import (
    CORE_TABLES,
    TableHealth,
    qualified_tables,
    short_name,
    unavailable_rules,
)


def _connect_all_ok():
    from .conftest import fake_connect

    return fake_connect(["c"], [])


def _connect_raising(bad: set[str], message="PERMISSION_DENIED"):
    """A connection whose probe fails for tables named in ``bad``."""

    class Cur:
        description = [("c",)]

        def execute(self, sql, *a, **k):
            if any(b in sql for b in bad):
                raise RuntimeError(message)

        def fetchall(self):
            return []

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    class Conn:
        def cursor(self):
            return Cur()

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    return lambda: Conn()


# --- dependency extraction -------------------------------------------------

def test_qualified_tables_ignores_prose_in_comments():
    """Rule templates name tables in their comment headers. Parsing those would
    invent dependencies the SQL never reads, and then report them as blocking."""
    sql = """
    -- Joined to billing.usage x list_prices and system.access.audit for activity
    /* also mentions system.serving.endpoint_usage in a block comment */
    SELECT * FROM system.compute.clusters c
    LEFT JOIN system.billing.usage u ON true
    """
    assert qualified_tables(sql) == {"system.compute.clusters", "system.billing.usage"}


def test_short_name_drops_the_catalog():
    """Health is per schema.table: the catalog is deployment config (it may be a
    mirror), not a property of the dependency."""
    assert short_name("system.billing.usage") == "billing.usage"
    assert short_name("my_mirror.compute.clusters") == "compute.clusters"


def test_unavailable_rules_maps_blocked_rules_to_missing_tables():
    deps = {
        "rule_a": {"billing.usage", "compute.node_timeline"},
        "rule_b": {"billing.usage"},
    }
    blocked = unavailable_rules(deps, healthy={"billing.usage"})
    assert blocked == {"rule_a": {"compute.node_timeline"}}


def test_healthy_workspace_blocks_nothing():
    deps = {"rule_a": {"billing.usage"}}
    assert unavailable_rules(deps, healthy={"billing.usage"}) == {}


# --- status semantics ------------------------------------------------------

def test_missing_optional_table_is_warn_not_fail():
    """The app still works and most rules still run, so an optional gap must not
    read as a total failure."""
    h = TableHealth(name="serving.endpoint_usage", available=False, required=False)
    assert h.status == "WARN"
    assert h.severity == "MEDIUM"


def test_missing_core_table_is_critical():
    h = TableHealth(name="billing.usage", available=False, required=True)
    assert h.status == "FAIL"
    assert h.severity == "CRITICAL"


def test_billing_tables_are_the_core_set():
    """Every rule joins billing.usage to list_prices to price its findings, so
    these are the two the app genuinely cannot work without."""
    assert CORE_TABLES == {"billing.usage", "billing.list_prices"}


# --- the report ------------------------------------------------------------

def test_fully_granted_workspace_reports_not_degraded():
    """The UI hides the whole section on a healthy workspace rather than showing a
    permanently-green ornament."""
    report = HealthService(Settings(compute_mode="live"), _connect_all_ok()).report()
    assert report.degraded is False
    assert report.unknown is False
    assert report.unavailable_rules == []
    assert report.message == ""
    assert all(s.status == "PASS" for s in report.sources)


def test_denied_optional_table_names_the_rules_it_blocks():
    connect = _connect_raising({"compute.node_timeline"})
    report = HealthService(Settings(compute_mode="live"), connect).report()

    assert report.degraded is True
    blocked_ids = {r.rule_id for r in report.unavailable_rules}
    # These rules read per-minute CPU; without the node timeline they cannot run.
    assert "rightsize_underutilized" in blocked_ids
    assert {"compute.node_timeline"} == set(
        next(r for r in report.unavailable_rules if r.rule_id == "rightsize_underutilized")
        .missing_sources
    )
    # And the source row points back at what it blocks, for the UI's grant hint.
    node = next(s for s in report.sources if s.name == "compute.node_timeline")
    assert node.status == "WARN"
    assert "rightsize_underutilized" in node.blocks_rules
    assert "PERMISSION_DENIED" in node.message


def test_denied_core_table_says_no_findings_are_possible():
    connect = _connect_raising({"billing.usage"})
    report = HealthService(Settings(compute_mode="live"), connect).report()

    assert report.degraded is True
    assert "billing.usage" in report.failing_required
    assert "Grant SELECT on system.billing" in report.message


def test_rules_that_do_not_need_the_missing_table_stay_available():
    """A single missing source must not be reported as breaking everything."""
    connect = _connect_raising({"serving.endpoint_usage", "serving.served_entities"})
    report = HealthService(Settings(compute_mode="live"), connect).report()
    blocked = {r.rule_id for r in report.unavailable_rules}
    assert blocked == {"idle_serving_endpoints", "serving_provisioned_overcapacity"}


def test_demo_mode_reads_no_system_tables_and_is_not_degraded():
    """Demo mode has no warehouse. Reporting every table as FAIL would be a lie
    about a mode that is working exactly as intended."""
    report = HealthService(Settings(compute_mode="demo"), _connect_all_ok()).report()
    assert report.degraded is False
    assert report.unknown is False
    assert report.sources == []
    assert "Demo mode" in report.message


def test_no_connection_at_all_is_unknown_not_broken():
    """When we cannot check, we must not claim the sources are fine OR broken."""

    def connect():
        raise RuntimeError("DATABRICKS_WAREHOUSE_ID is not set")

    report = HealthService(Settings(compute_mode="live"), connect).report()
    assert report.unknown is True
    assert report.degraded is False
    assert "Could not check" in report.message


# --- central mode ----------------------------------------------------------

def _central_settings():
    return Settings(
        compute_mode="precompute",
        central_mode=True,
        central_namespace="main.team_field_dsa_ce",
        finops_table="main.team_field_dsa_ce.finops_central_recommendations",
    )


def test_central_mode_probes_the_tables_it_actually_reads_not_system():
    """Central mode reads the precompute table + the central billing slice +
    certified/slice workspaces_latest — never system.*. The report must reflect
    exactly those, so an admin sees the real dependencies."""
    report = HealthService(_central_settings(), _connect_all_ok()).report()
    assert report.degraded is False
    assert report.message == ""
    names = {s.name for s in report.sources}
    assert names == {
        "main.team_field_dsa_ce.finops_central_recommendations",
        "main.team_field_dsa_ce.billing_usage",
        "main.team_field_dsa_ce.billing_list_prices",
        "main.team_field_dsa_ce.workspaces_latest",
    }
    # It must NOT probe the system billing tables the single-account path checks.
    assert not any("system.billing" in s.name for s in report.sources)


def test_central_mode_does_not_cry_wolf_over_system_billing():
    """The bug this fixes: the single-account probe hit system.billing (never
    granted on Central Logfood) and reported the app as broken while it worked.
    A connection that denies every system.* read but serves the central tables
    must come back healthy."""
    report = HealthService(_central_settings(), _connect_raising({"system."})).report()
    assert report.degraded is False
    assert report.failing_required == []
    assert report.message == ""


def test_central_mode_flags_the_recommendations_table_when_unreadable():
    connect = _connect_raising({"finops_central_recommendations"})
    report = HealthService(_central_settings(), connect).report()
    assert report.degraded is True
    assert "main.team_field_dsa_ce.finops_central_recommendations" in report.failing_required
    assert "Central data is unreadable" in report.message


def test_report_is_cached():
    """Grants change on the order of weeks; re-probing 18 tables per page load
    would add latency for an answer that almost never moves."""
    calls = {"n": 0}

    class Cur:
        description = [("c",)]

        def execute(self, sql, *a, **k):
            calls["n"] += 1

        def fetchall(self):
            return []

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    class Conn:
        def cursor(self):
            return Cur()

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    service = HealthService(Settings(compute_mode="live"), lambda: Conn())
    service.report()
    first = calls["n"]
    assert first > 0
    service.report()
    assert calls["n"] == first  # served from cache, no re-probe


# --- the last-precompute-run summary -----------------------------------------
# The recommendation table cannot say WHEN it was computed or whether the run that
# wrote it half-failed. Without that, a week-old partial run looks identical to
# last night's clean one, and every number on screen is older than it appears.

def _run_log_connect(rows, columns=None):
    """A connection whose queries all return `rows` — enough for the run-log read,
    which is the only query _last_run issues."""
    from .conftest import fake_connect

    cols = columns or [
        "finished_at", "flows_ok", "flows_failed", "failed_flows", "rows_written",
    ]
    return fake_connect(cols, rows)


def test_last_run_reports_a_clean_run():
    connect = _run_log_connect([("2026-08-11T11:50:53Z", 17, 0, "", 763)])
    svc = HealthService(Settings(compute_mode="precompute"), connect)
    run = svc._last_run()
    assert run is not None
    assert run.ok is True
    assert run.flows_ok == 17
    assert run.flows_failed == 0
    assert run.failed_flows == []
    assert run.rows_written == 763
    assert run.unavailable is False


def test_last_run_names_the_failed_flows():
    """Knowing a flow failed is only useful if you know WHICH rule is missing."""
    connect = _run_log_connect([(
        "2026-08-11T11:50:53Z", 15, 2,
        "cat.sch.candidates_failing_jobs,cat.sch.finops_genie_usage", 763,
    )])
    run = HealthService(Settings(compute_mode="precompute"), connect)._last_run()
    assert run.ok is False
    assert run.flows_failed == 2
    # Catalog/schema stripped — the flow's own name is what maps to a rule.
    assert run.failed_flows == ["candidates_failing_jobs", "finops_genie_usage"]


def test_last_run_is_omitted_in_live_mode():
    """Live mode computes on demand, so there is no run to report — and an empty
    card would imply the pipeline is broken."""
    connect = _run_log_connect([("2026-08-11T11:50:53Z", 17, 0, "", 763)])
    assert HealthService(Settings(compute_mode="live"), connect)._last_run() is None


def test_missing_run_log_is_unavailable_not_a_failure():
    """No run-log table is the expected state on a fresh install, or if the
    pipeline predates the event_log setting."""

    class Cur:
        description = [("c",)]

        def execute(self, sql, *a, **k):
            raise RuntimeError("TABLE_OR_VIEW_NOT_FOUND")

        def fetchall(self):
            return []

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    class Conn:
        def cursor(self):
            return Cur()

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    run = HealthService(Settings(compute_mode="precompute"), lambda: Conn())._last_run()
    assert run is not None
    assert run.unavailable is True
    assert run.ok is None  # we know nothing, rather than knowing it failed


def test_last_run_tolerates_a_null_row_count():
    """A run whose recommendations flow produced no event yields NULL, which must
    not become 0 — "wrote nothing" and "we don't know" are different claims."""
    connect = _run_log_connect([("2026-08-11T11:50:53Z", 17, 0, "", None)])
    run = HealthService(Settings(compute_mode="precompute"), connect)._last_run()
    assert run.rows_written is None
    assert run.ok is True


def test_run_log_query_scopes_to_the_latest_update():
    """Otherwise a previous night's failures would be reported as today's."""
    captured = {}

    class Cur:
        description = [
            ("finished_at",), ("flows_ok",), ("flows_failed",),
            ("failed_flows",), ("rows_written",),
        ]

        def execute(self, sql, *a, **k):
            captured["sql"] = sql

        def fetchall(self):
            return [("2026-08-11T11:50:53Z", 17, 0, "", 763)]

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    class Conn:
        def cursor(self):
            return Cur()

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    HealthService(Settings(compute_mode="precompute"), lambda: Conn())._last_run()
    sql = captured["sql"]
    assert "origin.update_id" in sql
    assert "ROW_NUMBER() OVER (ORDER BY timestamp DESC) = 1" in sql
    # Only terminal flow states — an in-flight flow is neither OK nor failed.
    assert "'COMPLETED', 'FAILED'" in sql
