"""Fakes + fixtures for backend tests (no live warehouse required)."""

from __future__ import annotations

import pytest


class FakeCursor:
    def __init__(self, columns: list[str], rows: list[tuple]):
        self.description = [(c,) for c in columns]
        self._rows = rows
        self.executed: str | None = None

    def execute(self, sql, *args, **kwargs):
        self.executed = sql

    def fetchall(self):
        return self._rows

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeConnection:
    """A minimal DBAPI-ish connection returning canned rows for every query."""

    def __init__(self, columns: list[str], rows: list[tuple]):
        self.columns = columns
        self.rows = rows
        self.last_cursor: FakeCursor | None = None

    def cursor(self):
        self.last_cursor = FakeCursor(self.columns, self.rows)
        return self.last_cursor

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def fake_connect(columns: list[str], rows: list[tuple]):
    def _connect():
        return FakeConnection(columns, rows)

    return _connect


@pytest.fixture
def request_headers():
    """A stand-in for a Starlette Request exposing only .headers."""

    class _Req:
        def __init__(self, headers: dict):
            self.headers = headers

    return _Req


# --- a throwaway Postgres database with the StopTheLeak feedback tables --------------
# The feedback store is Lakebase Postgres in production. Its tests need a real Postgres
# (the idempotency, supersedes and CHECK behaviour is the database's), so they run only
# when FINOPS_TEST_PG_DSN points at one, e.g.
#   FINOPS_TEST_PG_DSN=postgresql://postgres@localhost:5432/postgres
# and SKIP otherwise. Each test gets its own fresh database, dropped afterwards.
@pytest.fixture
def feedback_pg_dsn():
    import os
    import uuid
    from pathlib import Path

    admin_dsn = os.getenv("FINOPS_TEST_PG_DSN", "").strip()
    if not admin_dsn:
        pytest.skip("FINOPS_TEST_PG_DSN not set (needs a local Postgres)")
    psycopg = pytest.importorskip("psycopg")
    from psycopg.conninfo import conninfo_to_dict, make_conninfo

    name = f"finops_feedback_test_{uuid.uuid4().hex[:12]}"
    try:
        admin = psycopg.connect(admin_dsn, autocommit=True, connect_timeout=5)
    except psycopg.OperationalError as exc:
        pytest.skip(f"Postgres at FINOPS_TEST_PG_DSN unreachable: {exc}")
    with admin:
        admin.execute(f'CREATE DATABASE "{name}"')
    dsn = make_conninfo(**{**conninfo_to_dict(admin_dsn), "dbname": name})
    ddl = (Path(__file__).parent / "feedback_ddl.sql").read_text()
    with psycopg.connect(dsn) as conn:
        conn.execute(ddl)
    try:
        yield dsn
    finally:
        with psycopg.connect(admin_dsn, autocommit=True) as admin:
            admin.execute(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)')
