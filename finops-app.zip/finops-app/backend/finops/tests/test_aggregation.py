from __future__ import annotations

from datetime import date, datetime, timezone

from finops.models import Recommendation
from finops.services import aggregation


def _rec(
    rule="warehouse_autostop",
    ws="111",
    res_type="warehouse",
    res="wh-1",
    savings=400.0,
    waste=1000.0,
    category="sql",
    *,
    comp="exclusive",
    scope=None,
    low=None,
    status="bookable",
) -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule}-{ws}-{res}", snapshot_date=date(2026, 7, 13),
        rule_id=rule, rule_version="1", rule_title=rule, category=category,
        workspace_id=ws, resource_type=res_type, resource_id=res, resource_name=res,
        why="w", how="h", monthly_waste_usd=waste, monthly_savings_usd=savings,
        savings_status=status, monthly_savings_low_usd=low if low is not None else savings,
        savings_composition=comp, affected_spend_scope=scope,
        effort_band="low", effort_score=2, priority="HIGH", nba_score=1.0,
        computed_at=datetime.now(timezone.utc),
    )


def test_account_total_uses_best_option_not_sum_for_one_resource():
    # Two overlapping fixes on ONE warehouse: auto-stop ($404) + rightsize ($423).
    recs = [
        _rec(rule="warehouse_autostop", savings=404.0, waste=1000.0),
        _rec(rule="warehouse_rightsize", savings=423.0, waste=1000.0),
    ]
    ov = aggregation.account_overview(recs)
    # Bankable is the best single option (423), never the sum (827).
    assert ov.total_monthly_savings_usd == 423.0
    # Waste is the resource's spend, counted once (not 2000).
    assert ov.total_monthly_waste_usd == 1000.0
    # One resource => one counted recommendation.
    assert ov.recommendation_count == 1


def test_distinct_resources_still_summed():
    recs = [
        _rec(res="wh-1", savings=400.0, waste=1000.0),
        _rec(res="wh-2", savings=250.0, waste=600.0),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 650.0
    assert ov.total_monthly_waste_usd == 1600.0
    assert ov.recommendation_count == 2


def test_estimated_and_advisory_drop_from_booked_headline():
    # Phase 0 §0.2: only bookable low is booked. Three distinct resources — one
    # bookable ($400), one estimated ($900), one advisory ($700).
    recs = [
        _rec(res="wh-1", savings=400.0, waste=1000.0),
        _rec(res="wh-2", savings=900.0, waste=2000.0),
        _rec(res="wh-3", savings=700.0, waste=1500.0),
    ]
    recs[1].savings_status = "estimated"
    recs[2].savings_status = "advisory"
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 400.0
    # Estimated/advisory stay visible: waste and count still cover every resource.
    assert ov.total_monthly_waste_usd == 4500.0
    assert ov.recommendation_count == 3


def test_booked_credits_the_bookable_option_not_the_max_point_option():
    # One resource, two options: the bigger ($500) is only estimated, the smaller
    # ($300) is bookable. The booked floor credits $300, never $0.
    recs = [
        _rec(rule="warehouse_rightsize", res="wh-1", savings=500.0, waste=1000.0),
        _rec(rule="warehouse_autostop", res="wh-1", savings=300.0, waste=1000.0),
    ]
    recs[0].savings_status = "estimated"
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 300.0
    assert ov.recommendation_count == 1


def test_booked_headline_totals_the_low_bound_not_the_point():
    r = _rec(res="wh-1", savings=500.0)
    r.monthly_savings_low_usd = 350.0  # a rule widened the band below the point est.
    ov = aggregation.account_overview([r])
    assert ov.total_monthly_savings_usd == 350.0


# --- FIN-008 action-aware aggregation (§2.3 acceptance) ---------------------

def test_additive_options_on_one_resource_book_a_combined_bounded_figure():
    # Acceptance: auto-stop ($300) and right-size ($400) on ONE warehouse are COMPATIBLE
    # (one reclaims idle hours, the other cuts $/hour), so as `additive` they COMPOSE —
    # booked ABOVE the best single option — yet never exceed the warehouse's own cost.
    recs = [
        _rec(rule="warehouse_autostop", savings=300.0, waste=1000.0, comp="additive"),
        _rec(rule="warehouse_rightsize", savings=400.0, waste=1000.0, comp="additive"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 700.0        # 400 + 300 composed
    assert ov.total_monthly_waste_usd == 1000.0         # one resource's spend, counted once
    assert ov.recommendation_count == 1


def test_additive_composition_is_capped_at_the_scope_cost():
    # Two additive tunings that together exceed the pool are CLIPPED to it — you can never
    # reclaim more than the resource costs (the composition applies each to the remainder).
    recs = [
        _rec(rule="warehouse_autostop", savings=700.0, waste=1000.0, comp="additive"),
        _rec(rule="warehouse_rightsize", savings=600.0, waste=1000.0, comp="additive"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 1000.0       # min(700 + 600, 1000)


def test_migration_supersedes_source_tuning():
    # A serverless migration ($800, exclusive) is an ALTERNATIVE to tuning the classic
    # warehouse (auto-stop $300, additive): you either migrate OR tune, never both, so the
    # bigger migration books and the source tuning is suppressed — not summed on top.
    recs = [
        _rec(rule="warehouse_autostop", savings=300.0, waste=1000.0, comp="additive"),
        _rec(rule="enable_serverless", savings=800.0, waste=1000.0, comp="exclusive"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 800.0        # migration path; tuning superseded


def test_same_spend_segment_across_resources_is_booked_once():
    # Two findings on DIFFERENT resource ids that bill the SAME hourly/SKU segment (both
    # carry affected_spend_scope="seg-1") must book that pool ONCE, not summed — otherwise
    # the headline double-counts a single pool of dollars (FIN-008 cross-resource dedup).
    recs = [
        _rec(rule="rule_a", res="res-1", savings=400.0, waste=500.0, scope="seg-1"),
        _rec(rule="rule_b", res="res-2", savings=350.0, waste=500.0, scope="seg-1"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 400.0        # best single option in the shared scope


def test_shared_scope_does_not_bleed_across_workspaces():
    # The same explicit scope string in two workspaces stays two scopes (FIN-007): a scope
    # key is workspace-qualified, so cross-workspace dollars are still summed.
    recs = [
        _rec(rule="rule_a", ws="111", res="res-1", savings=400.0, waste=500.0, scope="seg-1"),
        _rec(rule="rule_a", ws="222", res="res-2", savings=350.0, waste=500.0, scope="seg-1"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.total_monthly_savings_usd == 750.0        # distinct workspaces => summed


def test_workspace_detail_category_breakdown_collapses_overlaps():
    recs = [
        _rec(rule="warehouse_autostop", res="wh-1", savings=404.0, category="sql"),
        _rec(rule="warehouse_rightsize", res="wh-1", savings=423.0, category="sql"),
        _rec(rule="idle_zombie_clusters", res_type="cluster", res="c-1",
             savings=100.0, category="compute"),
    ]
    d = aggregation.workspace_detail("111", recs)
    # sql collapses to the best warehouse option (423); compute is 100.
    assert d.monthly_savings_usd == 523.0
    assert d.recommendation_count == 2
    by_cat = {c.category: c for c in d.by_category}
    assert by_cat["sql"].monthly_savings_usd == 423.0
    assert by_cat["sql"].recommendation_count == 1
    assert by_cat["compute"].monthly_savings_usd == 100.0


# --- headline tier breakdown + range (savings confidence) --------------------

def _rec_full(rule, res, *, savings, low, high, status, confidence, waste=100000.0, ws="111"):
    """A rec with an explicit low/high band + evidence.confidence, for the tier tests.
    Each is its own resource (distinct scope) so they sum rather than compete."""
    return Recommendation(
        recommendation_id=f"{rule}-{res}", snapshot_date=date(2026, 7, 13),
        rule_id=rule, rule_version="1", rule_title=rule, category="sql",
        workspace_id=ws, resource_type="warehouse", resource_id=res, resource_name=res,
        why="w", how="h", monthly_waste_usd=waste, monthly_savings_usd=savings,
        savings_status=status, monthly_savings_low_usd=low, monthly_savings_high_usd=high,
        evidence={"confidence": confidence},
        effort_band="low", effort_score=2, priority="HIGH", nba_score=1.0,
        computed_at=datetime.now(timezone.utc),
    )


def test_savings_tiers_sum_to_addressable_and_band_brackets_it():
    recs = [
        _rec_full("cluster_autotermination", "c1", savings=100, low=100, high=100,
                  status="bookable", confidence="high"),
        _rec_full("warehouse_rightsize", "w1", savings=200, low=120, high=320,
                  status="estimated", confidence="high"),
        _rec_full("enable_photon_dbr", "p1", savings=90, low=40, high=180,
                  status="estimated", confidence="medium"),
        _rec_full("spot_fallback", "s1", savings=60, low=20, high=140,
                  status="estimated", confidence="low"),
        # Advisory contributes nothing to the savings headline.
        _rec_full("untagged_spend", "u1", savings=0, low=0, high=0,
                  status="advisory", confidence="high"),
    ]
    ov = aggregation.account_overview(recs)
    # Headline estimate = sum of non-advisory points.
    assert ov.total_monthly_savings_addressable_usd == 450.0
    # Tiers sum EXACTLY to the estimate, no dollar double-counted.
    assert round(sum(t.monthly_savings_usd for t in ov.savings_tiers), 2) == 450.0
    tiers = {t.tier: t.monthly_savings_usd for t in ov.savings_tiers}
    assert tiers == {"booked": 100.0, "high": 200.0, "medium": 90.0, "low": 60.0}
    # Band brackets the point (pessimistic 280 → optimistic 740): sum of the lows
    # (100+120+40+20) and the highs (100+320+180+140) across the non-advisory findings.
    assert ov.total_monthly_savings_low_usd == 280.0
    assert ov.total_monthly_savings_high_usd == 740.0
    assert (
        ov.total_monthly_savings_low_usd
        <= ov.total_monthly_savings_addressable_usd
        <= ov.total_monthly_savings_high_usd
    )
    # Advisory never enters any tier.
    assert "advisory" not in tiers


def test_bookable_finding_lands_in_booked_tier_regardless_of_confidence():
    # A bookable finding whose data-confidence is only "low" is still BOOKED, not "low".
    recs = [_rec_full("cluster_autotermination", "c1", savings=100, low=100, high=100,
                      status="bookable", confidence="low")]
    ov = aggregation.account_overview(recs)
    assert {t.tier for t in ov.savings_tiers} == {"booked"}


def test_advisory_findings_on_one_warehouse_count_its_spend_once():
    # Promoted advisory rules ($0 savings) on a warehouse that also has a priced option.
    recs = [
        _rec(rule="warehouse_rightsize", savings=400.0, waste=1000.0, status="estimated"),
        _rec(rule="warehouse_keepalive_queries", savings=0.0, waste=900.0, status="advisory"),
        _rec(rule="unpruned_repeated_queries", savings=0.0, waste=700.0, status="advisory"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.recommendation_count == 1
    assert ov.total_monthly_waste_usd == 1000.0  # not 2600
    assert aggregation.resource_count(recs) == 1


def test_alert_scoped_to_its_warehouse_shares_that_spend_pool():
    # An alert whose dollars are its warehouse's compute (affected_spend_scope) is its
    # own resource, but its spend is the warehouse's, so the total counts it once.
    recs = [
        _rec(rule="warehouse_keepalive_queries", savings=0.0, waste=900.0, status="advisory"),
        _rec(rule="alert_hygiene", res_type="alert", res="a-1", savings=0.0, waste=600.0,
             status="advisory", scope="warehouse|wh-1"),
    ]
    ov = aggregation.account_overview(recs)
    assert ov.recommendation_count == 2          # two things to look at
    assert ov.total_monthly_waste_usd == 900.0   # one spend pool
    assert ov.total_monthly_savings_usd == 0.0   # advisory books nothing


def test_collapse_breaks_zero_savings_ties_on_spend():
    recs = [
        _rec(rule="a", savings=0.0, waste=100.0, status="advisory"),
        _rec(rule="b", savings=0.0, waste=900.0, status="advisory"),
    ]
    (only,) = aggregation._collapse_to_resources(recs)
    assert only.rule_id == "b"
