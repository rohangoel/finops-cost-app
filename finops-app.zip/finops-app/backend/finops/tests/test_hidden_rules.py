"""The hidden-rule filter: computed and stored, but absent from the whole GUI.

``unused_scheduled_jobs`` and ``enable_photon_dbr`` are still produced by the
pipeline (we want the data), but must not appear in any list, group, chart, savings
total or NBA ranking. The filter therefore lives at the ONE boundary every read
path crosses — ``RecommendationSource.fetch`` — and these tests pin that, including
the endpoints that read ``service.source`` directly.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from finops.config import Settings
from finops.data.base import RecommendationSource
from finops.identity import Scope
from finops.models import Recommendation
from finops.services import aggregation
from finops.services.recommendation_service import RecommendationService

ADMIN = Scope(all_workspaces=True, workspace_ids=[])


def _rec(rule: str, savings: float, resource: str) -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule}-{resource}",
        snapshot_date=date(2026, 8, 4),
        rule_id=rule,
        rule_version="1.0.0",
        rule_title=rule.replace("_", " ").title(),
        category="compute",
        workspace_id="111",
        resource_type="cluster",
        resource_id=resource,
        resource_name=resource,
        why="because",
        how="do this",
        monthly_waste_usd=savings * 2,
        monthly_savings_usd=savings,
        effort_band="low",
        effort_score=2,
        priority="MEDIUM",
        nba_score=savings / 2,
        evidence={},
        computed_at=datetime(2026, 8, 4, tzinfo=timezone.utc),
    )


class _Source(RecommendationSource):
    def __init__(self, settings, recs):
        super().__init__(settings, None)
        self._recs = recs

    def load(self, scope, account_view=None):
        return list(self._recs)


_ALL = [
    _rec("cluster_autotermination", 100.0, "c-1"),
    _rec("unused_scheduled_jobs", 500.0, "j-1"),
    _rec("enable_photon_dbr", 900.0, "c-2"),
    _rec("rightsize_underutilized", 200.0, "c-3"),
]


def _source(hidden: list[str] | None = None) -> _Source:
    settings = Settings(
        hidden_rules=(
            ["unused_scheduled_jobs", "enable_photon_dbr"] if hidden is None else hidden
        )
    )
    return _Source(settings, _ALL)


def test_hidden_rules_are_dropped_from_fetch():
    ids = {r.rule_id for r in _source().fetch(ADMIN)}
    assert ids == {"cluster_autotermination", "rightsize_underutilized"}


def test_load_still_returns_them_for_the_serverless_case():
    # The About Serverless view reads `load` on purpose: the old-DBR evidence is
    # exactly what it needs, even though it's hidden from the recommendation GUI.
    ids = {r.rule_id for r in _source().load(ADMIN)}
    assert "enable_photon_dbr" in ids


def test_hidden_savings_excluded_from_account_totals():
    visible = _source().fetch(ADMIN)
    overview = aggregation.account_overview(visible)
    # 100 + 200 only; the hidden 500 + 900 must not inflate the headline.
    assert overview.total_monthly_savings_usd == 300.0
    assert overview.recommendation_count == 2


def test_hidden_rules_absent_from_groups_and_nba():
    svc = RecommendationService(_source())
    group_rules = {o.rule_id for g in svc.list_grouped(ADMIN) for o in g.options}
    assert "unused_scheduled_jobs" not in group_rules
    assert "enable_photon_dbr" not in group_rules
    nba_rules = {r.rule_id for r in svc.next_best_actions(ADMIN, limit=50)}
    assert not nba_rules & {"unused_scheduled_jobs", "enable_photon_dbr"}


def test_empty_config_shows_everything():
    # The switch is config, so a deployment can resurface them without a code change.
    ids = {r.rule_id for r in _source(hidden=[]).fetch(ADMIN)}
    assert len(ids) == 4
