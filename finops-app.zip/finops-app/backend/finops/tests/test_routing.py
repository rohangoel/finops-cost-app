"""finding_key + owner routing: the definitions StopTheLeak recomputes and compares.

See finops/routing.py. Three things are pinned here:
* the finding_key formula, recomputed independently (StopTheLeak's SQL);
* that ROUTING_SQL (what the pipeline runs) routes exactly like route() (what live,
  demo and old snapshots use), by running the SQL on SQLite over the same cases;
* that stored routing columns win over re-derivation on the read path.
"""

from __future__ import annotations

import hashlib
import sqlite3
from datetime import date, datetime, timezone

import pytest

from finops.data.workspace_owner_sql import valid_owner_tag, workspace_owner_sql
from finops.models import Recommendation
from finops.models.group import group_id
from finops.routing import ROUTING_SQL, finding_key, owner_kind, route

SP_ID = "3f2a9c1e-7b4d-4e2a-9f10-0a1b2c3d4e5f"

# (resource_owner, workspace_owner) -> (kind, recipient, source)
CASES = [
    ("Ana.Berg@Example.com", "boss@example.com", ("user", "ana.berg@example.com", "object_owner")),
    ("ana@example.com", None, ("user", "ana@example.com", "object_owner")),
    (SP_ID, "Boss@Example.com", ("service_principal", "boss@example.com", "workspace_owner")),
    (SP_ID, None, ("service_principal", None, None)),
    (None, "boss@example.com", ("unknown", "boss@example.com", "workspace_owner")),
    (None, None, ("unknown", None, None)),
    ("data-platform-team", "boss@example.com", ("unknown", "boss@example.com", "workspace_owner")),
    ("svc-etl-prod", None, ("unknown", None, None)),
    ("", "", ("unknown", None, None)),
]


def _rec(**kw) -> Recommendation:
    base = dict(
        recommendation_id="r1", snapshot_date=date(2026, 9, 28), rule_id="warehouse_autostop",
        rule_version="1", rule_title="t", category="sql", workspace_id="111",
        resource_type="warehouse", resource_id="abc", resource_name="wh", why="w", how="h",
        monthly_waste_usd=10.0, monthly_savings_usd=5.0, effort_band="low", effort_score=2,
        priority="HIGH", nba_score=1.0, computed_at=datetime.now(timezone.utc),
    )
    base.update(kw)
    return Recommendation(**base)


def test_finding_key_matches_stoptheleak_formula():
    # substr(sha2(concat_ws('|', rule_id, workspace_id, resource_type, resource_id), 256), 1, 32)
    expected = hashlib.sha256(b"warehouse_autostop|111|warehouse|abc").hexdigest()[:32]
    assert finding_key("warehouse_autostop", "111", "warehouse", "abc") == expected
    assert len(expected) == 32 and expected == expected.lower()


def test_finding_key_is_snapshot_independent_and_per_rule():
    a = _rec(snapshot_date=date(2026, 9, 28), recommendation_id="x")
    b = _rec(snapshot_date=date(2026, 9, 29), recommendation_id="y")
    other_rule = _rec(rule_id="enable_serverless")
    assert a.finding_key == b.finding_key
    assert a.finding_key != other_rule.finding_key
    # group_id is per resource, so both rules share it; finding_key tells them apart.
    assert a.group_id == other_rule.group_id == group_id("111", "warehouse", "abc")


@pytest.mark.parametrize("owner,ws_owner,expected", CASES)
def test_route_python(owner, ws_owner, expected):
    kind, recipient, source = expected
    assert owner_kind(owner) == kind
    assert route(owner, ws_owner) == (recipient, source)


def test_routing_sql_matches_python():
    """The pipeline's Spark SQL and route() must never disagree, or the app and the
    precompute table would name different recipients. The SQL is portable CASE /
    LIKE / lower, so SQLite runs it as-is."""
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE t (i INTEGER, resource_owner TEXT, workspace_owner TEXT)")
    con.executemany(
        "INSERT INTO t VALUES (?, ?, ?)",
        [(i, o, w) for i, (o, w, _) in enumerate(CASES)],
    )
    cols = ", ".join(f"{expr} AS {name}" for name, expr in ROUTING_SQL.items())
    rows = con.execute(f"SELECT i, {cols} FROM t ORDER BY i").fetchall()
    for i, kind, recipient, source in rows:
        owner, ws_owner, _ = CASES[i]
        assert kind == owner_kind(owner), CASES[i]
        assert (recipient, source) == route(owner, ws_owner), CASES[i]


def test_model_derives_routing_when_unset():
    rec = _rec(resource_owner="Ana@Example.com")
    assert rec.resource_owner_kind == "user"
    assert rec.notify_recipient == "ana@example.com"
    assert rec.recipient_source == "object_owner"

    sp_owned = _rec(resource_owner=SP_ID, workspace_owner="boss@example.com")
    assert (sp_owned.notify_recipient, sp_owned.recipient_source) == (
        "boss@example.com", "workspace_owner",
    )


def test_stored_routing_wins_over_derivation():
    """A snapshot row carries the pipeline's routing. Re-deriving on read would drop
    the workspace owner whenever the row lacked it, so the stored values are kept."""
    rec = _rec(
        resource_owner=SP_ID, workspace_owner=None, resource_owner_kind="service_principal",
        notify_recipient="boss@example.com", recipient_source="workspace_owner",
        finding_key="f" * 32,
    )
    assert rec.notify_recipient == "boss@example.com"
    assert rec.finding_key == "f" * 32


def test_owner_tag_validation_rejects_injection():
    assert valid_owner_tag("Owner") == "Owner"
    assert valid_owner_tag(" team.owner ") == "team.owner"
    assert valid_owner_tag("") is None
    assert valid_owner_tag(None) is None
    assert valid_owner_tag("x'] OR 1=1 --") is None
    with pytest.raises(ValueError):
        workspace_owner_sql(tag="x']")


def test_workspace_owner_sql_shape():
    sql = workspace_owner_sql("system", 30, "Owner")
    assert "custom_tags['Owner'] LIKE '%@%'" in sql
    assert "lower(u.custom_tags['Owner'])" in sql
    # Deterministic tie-break: the count, then the value.
    assert "max_by(owner, struct(n, owner))" in sql
    assert "GROUP BY workspace_id" in sql
