"""Total-workspace-spend reads: snapshot, live fallback, and honest unavailability.

The fallback chain matters more than the arithmetic here: a fresh deployment has no
snapshot yet, and the KPI must not read $0 as though the platform were free.
"""

from __future__ import annotations

import json

import pytest
from finops.config import Settings
from finops.data.spend_source import SpendSource, _rollup
from finops.data.spend_sql import workspace_spend_sql
from finops_rules.resolver import TableResolver
from finops.identity import Scope

from .conftest import fake_connect

ADMIN = Scope(all_workspaces=True, workspace_ids=[])
SCOPED = Scope(all_workspaces=False, workspace_ids=["111"])

_COLUMNS = [
    "workspace_id", "workspace_name", "lookback_days", "total_spend_usd",
    "monthly_spend_usd", "total_dbus", "serverless_spend_usd", "classic_spend_usd",
    "by_sku",
]


def _row(wid="111", total=3000.0, serverless=1000.0):
    by_sku = json.dumps([
        {"sku_group": "All-purpose compute", "spend_usd": total * 0.6, "dbus": 100.0},
        {"sku_group": "SQL Warehouse (serverless)", "spend_usd": total * 0.4, "dbus": 50.0},
    ])
    return (wid, f"ws-{wid}", 30, total, total, 200.0, serverless, total - serverless, by_sku)


def _source(columns, rows, *, mode="precompute") -> SpendSource:
    return SpendSource(Settings(compute_mode=mode), fake_connect(columns, rows))


class _RoutingConn:
    """A fake connection that answers the out-of-scope COUNT query and the spend
    query differently — fake_connect returns identical rows for every SQL, which
    can't exercise the two-query account_spend path."""

    def __init__(self, spend_columns, spend_rows, out_of_scope):
        self._spend = (spend_columns, spend_rows)
        self._oos = out_of_scope

    def cursor(self):
        conn = self

        class _Cur:
            description: list
            _rows: list

            def execute(self, sql, *a, **k):
                if "out_of_scope_workspaces" in sql:
                    self.description = [("out_of_scope_workspaces",)]
                    self._rows = [(conn._oos,)]
                else:
                    self.description = [(c,) for c in conn._spend[0]]
                    self._rows = conn._spend[1]

            def fetchall(self):
                return self._rows

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        return _Cur()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _routing_source(spend_rows, out_of_scope, *, mode="precompute") -> SpendSource:
    return SpendSource(Settings(compute_mode=mode), lambda: _RoutingConn(_COLUMNS, spend_rows, out_of_scope))


def test_reads_the_snapshot_in_precompute_mode():
    src = _source(_COLUMNS, [_row(), _row("222", 5000.0, 2000.0)])
    spend = src.account_spend(ADMIN)
    assert spend.unavailable is False
    assert spend.workspace_count == 2
    assert spend.total_monthly_spend_usd == 8000.0
    assert spend.total_serverless_spend_usd == 3000.0
    # Workspaces are ordered by spend so the UI can show a leaderboard directly.
    assert [w.workspace_id for w in spend.workspaces] == ["222", "111"]


def test_sku_breakdown_is_aggregated_across_workspaces():
    src = _source(_COLUMNS, [_row(total=1000.0), _row("222", total=1000.0)])
    spend = src.account_spend(ADMIN)
    groups = {s.sku_group: s.spend_usd for s in spend.by_sku}
    assert groups["All-purpose compute"] == pytest.approx(1200.0)
    assert groups["SQL Warehouse (serverless)"] == pytest.approx(800.0)
    # Sorted biggest-first so the "where the money goes" list reads correctly.
    assert spend.by_sku[0].sku_group == "All-purpose compute"


def test_falls_back_to_live_when_the_snapshot_is_empty():
    # A deployed-but-never-run precompute job yields an empty table; the live
    # query must cover it rather than reporting $0.
    src = _source(_COLUMNS, [])

    calls: list[str] = []
    original = src._query

    def spy(sql):
        calls.append(sql)
        if "out_of_scope_workspaces" in sql:
            return [{"out_of_scope_workspaces": 5}]
        # First spend call = snapshot (empty), second = the live aggregate.
        spend_calls = [c for c in calls if "out_of_scope_workspaces" not in c]
        return [] if len(spend_calls) == 1 else [dict(zip(_COLUMNS, _row()))]

    src._query = spy
    spend = src.account_spend(ADMIN)
    assert spend.unavailable is False
    assert spend.total_monthly_spend_usd == 3000.0
    assert spend.out_of_scope_workspaces == 5
    # snapshot (empty) + live aggregate + out-of-scope count
    assert len(calls) == 3
    assert any("billing.usage" in c for c in calls)
    assert original is not None


def test_unavailable_when_both_paths_fail():
    src = _source(_COLUMNS, [])

    def boom(_sql):
        raise RuntimeError("no grant on system.billing")

    src._query = boom
    spend = src.account_spend(ADMIN)
    # Honest emptiness: the UI omits the KPI instead of claiming zero spend.
    assert spend.unavailable is True
    assert spend.total_monthly_spend_usd == 0.0
    assert spend.workspaces == []


def test_live_path_is_scoped_to_the_callers_workspaces():
    src = _source(_COLUMNS, [], mode="live")
    seen: list[str] = []

    def spy(sql):
        seen.append(sql)
        return [dict(zip(_COLUMNS, _row()))]

    src._query = spy
    src.account_spend(SCOPED)
    assert "workspace_id IN ('111')" in seen[0]


def test_scoped_caller_with_no_workspaces_gets_nothing_not_everything():
    src = _source(_COLUMNS, [_row()], mode="live")
    spend = src.account_spend(Scope(all_workspaces=False, workspace_ids=[]))
    assert spend.workspaces == []
    assert spend.total_monthly_spend_usd == 0.0


def test_results_are_cached_per_scope():
    src = _source(_COLUMNS, [_row()])
    calls: list[str] = []

    def spy(sql):
        calls.append(sql)
        return [dict(zip(_COLUMNS, _row()))]

    src._query = spy
    src.account_spend(ADMIN)
    first = len(calls)
    src.account_spend(ADMIN)
    assert len(calls) == first  # second read served entirely from cache
    assert first == 2  # snapshot + out-of-scope count, cached together


def test_workspace_lookup_returns_none_for_unknown_id():
    src = _source(_COLUMNS, [_row()])
    assert src.workspace_spend(ADMIN, "111") is not None
    assert src.workspace_spend(ADMIN, "999") is None


def test_malformed_sku_json_degrades_to_empty():
    bad = list(_row())
    bad[-1] = "{not json"
    src = _source(_COLUMNS, [tuple(bad)])
    spend = src.account_spend(ADMIN)
    # The total still stands; only the breakdown is lost.
    assert spend.total_monthly_spend_usd == 3000.0
    assert spend.by_sku == []


def test_rollup_normalizes_a_short_window_to_a_month():
    # monthly_spend_usd comes from SQL, but the model must carry it through so the
    # figure is comparable with the rules' monthly savings.
    rows = [dict(zip(_COLUMNS, ("111", "ws", 15, 500.0, 1000.0, 10.0, 0.0, 500.0, None)))]
    spend = _rollup(rows, 15, unavailable=False)
    assert spend.total_monthly_spend_usd == 1000.0
    assert spend.workspaces[0].total_spend_usd == 500.0


def test_out_of_scope_count_is_reported_for_the_account_view():
    src = _routing_source([_row(), _row("222", 5000.0)], out_of_scope=7)
    spend = src.account_spend(ADMIN)
    assert spend.workspace_count == 2  # in-scope, from the spend rows
    assert spend.out_of_scope_workspaces == 7  # excluded-by-region, from the count query


def test_out_of_scope_is_zero_for_a_workspace_scoped_user():
    # A workspace admin is already narrowed to their own workspaces, so a region
    # exclusion count is meaningless for them — and the count query must not run.
    ran = {"count_query": False}

    class _Guard(_RoutingConn):
        def cursor(self):
            cur = super().cursor()
            orig = cur.execute

            def execute(sql, *a, **k):
                if "out_of_scope_workspaces" in sql:
                    ran["count_query"] = True
                return orig(sql, *a, **k)

            cur.execute = execute
            return cur

    src = SpendSource(Settings(compute_mode="precompute"),
                      lambda: _Guard(_COLUMNS, [_row()], 7))
    spend = src.account_spend(SCOPED)
    assert spend.out_of_scope_workspaces == 0
    assert ran["count_query"] is False


def test_out_of_scope_stays_zero_when_spend_is_unavailable():
    # Both snapshot and live fail => unavailable; don't claim an out-of-scope count.
    def _boom():
        raise RuntimeError("no billing grant")

    src = SpendSource(Settings(compute_mode="precompute"), _boom)
    spend = src.account_spend(ADMIN)
    assert spend.unavailable is True
    assert spend.out_of_scope_workspaces == 0


def test_sql_is_region_scoped_but_not_persona_filtered_and_prices_at_list():
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    # Persona scoping (a literal id list) is still injected by the caller, like the
    # rule SQL. The builder itself carries only the region filter: billing.usage is
    # account-global, so it is restricted to this metastore's workspaces (region.py).
    assert sql.count("workspace_id IN (") == 1
    assert "workspace_id IN (SELECT workspace_id FROM system.access.workspaces_latest" in sql
    assert "billing.list_prices" in sql
    assert "date_sub(current_date(), 30)" in sql


# --- the product breakdown groups on billing_origin_product -------------------
# It used to group on sku_name substrings, which cannot identify a product: Apps
# bill under PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_<REGION>, so they were pooled
# into a catch-all "Serverless (other)" bucket alongside Vector Search, Lakebase and
# Model Serving. On a real account that unlabelled bucket was the LARGEST line item
# (39% of spend), which defeats the point of having a breakdown at all.
def test_breakdown_groups_on_the_product_not_the_sku_name():
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "billing_origin_product" in sql
    # The product column must be carried through the priced CTE to be groupable.
    assert "u.billing_origin_product" in sql


def test_apps_have_their_own_bucket():
    """The specific regression: Apps must be nameable even though no part of their
    SKU name says "app"."""
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "'APPS'" in sql
    assert "Databricks Apps" in sql


def test_the_catch_all_serverless_bucket_is_gone():
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "Serverless (other)" not in sql


def test_the_big_serverless_products_are_named_individually():
    """These four shared the old catch-all bucket and are large enough on a real
    account that pooling them hides real money."""
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    for product, label in (
        ("APPS", "Databricks Apps"),
        ("VECTOR_SEARCH", "Vector Search"),
        ("LAKEBASE", "Lakebase"),
        ("MODEL_SERVING", "Model serving"),
    ):
        assert f"'{product}'" in sql
        assert label in sql


def test_sql_and_serverless_variants_are_still_distinguished():
    """The serverless/classic split within a product lives in the SKU name — the
    only place that carries it — so those arms still test sku_name."""
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    for label in (
        "SQL Warehouse (serverless)", "SQL Warehouse (pro)", "SQL Warehouse (classic)",
        "Pipelines (serverless)", "Pipelines (DLT)",
        "Jobs (serverless)", "Jobs compute",
    ):
        assert label in sql


def test_an_unknown_product_is_named_rather_than_pooled():
    """A product Databricks ships after this list was written should appear as
    itself the first time it bills, not vanish into "Other"."""
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "initcap" in sql
    assert "billing_origin_product" in sql.split("ELSE", 1)[1]


def test_the_serverless_classic_split_still_keys_on_sku_name():
    """That split is about COMPUTE type, not product, so it must not be switched to
    billing_origin_product — a serverless SQL warehouse and a classic one share the
    product 'SQL'."""
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "serverless_spend_usd" in sql
    totals = sql.split("totals AS", 1)[1]
    assert "sku_name LIKE '%SERVERLESS%'" in totals


# --- the daily spend trend ----------------------------------------------------
# A window total says how much; only the series says whether it is getting worse.
# Two things must hold: the series has to reconcile with the total it sits next to
# (a chart that disagrees with the KPI above it destroys trust in both), and a
# snapshot written before the column existed must degrade to "no chart" rather than
# to a flat line at zero, which would read as "spend stopped".

def _row_with_days(wid="111", total=300.0, days=3):
    from datetime import date, timedelta

    series = [
        {
            "usage_date": (date(2026, 8, 1) + timedelta(days=i)).isoformat(),
            "spend_usd": round(total / days, 2),
            "dbus": round(total / days / 0.55, 2),
        }
        for i in range(days)
    ]
    return dict(zip(
        [*_COLUMNS, "by_day"],
        (wid, f"ws-{wid}", 30, total, total, 100.0, 0.0, total,
         json.dumps([]), json.dumps(series)),
    ))


def test_daily_series_is_parsed_and_sorted_oldest_first():
    spend = _rollup([_row_with_days()], 30, unavailable=False)
    days = spend.workspaces[0].by_day
    assert len(days) == 3
    assert [d.usage_date for d in days] == sorted(d.usage_date for d in days)


def test_account_series_sums_every_workspace_per_day():
    """The account chart must be one line, not N — so same-day points across
    workspaces are added rather than concatenated."""
    spend = _rollup(
        [_row_with_days("111", 300.0), _row_with_days("222", 600.0)], 30,
        unavailable=False,
    )
    assert len(spend.by_day) == 3  # 3 distinct dates, not 6 rows
    assert spend.by_day[0].spend_usd == 100.0 + 200.0


def test_series_reconciles_with_the_window_total():
    """A chart that disagrees with the KPI above it discredits both."""
    spend = _rollup([_row_with_days(total=300.0)], 30, unavailable=False)
    series_sum = sum(d.spend_usd for d in spend.workspaces[0].by_day)
    assert series_sum == pytest.approx(spend.workspaces[0].total_spend_usd, abs=0.05)


def test_snapshot_without_the_column_yields_no_series():
    """An older snapshot has no by_day. The UI must omit the chart, not draw zero."""
    rows = [dict(zip(_COLUMNS, ("111", "ws", 30, 500.0, 500.0, 10.0, 0.0, 500.0, None)))]
    spend = _rollup(rows, 30, unavailable=False)
    assert spend.workspaces[0].by_day == []
    assert spend.by_day == []


def test_malformed_series_is_dropped_not_half_rendered():
    rows = [dict(zip([*_COLUMNS, "by_day"],
                     ("111", "ws", 30, 500.0, 500.0, 10.0, 0.0, 500.0, None,
                      "not json")))]
    assert _rollup(rows, 30, unavailable=False).workspaces[0].by_day == []


def test_a_point_with_no_date_is_skipped():
    """It cannot be placed on an axis, and a blank label would render as a gap."""
    rows = [dict(zip([*_COLUMNS, "by_day"],
                     ("111", "ws", 30, 500.0, 500.0, 10.0, 0.0, 500.0, None,
                      json.dumps([{"spend_usd": 10.0}, {"usage_date": "2026-08-01",
                                                        "spend_usd": 20.0}]))))]
    days = _rollup(rows, 30, unavailable=False).workspaces[0].by_day
    assert len(days) == 1
    assert days[0].usage_date == "2026-08-01"


def test_sql_emits_the_daily_series_sorted_ascending():
    sql = workspace_spend_sql(TableResolver.nested("system"), 30)
    assert "by_day" in sql
    # One JSON column, not a per-day grain: every existing reader depends on this
    # table being one row per workspace.
    assert "collect_list" in sql.split("daily AS", 1)[1]
    daily = sql.split("daily AS", 1)[1].split("SELECT\n  t.workspace_id", 1)[0]
    assert "array_sort" in daily
    assert "l.usage_date < r.usage_date THEN -1" in daily


def test_demo_series_reconciles_with_its_own_total():
    """Demo mode fabricates the series separately, so it can drift from the KPI
    unless it is built to sum to the same number."""
    from finops.config import Settings
    from finops.data.spend_source import DemoSpendSource

    src = DemoSpendSource(Settings(compute_mode="demo", lookback_days=30), None)
    acct = src.account_spend(ADMIN)
    assert len(acct.by_day) == 30
    assert sum(d.spend_usd for d in acct.by_day) == pytest.approx(
        acct.total_monthly_spend_usd, rel=0.01
    )


class _CentralRoutingConn:
    """Answers the account_id lookup (certified.workspaces_latest) and the central
    spend query with different rows, so the two-query central path is exercised."""

    def __init__(self, account_ids, spend_columns, spend_rows):
        self._ids = account_ids
        self._spend = (spend_columns, spend_rows)

    def cursor(self):
        conn = self

        class _Cur:
            def execute(self, sql, *a, **k):
                # The spend query references billing_usage (and, via the scope subquery,
                # workspaces_latest); the account_id lookup references only workspaces_latest.
                if "billing_usage" in sql:  # the central spend query
                    self.description = [(c,) for c in conn._spend[0]]
                    self._rows = conn._spend[1]
                else:  # the salesforce_account_name -> account_id lookup
                    self.description = [("account_id",)]
                    self._rows = [(a,) for a in conn._ids]

            def fetchall(self):
                return self._rows

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        return _Cur()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def test_central_spend_resolves_account_then_scopes_the_read():
    from finops.data.account_view import AccountView

    src = SpendSource(
        Settings(compute_mode="precompute", central_mode=True),
        lambda: _CentralRoutingConn(["acc-1"], _COLUMNS, [_row("111", 9000.0, 3000.0)]),
    )
    spend = src.account_spend(ADMIN, AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    assert not spend.unavailable
    assert spend.total_monthly_spend_usd == 9000.0


def test_central_spend_is_unavailable_without_a_selection():
    from finops.data.account_view import AccountView

    # The gate guarantees a selection; without one we refuse the all-accounts scan.
    src = SpendSource(
        Settings(compute_mode="precompute", central_mode=True),
        lambda: _CentralRoutingConn([], _COLUMNS, [_row()]),
    )
    spend = src.account_spend(ADMIN, AccountView())
    assert spend.unavailable is True
