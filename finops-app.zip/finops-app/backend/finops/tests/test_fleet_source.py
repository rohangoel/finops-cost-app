"""Fleet-facts reads for the About Serverless page.

These three queries each scan a wide system table. On the first real deploy they
ran serially (~10s each) and blew past the SQL connection's socket timeout, leaving
the page stuck on "Analysing your estate…". So the contract under test is: run them
concurrently, cap the whole section with a wall-clock budget, and degrade to fewer
cards rather than hanging or raising.
"""

from __future__ import annotations

import time

from finops.config import Settings
from finops.data import fleet_source as fs
from finops.data.fleet_source import FleetSource
from finops.identity import Scope

ADMIN = Scope(all_workspaces=True, workspace_ids=[])


def _source(handler, **settings_kw) -> FleetSource:
    """A FleetSource whose _try is replaced by ``handler(name) -> rows|None``."""
    src = FleetSource(Settings(**settings_kw), None)
    src._try = lambda name, sql: handler(name)  # type: ignore[method-assign]
    return src


_DBR = [{"dbr_version": "14.3.x", "cluster_count": 3, "spend_usd": 100.0}]
_LAT = [{
    "total_queries": 1000, "queries_waiting": 100, "total_wait_minutes": 50.0,
    "p50_wait_s": 3.0, "p95_wait_s": 12.0, "max_wait_s": 60.0,
}]
_SCALE = [{"clusters_scaling": 5, "resize_events": 20, "resize_hours": 1.5}]

_ALL = {"dbr_spread": _DBR, "startup_latency": _LAT, "autoscale": _SCALE}


def test_returns_all_three_metric_groups():
    facts = _source(lambda n: _ALL[n]).fleet_facts(ADMIN)
    assert facts["distinct_dbr_versions"] == 1
    assert facts["startup"]["queries_waiting"] == 100
    assert facts["startup"]["waiting_share"] == 0.1
    assert facts["autoscale"]["resize_events"] == 20
    assert facts["lookback_days"] == 30


def test_a_failing_metric_drops_only_itself():
    # An ungranted schema must cost one card, not the page.
    def handler(name):
        if name == "startup_latency":
            return None  # _try swallows the exception and reports None
        return _ALL[name]

    facts = _source(handler).fleet_facts(ADMIN)
    assert "startup" not in facts
    assert facts["distinct_dbr_versions"] == 1
    assert facts["autoscale"]["resize_events"] == 20


def test_queries_run_concurrently_not_serially():
    # Three 0.3s queries must finish in well under their 0.9s serial sum.
    def handler(name):
        time.sleep(0.3)
        return _ALL[name]

    start = time.monotonic()
    facts = _source(handler).fleet_facts(ADMIN)
    elapsed = time.monotonic() - start
    assert elapsed < 0.75, f"looks serial: {elapsed:.2f}s"
    assert "startup" in facts and "autoscale" in facts


def test_a_hanging_metric_is_dropped_at_the_budget(monkeypatch):
    # The regression this guards: one query that never returns must not hang the
    # response — it is omitted once the budget expires.
    monkeypatch.setattr(fs, "_FLEET_BUDGET_S", 0.4)

    def handler(name):
        if name == "autoscale":
            time.sleep(30)  # never comes back within the budget
        return _ALL[name]

    start = time.monotonic()
    facts = _source(handler).fleet_facts(ADMIN)
    elapsed = time.monotonic() - start
    assert elapsed < 3.0, f"budget not enforced: {elapsed:.2f}s"
    assert "autoscale" not in facts
    # ...and the metrics that DID return are still present.
    assert facts["distinct_dbr_versions"] == 1
    assert facts["startup"]["queries_waiting"] == 100


def test_results_are_cached():
    calls: list[str] = []

    def handler(name):
        calls.append(name)
        return _ALL[name]

    src = _source(handler)
    src.fleet_facts(ADMIN)
    src.fleet_facts(ADMIN)
    assert len(calls) == 3  # one round only; second read served from cache


def test_empty_result_set_omits_the_metric_without_error():
    # A workspace with no clusters yields zero rows, not an error.
    facts = _source(lambda n: [] if n == "dbr_spread" else _ALL[n]).fleet_facts(ADMIN)
    assert "dbr_versions" not in facts
    assert "startup" in facts


def test_zero_queries_does_not_divide_by_zero():
    empty_lat = [{
        "total_queries": 0, "queries_waiting": 0, "total_wait_minutes": 0.0,
        "p50_wait_s": 0.0, "p95_wait_s": 0.0, "max_wait_s": 0.0,
    }]
    facts = _source(
        lambda n: empty_lat if n == "startup_latency" else _ALL[n]
    ).fleet_facts(ADMIN)
    assert facts["startup"]["waiting_share"] == 0.0
