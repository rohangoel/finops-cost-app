"""Backend side of contract / cloud pricing (docs/TIER1_TIER2_IMPLEMENTATION_PLAN.md §A).

The rule-side derivation is pinned in rules/finops_rules/tests; these cover the
transform wiring, the spend SQL, the capability summary the UI gates on, and the
defensive (GH #108) reads of snapshots written before the columns existed."""

from __future__ import annotations

from datetime import date

from finops.config import Settings
from finops.data import precompute_source as pre_mod
from finops.data.precompute_source import _COLUMNS, PrecomputeRecommendationSource
from finops.data.spend_sql import workspace_spend_sql
from finops.identity import Scope
from finops.models import Recommendation
from finops.services.precompute_transform import records_for_rule
from finops.services.pricing_summary import pricing_summary
from finops_rules.catalog.autotermination import AutoTerminationRule
from finops_rules.price_basis import PricingCapabilities, probe_capabilities
from finops_rules.resolver import TableResolver

from .conftest import fake_connect

_THRESHOLDS = {
    "lookback_days": 30, "catalog": "system", "min_observation_days": 5,
    "cluster_autotermination": {"max_acceptable_minutes": 60, "min_idle_events": 3,
                                "use_audit_activity": False},
}
_ROW = {
    "workspace_id": "111", "cluster_id": "c-abc", "cluster_name": "adhoc",
    "auto_termination_minutes": None, "dbr_version": "13.3.x", "worker_count": 4,
    "cost_30d_usd": 3000.0, "dbus_30d": 5000.0, "idle_windows": 80,
    "total_windows": 100, "idle_minutes": 8000.0, "reclaimable_gross_min": 7000.0,
    "num_reclaim_gaps": 20, "longest_idle_gap_min": 500, "running_minutes": 10000.0,
    "job_runs_30d": 0, "observed_days": 28,
}


def _score(row, caps=None, **th):
    return records_for_rule(
        AutoTerminationRule(), [row], thresholds={**_THRESHOLDS, **th}, lookback_days=30,
        catalog="system", snapshot=date(2026, 9, 23), capabilities=caps,
    )


def test_flags_off_output_has_no_pricing_values():
    [rec] = _score({**_ROW, "contract_ratio": 0.8, "contract_price_coverage": 1.0})
    assert rec["price_basis"] is None
    assert rec["monthly_savings_contract_usd"] is None
    assert "LIST price" in __import__("json").loads(rec["evidence"])["data_basis"]


def test_covered_finding_gets_contract_figures_and_two_basis_note():
    import json

    [rec] = _score({**_ROW, "contract_ratio": 0.8, "contract_price_coverage": 0.99},
                   caps=PricingCapabilities(contract_prices=True))
    assert rec["price_basis"] == "contract"
    assert rec["monthly_savings_contract_usd"] == round(rec["monthly_savings_usd"] * 0.8, 2)
    assert rec["monthly_savings_contract_low_usd"] <= rec["monthly_savings_contract_usd"]
    ev = json.loads(rec["evidence"])
    assert ev["effective_discount"] == 0.2
    assert "contract rates" in ev["data_basis"]
    assert "proportionally lower" not in ev["data_basis"]  # list-only disclaimer skipped


def test_coverage_gate_falls_back_to_list():
    [rec] = _score({**_ROW, "contract_ratio": 0.8, "contract_price_coverage": 0.90},
                   caps=PricingCapabilities(contract_prices=True))
    assert rec["price_basis"] == "list"
    assert rec["contract_price_coverage"] == 0.9
    assert rec["monthly_savings_contract_usd"] is None
    # ...and the engine-wide threshold moves the gate.
    [rec] = _score({**_ROW, "contract_ratio": 0.8, "contract_price_coverage": 0.90},
                   caps=PricingCapabilities(contract_prices=True), contract_min_coverage=0.85)
    assert rec["price_basis"] == "contract"


def test_ranking_stays_on_list_basis():
    """D2: nba_score must not move when contract pricing turns on."""
    [off] = _score(_ROW)
    [on] = _score({**_ROW, "contract_ratio": 0.5, "contract_price_coverage": 1.0},
                  caps=PricingCapabilities(contract_prices=True))
    assert on["nba_score"] == off["nba_score"]
    assert on["monthly_savings_usd"] == off["monthly_savings_usd"]


def test_probe_capabilities_degrades_and_is_off_in_central():
    def boom(_sql):
        raise RuntimeError("TABLE_OR_VIEW_NOT_FOUND")

    assert probe_capabilities(boom, "system", "USD", 30) == PricingCapabilities.off()
    assert probe_capabilities(lambda s: [(1,)], "system", "USD", 30) == PricingCapabilities(True, True)
    assert probe_capabilities(lambda s: [], "system", "USD", 30) == PricingCapabilities.off()
    called = []
    assert probe_capabilities(lambda s: called.append(s) or [(1,)], "system", "USD", 30,
                              central=True) == PricingCapabilities.off()
    assert called == []


def test_spend_sql_always_emits_pricing_columns():
    off = workspace_spend_sql(TableResolver.nested("system"), 30, "USD")
    assert "account_prices" not in off and "cloud_infra_cost" not in off
    for col in ("total_spend_contract_usd", "contract_priced_share", "total_cloud_cost_usd"):
        assert f"AS {col}" in off
    on = workspace_spend_sql(TableResolver.nested("system"), 30, "USD",
                             contract_prices=True, cloud_costs=True)
    assert "system.billing.account_prices ap" in on
    assert "system.billing.cloud_infra_cost ci" in on
    central = workspace_spend_sql(TableResolver.central_for(["a1"]), 30, "USD",
                                  contract_prices=True, cloud_costs=True)
    assert "account_prices" not in central and "cloud_infra_cost" not in central


def _rec(**kw) -> Recommendation:
    base = dict(
        recommendation_id="r", snapshot_date=date(2026, 9, 23), rule_id="x", rule_version="1",
        rule_title="t", category="compute", workspace_id="1", resource_type="cluster",
        resource_id="c", resource_name="n", why="w", how="h", monthly_waste_usd=10,
        monthly_savings_usd=100.0, effort_band="low", effort_score=2, priority="HIGH",
        nba_score=1.0, computed_at="2026-09-23T00:00:00Z",
    )
    return Recommendation(**{**base, **kw})


def test_pricing_summary_states():
    none = pricing_summary([_rec(), _rec()])
    assert not none.contract_available and none.default_basis == "list"
    assert none.contract_coverage_account is None and not none.cloud_available

    full = pricing_summary([_rec(price_basis="contract", monthly_savings_contract_usd=78.0)] * 3)
    assert full.contract_available and full.contract_coverage_account == 1.0
    assert full.default_basis == "contract"

    partial = pricing_summary([
        _rec(price_basis="contract", monthly_savings_contract_usd=78.0),
        _rec(price_basis="list", monthly_savings_usd=50.0, cloud_cost_30d_usd=40.0),
    ])
    assert partial.contract_findings == 1 and partial.list_fallback_findings == 1
    assert partial.contract_coverage_account == round(100 / 150, 4)
    assert partial.default_basis == "list" and partial.cloud_available
    # The spend snapshot's account share wins over the findings-derived one.
    assert pricing_summary([_rec(price_basis="list")], spend_contract_share=0.97).default_basis == "contract"


def test_old_snapshot_without_pricing_columns_still_reads(monkeypatch):
    """GH #108: a table written before the pricing columns existed must still load."""
    monkeypatch.setattr(pre_mod, "_TABLE_COLUMNS", {})
    row = tuple({
        "recommendation_id": "r", "snapshot_date": date(2026, 9, 1), "rule_id": "x",
        "rule_version": "1", "rule_title": "t", "category": "compute", "workspace_id": "1",
        "workspace_name": None, "workspace_url": None, "resource_type": "cluster",
        "resource_id": "c", "resource_name": "n", "resource_owner": None,
        "resource_creator": None, "why": "w", "how": "h", "monthly_waste_usd": 1.0,
        "monthly_savings_usd": 2.0, "monthly_savings_low_usd": 2.0,
        "monthly_savings_high_usd": 2.0, "savings_status": "bookable", "effort_band": "low",
        "effort_score": 2, "priority": "LOW", "nba_score": 1.0, "evidence": "{}",
        "computed_at": "2026-09-01T00:00:00Z",
    }[c] for c in _COLUMNS)
    src = PrecomputeRecommendationSource(Settings(compute_mode="precompute"),
                                         fake_connect(_COLUMNS, [row]))
    [rec] = src.fetch(Scope(all_workspaces=True))
    assert rec.price_basis is None and rec.monthly_savings_contract_usd is None
