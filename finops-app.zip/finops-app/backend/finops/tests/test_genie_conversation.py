"""The context-aware Genie chat proxy (services/genie_conversation).

These assertions protect the two things that make the API path worth having over
the iframe:

* the page's context is woven into the prompt (so "why is this idle?" resolves to
  the actual resource) — and it only ever ADDS to the user's words, never replaces;
* a Genie/network failure comes back as a stated error, never an exception that
  would 500 the page.

The Conversation REST calls are stubbed, so this runs with no workspace.
"""

from __future__ import annotations

import finops.services.genie_conversation as gc
from finops.config import Settings
from finops.models import GenieAskRequest
from finops.services.genie_conversation import GenieConversationClient

API_SETTINGS = Settings(
    genie_enabled=True, genie_mode="api", genie_space_id="space123",
    server_hostname="host.example.com", databricks_token="tok",
)


class _FakeResp:
    def __init__(self, payload):
        self._payload = payload
        self.content = b"{}"

    def raise_for_status(self):
        pass

    def json(self):
        return self._payload


def _stub_requests(monkeypatch, script):
    """Route requests.request(method, url, ...) through a list of (matcher, payload).

    Each call pops the first matching entry; matcher is a substring of the URL."""
    calls = []

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        for i, (needle, payload) in enumerate(script):
            if needle in url:
                script.pop(i)
                return _FakeResp(payload)
        raise AssertionError(f"unexpected request: {method} {url}")

    import requests

    monkeypatch.setattr(requests, "request", fake_request)
    return calls


def test_contextualize_prepends_resource_and_keeps_question():
    c = GenieConversationClient(API_SETTINGS)
    req = GenieAskRequest(
        question="why is this idle?", resource_type="warehouse", resource_id="w1",
        resource_name="ETL", workspace_name="Prod",
    )
    prompt = c._contextualize(req)
    assert "why is this idle?" in prompt  # user's words survive verbatim
    assert "warehouse" in prompt and "ETL" in prompt and "Prod" in prompt


def test_contextualize_passthrough_when_no_context():
    c = GenieConversationClient(API_SETTINGS)
    assert c._contextualize(GenieAskRequest(question="account wide?")) == "account wide?"


def test_ask_start_poll_answer(monkeypatch):
    monkeypatch.setattr(gc.time, "sleep", lambda *_: None)  # no real waiting
    script = [
        ("start-conversation", {"conversation_id": "cid", "message_id": "mid"}),
        # first poll still working, second completed with a text attachment
        ("messages/mid", {"status": "ASKING_AI"}),
        ("messages/mid", {
            "status": "COMPLETED",
            "attachments": [{"text": {"content": "It billed 30 days, served 2 requests."}}],
        }),
    ]
    _stub_requests(monkeypatch, script)
    c = GenieConversationClient(API_SETTINGS)
    out = c.ask(GenieAskRequest(question="why idle?"), user_token="utok")
    assert out.error is None
    assert out.conversation_id == "cid"
    assert "served 2 requests" in out.text


def test_ask_uses_conversation_id_for_followup(monkeypatch):
    monkeypatch.setattr(gc.time, "sleep", lambda *_: None)
    script = [
        ("conversations/existing/messages", {"conversation_id": "existing", "message_id": "m2"}),
        ("messages/m2", {"status": "COMPLETED", "content": "ok"}),
    ]
    calls = _stub_requests(monkeypatch, script)
    c = GenieConversationClient(API_SETTINGS)
    out = c.ask(GenieAskRequest(question="and the other one?", conversation_id="existing"), "utok")
    assert out.conversation_id == "existing"
    # The follow-up must post to the existing conversation, not start a new one.
    assert any("conversations/existing/messages" in url for _, url, _ in calls)
    assert not any("start-conversation" in url for _, url, _ in calls)


def test_ask_failure_returns_error_not_exception(monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("network down")

    import requests

    monkeypatch.setattr(requests, "request", boom)
    c = GenieConversationClient(API_SETTINGS)
    out = c.ask(GenieAskRequest(question="anything"), "utok")
    assert out.error is not None  # stated, not raised
    assert out.text == ""


def test_ask_timeout_is_reported(monkeypatch):
    monkeypatch.setattr(gc.time, "sleep", lambda *_: None)
    # monotonic: 0 when the deadline is computed, then far past it on the first
    # loop check, so the poll loop exits immediately as a timeout without ever GETing.
    ticks = iter([0, 10**9, 10**9])
    monkeypatch.setattr(gc.time, "monotonic", lambda: next(ticks))
    script = [("start-conversation", {"conversation_id": "cid", "message_id": "mid"})]
    _stub_requests(monkeypatch, script)
    c = GenieConversationClient(API_SETTINGS)
    out = c.ask(GenieAskRequest(question="slow?"), "utok")
    assert out.error is not None and "too long" in out.error.lower()


def test_unconfigured_space_returns_error():
    c = GenieConversationClient(Settings(genie_enabled=True, genie_mode="api"))
    out = c.ask(GenieAskRequest(question="x"), None)
    assert out.error is not None


# --- config: which transport does the app expose? ----------------------------
def test_space_id_resolved_from_url():
    s = Settings(genie_space_url="https://h/embed/genie/rooms/abc123?x=1")
    assert s.genie_space_id_resolved == "abc123"


def test_space_id_explicit_wins_over_url():
    s = Settings(genie_space_id="explicit", genie_space_url="https://h/embed/genie/rooms/other")
    assert s.genie_space_id_resolved == "explicit"


def test_api_mode_on_with_space_id():
    s = Settings(genie_enabled=True, genie_mode="api", genie_space_id="s1")
    assert s.genie_use_api is True
    assert s.genie_panel_enabled is True


def test_api_mode_without_space_id_degrades_off():
    # api mode but no resolvable space id and no embed url -> panel off entirely.
    s = Settings(genie_enabled=True, genie_mode="api")
    assert s.genie_use_api is False
    assert s.genie_panel_enabled is False


def test_iframe_mode_unaffected_by_api_props():
    s = Settings(genie_enabled=True, genie_space_id="k", server_hostname="h")
    assert s.genie_use_api is False
    assert s.genie_panel_enabled is True
    assert s.genie_embed_url.endswith("/embed/genie/rooms/k")


def test_disabled_stays_off_in_both_modes():
    assert Settings(genie_enabled=False, genie_mode="api", genie_space_id="s").genie_panel_enabled is False
