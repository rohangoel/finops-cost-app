from __future__ import annotations

from datetime import date

from finops.services.nba_ranker import build_recommendation, compute_nba, recommendation_id
from finops_rules import EffortBand, Rule, RuleContext, RuleFinding, RulePriority


class _DummyRule(Rule):
    id = "dummy"
    version = "1.0.0"
    title = "Dummy"
    resource_type = "cluster"
    category = "compute"

    def score(self, row, ctx: RuleContext):  # pragma: no cover - unused
        return None


def _finding(savings=1000.0, effort=EffortBand.TRIVIAL, priority=RulePriority.HIGH):
    return RuleFinding(
        workspace_id="111",
        resource_type="cluster",
        resource_id="c-1",
        resource_name="c-1",
        monthly_waste_usd=savings,
        monthly_savings_usd=savings,
        effort=effort,
        priority=priority,
        why="w",
        how="h",
    )


def test_nba_rewards_low_effort_high_priority():
    # $1000 trivial(1) HIGH(x1.25) beats $1000 medium(3) MEDIUM(x1.0)
    assert compute_nba(1000, 1, "HIGH") > compute_nba(1000, 3, "MEDIUM")


def test_build_recommendation_populates_contract():
    rec = build_recommendation(_DummyRule(), _finding(), snapshot=date(2026, 7, 1))
    assert rec.rule_id == "dummy"
    assert rec.effort_score == 1
    assert rec.priority == "HIGH"
    assert rec.nba_score == compute_nba(1000, 1, "HIGH")
    assert rec.snapshot_date == date(2026, 7, 1)


def test_build_recommendation_carries_workspace_deep_link_host():
    # The resource's own workspace URL must travel with the recommendation so the
    # UI can deep-link to the correct workspace host (the account spans many).
    rec = build_recommendation(
        _DummyRule(),
        _finding(),
        snapshot=date(2026, 7, 1),
        workspace_name="prod-analytics",
        workspace_url="https://fe-vm-prod-analytics.cloud.databricks.com",
    )
    assert rec.workspace_name == "prod-analytics"
    assert rec.workspace_url == "https://fe-vm-prod-analytics.cloud.databricks.com"
    # Absent (legacy rows) stays None so the UI can fall back.
    assert build_recommendation(_DummyRule(), _finding()).workspace_url is None


def test_savings_status_defaults_to_bookable_and_bounds_to_point():
    # Phase 0 scaffold: a rule that declares nothing and a finding that sets no
    # bounds must be byte-compatible with pre-scaffold behavior — bookable, and
    # low == point == high.
    rec = build_recommendation(_DummyRule(), _finding(savings=1000.0))
    assert rec.savings_status == "bookable"
    assert rec.monthly_savings_low_usd == 1000.0
    assert rec.monthly_savings_high_usd == 1000.0


def test_rule_default_savings_status_is_honored():
    class _Advisory(_DummyRule):
        default_savings_status = "advisory"

    assert build_recommendation(_Advisory(), _finding()).savings_status == "advisory"


def test_finding_status_and_bounds_override_rule_default():
    class _Advisory(_DummyRule):
        default_savings_status = "advisory"

    f = _finding(savings=1000.0)
    f.savings_status = "bookable"  # a per-finding tier wins over the rule default
    f.monthly_savings_low_usd = 600.0
    f.monthly_savings_high_usd = 1500.0
    rec = build_recommendation(_Advisory(), f)
    assert rec.savings_status == "bookable"
    assert rec.monthly_savings_low_usd == 600.0
    assert rec.monthly_savings_high_usd == 1500.0


def test_recommendation_id_is_deterministic():
    a = recommendation_id("r", "111", "c-1", date(2026, 7, 1))
    b = recommendation_id("r", "111", "c-1", date(2026, 7, 1))
    c = recommendation_id("r", "111", "c-2", date(2026, 7, 1))
    assert a == b and a != c
