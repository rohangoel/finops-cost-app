"""Coverage for recommendation archetypes that the UI demo must explain."""

from finops.config import Settings
from finops.data.demo_source import DemoRecommendationSource
from finops.identity import Scope


def test_continuous_pipeline_demo_has_measured_reasoning_and_chart():
    source = DemoRecommendationSource(Settings(compute_mode="demo"), None)
    recommendations = [
        rec
        for rec in source.load(Scope(all_workspaces=True))
        if rec.rule_id == "continuous_pipeline"
    ]

    assert recommendations
    for rec in recommendations:
        evidence = rec.evidence
        assert evidence["billed_hours"] > evidence["active_hours"]
        assert evidence["idle_hours"] > 0
        assert evidence["updates_30d"] > 0
        assert evidence["avg_update_minutes"] > 0
        assert evidence["viz"]["kind"] == "hour_heatmap"
        assert evidence["viz"]["context"] == "pipeline"
        assert len(evidence["viz"]["grid"]) == 30
        assert "billed idle hours" in rec.why
        assert "—" not in rec.why
        assert "–" not in rec.why


# The rules promoted out of Labs (2026-09-23): demo findings are the real rule
# scoring a synthetic candidate row (data/demo_rule_rows.py), so they carry the
# production status, copy and chart.
_PROMOTED_CHARTS = {
    "warehouse_keepalive_queries": "hour_heatmap",
    "warehouse_min_clusters": "daily_stack",
    "alert_hygiene": "daily_stack",
    "job_no_new_input": "daily_stack",
    "job_task_retry_waste": "daily_stack",
    "serving_provisioned_overcapacity": "serving_traffic",
    "unpruned_repeated_queries": "ranked_bars",
    "unviewed_scheduled_dashboards": "daily_stack",
    "pipeline_failed_updates": "pipeline_failures",
    "sql_repeated_failures": "sql_failures",
    "instance_pool_idle": "instance_pool",
}


def _demo_recs():
    return DemoRecommendationSource(Settings(compute_mode="demo"), None).load(
        Scope(all_workspaces=True))


def test_promoted_rules_have_demo_findings_with_their_chart():
    recs = _demo_recs()
    for rule_id, kind in _PROMOTED_CHARTS.items():
        mine = [r for r in recs if r.rule_id == rule_id]
        assert mine, rule_id
        for r in mine:
            assert r.evidence["viz"]["kind"] == kind, rule_id
    keepalive = next(r for r in recs if r.rule_id == "warehouse_keepalive_queries")
    assert keepalive.evidence["viz"]["context"] == "keepalive"


def test_new_advisory_rules_show_no_saving_in_demo():
    # These rules' advisory findings are $0 in production (their dollars are spend,
    # not a saving). Some older rules deliberately show an unbooked advisory figure,
    # so this is pinned per rule, not for every advisory finding.
    new_rules = set(_PROMOTED_CHARTS) | {
        "job_runaway_no_timeout", "pipeline_full_refresh_churn",
        "allpurpose_shape_mismatch", "instance_generation_modernize",
    }
    for r in _demo_recs():
        if r.rule_id in new_rules and r.savings_status == "advisory":
            assert r.monthly_savings_usd == 0.0, r.rule_id
        if r.rule_id == "instance_generation_modernize":
            assert r.monthly_waste_usd == 0.0
