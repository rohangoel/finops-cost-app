"""Central-mode scoping shared by the spend / genie / apps live readers.

Pins two things: (1) ``CentralScope`` resolves the account_id set, the workspace
scope subquery and a central ``TableResolver`` correctly, and (2) the genie/apps
SQL builders actually switch to the central layout when handed a central resolver
(and stay byte-for-byte nested otherwise, so the SDP pipeline is untouched).
"""

from __future__ import annotations

from finops_rules.resolver import CENTRAL_NAMESPACE, TableResolver

from finops.config import Settings
from finops.data.account_view import AccountView
from finops.data.apps_sql import apps_daily_sql
from finops.data.central_scope import CentralScope
from finops.data.genie_sql import genie_user_sql


def _scope(settings=None, rows=None):
    """A CentralScope whose query() returns canned rows (the account_id lookup)."""
    calls: list[str] = []

    def query(sql: str) -> list[dict]:
        calls.append(sql)
        return rows if rows is not None else []

    settings = settings or Settings(central_mode=True, central_namespace="main.slice_ns")
    cs = CentralScope(settings, query)
    cs.calls = calls  # type: ignore[attr-defined]
    return cs


def test_account_ids_uses_explicit_databricks_account_id_without_a_query():
    cs = _scope()
    ids = cs.account_ids(AccountView(databricks_account_id="acc-123"))
    assert ids == ["acc-123"]
    assert cs.calls == []  # no lookup needed


def test_account_ids_maps_salesforce_name_via_the_workspace_directory():
    cs = _scope(rows=[{"account_id": "a1"}, {"account_id": "a2"}, {"account_id": None}])
    ids = cs.account_ids(AccountView(salesforce_account_name="Bayer AG - Global HQ"))
    assert ids == ["a1", "a2"]  # the NULL row is dropped
    assert "workspaces_latest" in cs.calls[0]
    assert "Bayer AG - Global HQ" in cs.calls[0]


def test_account_ids_empty_when_nothing_selected():
    assert _scope().account_ids(AccountView()) == []


def test_workspace_scope_sql_builds_a_scoped_subquery_and_is_none_when_unselected():
    cs = _scope()
    sql = cs.workspace_scope_sql(
        AccountView(salesforce_account_name="Bayer AG - Global HQ", cloud_type="azure")
    )
    assert sql is not None
    assert "salesforce_account_name = 'Bayer AG - Global HQ'" in sql
    assert "cloud_type = 'azure'" in sql
    assert cs.workspace_scope_sql(AccountView()) is None


def test_workspaces_dir_prefers_a_configured_slice_namespace():
    slice_cs = _scope(Settings(central_mode=True, central_namespace="main.slice_ns"))
    assert slice_cs._workspaces_dir() == "main.slice_ns.workspaces_latest"
    full_cs = _scope(Settings(central_mode=True, central_namespace=CENTRAL_NAMESPACE))
    # Full central falls back to the certified directory (no per-slice copy).
    assert full_cs._workspaces_dir() == "main.certified.workspaces_latest"


def test_resolver_is_none_without_account_ids_else_central():
    assert _scope().resolver(AccountView()) is None
    cs = _scope(rows=[{"account_id": "a1"}])
    r = cs.resolver(AccountView(salesforce_account_name="X"))
    assert r is not None and r.central and r.account_ids == ("a1",)


# --- SQL builders switch layout on the resolver ----------------------------

def test_genie_sql_uses_central_layout_with_a_central_resolver():
    r = TableResolver.central_for(["a1"], namespace="main.slice_ns")
    sql = genie_user_sql(resolver=r, workspace_scope_sql="SELECT workspace_id FROM d")
    # Reads the flat central billing table, scoped to the account and its workspaces.
    assert "main.slice_ns.billing_usage" in sql
    assert "u.workspace_id IN (SELECT workspace_id FROM d)" in sql
    # Not the nested system layout, and no region filter (that is nested-only).
    assert "system.billing.usage" not in sql
    assert "workspaces_latest" not in sql.replace("SELECT workspace_id FROM d", "")


def test_apps_sql_stays_byte_for_byte_nested_by_default():
    """The default (no resolver) path must be unchanged so the SDP pipeline and its
    golden tests keep producing the identical query."""
    default = apps_daily_sql("system", 30, "USD")
    explicit = apps_daily_sql("system", 30, "USD", resolver=None, workspace_scope_sql=None)
    assert default == explicit
    assert "system.billing.usage" in default


# --- honest markers for the sections central data can't fill ----------------

def test_genie_central_mode_drops_the_unknown_leaderboard_and_says_so():
    """Central billing rows carry no run_as identity, so the per-user leaderboard
    would be a single meaningless 'unknown' row. It is dropped and a note explains
    why; the rest of the tab is untouched."""
    from finops.data.genie_source import GenieSource
    from finops.identity import Scope

    src = GenieSource(
        Settings(compute_mode="precompute", central_mode=True, central_namespace="main.slice_ns"),
        lambda: None,
    )
    src._from_snapshot = lambda scope: None
    src._from_live = lambda scope, account_view=None: (
        {
            "user": [
                {
                    "workspace_id": "1", "principal": "unknown", "free_dbus": 0.0,
                    "paid_dbus": 5.0, "spend_usd": 100.0, "active_days": 3,
                    "by_surface": "[]", "last_active_date": "2026-09-01",
                }
            ],
            "surface": [], "space": [], "daily": [],
        },
        30,
    )
    costs = src.genie_costs(Scope(all_workspaces=True), AccountView(salesforce_account_name="X"))
    assert costs.top_users == []
    assert "per-user spender leaderboard is not available" in costs.central_note


def test_apps_central_mode_notes_the_missing_lifecycle():
    from finops.data.apps_source import AppsSource
    from finops.identity import Scope

    src = AppsSource(
        Settings(compute_mode="precompute", central_mode=True, central_namespace="main.slice_ns"),
        lambda: None,
    )
    src._from_snapshot = lambda scope: None
    src._from_live = lambda scope, account_view=None: (
        {
            "inventory": [
                {
                    "workspace_id": "1", "app_id": "a", "app_name": "app", "compute_size": "MEDIUM",
                    "spend_usd": 100.0, "monthly_spend_usd": 100.0, "dbus": 10.0, "days_billed": 30,
                    "observed_days": 30, "size_changes": 0,
                }
            ],
            "size": [], "daily": [],
        },
        30,
    )
    inv = src.apps_inventory(Scope(all_workspaces=True), AccountView(salesforce_account_name="X"))
    assert "lifecycle history" in inv.lifecycle_note.lower()
