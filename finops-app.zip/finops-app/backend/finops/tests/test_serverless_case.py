"""The About Serverless case builder.

The load-bearing property is that dollars are de-duplicated PER RESOURCE. A single
oversized cluster is routinely flagged by three rules; summing them would produce a
headline number that overstates the opportunity, which is exactly the credibility
problem this app exists to avoid.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from finops.models import Recommendation
from finops.models.spend import AccountSpend
from finops.services import serverless_case


def _rec(rule: str, savings: float, resource: str, ws: str = "111") -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule}-{resource}",
        snapshot_date=date(2026, 8, 4),
        rule_id=rule,
        rule_version="1.0.0",
        rule_title=rule.replace("_", " ").title(),
        category="compute",
        workspace_id=ws,
        workspace_name=f"ws-{ws}",
        resource_type="cluster",
        resource_id=resource,
        resource_name=resource,
        why=f"Cluster '{resource}' averaged 6% CPU across 8 workers. More detail here.",
        how="do this",
        monthly_waste_usd=savings * 3,
        monthly_savings_usd=savings,
        effort_band="medium",
        effort_score=3,
        priority="MEDIUM",
        nba_score=savings / 3,
        evidence={},
        computed_at=datetime(2026, 8, 4, tzinfo=timezone.utc),
    )


def test_groups_rules_into_issue_categories():
    case = serverless_case.build_case([
        _rec("rightsize_underutilized", 300.0, "c-1"),
        _rec("cluster_autotermination", 200.0, "c-2"),
        _rec("spot_fallback", 100.0, "c-3"),
    ])
    keys = {i.key for i in case.issues}
    assert keys == {"cluster_sizing", "idle_compute", "capacity_risk"}
    # Ordered by savings so the biggest lever is read first.
    assert [i.key for i in case.issues][0] == "cluster_sizing"


def test_savings_are_deduplicated_per_resource_within_an_issue():
    # Both rules land in the "idle_compute" bucket on the SAME cluster: the issue
    # must count the best option once (250), not the sum (400).
    case = serverless_case.build_case([
        _rec("cluster_autotermination", 250.0, "c-1"),
        _rec("idle_zombie_clusters", 150.0, "c-1"),
    ])
    issue = next(i for i in case.issues if i.key == "idle_compute")
    assert issue.monthly_savings_usd == 250.0
    assert issue.resource_count == 1


def test_headline_total_counts_each_resource_once_across_issues():
    # One cluster flagged by rules in two DIFFERENT issue categories. Each issue
    # legitimately reports it, but the headline must not double-count.
    case = serverless_case.build_case([
        _rec("rightsize_underutilized", 400.0, "c-1"),   # cluster_sizing
        _rec("cluster_autotermination", 300.0, "c-1"),   # idle_compute
        _rec("spot_fallback", 100.0, "c-2"),             # capacity_risk
    ])
    sum_of_issues = sum(i.monthly_savings_usd for i in case.issues)
    assert sum_of_issues == 800.0  # 400 + 300 + 100, per-issue view
    # ...but the headline de-duplicates c-1 to its best option: 400 + 100.
    assert case.total_monthly_savings_usd == 500.0
    assert case.affected_resource_count == 2


def test_includes_hidden_rule_evidence():
    # enable_photon_dbr is hidden from the recommendation GUI but is the evidence
    # for the runtime-upkeep argument, so it must appear here.
    case = serverless_case.build_case([_rec("enable_photon_dbr", 700.0, "c-1")])
    issue = next(i for i in case.issues if i.key == "runtime_upkeep")
    assert issue.monthly_savings_usd == 700.0
    # And it says out loud that the figure is indicative, not measured.
    assert "estimated" in issue.evidence_note or "indicative" in issue.evidence_note


def test_empty_issues_are_omitted_not_shown_as_zero():
    case = serverless_case.build_case([_rec("spot_fallback", 50.0, "c-1")])
    assert [i.key for i in case.issues] == ["capacity_risk"]


def test_examples_are_capped_and_ranked_with_deep_links():
    recs = [_rec("rightsize_underutilized", float(i * 10), f"c-{i}") for i in range(1, 9)]
    case = serverless_case.build_case(recs)
    issue = case.issues[0]
    assert issue.resource_count == 8
    assert len(issue.examples) == 5  # capped: concrete, not a second table
    savings = [e.monthly_savings_usd for e in issue.examples]
    assert savings == sorted(savings, reverse=True)
    assert all(e.group_id for e in issue.examples)  # links to the resource page


def test_readiness_reports_serverless_share_of_spend():
    spend = AccountSpend(
        total_monthly_spend_usd=1000.0,
        total_serverless_spend_usd=250.0,
        total_classic_spend_usd=750.0,
        workspace_count=1,
    )
    case = serverless_case.build_case([_rec("spot_fallback", 10.0, "c-1")], spend=spend)
    assert case.readiness.spend_available is True
    assert case.readiness.serverless_share == 0.25


def test_readiness_flags_missing_spend_rather_than_implying_zero():
    case = serverless_case.build_case(
        [_rec("spot_fallback", 10.0, "c-1")],
        spend=AccountSpend(unavailable=True),
    )
    assert case.readiness.spend_available is False
    assert case.readiness.serverless_share == 0.0


def test_workspace_count_spans_the_affected_estate():
    case = serverless_case.build_case([
        _rec("spot_fallback", 10.0, "c-1", ws="111"),
        _rec("spot_fallback", 20.0, "c-2", ws="222"),
    ])
    assert case.workspace_count == 2
