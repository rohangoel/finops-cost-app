"""The optional ``?workspace_id=`` view filter behind the global workspace switcher.

``get_view_scope`` is what makes one workspace selection in the UI apply to every
account-wide view at once (recommendations, overview, spend, Genie, Apps) instead
of only the two pages that have a ``/workspaces/{id}/...`` route. It narrows the
caller's server-derived scope, so the invariant is the same as ``Scope.narrowed_to``:
narrowing only ever REMOVES access, and a bad/blank value falls back to full scope
rather than 400-ing an otherwise valid page.
"""

from __future__ import annotations

from starlette.datastructures import QueryParams

from finops.deps import get_view_scope
from finops.identity import Scope


class _Req:
    """Minimal stand-in for the parts of starlette.Request get_view_scope reads."""

    def __init__(self, query: str = ""):
        self.query_params = QueryParams(query)


def test_absent_workspace_id_leaves_scope_untouched():
    admin = Scope(all_workspaces=True, workspace_ids=[])
    assert get_view_scope(_Req(""), admin) is admin


def test_blank_workspace_id_leaves_scope_untouched():
    admin = Scope(all_workspaces=True, workspace_ids=[])
    assert get_view_scope(_Req("workspace_id="), admin) is admin


def test_admin_narrows_to_the_named_workspace():
    admin = Scope(all_workspaces=True, workspace_ids=[])
    narrowed = get_view_scope(_Req("workspace_id=123"), admin)
    assert narrowed.all_workspaces is False
    assert narrowed.workspace_ids == ["123"]


def test_workspace_admin_naming_an_unowned_workspace_gets_empty_scope():
    # narrowing only removes access: asking for a workspace you don't own yields
    # an empty scope (no rows), never someone else's data.
    wsadmin = Scope(all_workspaces=False, workspace_ids=["111", "222"])
    narrowed = get_view_scope(_Req("workspace_id=999"), wsadmin)
    assert narrowed.all_workspaces is False
    assert narrowed.workspace_ids == []


def test_workspace_admin_naming_an_owned_workspace_narrows_to_it():
    wsadmin = Scope(all_workspaces=False, workspace_ids=["111", "222"])
    narrowed = get_view_scope(_Req("workspace_id=222"), wsadmin)
    assert narrowed.workspace_ids == ["222"]


def test_malformed_workspace_id_falls_back_to_full_scope():
    # Unlike the /{workspace_id} path endpoints (which 400), this is an optional
    # view filter: a non-numeric value should degrade to the full scope, not error.
    admin = Scope(all_workspaces=True, workspace_ids=[])
    assert get_view_scope(_Req("workspace_id=not-a-number"), admin) is admin
