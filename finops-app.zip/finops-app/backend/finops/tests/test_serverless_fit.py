"""Tests for the per-resource serverless-fit verdict (services/serverless_fit.py).

The invariant under test: a projected dollar figure appears ONLY when a real
finding measured one. "not_a_fit" and "cannot_estimate" must never carry a number.
"""

from __future__ import annotations

from datetime import date, datetime

from finops.models import Recommendation
from finops.services.serverless_fit import evaluate


def _rec(rule_id: str, *, resource_type: str = "warehouse", resource_id: str = "wh-1",
         savings: float = 0.0, evidence: dict | None = None) -> Recommendation:
    return Recommendation(
        recommendation_id=f"{rule_id}-{resource_id}",
        snapshot_date=date(2026, 8, 12),
        rule_id=rule_id,
        rule_version="1.0.0",
        rule_title=rule_id,
        category="sql",
        workspace_id="111",
        resource_type=resource_type,
        resource_id=resource_id,
        resource_name="test-resource",
        why="why",
        how="how",
        monthly_waste_usd=100.0,
        monthly_savings_usd=savings,
        effort_band="low",
        effort_score=2,
        priority="MEDIUM",
        nba_score=1.0,
        evidence=evidence or {},
        computed_at=datetime(2026, 8, 12, 0, 0, 0),
    )


# --- warehouses -------------------------------------------------------------

def test_warehouse_recommended_when_enable_serverless_fired():
    fit = evaluate("warehouse", [
        _rec("enable_serverless", savings=420.0, evidence={"idle_hours_pct": 63.0}),
    ])
    assert fit is not None
    assert fit.verdict == "recommended"
    # projection is the measured finding's saving, and a deep link is provided
    assert fit.projected_monthly_savings_usd == 420.0
    assert fit.group_id is not None
    assert "63%" in fit.reason


def test_warehouse_not_a_fit_when_classic_but_no_serverless_finding():
    # A classic warehouse that only matched size/scale-out => enable_serverless
    # was evaluated and didn't clear the bar. No number.
    fit = evaluate("warehouse", [
        _rec("warehouse_rightsize", savings=200.0, evidence={"warehouse_type": "PRO"}),
    ])
    assert fit is not None
    assert fit.verdict == "not_a_fit"
    assert fit.projected_monthly_savings_usd is None


def test_warehouse_already_serverless_from_type():
    fit = evaluate("warehouse", [
        _rec("warehouse_scale_out", evidence={"warehouse_type": "SERVERLESS"}),
    ])
    assert fit is not None
    assert fit.verdict == "already_serverless"
    assert fit.projected_monthly_savings_usd is None


def test_warehouse_already_serverless_from_serverless_only_rule():
    fit = evaluate("warehouse", [
        _rec("warehouse_autostop_serverless", savings=30.0),
    ])
    assert fit is not None
    assert fit.verdict == "already_serverless"
    assert "auto-stop" in fit.reason
    # An already-serverless verdict never projects a serverless-migration number.
    assert fit.projected_monthly_savings_usd is None


def test_warehouse_cannot_estimate_without_type_signal():
    # Only size/scale-out fired AND neither carried warehouse_type.
    fit = evaluate("warehouse", [_rec("warehouse_rightsize", savings=200.0)])
    assert fit is not None
    assert fit.verdict == "cannot_estimate"
    assert fit.projected_monthly_savings_usd is None


# --- jobs -------------------------------------------------------------------

def test_job_recommended_cost_optimized():
    fit = evaluate("job", [
        _rec("serverless_cost_optimized", resource_type="job", resource_id="j-1", savings=88.0),
    ])
    assert fit is not None
    assert fit.verdict == "recommended"
    assert fit.projected_monthly_savings_usd == 88.0
    assert fit.group_id is not None


def test_job_interactive_to_job_is_honest_unknown():
    # Serverless jobs are a candidate, but we haven't modeled the serverless-rate
    # projection for this path — so no number, explicitly.
    fit = evaluate("job", [
        _rec("interactive_to_job", resource_type="job", resource_id="j-2", savings=500.0),
    ])
    assert fit is not None
    assert fit.verdict == "cannot_estimate"
    assert fit.projected_monthly_savings_usd is None


def test_job_reliability_only_cannot_estimate():
    fit = evaluate("job", [
        _rec("failing_jobs", resource_type="job", resource_id="j-3", savings=40.0),
    ])
    assert fit is not None
    assert fit.verdict == "cannot_estimate"
    assert fit.projected_monthly_savings_usd is None


# --- clusters ----------------------------------------------------------------

def test_cluster_idle_points_to_autostop_no_projection():
    # An idle/abandoned all-purpose cluster: serverless isn't a warehouse-style
    # toggle here — the lever is auto-stop. Explain that, invent no dollar figure.
    fit = evaluate("cluster", [
        _rec("cluster_autotermination", resource_type="cluster", resource_id="c-1", savings=300.0),
    ])
    assert fit is not None
    assert fit.verdict == "cannot_estimate"
    assert fit.projected_monthly_savings_usd is None
    assert "auto-stop" in fit.reason.lower()


def test_cluster_with_recurring_jobs_points_to_serverless_jobs():
    fit = evaluate("cluster", [
        _rec("interactive_to_job", resource_type="cluster", resource_id="c-2", savings=500.0),
    ])
    assert fit is not None
    assert fit.verdict == "cannot_estimate"
    assert fit.projected_monthly_savings_usd is None
    assert "serverless jobs" in fit.reason.lower()


# --- out of scope -----------------------------------------------------------

def test_empty_options_returns_none():
    assert evaluate("warehouse", []) is None
