"""Who a finding belongs to: the stable ``finding_key`` and the notify routing.

StopTheLeak (a separate project) emails resource owners about their findings and
collects a vote on each. It computes the same two things independently from this
table and checks every day that both agree, so the definitions here are a shared
contract (StopTheLeak ``docs/FINOPS_APP_CONTRACT.md`` §2). **Don't change them.**

* ``finding_key`` = ``sha256(rule_id|workspace_id|resource_type|resource_id)[:32]``,
  lowercase hex. Unlike ``recommendation_id`` it has no ``snapshot_date`` in it, so
  a link built from it still opens the finding after the nightly recompute. It is
  one per rule x resource; ``group_id`` is one per resource and doesn't say which
  rule.
* Routing: the object owner if it's a user (an email), else the workspace owner,
  else nobody. ``notify_recipient`` is lowercased so the comparison with the
  signed-in user's ``X-Forwarded-Email`` never depends on case.

The routing exists twice on purpose: :func:`route` (Python, used by live/demo mode
and the read path of an old snapshot) and :data:`ROUTING_SQL` (used by the pipeline,
where the object owner is only known after the Spark owner join). The SQL is kept
to portable ``CASE``/``LIKE``/``lower`` so ``test_routing.py`` can run it on SQLite
and check that it matches :func:`route` case for case.
"""

from __future__ import annotations

import hashlib
import re

OBJECT_OWNER = "object_owner"
WORKSPACE_OWNER = "workspace_owner"

USER = "user"
SERVICE_PRINCIPAL = "service_principal"
UNKNOWN = "unknown"

# A service principal shows up in identity_metadata as its application id, a UUID.
# Written as a LIKE pattern (``_`` = one character) rather than a regex so the SQL
# twin below runs unchanged on Spark, Postgres and SQLite.
_UUID_LIKE = "________-____-____-____-____________"
_UUID_RE = re.compile(r".{8}-.{4}-.{4}-.{4}-.{12}", re.DOTALL)


def finding_key(rule_id: str, workspace_id: str, resource_type: str, resource_id: str) -> str:
    """Snapshot-independent id of one rule's finding on one resource.

    Same value as StopTheLeak's
    ``substr(sha2(concat_ws('|', rule_id, workspace_id, resource_type, resource_id), 256), 1, 32)``.
    """
    raw = f"{rule_id}|{workspace_id}|{resource_type}|{resource_id}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def is_email(value: str | None) -> bool:
    """Same test as the SQL (``LIKE '%@%'``)."""
    return value is not None and "@" in value


def owner_kind(resource_owner: str | None) -> str:
    """``user`` | ``service_principal`` | ``unknown`` for a ``resource_owner`` value."""
    if is_email(resource_owner):
        return USER
    if resource_owner is not None and _UUID_RE.fullmatch(resource_owner):
        return SERVICE_PRINCIPAL
    return UNKNOWN


def route(
    resource_owner: str | None, workspace_owner: str | None
) -> tuple[str | None, str | None]:
    """``(notify_recipient, recipient_source)`` for a finding.

    The object owner if it's an email, else the workspace owner, else ``(None,
    None)``: the finding reaches nobody and isn't shown in anyone's My findings.
    """
    if is_email(resource_owner):
        return resource_owner.lower(), OBJECT_OWNER
    if workspace_owner:
        return workspace_owner.lower(), WORKSPACE_OWNER
    return None, None


#: The routing as SQL expressions over ``resource_owner`` and ``workspace_owner``,
#: keyed by output column. The pipeline applies these after the owner join.
ROUTING_SQL: dict[str, str] = {
    "resource_owner_kind": (
        "CASE WHEN resource_owner LIKE '%@%' THEN 'user' "
        f"WHEN resource_owner LIKE '{_UUID_LIKE}' THEN 'service_principal' "
        "ELSE 'unknown' END"
    ),
    "notify_recipient": (
        "CASE WHEN resource_owner LIKE '%@%' THEN lower(resource_owner) "
        "WHEN workspace_owner IS NOT NULL AND workspace_owner <> '' THEN lower(workspace_owner) "
        "END"
    ),
    "recipient_source": (
        "CASE WHEN resource_owner LIKE '%@%' THEN 'object_owner' "
        "WHEN workspace_owner IS NOT NULL AND workspace_owner <> '' THEN 'workspace_owner' "
        "END"
    ),
}
