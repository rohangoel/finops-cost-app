"""FastAPI application factory.

Serves the JSON API under ``/api`` and the built React SPA (Vite output in
``static/``) for everything else, with a catch-all so client-side routes deep
link correctly. ``/health`` is the Databricks Apps readiness gate.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .api import ROUTERS
from .config import get_settings
from .logging import configure_logging, get_logger

STATIC_DIR = Path(__file__).parent / "static"
INDEX_HTML = STATIC_DIR / "index.html"


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)
    log = get_logger("finops")
    log.info(
        "Starting FinOpsApp (compute_mode=%s, auth_mode=%s)",
        settings.compute_mode,
        settings.auth_mode,
    )

    app = FastAPI(title="FinOpsApp", version="0.5.0")
    for router in ROUTERS:
        app.include_router(router)

    @app.get("/health")
    def health() -> dict:
        return {"status": "healthy"}

    if STATIC_DIR.exists():
        # Serve hashed assets directly...
        app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")

        # ...and fall back to index.html for SPA client-side routes.
        @app.get("/{full_path:path}")
        def spa(full_path: str):
            candidate = STATIC_DIR / full_path
            if full_path and candidate.is_file():
                return FileResponse(candidate)
            if INDEX_HTML.exists():
                return FileResponse(INDEX_HTML)
            return JSONResponse({"detail": "Not found"}, status_code=404)
    else:
        # No SPA bundle (e.g. API-only deploy before `npm run build`): send the
        # root to the interactive API docs so the app is still usable.
        @app.get("/")
        def root():
            return RedirectResponse(url="/docs")

    return app


app = create_app()
