"""The "About Serverless" endpoint — the platform-admin case for moving.

Reads the recommendation source **before** the hidden-rule filter (via
``source.load``): the old-DBR findings are hidden from the recommendation GUI but
are precisely the evidence this page is built on. See
``services.serverless_case`` for the reasoning.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ..config import get_settings
from ..data import SpendSource
from ..data.fleet_source import FleetSource
from ..deps import (
    get_account_view,
    get_fleet_source,
    get_recommendation_service,
    get_spend_source,
    get_view_scope,
)
from ..identity import Scope
from ..models.serverless import ServerlessCase
from ..services import RecommendationService, serverless_case

router = APIRouter(prefix="/api", tags=["serverless"])


@router.get("/serverless-case", response_model=ServerlessCase)
def get_serverless_case(
    scope: Scope = Depends(get_view_scope),
    service: RecommendationService = Depends(get_recommendation_service),
    spend_source: SpendSource = Depends(get_spend_source),
    fleet_source: FleetSource = Depends(get_fleet_source),
    account_view=Depends(get_account_view),
) -> ServerlessCase:
    central = getattr(get_settings(), "central_mode", False)
    # `load` (not `fetch`) so hidden-but-computed rules still inform the case. Pass the
    # account view so central mode scopes the case to the SELECTED customer (precompute
    # folds it into the WHERE); without it the case pooled every account together.
    recs = service.source.load(scope, account_view)
    spend = spend_source.account_spend(scope, account_view)
    # Fleet context reads the compute/query timeline tables. Those live only in FULL
    # central (main.centralized_system_tables), not the billing slice, and are enormous
    # multi-account tables that reliably blow the fleet budget — so in central mode we
    # skip them and show the case without the (DBR spread / startup / autoscale) cards
    # rather than hang the page on scans that mostly time out.
    fleet: dict = {"lookback_days": spend.lookback_days or 30}
    if not central:
        fleet = fleet_source.fleet_facts(scope)
    return serverless_case.build_case(
        recs,
        spend=spend,
        fleet=fleet,
        lookback_days=fleet.get("lookback_days", 30),
    )
