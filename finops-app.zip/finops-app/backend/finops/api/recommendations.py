"""Recommendation list + detail endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from ..deps import (
    get_account_view,
    get_caller_email,
    get_recommendation_service,
    get_scope,
)
from ..data.account_view import AccountView
from ..identity import Scope
from ..models import (
    Recommendation,
    RecommendationGroup,
)
from ..services import RecommendationService

router = APIRouter(prefix="/api", tags=["recommendations"])


@router.get("/recommendations", response_model=list[Recommendation])
def list_recommendations(
    workspace_id: str | None = Query(None),
    rule_id: str | None = Query(None),
    resource_type: str | None = Query(None),
    priority: str | None = Query(None),
    min_savings: float | None = Query(None),
    sort: str = Query("nba", pattern="^(nba|savings)$"),
    scope: Scope = Depends(get_scope),
    service: RecommendationService = Depends(get_recommendation_service),
) -> list[Recommendation]:
    # The account / cloud / databricks_account_id filters are global: the frontend
    # appends them to every request and they are applied once at the source's fetch
    # boundary (see deps.get_recommendation_service), not per endpoint.
    return service.list(
        scope,
        workspace_id=workspace_id,
        rule_id=rule_id,
        resource_type=resource_type,
        priority=priority,
        min_savings=min_savings,
        sort=sort,
    )


@router.get("/recommendation-facets", response_model=dict[str, list[str]])
def recommendation_facets(
    scope: Scope = Depends(get_scope),
    service: RecommendationService = Depends(get_recommendation_service),
    account_view: AccountView = Depends(get_account_view),
) -> dict[str, list[str]]:
    """Distinct account/cloud/account_id values, to populate the UI filters. Dependent:
    the cloud and account-id lists narrow to the selected account (and account-id to the
    selected cloud), so the filters cascade. All lists are empty in single-account mode,
    so the frontend hides those controls."""
    return service.facets(scope, account_view)


@router.get("/recommendation-groups", response_model=list[RecommendationGroup])
def list_recommendation_groups(
    workspace_id: str | None = Query(None),
    resource_type: str | None = Query(None),
    priority: str | None = Query(None),
    min_savings: float | None = Query(None),
    rule_ids: str | None = Query(
        None,
        description="Comma-separated rule ids. ALL semantics: keep only resources "
        "where every listed recommendation type applies.",
    ),
    sort: str = Query("nba", pattern="^(nba|savings)$"),
    scope: Scope = Depends(get_scope),
    service: RecommendationService = Depends(get_recommendation_service),
) -> list[RecommendationGroup]:
    """Overview rollup: one row per resource, collapsing the several rules that
    may flag it into a single group whose savings is the max option (not the
    sum — options overlap). The detail view expands the options.

    The account / cloud / databricks_account_id filters are global (applied at the
    source's fetch boundary), so they are not endpoint params here."""
    rule_id_list = [r.strip() for r in rule_ids.split(",") if r.strip()] if rule_ids else None
    return service.list_grouped(
        scope,
        workspace_id=workspace_id,
        resource_type=resource_type,
        priority=priority,
        min_savings=min_savings,
        rule_ids=rule_id_list,
        sort=sort,
    )


@router.get("/recommendation-groups/{group_id}", response_model=RecommendationGroup)
def get_recommendation_group(
    group_id: str,
    scope: Scope = Depends(get_scope),
    email: str | None = Depends(get_caller_email),
    service: RecommendationService = Depends(get_recommendation_service),
) -> RecommendationGroup:
    """One resource's findings, within the caller's workspace scope.

    With the optional StopTheLeak integration on, it also opens for a finding's
    recipient without that scope (a My findings / email link) and then holds only
    the findings routed to them. The recipient comes from X-Forwarded-Email only;
    with the integration off ``email`` is always None and only scope counts."""
    group = service.get_group(scope, group_id)
    if group is None and email:
        group = service.get_group_for_recipient(email, group_id)
    if group is None:
        raise HTTPException(status_code=404, detail="Recommendation group not found")
    return group


@router.get("/recommendations/{recommendation_id}", response_model=Recommendation)
def get_recommendation(
    recommendation_id: str,
    scope: Scope = Depends(get_scope),
    email: str | None = Depends(get_caller_email),
    service: RecommendationService = Depends(get_recommendation_service),
) -> Recommendation:
    """A finding by recommendation_id or finding_key (always), in scope or, with the
    StopTheLeak integration on, routed to the caller."""
    rec = service.get(scope, recommendation_id)
    if rec is None and email:
        rec = service.find_for_recipient(email, recommendation_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    return rec
