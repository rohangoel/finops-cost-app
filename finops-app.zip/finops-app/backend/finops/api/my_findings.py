"""My findings, votes on findings and the weekly-email opt-out (GH #123, StopTheLeak).

Every endpoint here identifies the caller by :func:`deps.get_caller_email`
(``X-Forwarded-Email`` only). None of them accepts an email, a voter, a snapshot date
or a relation from the client: an extra ``?email=`` or body field is ignored, which
``test_my_findings.py`` checks.

Optional: the whole router answers 404 unless ``FINOPS_STOPTHELEAK_ENABLED`` is on.
With it on, My findings works for every signed-in user, admin or not, and needs no
workspace scope: a finding is yours when its ``notify_recipient`` is your email (see
``finops.routing``). Votes and the opt-out additionally need
``FINOPS_FEEDBACK_ENABLED`` (and the Lakebase store); without it they answer 404.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel

from ..data.feedback_store import FeedbackConflict, FeedbackStore
from ..deps import (
    get_caller_email,
    get_feedback_store,
    get_recommendation_service,
    get_scope,
    require_stoptheleak,
)
from ..identity import Scope
from ..models import Recommendation
from ..models.feedback import EmailPreference, Vote, VoteRequest
from ..services import RecommendationService

router = APIRouter(
    prefix="/api", tags=["my-findings"], dependencies=[Depends(require_stoptheleak)]
)


class MyFindings(BaseModel):
    # None when the request carries no X-Forwarded-Email (then findings is empty).
    email: str | None
    feedback_enabled: bool
    # Routed to this email, biggest saving first. recipient_source says why each one
    # is theirs (object_owner vs workspace_owner); the UI groups on it.
    findings: list[Recommendation]


def _require_email(email: str | None) -> str:
    if not email:
        raise HTTPException(
            status_code=401, detail="Could not tell who you are (no X-Forwarded-Email)."
        )
    return email


def _require_store(store: FeedbackStore | None) -> FeedbackStore:
    if store is None:
        raise HTTPException(status_code=404, detail="Feedback is not enabled on this app.")
    return store


@router.get("/my-findings", response_model=MyFindings)
def my_findings(
    email: str | None = Depends(get_caller_email),
    service: RecommendationService = Depends(get_recommendation_service),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> MyFindings:
    return MyFindings(
        email=email,
        feedback_enabled=store is not None,
        findings=service.for_recipient(email) if email else [],
    )


@router.get("/feedback/mine", response_model=dict[str, Vote])
def my_votes(
    email: str | None = Depends(get_caller_email),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> dict[str, Vote]:
    """``finding_key -> your latest vote``. Empty when feedback is off, so pages can
    call it unconditionally."""
    if store is None or not email:
        return {}
    return store.latest_votes(email)


@router.post("/feedback", response_model=Vote, status_code=201)
def cast_vote(
    body: VoteRequest,
    email: str | None = Depends(get_caller_email),
    scope: Scope = Depends(get_scope),
    service: RecommendationService = Depends(get_recommendation_service),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> Vote:
    """Record one vote by the signed-in user on one of THEIR findings.

    Only the finding's recipient can vote. Anyone else gets 403 when their workspace
    scope lets them see the finding, and 404 otherwise, so the response never tells
    a user that a finding they can't see exists. The voter, observation date, rule
    and relation all come from the server.
    """
    store = _require_store(store)
    me = _require_email(email)
    rec = service.find_for_recipient(me, body.finding_key)
    if rec is None:
        if service.get(scope, body.finding_key) is not None:
            raise HTTPException(
                status_code=403,
                detail="Only the person this finding is routed to can vote on it.",
            )
        raise HTTPException(status_code=404, detail="Finding not found")
    try:
        return store.record_vote(
            idempotency_key=body.idempotency_key,
            finding_key=rec.finding_key,
            observation_date=rec.snapshot_date,
            rule_id=rec.rule_id,
            voter_email=me,
            # Only recipients get here, so the relation is how the finding reached
            # them. 'other' (a non-recipient vote) is never written by the app.
            voter_relation=rec.recipient_source,
            channel=body.channel,
            verdict=body.verdict,
            reason_codes=body.reason_codes,
            savings_assessment=body.savings_assessment,
            free_text=body.free_text,
            snooze_days=body.snooze_days,
        )
    except FeedbackConflict as exc:
        raise HTTPException(status_code=409, detail="That request id was already used.") from exc


@router.get("/email-preference", response_model=EmailPreference)
def get_email_preference(
    email: str | None = Depends(get_caller_email),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> EmailPreference:
    store = _require_store(store)
    me = _require_email(email)
    return EmailPreference(email=me, weekly_email=not store.is_opted_out(me))


@router.delete("/email-preference/weekly-email", status_code=204)
def stop_weekly_email(
    email: str | None = Depends(get_caller_email),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> Response:
    """Opt out of the StopTheLeak weekly email (a row in ops.opt_outs)."""
    store = _require_store(store)
    store.opt_out(_require_email(email))
    return Response(status_code=204)


@router.put("/email-preference/weekly-email", status_code=204)
def resume_weekly_email(
    email: str | None = Depends(get_caller_email),
    store: FeedbackStore | None = Depends(get_feedback_store),
) -> Response:
    """Undo the opt-out."""
    store = _require_store(store)
    store.opt_in(_require_email(email))
    return Response(status_code=204)
