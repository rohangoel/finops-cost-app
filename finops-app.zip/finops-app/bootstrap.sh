#!/usr/bin/env bash
# bootstrap.sh — one command for a teammate to get, set up, and start the FinOps
# app locally against Central Logfood. Safe to re-run: it clones/pulls the repo,
# skips whatever setup is already done, and then starts the app. After the first
# run it doubles as your everyday launcher (it pulls latest each time).
#
# Two ways to run it:
#   * Standalone — save just this file anywhere and run it. It clones the repo
#     (into $HOME/dsa-emea-ce, or $REPO_DIR) and hands off to the repo's copy.
#   * In-repo — run ./bootstrap.sh from accelerators/apps/finops-app; it pulls
#     latest, then sets up and starts.
#
# Usage:
#   ./bootstrap.sh                 # clone/pull, set up what's missing, start on :8000
#   PORT=8010 ./bootstrap.sh       # start on a custom port
#   REPO_DIR=~/src ./bootstrap.sh  # where to clone the repo (standalone run)
#   WAREHOUSE_ID=<id> ./bootstrap.sh   # use your own logfood SQL warehouse
#   PYTHON=/opt/homebrew/bin/python3.13 ./bootstrap.sh  # force which python builds the venv
#   ./bootstrap.sh --rebuild       # force-rebuild the frontend SPA
#   ./bootstrap.sh --reinstall     # recreate the Python venv from scratch
#   ./bootstrap.sh --no-pull       # don't touch git (use the checkout as-is)
#   ./bootstrap.sh --setup-only    # do everything except start the server
#
# Prerequisites it checks (and tells you how to get): git + GitHub access (an
# SSH key SSO-authorized for the org, or the gh CLI), Databricks CLI, Python
# 3.10+, and only when the SPA needs building, Node 20+. It auto-selects a Python
# >=3.10 for the venv and refuses macOS system Python 3.9 (too old for the deps,
# and its OpenSSL fails the internal pypi proxy TLS handshake). It will NOT
# install system packages for you, and it can't grant you the data access: you
# need the Opal grants for main.centralized_system_tables + main.certified
# (go/opal/tile).

set -euo pipefail

REPO_URL="git@github.com:databricks-field-eng/dsa-emea-ce.git"
APP_SUBPATH="accelerators/apps/finops-app"
REPO_DIR="${REPO_DIR:-$HOME/dsa-emea-ce}"
LOGFOOD_HOST="https://adb-2548836972759138.18.azuredatabricks.net"
PROFILE="logfood"
VENV=".venv"
PY="$VENV/bin/python"
WAREHOUSE_ID="${WAREHOUSE_ID:-9fb2ea023126d1f4}"   # shared, usually-uncontended
MIN_PY_MINOR=10                                    # pyproject requires-python >=3.10
PYTHON="${PYTHON:-}"                               # override the interpreter for the venv
REBUILD=0; REINSTALL=0; SETUP_ONLY=0; NO_PULL=0; ALREADY_PULLED=0

for a in "$@"; do case "$a" in
  --rebuild)    REBUILD=1 ;;
  --reinstall)  REINSTALL=1 ;;
  --setup-only) SETUP_ONLY=1 ;;
  --no-pull)    NO_PULL=1 ;;
  --_pulled)    ALREADY_PULLED=1 ;;   # internal: set after a self-updating pull
  -h|--help)    awk 'NR==1{next} /^#/{sub(/^# ?/,"");print;next} {exit}' "$0"; exit 0 ;;
  *) echo "unknown argument: $a  (try --help)"; exit 2 ;;
esac; done

say(){ printf '\n\033[1;36m▶ %s\033[0m\n' "$*"; }
die(){ printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }
warn(){ printf '\n\033[1;33m! %s\033[0m\n' "$*" >&2; }

# Pick a Python >=3.$MIN_PY_MINOR for the venv, preferring the newest. macOS system
# python3 is 3.9: below requires-python AND carrying an OpenSSL too old for the
# internal pypi proxy TLS handshake, so we skip it for a newer interpreter
# (Homebrew / pyenv / python.org). Honors an explicit PYTHON=... override first.
pick_python(){
  local c
  for c in "$PYTHON" python3.13 python3.12 python3.11 python3.10 python3 python; do
    { [ -n "$c" ] && command -v "$c" >/dev/null 2>&1; } || continue
    if "$c" -c 'import sys; sys.exit(0 if sys.version_info[:2] >= (3, '"$MIN_PY_MINOR"') else 1)' 2>/dev/null; then
      command -v "$c"; return 0
    fi
  done
  return 1
}

# A DATABRICKS_TOKEN inherited from your shell (e.g. a leftover PAT for another
# workspace) silently overrides the OAuth profile this preview uses, so the wrong
# credential reaches the logfood warehouse -> "Could not load the account list" (500).
# Drop it now so the databricks CLI and the launched app both use the '$PROFILE'
# profile. A token set explicitly in .env is still honored (start.sh sources .env
# after its own guard). Set FINOPS_KEEP_TOKEN=1 to keep an inherited token.
if [ -n "${DATABRICKS_TOKEN:-}" ] && [ "${FINOPS_KEEP_TOKEN:-0}" != 1 ]; then
  warn "Ignoring an inherited DATABRICKS_TOKEN (it would override the '$PROFILE' OAuth profile). Set FINOPS_KEEP_TOKEN=1 to keep it."
  unset DATABRICKS_TOKEN
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# 0. Locate the repo — or clone it (standalone run) --------------------------
if [ -f "$SCRIPT_DIR/start.sh" ] && [ -d "$SCRIPT_DIR/backend/finops" ]; then
  APP_DIR="$SCRIPT_DIR"                       # we're inside the app already
else
  say "Fetching the repo (standalone run)"
  command -v git >/dev/null || die "git not found."
  if [ -d "$REPO_DIR/.git" ]; then
    echo "  repo already at $REPO_DIR — reusing it"
  else
    echo "  cloning into $REPO_DIR …"
    # GIT_TERMINAL_PROMPT=0 makes a failed clone fail fast instead of hanging on a
    # username/password prompt. The org enforces SAML SSO, so HTTPS password auth
    # is not supported; the working paths are an SSO-authorized SSH key or the gh CLI.
    if GIT_TERMINAL_PROMPT=0 git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null; then
      :
    elif command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
      echo "  SSH clone failed; using the authenticated gh CLI instead…"
      gh repo clone databricks-field-eng/dsa-emea-ce "$REPO_DIR" \
        || die "gh clone failed. Run 'gh auth login' and SSO-authorize for databricks-field-eng, then re-run."
    else
      die "clone failed. The org enforces SAML SSO (HTTPS username/password is not supported). Use one of:
       1) SSH: add your key to GitHub, click 'Configure SSO' to authorize it for
          databricks-field-eng, verify with 'ssh -T git@github.com', then re-run; or
       2) GitHub CLI: 'brew install gh && gh auth login', then re-run."
    fi
  fi
  APP_DIR="$REPO_DIR/$APP_SUBPATH"
  [ -f "$APP_DIR/bootstrap.sh" ] || die "no bootstrap.sh under $APP_DIR after clone."
  exec "$APP_DIR/bootstrap.sh" "$@"   # hand off to the repo's own copy
fi

cd "$APP_DIR"

# 0b. Pull latest, then re-exec the updated script (in-repo run) -------------
if [ "$NO_PULL" = 0 ] && [ "$ALREADY_PULLED" = 0 ] && git rev-parse --git-dir >/dev/null 2>&1; then
  say "Updating repo"
  branch="$(git rev-parse --abbrev-ref HEAD)"
  if git diff --quiet && git diff --cached --quiet; then
    before="$(git rev-parse HEAD)"
    if git pull --ff-only 2>/dev/null; then
      if [ "$before" != "$(git rev-parse HEAD)" ]; then
        echo "  updated $branch — re-running the new bootstrap.sh"
        exec "$APP_DIR/bootstrap.sh" --_pulled "$@"
      fi
      echo "  already up to date ($branch)"
    else
      echo "  couldn't fast-forward $branch (no upstream or diverged) — continuing as-is"
    fi
  else
    echo "  local uncommitted changes — skipping pull"
  fi
fi

# 1. Prerequisites -----------------------------------------------------------
say "Checking prerequisites"
command -v databricks >/dev/null \
  || die "Databricks CLI not found. Install it: brew tap databricks/tap && brew install databricks"
command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1 \
  || die "No Python found. Install Python 3.$MIN_PY_MINOR+ (macOS: brew install python@3.13)."
echo "  databricks $(databricks version 2>/dev/null | head -1)"

# 2. Auth to Central Logfood (OAuth; opens a browser the first time) ---------
say "Databricks auth (profile: $PROFILE)"
if databricks current-user me -p "$PROFILE" >/dev/null 2>&1; then
  echo "  authenticated OK"
else
  echo "  not authenticated — launching OAuth login (a browser window will open)…"
  databricks auth login --host "$LOGFOOD_HOST" --profile "$PROFILE" \
    || die "auth login failed. Run manually: databricks auth login --host $LOGFOOD_HOST --profile $PROFILE"
fi
echo "  NOTE: this validates login, not data access. If pages 403, request the Opal grants"
echo "        for main.centralized_system_tables + main.certified at go/opal/tile."

# 3. Python venv + backend deps ----------------------------------------------
say "Python environment"
if [ "$REINSTALL" = 1 ] && [ -d "$VENV" ]; then echo "  --reinstall: removing $VENV"; rm -rf "$VENV"; fi
if [ ! -x "$PY" ]; then
  pybin="$(pick_python)" \
    || die "No Python >=3.$MIN_PY_MINOR found. macOS system Python 3.9 is too old for the deps and its OpenSSL fails the internal pypi proxy. Install a newer one (macOS: brew install python@3.13; or use pyenv), then re-run. Or set PYTHON=/path/to/python3.x."
  echo "  using $("$pybin" --version 2>&1) at $pybin"
  echo "  creating venv + installing backend/dev deps (first run, ~1-2 min)…"
  "$pybin" -m venv "$VENV"
  "$PY" -m pip install -q --upgrade pip \
    || die "pip could not reach the package index. Installs are routed through pypi-proxy.cloud.databricks.com (pypi.org is pinned to localhost by policy); a pre-3.$MIN_PY_MINOR Python's OpenSSL fails its TLS handshake. Rebuild the venv with Python >=3.$MIN_PY_MINOR: ./bootstrap.sh --reinstall."
  "$PY" -m pip install -q -e ".[dev]"
else
  cur="$("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo '0.0')"
  if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info[:2] >= (3, '"$MIN_PY_MINOR"') else 1)' 2>/dev/null; then
    die "Existing $VENV was built with Python $cur, below the required 3.$MIN_PY_MINOR (this is what breaks 'pip install -e' and the pypi-proxy TLS handshake). Rebuild it after installing Python >=3.$MIN_PY_MINOR: ./bootstrap.sh --reinstall."
  fi
  echo "  venv present (Python $cur) — skipping (use --reinstall to rebuild it)"
fi
# pyarrow: native result types + faster fetch. Recommended; install if absent.
if ! "$PY" -c "import pyarrow" >/dev/null 2>&1; then
  echo "  installing pyarrow (recommended for speed)…"; "$PY" -m pip install -q pyarrow
fi

# 4. Frontend SPA (the backend serves the pre-built bundle; not committed) ----
say "Frontend SPA"
if [ "$REBUILD" = 1 ] || [ ! -f backend/finops/static/index.html ]; then
  command -v npm >/dev/null || die "Node/npm not found — need Node 20+ to build the SPA. Install Node, then re-run."
  echo "  building (npm install + vite build)…"
  ( cd frontend && npm install --silent && npm run build )
else
  echo "  bundle present — skipping (use --rebuild to refresh after frontend changes)"
fi

# 5. Config (.env) — created once; never clobbered --------------------------
say "Config (.env)"
if [ -f .env ]; then
  echo "  .env present — keeping it (delete it to regenerate)"
else
  echo "  writing .env for Central Logfood (warehouse $WAREHOUSE_ID)…"
  cat > .env <<EOF
# Local Central-Logfood preview. Auth comes from the '$PROFILE' OAuth profile
# (no token stored here). Reads the shared, pre-built central tables — no
# pipeline/slice run needed on your machine.
FINOPS_COMPUTE_MODE=precompute
FINOPS_AUTH_MODE=obo
DATABRICKS_SERVER_HOSTNAME=adb-2548836972759138.18.azuredatabricks.net
DATABRICKS_WAREHOUSE_ID=/sql/1.0/warehouses/$WAREHOUSE_ID
DATABRICKS_CONFIG_PROFILE=$PROFILE
FINOPS_CENTRAL_MODE=true
FINOPS_TABLE=main.team_field_dsa_ce.finops_central_recommendations
FINOPS_CENTRAL_NAMESPACE=main.team_field_dsa_ce
FINOPS_DEV_ROLE=platform_admin
FINOPS_NO_AUDIT=true
FINOPS_PRECOMPUTE_CACHE_TTL=43200
FINOPS_SPEND_CACHE_TTL=43200
FINOPS_APPS_CACHE_TTL=43200
FINOPS_GENIE_CACHE_TTL=43200
LOG_LEVEL=INFO
EOF
fi

# 6. Start -------------------------------------------------------------------
if [ "$SETUP_ONLY" = 1 ]; then
  say "Setup complete"
  echo "  Start it any time with:  ./start.sh   (or  PORT=8010 ./start.sh )"
  exit 0
fi
say "Starting the app"
exec ./start.sh
