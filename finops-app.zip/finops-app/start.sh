#!/usr/bin/env bash
# Launch the FinOps app locally against the Central Logfood mirror.
#
# Why this exists: FINOPS_LIVE_CACHE_TTL is read at module-import time, before
# the app loads .env. Starting uvicorn plainly therefore leaves the live-result
# cache OFF, and every recommendations/account-overview request recomputes all
# rules from scratch (minutes each). Exporting .env into the environment BEFORE
# launch fixes that. Run this instead of calling uvicorn directly.
#
# Usage:  ./start.sh            # http://127.0.0.1:8000
#         PORT=8001 ./start.sh  # override port
set -euo pipefail

cd "$(dirname "$0")"

PORT="${PORT:-8000}"
PY="./.venv/bin/python"
[ -x "$PY" ] || { echo "No venv at $PY — create it or point PY at a Python with the app deps."; exit 1; }
[ -f .env ] || { echo "No .env in $(pwd) — needed for catalog/warehouse/cache config."; exit 1; }

# A DATABRICKS_TOKEN inherited from your shell (e.g. a leftover PAT for another
# workspace) overrides the OAuth profile in .env, so the wrong credential reaches
# the warehouse -> "Could not load the account list" (500). Drop the inherited one
# before loading .env; a token set explicitly in .env is still honored. Set
# FINOPS_KEEP_TOKEN=1 to keep an inherited token.
if [ -n "${DATABRICKS_TOKEN:-}" ] && [ "${FINOPS_KEEP_TOKEN:-0}" != 1 ]; then
  echo "Ignoring an inherited DATABRICKS_TOKEN (would override the .env OAuth profile; set FINOPS_KEEP_TOKEN=1 to keep it)."
  unset DATABRICKS_TOKEN
fi

# Export .env into the environment so module-level reads (FINOPS_LIVE_CACHE_TTL) see it.
set -a; . ./.env; set +a

# Free the port if a stale instance is bound.
if lsof -ti:"$PORT" >/dev/null 2>&1; then
  echo "Port $PORT in use; stopping the existing instance."
  lsof -ti:"$PORT" | xargs kill -9 2>/dev/null || true
  sleep 1
fi

echo "Starting FinOps app on http://127.0.0.1:$PORT"
echo "  catalog=${FINOPS_CATALOG:-system}  cache_ttl=${FINOPS_LIVE_CACHE_TTL:-0}s  no_audit=${FINOPS_NO_AUDIT:-false}"
echo "  First page load recomputes live (can take minutes on big accounts); cached after that."
exec env PYTHONPATH=rules:backend "$PY" -m uvicorn finops.main:app --host 127.0.0.1 --port "$PORT"
